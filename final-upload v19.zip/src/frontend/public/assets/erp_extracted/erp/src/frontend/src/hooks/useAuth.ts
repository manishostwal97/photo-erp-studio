// ── Local auth stubs ─────────────────────────────────────────────────────────
// All auth operations run locally (no Firebase SDK calls).
// Replace stubs with real Firebase calls when connecting Firebase.
import { type UserRole, useAuthStore } from "@/stores/authStore";
import { useEffect, useRef } from "react";
import { toast } from "sonner";

// Re-export for legacy imports
export { useAuthStore };

// ── Local OTP session ─────────────────────────────────────────────────────────
// Tracks the phone number that requested an OTP so verifyOTP can use it.
const LOCAL_OTP_CODE = "123456";

// ── Hook ─────────────────────────────────────────────────────────────────────

export function useAuth() {
  const {
    clearAuth,
    setError,
    setUser,
    setUserRole,
    setLoading,
    setInitialized,
  } = useAuthStore();
  // Keep a ref to the phone number used during OTP flow
  const otpPhoneRef = useRef<string | null>(null);

  // Wire logout into the store so Sidebar can call store.logout()
  useEffect(() => {
    useAuthStore.setState({
      logout: async () => {
        clearAuth();
        toast.success("Logged out.");
      },
    });
  }, [clearAuth]);

  // ── Email sign-in ──────────────────────────────────────────────────────────
  async function signInWithEmail(email: string, password: string) {
    if (!email.trim() || !password.trim()) {
      const msg = "Email and password are required.";
      setError(msg);
      toast.error(msg);
      return false;
    }
    const ADMIN_EMAIL = "admin@studio.com";
    const ADMIN_PASSWORD = "Admin@123";
    if (email.trim() !== ADMIN_EMAIL || password !== ADMIN_PASSWORD) {
      const msg = "Invalid credentials. Please check your email and password.";
      setError(msg);
      toast.error(msg);
      return false;
    }
    setLoading(true);
    setUser({
      uid: "local-admin-1",
      email: ADMIN_EMAIL,
      displayName: "Studio Admin",
      photoURL: null,
    });
    setUserRole("admin");
    setLoading(false);
    setInitialized(true);
    toast.success("Welcome back, Studio Admin!");
    return true;
  }

  // ── Email sign-up ──────────────────────────────────────────────────────────
  async function signUpWithEmail(
    email: string,
    password: string,
    displayName: string,
    role: UserRole,
  ) {
    if (!email.trim() || !password.trim() || !displayName.trim()) {
      const msg = "All fields are required.";
      setError(msg);
      toast.error(msg);
      return false;
    }
    setLoading(true);
    setUser({ uid: "local-uid-1", email, displayName, photoURL: null });
    setUserRole(role);
    setLoading(false);
    setInitialized(true);
    toast.success("Account created locally.");
    return true;
  }

  // ── Google sign-in ─────────────────────────────────────────────────────────
  async function signInWithGoogle() {
    setLoading(true);
    setUser({
      uid: "local-uid-google",
      email: "google@local.dev",
      displayName: "Google User",
      photoURL: null,
    });
    setUserRole("admin");
    setLoading(false);
    setInitialized(true);
    toast.success("Google sign-in simulated.");
    return true;
  }

  // ── Phone OTP ──────────────────────────────────────────────────────────────
  async function sendOTP(phoneNumber: string): Promise<boolean> {
    if (!phoneNumber.trim()) {
      const msg = "Phone number is required.";
      setError(msg);
      toast.error(msg);
      return false;
    }
    otpPhoneRef.current = phoneNumber;
    toast.success(`OTP sent (local: use ${LOCAL_OTP_CODE}).`);
    return true;
  }

  // ── Verify OTP ─────────────────────────────────────────────────────────────
  async function verifyOTP(otp: string): Promise<boolean> {
    if (otp !== LOCAL_OTP_CODE) {
      const msg = `Invalid OTP. Use ${LOCAL_OTP_CODE}.`;
      setError(msg);
      toast.error(msg);
      return false;
    }
    const phone = otpPhoneRef.current ?? "unknown";
    setLoading(true);
    setUser({
      uid: "local-uid-phone",
      email: null,
      displayName: "Phone User",
      photoURL: null,
    });
    setUserRole("staff");
    setLoading(false);
    setInitialized(true);
    // Store phone in displayName slot for reference
    useAuthStore.setState((s) => ({
      user: s.user
        ? { ...s.user, displayName: `Phone User (${phone})` }
        : s.user,
    }));
    toast.success("OTP verified.");
    return true;
  }

  // ── Password reset ─────────────────────────────────────────────────────────
  async function sendPasswordReset(email: string): Promise<boolean> {
    if (!email.trim()) {
      const msg = "Email is required.";
      setError(msg);
      toast.error(msg);
      return false;
    }
    toast.success("Password reset email sent (simulated).");
    return true;
  }

  // ── Logout ─────────────────────────────────────────────────────────────────
  async function logout() {
    clearAuth();
    toast.success("Logged out.");
  }

  return {
    signInWithEmail,
    signUpWithEmail,
    signInWithGoogle,
    sendOTP,
    verifyOTP,
    sendPasswordReset,
    logout,
  };
}
