/**
 * useInitData — simplified hook for localStorage-based ERP.
 *
 * Previously wired to ICP actor and useInternetIdentity.
 * Data now lives in Zustand stores (useERPStore, useStudioStore),
 * which hydrate automatically from localStorage via persist middleware.
 *
 * This hook is kept as a no-op so existing call sites don't break.
 */
export function useInitData() {
  return { isLoading: false, isError: false };
}
