import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { getInitials } from "@/lib/utils";
import { useAuthStore } from "@/stores/authStore";
import { useStudioStore } from "@/stores/useStudioStore";
import { useQueryClient } from "@tanstack/react-query";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  Calendar,
  Camera,
  DollarSign,
  FileText,
  LayoutDashboard,
  LogOut,
  MapPin,
  Settings,
  Truck,
  UserCheck,
  Users,
  Wrench,
} from "lucide-react";

const navItems = [
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { path: "/invoices", label: "Invoices", icon: FileText },
  { path: "/clients", label: "Clients", icon: Users },
  { path: "/team", label: "Team", icon: UserCheck },
  { path: "/services", label: "Services", icon: Wrench },
  { path: "/expenses", label: "Expenses", icon: DollarSign },
  { path: "/equipment-rental", label: "Equipment Rental", icon: Camera },
  { path: "/calendar", label: "Calendar", icon: Calendar },
  { path: "/delivery", label: "Delivery Tracker", icon: Truck },
  { path: "/reports", label: "Reports", icon: BarChart3 },
  { path: "/settings", label: "Settings", icon: Settings },
];

interface SidebarProps {
  onClose?: () => void;
}

export default function Sidebar({ onClose }: SidebarProps) {
  const { location } = useRouterState();
  const studioProfile = useStudioStore((s) => s.studioProfile);
  const logout = useAuthStore((s) => s.logout);
  const queryClient = useQueryClient();

  const handleLogout = () => {
    logout();
    queryClient.clear();
  };

  return (
    <aside className="flex flex-col h-full bg-sidebar text-sidebar-foreground">
      {/* Studio header */}
      <div className="px-4 pt-5 pb-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3 mb-3">
          <div className="relative">
            <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center shadow-red overflow-hidden flex-shrink-0">
              {studioProfile?.logo ? (
                <img
                  src={studioProfile.logo}
                  alt={studioProfile.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-primary-foreground text-xl font-bold">
                  📷
                </span>
              )}
            </div>
          </div>
          <div className="min-w-0">
            <h1 className="font-display font-bold text-sm leading-tight truncate text-sidebar-foreground">
              {studioProfile?.name || "Photography Studio"}
            </h1>
            <p className="text-xs text-sidebar-foreground/60 truncate">
              {studioProfile?.ownerName || "Studio Manager"}
            </p>
          </div>
        </div>
        {studioProfile?.address && (
          <div className="flex items-start gap-1.5 mt-1">
            <MapPin className="w-3 h-3 text-sidebar-foreground/40 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-sidebar-foreground/40 line-clamp-2 leading-relaxed">
              {studioProfile.address}
            </p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
        {navItems.map(({ path, label, icon: Icon }) => {
          const isActive =
            location.pathname === path ||
            (path !== "/dashboard" && location.pathname.startsWith(path));
          return (
            <Link
              key={path}
              to={path}
              onClick={onClose}
              data-ocid={`nav.${label.toLowerCase().replace(/\s+/g, "-")}.link`}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                isActive
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground",
              )}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              <span>{label}</span>
              {isActive && (
                <span className="ml-auto text-xs bg-primary-foreground/20 text-primary-foreground px-1.5 py-0.5 rounded-full">
                  Active
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="px-3 py-4 border-t border-sidebar-border">
        <button
          type="button"
          onClick={handleLogout}
          data-ocid="nav.logout.button"
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-sidebar-foreground/70 hover:bg-destructive/10 hover:text-destructive transition-all duration-200"
        >
          <LogOut className="w-4 h-4 flex-shrink-0" />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
}
