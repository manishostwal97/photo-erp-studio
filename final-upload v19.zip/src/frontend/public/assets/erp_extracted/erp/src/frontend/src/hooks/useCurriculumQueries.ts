import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  initSeedData,
  curriculumState as store,
  syncCurriculumToStorage,
} from "../data/curriculumStore";
import type {
  Assessment,
  Assignment,
  AssignmentType,
  Course,
  CurriculumFramework,
  Difficulty,
  FrameworkFields,
  Lesson,
  Module,
  Rubric,
  ScoringModel,
  Unit,
} from "../lib/curriculumTypes";

// Re-export types for barrel
export type {
  Course,
  Unit,
  Lesson,
  Module,
  Assignment,
  Assessment,
  AssignmentType,
  CurriculumFramework,
  FrameworkFields,
  Rubric,
  Difficulty,
  ScoringModel,
};

export function useGetCourses() {
  initSeedData();
  return useQuery<Course[]>({
    queryKey: ["courses"],
    queryFn: async () => [...store.courseStore],
    staleTime: Number.POSITIVE_INFINITY,
  });
}

// Aliases
export const useCourses = useGetCourses;

export function useCreateCourse() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      title: string;
      subject: string;
      gradeLevel?: string;
      gradeBand?: string;
      description: string;
      framework?: CurriculumFramework;
    }): Promise<Course> => {
      const course: Course = {
        id: store.nextCourseId++,
        title: params.title,
        subject: params.subject,
        gradeBand: params.gradeBand ?? params.gradeLevel ?? "9-12",
        gradeLevel: params.gradeLevel,
        description: params.description,
        framework: params.framework ?? "ims",
        frameworkFields: {},
        standards: [],
        tags: [],
        draftStatus: "draft",
        version: 1,
        versionHistory: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      store.courseStore = [...store.courseStore, course];
      return course;
    },
    onSuccess: () => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({ queryKey: ["courses"] });
    },
  });
}

export function useUpdateCourse() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      id: number;
      title?: string;
      description?: string;
      subject?: string;
      gradeLevel?: string;
      gradeBand?: string;
      framework?: CurriculumFramework;
      frameworkFields?: FrameworkFields;
      standards?: string[];
      tags?: string[];
      draftStatus?: "draft" | "published";
    }): Promise<Course> => {
      store.courseStore = store.courseStore.map((c) =>
        c.id === params.id ? { ...c, ...params, updatedAt: Date.now() } : c,
      );
      return store.courseStore.find((c) => c.id === params.id)!;
    },
    onSuccess: () => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({ queryKey: ["courses"] });
    },
  });
}

export function usePublishCourse() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (courseId: number): Promise<Course> => {
      store.courseStore = store.courseStore.map((c) => {
        if (c.id !== courseId) return c;
        const newVersion = c.version + 1;
        return {
          ...c,
          draftStatus: "published",
          version: newVersion,
          versionHistory: [
            ...c.versionHistory,
            {
              version: newVersion,
              savedAt: Date.now(),
              snapshot: JSON.stringify(c),
            },
          ],
          updatedAt: Date.now(),
        };
      });
      return store.courseStore.find((c) => c.id === courseId)!;
    },
    onSuccess: () => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({ queryKey: ["courses"] });
      toast.success("Course published successfully");
    },
  });
}

export function useDeleteCourse() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (courseId: number): Promise<void> => {
      store.courseStore = store.courseStore.filter((c) => c.id !== courseId);
      const removedUnitIds = store.unitStore
        .filter((u) => u.courseId === courseId)
        .map((u) => u.id);
      store.unitStore = store.unitStore.filter((u) => u.courseId !== courseId);
      const removedModuleIds = store.moduleStore
        .filter((m) => !removedUnitIds.includes(m.unitId))
        .map((m) => m.id);
      store.moduleStore = store.moduleStore.filter(
        (m) => !removedUnitIds.includes(m.unitId),
      );
      store._lessonStore = store.moduleStore;
      store.assignmentStore = store.assignmentStore.filter(
        (a) => !removedModuleIds.includes(a.moduleId ?? a.lessonId ?? 0),
      );
      store.assessmentStore = store.assessmentStore.filter(
        (a) => a.courseId !== courseId,
      );
    },
    onSuccess: () => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({ queryKey: ["courses"] });
      queryClient.invalidateQueries({ queryKey: ["units"] });
      queryClient.invalidateQueries({ queryKey: ["modules"] });
      queryClient.invalidateQueries({ queryKey: ["lessons"] });
    },
  });
}

export function useGetUnits(courseId?: number) {
  initSeedData();
  return useQuery<Unit[]>({
    queryKey: ["units", courseId],
    queryFn: async () =>
      store.unitStore
        .filter((u) => courseId === undefined || u.courseId === courseId)
        .sort((a, b) => a.order - b.order),
    staleTime: Number.POSITIVE_INFINITY,
  });
}

// Alias
export const useUnits = useGetUnits;

export function useCreateUnit() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      courseId: number;
      title: string;
      description: string;
      order?: number;
      essentialQuestion?: string;
      durationValue?: number;
      durationUnit?: "days" | "weeks";
    }): Promise<Unit> => {
      const unit: Unit = {
        id: store.nextUnitId++,
        courseId: params.courseId,
        title: params.title,
        description: params.description,
        essentialQuestion: params.essentialQuestion ?? "",
        durationValue: params.durationValue ?? 1,
        durationUnit: params.durationUnit ?? "weeks",
        standards: [],
        tags: [],
        frameworkFields: {},
        order:
          params.order ??
          store.unitStore.filter((u) => u.courseId === params.courseId).length +
            1,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      store.unitStore = [...store.unitStore, unit];
      return unit;
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["units", variables.courseId],
      });
      queryClient.invalidateQueries({ queryKey: ["courses"] });
    },
  });
}

export function useUpdateUnit() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      id?: number;
      unitId?: number;
      courseId: number;
      title?: string;
      description?: string;
      order?: number;
      essentialQuestion?: string;
      durationValue?: number;
      durationUnit?: "days" | "weeks";
      standards?: string[];
      tags?: string[];
      frameworkFields?: FrameworkFields;
      domain?: string;
    }): Promise<Unit> => {
      const id = params.unitId ?? params.id!;
      store.unitStore = store.unitStore.map((u) =>
        u.id === id ? { ...u, ...params, id, updatedAt: Date.now() } : u,
      );
      return store.unitStore.find((u) => u.id === id)!;
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["units", variables.courseId],
      });
    },
  });
}

export function useDeleteUnit() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      unitId: number;
      courseId: number;
    }): Promise<void> => {
      store.unitStore = store.unitStore.filter((u) => u.id !== params.unitId);
      const removedModuleIds = store.moduleStore
        .filter((m) => m.unitId === params.unitId)
        .map((m) => m.id);
      store.moduleStore = store.moduleStore.filter(
        (m) => m.unitId !== params.unitId,
      );
      store._lessonStore = store.moduleStore;
      store.assignmentStore = store.assignmentStore.filter(
        (a) => !removedModuleIds.includes(a.moduleId ?? a.lessonId ?? 0),
      );
      store.assessmentStore = store.assessmentStore.filter(
        (a) => !removedModuleIds.includes(a.moduleId),
      );
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["units", variables.courseId],
      });
      queryClient.invalidateQueries({ queryKey: ["modules"] });
      queryClient.invalidateQueries({ queryKey: ["lessons"] });
    },
  });
}

export function useGetLessons(unitId?: number) {
  initSeedData();
  return useQuery<Module[]>({
    queryKey: ["lessons", unitId],
    queryFn: async () =>
      store.moduleStore
        .filter((m) => unitId === undefined || m.unitId === unitId)
        .sort((a, b) => a.order - b.order),
    staleTime: Number.POSITIVE_INFINITY,
  });
}

export function useGetModules(unitId?: number) {
  initSeedData();
  return useQuery<Module[]>({
    queryKey: ["modules", unitId],
    queryFn: async () =>
      store.moduleStore
        .filter((m) => unitId === undefined || m.unitId === unitId)
        .sort((a, b) => a.order - b.order),
    staleTime: Number.POSITIVE_INFINITY,
  });
}

// Alias
export const useLessons = useGetLessons;

export function useCreateLesson() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      unitId: number;
      courseId?: number;
      title: string;
      description: string;
      order?: number;
      standards?: string[];
      duration?: number;
    }): Promise<Module> => {
      const mod: Module = {
        id: store.nextModuleId++,
        unitId: params.unitId,
        courseId: params.courseId ?? 0,
        title: params.title,
        description: params.description,
        learningObjectives: [],
        vocabulary: [],
        standards: params.standards ?? [],
        tags: [],
        frameworkFields: {},
        order:
          params.order ??
          store.moduleStore.filter((m) => m.unitId === params.unitId).length +
            1,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      store.moduleStore = [...store.moduleStore, mod];
      store._lessonStore = store.moduleStore;
      store._nextLessonId = store.nextModuleId;
      return mod;
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["lessons", variables.unitId],
      });
      queryClient.invalidateQueries({
        queryKey: ["modules", variables.unitId],
      });
      queryClient.invalidateQueries({ queryKey: ["units"] });
    },
  });
}

export function useCreateModule() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      unitId: number;
      courseId: number;
      title: string;
      description?: string;
    }): Promise<Module> => {
      const mod: Module = {
        id: store.nextModuleId++,
        unitId: params.unitId,
        courseId: params.courseId,
        title: params.title,
        description: params.description ?? "",
        learningObjectives: [],
        vocabulary: [],
        standards: [],
        tags: [],
        frameworkFields: {},
        order:
          store.moduleStore.filter((m) => m.unitId === params.unitId).length +
          1,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      store.moduleStore = [...store.moduleStore, mod];
      store._lessonStore = store.moduleStore;
      store._nextLessonId = store.nextModuleId;
      return mod;
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["modules", variables.unitId],
      });
      queryClient.invalidateQueries({
        queryKey: ["lessons", variables.unitId],
      });
      queryClient.invalidateQueries({ queryKey: ["units"] });
    },
  });
}

export function useUpdateLesson() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      id?: number;
      lessonId?: number;
      unitId: number;
      courseId?: number;
      title?: string;
      description?: string;
      order?: number;
      standards?: string[];
      tags?: string[];
      learningObjectives?: string[];
      vocabulary?: string[];
      frameworkFields?: FrameworkFields;
      duration?: number;
    }): Promise<Module> => {
      const id = params.lessonId ?? params.id!;
      store.moduleStore = store.moduleStore.map((m) =>
        m.id === id ? { ...m, ...params, id, updatedAt: Date.now() } : m,
      );
      store._lessonStore = store.moduleStore;
      return store.moduleStore.find((m) => m.id === id)!;
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["lessons", variables.unitId],
      });
      queryClient.invalidateQueries({
        queryKey: ["modules", variables.unitId],
      });
    },
  });
}

export function useUpdateModule() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      id: number;
      unitId: number;
      courseId?: number;
      title?: string;
      description?: string;
      learningObjectives?: string[];
      vocabulary?: string[];
      standards?: string[];
      tags?: string[];
      frameworkFields?: FrameworkFields;
      order?: number;
    }): Promise<Module> => {
      store.moduleStore = store.moduleStore.map((m) =>
        m.id === params.id ? { ...m, ...params, updatedAt: Date.now() } : m,
      );
      store._lessonStore = store.moduleStore;
      return store.moduleStore.find((m) => m.id === params.id)!;
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["modules", variables.unitId],
      });
      queryClient.invalidateQueries({
        queryKey: ["lessons", variables.unitId],
      });
    },
  });
}

export function useDeleteLesson() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      lessonId: number;
      unitId: number;
    }): Promise<void> => {
      store.moduleStore = store.moduleStore.filter(
        (m) => m.id !== params.lessonId,
      );
      store._lessonStore = store.moduleStore;
      store.assignmentStore = store.assignmentStore.filter(
        (a) => (a.moduleId ?? a.lessonId) !== params.lessonId,
      );
      store.assessmentStore = store.assessmentStore.filter(
        (a) => a.moduleId !== params.lessonId,
      );
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["lessons", variables.unitId],
      });
      queryClient.invalidateQueries({
        queryKey: ["modules", variables.unitId],
      });
      queryClient.invalidateQueries({ queryKey: ["assignments"] });
      queryClient.invalidateQueries({ queryKey: ["assessments"] });
    },
  });
}

export function useDeleteModule() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      moduleId: number;
      unitId: number;
    }): Promise<void> => {
      store.moduleStore = store.moduleStore.filter(
        (m) => m.id !== params.moduleId,
      );
      store._lessonStore = store.moduleStore;
      store.assignmentStore = store.assignmentStore.filter(
        (a) => (a.moduleId ?? a.lessonId) !== params.moduleId,
      );
      store.assessmentStore = store.assessmentStore.filter(
        (a) => a.moduleId !== params.moduleId,
      );
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["modules", variables.unitId],
      });
      queryClient.invalidateQueries({
        queryKey: ["lessons", variables.unitId],
      });
      queryClient.invalidateQueries({ queryKey: ["assignments"] });
      queryClient.invalidateQueries({ queryKey: ["assessments"] });
    },
  });
}

export function useGetAssignments(moduleId?: number) {
  initSeedData();
  return useQuery<Assignment[]>({
    queryKey: ["assignments", moduleId],
    queryFn: async () =>
      store.assignmentStore.filter(
        (a) =>
          moduleId === undefined ||
          a.moduleId === moduleId ||
          a.lessonId === moduleId,
      ),
    staleTime: Number.POSITIVE_INFINITY,
  });
}

// Alias used by AssignmentsSection
export const useAssignments = useGetAssignments;

export function useAllAssignments() {
  initSeedData();
  return useQuery<Assignment[]>({
    queryKey: ["assignments"],
    queryFn: async () => [...store.assignmentStore],
    staleTime: Number.POSITIVE_INFINITY,
  });
}

export function useCreateAssignment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      moduleId?: number;
      lessonId?: number;
      courseId?: number;
      title: string;
      description?: string;
      instructions?: string;
      dueDate: string;
      points?: number;
      pointsPossible?: number;
      assignmentType: AssignmentType;
      standards?: string[];
      tags?: string[];
      rubric?: Assignment["rubric"];
    }): Promise<Assignment> => {
      const modId = params.moduleId ?? params.lessonId ?? 0;
      const assignment: Assignment = {
        id: store.nextAssignmentId++,
        moduleId: modId,
        lessonId: modId,
        courseId: params.courseId ?? 0,
        title: params.title,
        description: params.description ?? "",
        instructions: params.instructions ?? "",
        points: params.points ?? params.pointsPossible ?? 100,
        pointsPossible: params.points ?? params.pointsPossible ?? 100,
        assignmentType: params.assignmentType,
        dueDate: params.dueDate,
        standards: params.standards ?? [],
        tags: params.tags ?? [],
        rubric: params.rubric ?? null,
        frameworkFields: {},
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      store.assignmentStore = [...store.assignmentStore, assignment];
      return assignment;
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      const modId = variables.moduleId ?? variables.lessonId ?? 0;
      queryClient.invalidateQueries({ queryKey: ["assignments", modId] });
      queryClient.invalidateQueries({ queryKey: ["assignments"] });
    },
  });
}

export function useUpdateAssignment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      id?: number;
      assignmentId?: number;
      moduleId?: number;
      lessonId?: number;
      courseId?: number;
      title?: string;
      description?: string;
      instructions?: string;
      dueDate?: string;
      points?: number;
      pointsPossible?: number;
      assignmentType?: AssignmentType;
      standards?: string[];
      tags?: string[];
      rubric?: Assignment["rubric"];
      frameworkFields?: FrameworkFields;
      bloomsLevel?: string;
      dokLevel?: string;
    }): Promise<Assignment> => {
      const id = params.assignmentId ?? params.id!;
      store.assignmentStore = store.assignmentStore.map((a) =>
        a.id === id
          ? {
              ...a,
              ...params,
              id,
              pointsPossible:
                params.points ?? params.pointsPossible ?? a.pointsPossible,
              updatedAt: Date.now(),
            }
          : a,
      );
      return store.assignmentStore.find((a) => a.id === id)!;
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      const modId = variables.moduleId ?? variables.lessonId ?? 0;
      queryClient.invalidateQueries({ queryKey: ["assignments", modId] });
      queryClient.invalidateQueries({ queryKey: ["assignments"] });
    },
  });
}

export function useDeleteAssignment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      assignmentId?: number;
      id?: number;
      moduleId?: number;
      lessonId?: number;
    }): Promise<void> => {
      const id = params.assignmentId ?? params.id!;
      store.assignmentStore = store.assignmentStore.filter((a) => a.id !== id);
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      const modId = variables.moduleId ?? variables.lessonId ?? 0;
      queryClient.invalidateQueries({ queryKey: ["assignments", modId] });
      queryClient.invalidateQueries({ queryKey: ["assignments"] });
    },
  });
}

export function useDuplicateAssignment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (assignmentId: number): Promise<Assignment> => {
      const original = store.assignmentStore.find((a) => a.id === assignmentId);
      if (!original) throw new Error("Assignment not found");
      const copy: Assignment = {
        ...original,
        id: store.nextAssignmentId++,
        title: `Copy of ${original.title}`,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      store.assignmentStore = [...store.assignmentStore, copy];
      return copy;
    },
    onSuccess: () => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({ queryKey: ["assignments"] });
    },
  });
}

// ─── Assessment Hooks ─────────────────────────────────────────────────────────

export function useGetAssessments(moduleId?: number) {
  initSeedData();
  return useQuery<Assessment[]>({
    queryKey: ["assessments", moduleId],
    queryFn: async () =>
      store.assessmentStore.filter(
        (a) => moduleId === undefined || a.moduleId === moduleId,
      ),
    staleTime: Number.POSITIVE_INFINITY,
  });
}

export function useAllAssessments() {
  initSeedData();
  return useQuery<Assessment[]>({
    queryKey: ["assessments"],
    queryFn: async () => [...store.assessmentStore],
    staleTime: Number.POSITIVE_INFINITY,
  });
}

export function useCreateAssessment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      moduleId: number;
      courseId: number;
      title: string;
      description?: string;
      assessmentType?: string;
      difficulty?: Difficulty;
      totalPoints?: number;
      scoringModel?: ScoringModel;
      dueDate?: string;
      standards?: string[];
      tags?: string[];
      items?: string[];
    }): Promise<Assessment> => {
      const assessment: Assessment = {
        id: store.nextAssessmentId++,
        moduleId: params.moduleId,
        courseId: params.courseId,
        title: params.title,
        description: params.description ?? "",
        assessmentType: params.assessmentType ?? "Quiz",
        items: params.items ?? [],
        scoringModel: params.scoringModel ?? "points",
        totalPoints: params.totalPoints ?? 100,
        difficulty: params.difficulty ?? "medium",
        dueDate: params.dueDate ?? "",
        standards: params.standards ?? [],
        tags: params.tags ?? [],
        frameworkFields: {},
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      store.assessmentStore = [...store.assessmentStore, assessment];
      return assessment;
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["assessments", variables.moduleId],
      });
      queryClient.invalidateQueries({ queryKey: ["assessments"] });
    },
  });
}

export function useUpdateAssessment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      id: number;
      moduleId: number;
      title?: string;
      description?: string;
      assessmentType?: string;
      items?: string[];
      scoringModel?: ScoringModel;
      totalPoints?: number;
      difficulty?: Difficulty;
      dueDate?: string;
      standards?: string[];
      tags?: string[];
      frameworkFields?: FrameworkFields;
      bloomsLevel?: string;
      dokLevel?: string;
    }): Promise<Assessment> => {
      store.assessmentStore = store.assessmentStore.map((a) =>
        a.id === params.id ? { ...a, ...params, updatedAt: Date.now() } : a,
      );
      return store.assessmentStore.find((a) => a.id === params.id)!;
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["assessments", variables.moduleId],
      });
      queryClient.invalidateQueries({ queryKey: ["assessments"] });
    },
  });
}

export function useDeleteAssessment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (params: {
      assessmentId: number;
      moduleId: number;
    }): Promise<void> => {
      store.assessmentStore = store.assessmentStore.filter(
        (a) => a.id !== params.assessmentId,
      );
    },
    onSuccess: (_data, variables) => {
      syncCurriculumToStorage();
      queryClient.invalidateQueries({
        queryKey: ["assessments", variables.moduleId],
      });
      queryClient.invalidateQueries({ queryKey: ["assessments"] });
    },
  });
}
