import { useMemo } from "react";

const DAY_NAMES = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

export interface SchedulePeriod {
  id: string;
  name: string;
  startTime: string;
  endTime: string;
  subject: string | null;
  room: string | null;
  isCurrent: boolean;
  isPast: boolean;
}

export function getDayNames() {
  return DAY_NAMES;
}

export function useTodayBanner() {
  const dayName = DAY_NAMES[new Date().getDay()];

  const timetableInfo = useMemo(() => {
    try {
      const raw = localStorage.getItem("edunite_timetable");
      if (!raw) return null;
      const timetable = JSON.parse(raw) as {
        periods?: Array<{
          id: string;
          name: string;
          startTime: string;
          endTime: string;
          subject?: string;
        }>;
        assignments?: Array<{
          periodId: string;
          day: string;
          courseName: string;
          room?: string;
        }>;
        scheduleMode?: string;
        currentWeek?: "A" | "B";
        weekBAssignments?: Array<{
          periodId: string;
          day: string;
          courseName: string;
          room?: string;
        }>;
        // legacy fields
        useABRotation?: boolean;
        activeWeek?: "A" | "B";
        weekA?: Array<{
          day: string;
          periods: Array<{
            name: string;
            startTime: string;
            endTime: string;
            subject?: string;
          }>;
        }>;
        weekB?: Array<{
          day: string;
          periods: Array<{
            name: string;
            startTime: string;
            endTime: string;
            subject?: string;
          }>;
        }>;
      };

      const now = new Date();
      const hh = now.getHours();
      const mm = now.getMinutes();
      const currentMins = hh * 60 + mm;
      const todayDayName = DAY_NAMES[now.getDay()];

      // Standard (non-legacy) timetable format
      if (
        timetable.periods &&
        Array.isArray(timetable.periods) &&
        timetable.periods[0]?.id
      ) {
        const assignments = timetable.assignments ?? [];
        for (const p of timetable.periods) {
          if (!p.startTime || !p.endTime) continue;
          const [sh, sm] = p.startTime.split(":").map(Number);
          const [eh, em] = p.endTime.split(":").map(Number);
          const start = sh * 60 + sm;
          const end = eh * 60 + em;
          if (currentMins >= start && currentMins <= end) {
            // Find assignment for this period on today
            const assignment = assignments.find(
              (a) => a.periodId === p.id && a.day === todayDayName,
            );
            const endMins = eh * 60 + em;
            const remaining = endMins - currentMins;
            return {
              currentPeriod: p.name,
              subject: assignment?.courseName ?? p.subject ?? null,
              room: assignment?.room ?? null,
              remainingMins: remaining,
            };
          }
        }
        return {
          currentPeriod: null,
          subject: null,
          room: null,
          remainingMins: null,
        };
      }

      // Legacy AB rotation format
      let periodsToCheck: Array<{
        name: string;
        startTime: string;
        endTime: string;
        subject?: string;
      }> = [];
      if (timetable.useABRotation) {
        const weekData =
          timetable.activeWeek === "B" ? timetable.weekB : timetable.weekA;
        const todayRow = (weekData ?? []).find((r) => r.day === todayDayName);
        periodsToCheck = todayRow?.periods ?? [];
      } else {
        periodsToCheck = (timetable.periods ?? []) as any;
      }

      for (const p of periodsToCheck) {
        if (!p.startTime || !p.endTime) continue;
        const [sh, sm] = p.startTime.split(":").map(Number);
        const [eh, em] = p.endTime.split(":").map(Number);
        const start = sh * 60 + sm;
        const end = eh * 60 + em;
        if (currentMins >= start && currentMins <= end) {
          const remaining = end - currentMins;
          return {
            currentPeriod: p.name,
            subject: p.subject ?? null,
            room: null,
            remainingMins: remaining,
          };
        }
      }

      return {
        currentPeriod: null,
        subject: null,
        room: null,
        remainingMins: null,
      };
    } catch {
      return null;
    }
  }, []);

  return { dayName, timetableInfo };
}

// ── useTodaySchedule: All periods for today with current indicator ──────────

export function useTodaySchedule(): SchedulePeriod[] {
  return useMemo(() => {
    try {
      const raw = localStorage.getItem("edunite_timetable");
      if (!raw) return [];
      const timetable = JSON.parse(raw) as any;
      const now = new Date();
      const hh = now.getHours();
      const mm = now.getMinutes();
      const currentMins = hh * 60 + mm;
      const todayDayName = DAY_NAMES[now.getDay()];

      const result: SchedulePeriod[] = [];

      if (
        timetable.periods &&
        Array.isArray(timetable.periods) &&
        timetable.periods[0]?.id
      ) {
        const assignments: any[] = timetable.assignments ?? [];
        for (const p of timetable.periods) {
          if (!p.startTime || !p.endTime) continue;
          const [sh, sm] = p.startTime.split(":").map(Number);
          const [eh, em] = p.endTime.split(":").map(Number);
          const start = sh * 60 + sm;
          const end = eh * 60 + em;
          const assignment = assignments.find(
            (a: any) => a.periodId === p.id && a.day === todayDayName,
          );
          result.push({
            id: p.id,
            name: p.name,
            startTime: p.startTime,
            endTime: p.endTime,
            subject: assignment?.courseName ?? p.subject ?? null,
            room: assignment?.room ?? null,
            isCurrent: currentMins >= start && currentMins <= end,
            isPast: currentMins > end,
          });
        }
        return result.sort((a, b) => {
          const [ah, am] = a.startTime.split(":").map(Number);
          const [bh, bm] = b.startTime.split(":").map(Number);
          return ah * 60 + am - (bh * 60 + bm);
        });
      }

      // Legacy format
      let periodsToCheck: any[] = [];
      if (timetable.useABRotation) {
        const weekData =
          timetable.activeWeek === "B" ? timetable.weekB : timetable.weekA;
        const todayRow = (weekData ?? []).find(
          (r: any) => r.day === todayDayName,
        );
        periodsToCheck = todayRow?.periods ?? [];
      } else {
        periodsToCheck = timetable.periods ?? [];
      }
      for (let i = 0; i < periodsToCheck.length; i++) {
        const p = periodsToCheck[i];
        if (!p.startTime || !p.endTime) continue;
        const [sh, sm] = p.startTime.split(":").map(Number);
        const [eh, em] = p.endTime.split(":").map(Number);
        const start = sh * 60 + sm;
        const end = eh * 60 + em;
        result.push({
          id: String(i),
          name: p.name,
          startTime: p.startTime,
          endTime: p.endTime,
          subject: p.subject ?? null,
          room: null,
          isCurrent: currentMins >= start && currentMins <= end,
          isPast: currentMins > end,
        });
      }
      return result;
    } catch {
      return [];
    }
  }, []);
}

// ── AttendanceSparkline: 7-day trend line ────────────────────────────────────────────────
