import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { PaymentLedgerEntry } from "@/types";
import {
  AlertCircle,
  CheckCircle2,
  CreditCard,
  Edit2,
  Trash2,
  TrendingUp,
} from "lucide-react";
import { useMemo } from "react";

interface ClientPaymentTabProps {
  clientId: string;
  onEdit: (entry: PaymentLedgerEntry) => void;
}

export default function ClientPaymentTab({
  clientId,
  onEdit,
}: ClientPaymentTabProps) {
  const {
    getClientPaymentSummary,
    getClientPaymentHistory,
    deleteClientPayment,
  } = useERPStore();

  const summary = useMemo(
    () => getClientPaymentSummary(clientId),
    [getClientPaymentSummary, clientId],
  );
  const history = useMemo(
    () => getClientPaymentHistory(clientId),
    [getClientPaymentHistory, clientId],
  );

  const handleDelete = (entryId: string) => {
    if (confirm("Are you sure you want to delete this payment?")) {
      deleteClientPayment(clientId, entryId);
    }
  };

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium">
                  Total Paid
                </p>
                <p className="text-xl font-bold text-green-600">
                  {formatCurrency(summary.totalPaid)}
                </p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-green-500 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card className="border border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium">
                  Total Due
                </p>
                <p className="text-xl font-bold text-foreground">
                  {formatCurrency(summary.totalDue)}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-primary opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card className="border border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium">
                  Pending Balance
                </p>
                <p
                  className={`text-xl font-bold ${
                    summary.pendingBalance > 0
                      ? "text-destructive"
                      : "text-green-600"
                  }`}
                >
                  {formatCurrency(summary.pendingBalance)}
                </p>
              </div>
              <AlertCircle
                className={`w-8 h-8 opacity-50 ${
                  summary.pendingBalance > 0
                    ? "text-destructive"
                    : "text-green-500"
                }`}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment History Timeline */}
      <h3 className="font-display font-semibold text-foreground">
        Payment History
      </h3>
      {history.length === 0 ? (
        <div
          className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3"
          data-ocid="client_profile.payments.empty_state"
        >
          <CreditCard className="w-10 h-10 opacity-40" />
          <p className="font-medium">No payments recorded</p>
        </div>
      ) : (
        <div className="space-y-2">
          {history.map((entry, i) => (
            <div
              key={entry.id}
              className="flex items-center gap-3 p-3 rounded-xl border border-border bg-card"
              data-ocid={`client_profile.payment.item.${i + 1}`}
            >
              <div className="w-8 h-8 rounded-lg bg-green-50 flex items-center justify-center flex-shrink-0">
                <CreditCard className="w-4 h-4 text-green-600" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-sm text-foreground">
                    {formatCurrency(entry.amount)}
                  </span>
                  <Badge variant="secondary" className="text-xs">
                    {entry.mode || "Cash"}
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {formatDate(entry.date)}
                  {entry.note ? ` · ${entry.note}` : ""}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  Balance after: {formatCurrency(entry.balanceAfterPayment)}
                </div>
              </div>
              <div className="flex items-center gap-1 flex-shrink-0">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => onEdit(entry)}
                  data-ocid={`client_profile.payment.edit_button.${i + 1}`}
                >
                  <Edit2 className="w-4 h-4 text-muted-foreground" />
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive"
                  onClick={() => handleDelete(entry.id)}
                  data-ocid={`client_profile.payment.delete_button.${i + 1}`}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
