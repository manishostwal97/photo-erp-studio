import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "@tanstack/react-router";
import { ArrowLeft, CheckCircle, KeyRound } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";

interface ForgotFormValues {
  email: string;
}

export default function ForgotPasswordPage() {
  const navigate = useNavigate();
  const { sendPasswordReset } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sent, setSent] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ForgotFormValues>();

  const onSubmit = async (data: ForgotFormValues) => {
    setIsSubmitting(true);
    const ok = await sendPasswordReset(data.email);
    setIsSubmitting(false);
    if (ok) setSent(true);
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center bg-background px-4"
      data-ocid="forgot_password.page"
    >
      <div className="w-full max-w-md">
        {/* Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4">
            <KeyRound className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-display font-bold text-foreground">
            Reset Password
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Enter your email and we'll send a reset link
          </p>
        </div>

        <Card className="shadow-lg border-border">
          <CardContent className="px-6 py-6 space-y-5">
            {sent ? (
              <div
                className="flex flex-col items-center gap-4 py-6 text-center"
                data-ocid="forgot_password.success_state"
              >
                <CheckCircle className="w-14 h-14 text-green-500" />
                <div>
                  <p className="font-semibold text-foreground text-lg">
                    Reset email sent!
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Check your inbox and follow the link to reset your password.
                  </p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate({ to: "/login" })}
                  className="mt-2"
                  data-ocid="forgot_password.back_to_login_button"
                >
                  Back to Sign In
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="reset-email">Email address</Label>
                  <Input
                    id="reset-email"
                    type="email"
                    placeholder="you@studio.com"
                    data-ocid="forgot_password.email_input"
                    {...register("email", {
                      required: "Email is required.",
                      pattern: {
                        value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                        message: "Enter a valid email address.",
                      },
                    })}
                  />
                  {errors.email && (
                    <p
                      className="text-xs text-destructive"
                      data-ocid="forgot_password.field_error"
                    >
                      {errors.email.message}
                    </p>
                  )}
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isSubmitting}
                  data-ocid="forgot_password.submit_button"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 rounded-full border-2 border-primary-foreground border-t-transparent animate-spin" />
                      Sending…
                    </span>
                  ) : (
                    "Send Reset Link"
                  )}
                </Button>

                <button
                  type="button"
                  onClick={() => navigate({ to: "/login" })}
                  className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
                  data-ocid="forgot_password.back_link"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Back to login
                </button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
