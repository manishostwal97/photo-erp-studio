// ─── Shared Calendar Types & Utilities ──────────────────────────────────────
// Shared between Calendar.tsx page and extracted view sub-components.

import type React from "react";

export interface CalendarEvent {
  id: string;
  date: string; // "YYYY-MM-DD"
  type:
    | "incident"
    | "praise"
    | "absence"
    | "tardy"
    | "assignment"
    | "class"
    | "school_event";
  label: string;
  studentName?: string;
  source?: "custom";
  classId?: string;
}

export interface CustomStoredEvent {
  id: string;
  title: string;
  type: "Assignment" | "Assessment" | "School Event" | "Holiday" | "PD Day";
  date: string;
  classId?: string;
}

export interface TimetablePeriodLocal {
  id: string;
  name: string;
  startTime: string;
  endTime: string;
  courseName?: string;
  room?: string;
}

// ── Helpers ──────────────────────────────────────────────────────────────────

export const MONTH_NAMES = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

export const DAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
export const DAY_LABELS_SHORT = ["S", "M", "T", "W", "T", "F", "S"];

export function toDateStr(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function getAbDayLabel(date: Date, baseDate?: Date): "A" | "B" {
  const base = baseDate ?? new Date(date.getFullYear(), 7, 1);
  let bdayCount = 0;
  const iter = new Date(base);
  const target = new Date(date);
  target.setHours(12, 0, 0, 0);
  while (iter < target) {
    const dow = iter.getDay();
    if (dow !== 0 && dow !== 6) bdayCount++;
    iter.setDate(iter.getDate() + 1);
  }
  return bdayCount % 2 === 0 ? "A" : "B";
}

export function getMonthGrid(year: number, month: number): (Date | null)[] {
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (Date | null)[] = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

// ── EventDot ─────────────────────────────────────────────────────────────────

export function EventDot({ type }: { type: CalendarEvent["type"] }) {
  const colors: Record<CalendarEvent["type"], string> = {
    incident: "bg-destructive",
    praise: "bg-success",
    absence: "bg-info",
    tardy: "bg-warning",
    assignment: "bg-primary",
    class: "bg-primary/30",
    school_event: "bg-muted-foreground/40",
  };
  return (
    <span
      className={`inline-block w-1.5 h-1.5 rounded-full flex-shrink-0 ${colors[type] ?? "bg-muted-foreground/30"}`}
    />
  );
}

// ── EventChip ─────────────────────────────────────────────────────────────────

export function EventChip({
  event,
  draggable,
  onDragStart,
}: {
  event: CalendarEvent;
  draggable?: boolean;
  onDragStart?: (e: React.DragEvent, id: string) => void;
}) {
  const styles: Record<CalendarEvent["type"], string> = {
    incident: "bg-destructive/10 text-destructive border-destructive/20",
    praise: "bg-success/10 text-success border-success/20",
    absence: "bg-info/10 text-info border-info/20",
    tardy: "bg-warning/10 text-warning-foreground border-warning/20",
    assignment: "bg-primary/10 text-primary border-primary/20",
    class: "bg-primary/5 text-primary/60 border-primary/10",
    school_event: "bg-muted/50 text-muted-foreground border-border",
  };
  const chipCls =
    styles[event.type] ?? "bg-muted text-muted-foreground border-border";
  const label = event.studentName
    ? `${event.studentName}: ${event.label}`
    : event.label;

  return (
    <div
      draggable={draggable}
      onDragStart={
        draggable && onDragStart ? (e) => onDragStart(e, event.id) : undefined
      }
      className={`text-[10px] px-1.5 py-0.5 rounded border truncate leading-tight ${chipCls} ${draggable ? "cursor-grab" : ""}`}
      title={label}
    >
      {label}
    </div>
  );
}
