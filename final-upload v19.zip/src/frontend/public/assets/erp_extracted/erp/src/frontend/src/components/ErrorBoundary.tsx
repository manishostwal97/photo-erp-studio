import { AlertTriangle, RefreshCw } from "lucide-react";
import React from "react";

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
  pageName?: string;
}

export class ErrorBoundary extends React.Component<
  ErrorBoundaryProps,
  ErrorBoundaryState
> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error("[ErrorBoundary] Caught error:", error, info);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) return <>{this.props.fallback}</>;

      const pageName = this.props.pageName ?? "this page";
      return (
        <div
          className="flex flex-col items-center justify-center min-h-[300px] p-8 text-center"
          data-ocid="error_boundary.error_state"
        >
          <div className="w-14 h-14 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
            <AlertTriangle className="w-7 h-7 text-destructive" />
          </div>
          <h2 className="text-xl font-display font-semibold text-foreground mb-2">
            Something went wrong
          </h2>
          <p className="text-sm text-muted-foreground mb-1 max-w-sm">
            An unexpected error occurred while loading {pageName}.
          </p>
          {this.state.error && (
            <p className="text-xs text-muted-foreground/70 font-mono mb-4 max-w-sm break-all">
              {this.state.error.message}
            </p>
          )}
          <button
            type="button"
            onClick={this.handleReset}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
            data-ocid="error_boundary.retry_button"
          >
            <RefreshCw className="w-4 h-4" />
            Try Again
          </button>
        </div>
      );
    }

    return <>{this.props.children}</>;
  }
}

/**
 * Wraps a page component in an ErrorBoundary with a page-specific name.
 */
export function withPageErrorBoundary<P extends object>(
  Component: React.ComponentType<P>,
  pageName: string,
): React.FC<P> {
  const Wrapped: React.FC<P> = (props) => (
    <ErrorBoundary pageName={pageName}>
      <Component {...props} />
    </ErrorBoundary>
  );
  Wrapped.displayName = `PageErrorBoundary(${pageName})`;
  return Wrapped;
}
