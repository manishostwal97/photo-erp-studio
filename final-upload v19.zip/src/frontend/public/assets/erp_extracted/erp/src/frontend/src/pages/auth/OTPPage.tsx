import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Phone } from "lucide-react";
import { useEffect, useRef, useState } from "react";

type Step = "phone" | "otp";

export default function OTPPage() {
  const navigate = useNavigate();
  const { sendOTP, verifyOTP } = useAuth();

  const [step, setStep] = useState<Step>("phone");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [phoneError, setPhoneError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  function startCountdown() {
    setCountdown(60);
    timerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }

  const handleSendOTP = async () => {
    const trimmed = phone.trim();
    if (!/^\+\d{7,15}$/.test(trimmed)) {
      setPhoneError(
        "Enter a valid phone number with country code (e.g. +1234567890).",
      );
      return;
    }
    setPhoneError("");
    setIsLoading(true);
    const ok = await sendOTP(trimmed);
    setIsLoading(false);
    if (ok) {
      setStep("otp");
      startCountdown();
    }
  };

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) return;
    setIsLoading(true);
    const ok = await verifyOTP(otp);
    setIsLoading(false);
    if (ok) navigate({ to: "/dashboard" });
  };

  const handleResend = async () => {
    if (countdown > 0) return;
    setOtp("");
    setIsLoading(true);
    const ok = await sendOTP(phone.trim());
    setIsLoading(false);
    if (ok) startCountdown();
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center bg-background px-4"
      data-ocid="otp.page"
    >
      {/* Hidden recaptcha container */}
      <div id="recaptcha-container" />

      <div className="w-full max-w-md">
        {/* Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4">
            <Phone className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-display font-bold text-foreground">
            {step === "phone" ? "Login with Phone" : "Enter OTP"}
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            {step === "phone"
              ? "Enter your mobile number to receive a verification code"
              : `We sent a 6-digit code to ${phone}`}
          </p>
        </div>

        <Card className="shadow-lg border-border">
          <CardContent className="px-6 py-6 space-y-5">
            {step === "phone" ? (
              <>
                <div className="space-y-1.5">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+1 234 567 8901"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    data-ocid="otp.phone_input"
                  />
                  {phoneError && (
                    <p
                      className="text-xs text-destructive"
                      data-ocid="otp.phone_field_error"
                    >
                      {phoneError}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Include country code (e.g. +1 for US, +91 for India)
                  </p>
                </div>

                <Button
                  type="button"
                  className="w-full"
                  onClick={handleSendOTP}
                  disabled={isLoading}
                  data-ocid="otp.send_button"
                >
                  {isLoading ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 rounded-full border-2 border-primary-foreground border-t-transparent animate-spin" />
                      Sending…
                    </span>
                  ) : (
                    "Send OTP"
                  )}
                </Button>
              </>
            ) : (
              <>
                <div className="space-y-3">
                  <Label>6-Digit Code</Label>
                  <div className="flex justify-center">
                    <InputOTP
                      maxLength={6}
                      value={otp}
                      onChange={setOtp}
                      data-ocid="otp.input"
                    >
                      <InputOTPGroup>
                        <InputOTPSlot index={0} />
                        <InputOTPSlot index={1} />
                        <InputOTPSlot index={2} />
                        <InputOTPSlot index={3} />
                        <InputOTPSlot index={4} />
                        <InputOTPSlot index={5} />
                      </InputOTPGroup>
                    </InputOTP>
                  </div>
                </div>

                <Button
                  type="button"
                  className="w-full"
                  onClick={handleVerifyOTP}
                  disabled={isLoading || otp.length !== 6}
                  data-ocid="otp.verify_button"
                >
                  {isLoading ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 rounded-full border-2 border-primary-foreground border-t-transparent animate-spin" />
                      Verifying…
                    </span>
                  ) : (
                    "Verify OTP"
                  )}
                </Button>

                <Button
                  type="button"
                  variant="ghost"
                  className="w-full text-sm"
                  onClick={handleResend}
                  disabled={countdown > 0 || isLoading}
                  data-ocid="otp.resend_button"
                >
                  {countdown > 0 ? `Resend in ${countdown}s` : "Resend OTP"}
                </Button>
              </>
            )}

            <button
              type="button"
              onClick={() =>
                step === "otp" ? setStep("phone") : navigate({ to: "/login" })
              }
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
              data-ocid="otp.back_link"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              {step === "otp" ? "Change number" : "Back to login"}
            </button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
