import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Check, Palette } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface Template {
  id: string;
  name: string;
  primaryColor: string;
  accentColor: string;
  backgroundColor: string;
  textColor: string;
  headerBg: string;
  headerText: string;
  fontStyle: "serif" | "sans-serif";
  logoPosition: "left" | "center" | "right";
  headerStyle: "gradient" | "solid" | "minimal";
  showWatermark: boolean;
  watermarkText?: string;
  description: string;
}

const TEMPLATES: Template[] = [
  {
    id: "classic",
    name: "Classic Professional",
    primaryColor: "#DC2626",
    accentColor: "#DC2626",
    backgroundColor: "#ffffff",
    textColor: "#1e1e1e",
    headerBg: "#DC2626",
    headerText: "#ffffff",
    fontStyle: "sans-serif",
    logoPosition: "left",
    headerStyle: "solid",
    showWatermark: false,
    description:
      "Clean white with bold red accents — ideal for everyday invoices.",
  },
  {
    id: "luxury",
    name: "Luxury Black & Gold",
    primaryColor: "#D4AF37",
    accentColor: "#D4AF37",
    backgroundColor: "#121212",
    textColor: "#F0EBD2",
    headerBg: "#0C0C0C",
    headerText: "#D4AF37",
    fontStyle: "serif",
    logoPosition: "center",
    headerStyle: "gradient",
    showWatermark: true,
    watermarkText: "PREMIUM STUDIO",
    description:
      "Luxury black canvas with gold typography — premium wedding clients.",
  },
  {
    id: "cinematic",
    name: "Cinematic Dark",
    primaryColor: "#9696A0",
    accentColor: "#B4B4C8",
    backgroundColor: "#1C1E24",
    textColor: "#DCDCE6",
    headerBg: "#14161C",
    headerText: "#C8C8D2",
    fontStyle: "sans-serif",
    logoPosition: "left",
    headerStyle: "solid",
    showWatermark: false,
    description:
      "Dark charcoal with silver accents — cinematic & film-style shoots.",
  },
  {
    id: "wedding",
    name: "Wedding Elegance",
    primaryColor: "#B6785A",
    accentColor: "#B6785A",
    backgroundColor: "#FFFCF8",
    textColor: "#3C281E",
    headerBg: "#B6785A",
    headerText: "#FFFCF8",
    fontStyle: "serif",
    logoPosition: "left",
    headerStyle: "gradient",
    showWatermark: false,
    description:
      "Warm ivory with rose-gold accents — perfect for wedding albums.",
  },
  {
    id: "minimal",
    name: "Modern Minimal",
    primaryColor: "#141414",
    accentColor: "#505050",
    backgroundColor: "#ffffff",
    textColor: "#141414",
    headerBg: "#F0F0F0",
    headerText: "#141414",
    fontStyle: "sans-serif",
    logoPosition: "left",
    headerStyle: "minimal",
    showWatermark: false,
    description:
      "Pure white with black typography — ultra-clean corporate style.",
  },
];

// ── Mini thumbnail preview ────────────────────────────────────────────────────
function TemplateThumbnail({
  tpl,
  selected,
  onClick,
}: { tpl: Template; selected: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      data-ocid={`invoice_template.${tpl.id}.card`}
      className="relative rounded-xl border-2 overflow-hidden transition-all text-left"
      style={{
        borderColor: selected ? tpl.primaryColor : "#e5e7eb",
        boxShadow: selected ? `0 0 0 2px ${tpl.primaryColor}40` : undefined,
      }}
    >
      {/* Mini PDF preview */}
      <div
        className="w-full"
        style={{
          background: tpl.backgroundColor,
          fontFamily:
            tpl.fontStyle === "serif" ? "Georgia, serif" : "Arial, sans-serif",
        }}
      >
        {/* Header */}
        <div
          className="px-2 py-1.5 flex items-center justify-between"
          style={{ background: tpl.headerBg }}
        >
          <div className="flex items-center gap-1">
            <div
              className="w-4 h-4 rounded"
              style={{
                background: `${tpl.primaryColor}40`,
                border: `1px solid ${tpl.primaryColor}60`,
              }}
            />
            <div className="space-y-0.5">
              <div
                className="h-1.5 w-12 rounded-sm"
                style={{ background: `${tpl.headerText}CC` }}
              />
              <div
                className="h-1 w-8 rounded-sm"
                style={{ background: `${tpl.headerText}70` }}
              />
            </div>
          </div>
          <div className="text-right">
            <div
              className="h-1.5 w-8 rounded-sm ml-auto"
              style={{ background: `${tpl.headerText}CC` }}
            />
            <div
              className="h-1 w-10 rounded-sm ml-auto mt-0.5"
              style={{ background: `${tpl.headerText}70` }}
            />
          </div>
        </div>
        {/* Body */}
        <div className="p-2 space-y-1.5">
          {/* Client + Event row */}
          <div className="grid grid-cols-2 gap-1">
            {[0, 1].map((i) => (
              <div
                key={i}
                className="rounded p-1"
                style={{ background: `${tpl.textColor}08` }}
              >
                <div
                  className="h-1 w-8 rounded mb-1"
                  style={{ background: tpl.primaryColor }}
                />
                <div
                  className="h-1.5 w-12 rounded"
                  style={{ background: `${tpl.textColor}CC` }}
                />
                <div
                  className="h-1 w-10 rounded mt-0.5"
                  style={{ background: `${tpl.textColor}60` }}
                />
              </div>
            ))}
          </div>
          {/* Services table */}
          <div className="rounded overflow-hidden">
            <div
              className="px-1 py-0.5 flex justify-between"
              style={{ background: tpl.headerBg }}
            >
              <div
                className="h-1 w-10 rounded"
                style={{ background: `${tpl.headerText}CC` }}
              />
              <div
                className="h-1 w-5 rounded"
                style={{ background: `${tpl.headerText}CC` }}
              />
            </div>
            {[0, 1].map((i) => (
              <div
                key={i}
                className="px-1 py-0.5 flex justify-between"
                style={{
                  background:
                    i % 2 === 0 ? `${tpl.textColor}05` : `${tpl.textColor}0A`,
                }}
              >
                <div
                  className="h-1 w-12 rounded"
                  style={{ background: `${tpl.textColor}70` }}
                />
                <div
                  className="h-1 w-5 rounded"
                  style={{ background: tpl.primaryColor }}
                />
              </div>
            ))}
          </div>
          {/* Payment summary */}
          <div className="flex justify-end">
            <div
              className="rounded p-1 w-16"
              style={{ background: `${tpl.textColor}08` }}
            >
              <div className="flex justify-between mb-0.5">
                <div
                  className="h-1 w-5 rounded"
                  style={{ background: `${tpl.textColor}60` }}
                />
                <div
                  className="h-1 w-5 rounded"
                  style={{ background: `${tpl.textColor}90` }}
                />
              </div>
              <div className="flex justify-between">
                <div
                  className="h-1.5 w-6 rounded"
                  style={{ background: tpl.primaryColor }}
                />
                <div
                  className="h-1.5 w-6 rounded"
                  style={{ background: "#22c55e" }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Selected badge */}
      {selected && (
        <div
          className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full flex items-center justify-center"
          style={{ background: tpl.primaryColor }}
        >
          <Check className="w-3 h-3 text-white" />
        </div>
      )}
    </button>
  );
}

// ── Full-size live preview ────────────────────────────────────────────────────
function TemplateFullPreview({ tpl }: { tpl: Template }) {
  return (
    <div
      className="rounded-xl overflow-hidden border border-border"
      style={{
        background: tpl.backgroundColor,
        fontFamily:
          tpl.fontStyle === "serif" ? "Georgia, serif" : "Arial, sans-serif",
        color: tpl.textColor,
        maxHeight: "70vh",
        overflowY: "auto",
      }}
      data-ocid="invoice_template.preview_panel"
    >
      {/* Header */}
      <div
        className="px-6 py-4 flex items-start justify-between"
        style={{ background: tpl.headerBg }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-12 h-12 rounded-lg flex items-center justify-center text-lg font-bold"
            style={{
              background: `${tpl.primaryColor}30`,
              border: `2px solid ${tpl.primaryColor}60`,
              color: tpl.headerText,
            }}
          >
            S
          </div>
          <div>
            <p
              className="font-bold text-base"
              style={{ color: tpl.headerText }}
            >
              Your Photography Studio
            </p>
            <p className="text-xs opacity-70" style={{ color: tpl.headerText }}>
              Owner Name · +91 98765 43210
            </p>
            <p className="text-xs opacity-60" style={{ color: tpl.headerText }}>
              studio@example.com · Mumbai, India
            </p>
          </div>
        </div>
        <div className="text-right">
          <p
            className="text-xs uppercase tracking-widest font-semibold"
            style={{ color: tpl.primaryColor }}
          >
            INVOICE
          </p>
          <p className="font-bold text-lg" style={{ color: tpl.headerText }}>
            260501
          </p>
          <p className="text-xs opacity-60" style={{ color: tpl.headerText }}>
            17 May 2026 · 10:30 AM
          </p>
        </div>
      </div>

      {/* Divider */}
      <div className="h-0.5" style={{ background: tpl.primaryColor }} />

      <div className="p-5 space-y-5">
        {/* Client + Event */}
        <div className="grid grid-cols-2 gap-4">
          {[
            {
              label: "BILL TO",
              name: "Rahul Sharma",
              line1: "Ph: +91 98765 43210",
              line2: "123 Main Street, Mumbai",
            },
            {
              label: "EVENT DETAILS",
              name: "Wedding",
              line1: "18 May – 21 May 2026",
              line2: "Hotel Sunrise, Mandsaur",
            },
          ].map((col) => (
            <div
              key={col.label}
              className="rounded-lg p-3"
              style={{
                background: `${tpl.textColor}08`,
                border: `1px solid ${tpl.textColor}15`,
              }}
            >
              <p
                className="text-xs font-bold mb-1"
                style={{ color: tpl.primaryColor }}
              >
                {col.label}
              </p>
              <p
                className="font-semibold text-sm"
                style={{ color: tpl.textColor }}
              >
                {col.name}
              </p>
              <p
                className="text-xs mt-0.5"
                style={{ color: `${tpl.textColor}90` }}
              >
                {col.line1}
              </p>
              <p className="text-xs" style={{ color: `${tpl.textColor}70` }}>
                {col.line2}
              </p>
            </div>
          ))}
        </div>

        {/* Services */}
        <div>
          <p
            className="text-xs font-bold mb-1"
            style={{ color: tpl.primaryColor }}
          >
            SERVICES
          </p>
          <div className="rounded-lg overflow-hidden">
            <div
              className="grid grid-cols-4 px-3 py-1.5"
              style={{ background: tpl.headerBg }}
            >
              {["Service", "Qty", "Rate", "Amount"].map((h) => (
                <p
                  key={h}
                  className="text-xs font-bold"
                  style={{ color: tpl.headerText }}
                >
                  {h}
                </p>
              ))}
            </div>
            {[
              ["Wedding Photography", "1", "Rs.20,000", "Rs.20,000"],
              ["Cinematic Video", "1", "Rs.15,000", "Rs.15,000"],
            ].map((row, i) => (
              <div
                key={row[0]}
                className="grid grid-cols-4 px-3 py-1.5"
                style={{
                  background:
                    i % 2 === 0 ? `${tpl.textColor}06` : `${tpl.textColor}0C`,
                }}
              >
                {row.map((cell) => (
                  <p
                    key={cell}
                    className="text-xs"
                    style={{ color: tpl.textColor }}
                  >
                    {cell}
                  </p>
                ))}
              </div>
            ))}
          </div>
        </div>

        {/* Payment Summary */}
        <div className="flex justify-end">
          <div
            className="rounded-lg p-3 w-48"
            style={{
              background: `${tpl.textColor}08`,
              border: `1px solid ${tpl.textColor}15`,
            }}
          >
            <p
              className="text-xs font-bold mb-2"
              style={{ color: tpl.primaryColor }}
            >
              PAYMENT SUMMARY
            </p>
            {[
              {
                l: "Grand Total",
                v: "Rs.35,000",
                bold: true,
                color: tpl.textColor,
              },
              { l: "Advance Paid", v: "Rs.20,000", color: "#22c55e" },
              { l: "Remaining Due", v: "Rs.15,000", color: "#DC2626" },
            ].map((r) => (
              <div key={r.l} className="flex justify-between py-0.5">
                <span
                  className="text-xs"
                  style={{ color: `${tpl.textColor}80` }}
                >
                  {r.l}
                </span>
                <span
                  className="text-xs"
                  style={{ color: r.color, fontWeight: r.bold ? 700 : 400 }}
                >
                  {r.v}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function InvoiceTemplateEngine() {
  const [selected, setSelected] = useState<string>(() =>
    typeof localStorage !== "undefined"
      ? (localStorage.getItem("invoiceTemplate") ?? "classic")
      : "classic",
  );
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewId, setPreviewId] = useState<string>("classic");

  function handleSelect(id: string) {
    setSelected(id);
    localStorage.setItem("invoiceTemplate", id);
    const tpl = TEMPLATES.find((t) => t.id === id);
    toast.success(`Template switched to "${tpl?.name ?? id}"`);
  }

  function handlePreview(id: string) {
    setPreviewId(id);
    setPreviewOpen(true);
  }

  const selectedTpl = TEMPLATES.find((t) => t.id === selected) ?? TEMPLATES[0];
  const previewTpl = TEMPLATES.find((t) => t.id === previewId) ?? TEMPLATES[0];

  return (
    <div className="space-y-5" data-ocid="invoice_template.section">
      {/* Active template badge */}
      <div className="flex items-center gap-3">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ background: selectedTpl.headerBg }}
        >
          <Palette
            className="w-4 h-4"
            style={{ color: selectedTpl.primaryColor }}
          />
        </div>
        <div>
          <p className="text-sm font-semibold text-foreground">
            Invoice Template
          </p>
          <p className="text-xs text-muted-foreground">
            Currently using:{" "}
            <span className="font-medium text-foreground">
              {selectedTpl.name}
            </span>
          </p>
        </div>
        <Badge
          variant="outline"
          className="ml-auto text-xs capitalize"
          style={{
            borderColor: selectedTpl.primaryColor,
            color: selectedTpl.primaryColor,
          }}
        >
          Active
        </Badge>
      </div>

      {/* Template grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
        {TEMPLATES.map((tpl) => (
          <div key={tpl.id} className="space-y-1.5">
            <TemplateThumbnail
              tpl={tpl}
              selected={selected === tpl.id}
              onClick={() => handleSelect(tpl.id)}
            />
            <div className="space-y-0.5 px-0.5">
              <p className="text-xs font-medium text-foreground truncate">
                {tpl.name}
              </p>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-6 text-xs px-1.5 w-full"
                data-ocid={`invoice_template.${tpl.id}.preview_button`}
                onClick={() => handlePreview(tpl.id)}
              >
                Preview
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Description */}
      <p className="text-xs text-muted-foreground bg-muted/30 rounded-lg px-3 py-2">
        {selectedTpl.description}
      </p>

      {/* Full preview dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent
          className="sm:max-w-2xl"
          data-ocid="invoice_template.preview_dialog"
        >
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Palette className="w-4 h-4" />
              {previewTpl.name} — Preview
            </DialogTitle>
          </DialogHeader>
          <TemplateFullPreview tpl={previewTpl} />
          <div className="flex gap-2 pt-2">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              data-ocid="invoice_template.preview_close_button"
              onClick={() => setPreviewOpen(false)}
            >
              Close
            </Button>
            <Button
              type="button"
              className="flex-1"
              data-ocid="invoice_template.preview_use_button"
              style={{
                background: previewTpl.primaryColor,
                color: previewTpl.headerText,
              }}
              onClick={() => {
                handleSelect(previewId);
                setPreviewOpen(false);
              }}
            >
              <Check className="w-4 h-4 mr-1.5" /> Use This Template
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
