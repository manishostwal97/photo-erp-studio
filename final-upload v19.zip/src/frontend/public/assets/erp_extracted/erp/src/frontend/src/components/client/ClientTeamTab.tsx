import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { formatDate, getInitials } from "@/lib/utils";
import type { Invoice, TeamMember } from "@/types";
import { useNavigate } from "@tanstack/react-router";
import { Calendar, MapPin, Users } from "lucide-react";
import { useMemo } from "react";

interface ClientTeamTabProps {
  clientInvoices: Invoice[];
  teamMembers: TeamMember[];
}

export default function ClientTeamTab({
  clientInvoices,
  teamMembers,
}: ClientTeamTabProps) {
  const navigate = useNavigate();

  const assignedMembers = useMemo(() => {
    const map = new Map<
      string,
      {
        member: TeamMember;
        assignments: Array<{
          program?: string;
          date?: string;
          location?: string;
          role?: string;
        }>;
      }
    >();
    for (const inv of clientInvoices) {
      for (const a of inv.teamAssignments ?? []) {
        if (!a.teamMemberId) continue;
        const tm = teamMembers.find((m) => m.id === a.teamMemberId);
        if (!tm) continue;
        const existing = map.get(tm.id);
        const entry = {
          program: a.program,
          date: a.date ?? a.dateRangeStart,
          location: a.location,
          role: a.role,
        };
        if (existing) {
          existing.assignments.push(entry);
        } else {
          map.set(tm.id, { member: tm, assignments: [entry] });
        }
      }
    }
    return Array.from(map.values());
  }, [clientInvoices, teamMembers]);

  if (assignedMembers.length === 0) {
    return (
      <div
        className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3"
        data-ocid="client_profile.team.empty_state"
      >
        <Users className="w-10 h-10 opacity-40" />
        <p className="font-medium">No team members assigned</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {assignedMembers.map(({ member, assignments }, i) => (
        <Card
          key={member.id}
          className="border border-border"
          data-ocid={`client_profile.team.item.${i + 1}`}
        >
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm flex-shrink-0">
                {getInitials(member.name)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-semibold text-sm text-foreground">
                    {member.name}
                  </p>
                  <Badge variant="secondary" className="text-xs">
                    {member.role}
                  </Badge>
                </div>
                <div className="mt-2 space-y-1">
                  {assignments.map((a, idx) => (
                    <div
                      key={`${a.program}-${a.date}-${idx}`}
                      className="text-xs text-muted-foreground flex items-center gap-2 flex-wrap"
                    >
                      {a.program && (
                        <span className="font-medium text-foreground">
                          {a.program}
                        </span>
                      )}
                      {a.date && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(a.date)}
                        </span>
                      )}
                      {a.location && (
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {a.location}
                        </span>
                      )}
                      {a.role && (
                        <Badge variant="outline" className="text-[10px]">
                          {a.role}
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              <button
                type="button"
                className="text-xs text-primary font-medium hover:underline flex-shrink-0"
                onClick={() => navigate({ to: `/team/${member.id}` })}
                data-ocid={`client_profile.team.link.${i + 1}`}
              >
                View Profile
              </button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
