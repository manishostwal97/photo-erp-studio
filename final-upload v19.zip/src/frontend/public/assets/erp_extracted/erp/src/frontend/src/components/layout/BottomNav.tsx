import { useNavigate, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  Box,
  CalendarDays,
  CreditCard,
  FileText,
  LayoutDashboard,
  MoreHorizontal,
  Settings,
  Truck,
  Users,
  Wallet,
  X,
} from "lucide-react";
import { useState } from "react";

interface BottomNavItem {
  label: string;
  path: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  tab?: string;
}

const PRIMARY_ITEMS: BottomNavItem[] = [
  { label: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
  { label: "Invoices", path: "/invoices", icon: FileText },
  { label: "Calendar", path: "/calendar", icon: CalendarDays },
  { label: "Team", path: "/team", icon: Users },
];

const MORE_ITEMS: BottomNavItem[] = [
  { label: "Clients", path: "/clients", icon: CreditCard },
  { label: "Expenses", path: "/expenses", icon: Wallet },
  { label: "Equipment", path: "/equipment-rental", icon: Box },
  { label: "Delivery", path: "/delivery", icon: Truck },
  { label: "Reports", path: "/reports", icon: BarChart3 },
  { label: "Settings", path: "/settings", icon: Settings },
];

export default function BottomNav() {
  const navigate = useNavigate();
  const routerState = useRouterState();
  const pathname = routerState.location.pathname;
  const [moreOpen, setMoreOpen] = useState(false);

  function isActive(path: string) {
    if (path === "/dashboard") return pathname === "/dashboard";
    return pathname === path || pathname.startsWith(`${path}/`);
  }

  const anyMoreActive = MORE_ITEMS.some((item) => isActive(item.path));

  return (
    <>
      {/* More drawer overlay */}
      {moreOpen && (
        <button
          type="button"
          className="fixed inset-0 z-40 bg-black/30 cursor-default"
          onClick={() => setMoreOpen(false)}
          aria-label="Close menu"
        />
      )}

      {/* More drawer panel */}
      <div
        className="fixed left-0 right-0 z-50 bg-card border-t border-border rounded-t-2xl shadow-xl transition-transform duration-300"
        style={{
          bottom: "4rem",
          transform: moreOpen ? "translateY(0)" : "translateY(110%)",
          pointerEvents: moreOpen ? "auto" : "none",
        }}
        data-ocid="bottomnav.more.panel"
      >
        <div className="flex items-center justify-between px-4 pt-4 pb-2">
          <span className="text-sm font-semibold text-foreground">More</span>
          <button
            type="button"
            onClick={() => setMoreOpen(false)}
            className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
            aria-label="Close"
            data-ocid="bottomnav.more.close_button"
          >
            <X size={16} />
          </button>
        </div>
        <div className="grid grid-cols-3 gap-1 px-3 pb-4">
          {MORE_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            return (
              <button
                key={item.label}
                type="button"
                onClick={() => {
                  navigate({ to: item.path });
                  setMoreOpen(false);
                }}
                className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl min-h-[64px] transition-colors ${
                  active
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-accent hover:text-foreground"
                }`}
                data-ocid={`bottomnav.more.${item.label.toLowerCase().replace(/ /g, "_")}.link`}
              >
                <Icon size={20} />
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom nav bar */}
      <nav
        className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border flex items-center lg:hidden"
        style={{
          height: "4rem",
          paddingBottom: "env(safe-area-inset-bottom, 0px)",
        }}
        data-ocid="bottomnav.panel"
      >
        {PRIMARY_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);
          return (
            <button
              key={item.label}
              type="button"
              onClick={() => {
                navigate({ to: item.path });
                setMoreOpen(false);
              }}
              className={`flex flex-col items-center justify-center gap-0.5 flex-1 h-full transition-colors ${
                active ? "text-primary" : "text-muted-foreground"
              }`}
              data-ocid={`bottomnav.${item.label.toLowerCase().replace(/ /g, "_")}.link`}
            >
              <Icon size={22} />
              <span className="text-[10px] font-medium leading-tight">
                {item.label}
              </span>
            </button>
          );
        })}

        {/* More button */}
        <button
          type="button"
          onClick={() => setMoreOpen((v) => !v)}
          className={`flex flex-col items-center justify-center gap-0.5 flex-1 h-full transition-colors ${
            anyMoreActive || moreOpen ? "text-primary" : "text-muted-foreground"
          }`}
          data-ocid="bottomnav.more_button"
        >
          <MoreHorizontal size={22} />
          <span className="text-[10px] font-medium leading-tight">More</span>
        </button>
      </nav>
    </>
  );
}
