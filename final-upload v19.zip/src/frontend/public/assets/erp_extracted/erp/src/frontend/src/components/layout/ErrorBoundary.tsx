import { Button } from "@/components/ui/button";
import { AlertTriangle, RefreshCw } from "lucide-react";
import React from "react";

interface Props {
  children: React.ReactNode;
  moduleName?: string;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // Intentionally silent in production — error is surfaced in the fallback UI
    void error;
    void info;
  }

  handleRetry = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      const { moduleName } = this.props;
      return (
        <div
          className="flex items-center justify-center h-full min-h-[400px] bg-background p-8"
          data-ocid="error_boundary.error_state"
        >
          <div className="bg-card rounded-xl border border-border shadow-sm p-8 max-w-md w-full text-center">
            <div className="flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 mx-auto mb-5">
              <AlertTriangle className="w-7 h-7 text-primary" />
            </div>
            <h2 className="text-lg font-semibold text-foreground mb-2">
              Something went wrong
            </h2>
            <p className="text-sm text-muted-foreground mb-6">
              {moduleName
                ? `The ${moduleName} module encountered an unexpected error.`
                : "An unexpected error occurred."}{" "}
              Reloading the page will usually fix this.
            </p>
            <Button
              onClick={this.handleRetry}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
              data-ocid="error_boundary.primary_button"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Try again
            </Button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
