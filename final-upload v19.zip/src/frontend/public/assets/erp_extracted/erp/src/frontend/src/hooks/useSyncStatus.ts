// ─── useSyncStatus ───────────────────────────────────────────────────────────
// Shared hook for tracking backend sync state across modules.
// Provides a consistent interface for syncing, last-saved timestamps,
// and pending change tracking.

import { useCallback, useState } from "react";

export type SyncPhase = "idle" | "pending" | "syncing" | "synced" | "error";

export interface SyncStatusState {
  phase: SyncPhase;
  lastSavedLabel: string;
  pendingCount: number;
}

export interface UseSyncStatusReturn extends SyncStatusState {
  markPending: () => void;
  markSyncing: () => void;
  markSynced: () => void;
  markError: () => void;
  reset: () => void;
}

function formatLabel(): string {
  return new Date().toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function useSyncStatus(
  initialPhase: SyncPhase = "idle",
): UseSyncStatusReturn {
  const [state, setState] = useState<SyncStatusState>({
    phase: initialPhase,
    lastSavedLabel: "",
    pendingCount: 0,
  });

  const markPending = useCallback(() => {
    setState((prev) => ({
      ...prev,
      phase: "pending",
      pendingCount: prev.pendingCount + 1,
    }));
  }, []);

  const markSyncing = useCallback(() => {
    setState((prev) => ({ ...prev, phase: "syncing" }));
  }, []);

  const markSynced = useCallback(() => {
    setState({
      phase: "synced",
      lastSavedLabel: formatLabel(),
      pendingCount: 0,
    });
  }, []);

  const markError = useCallback(() => {
    setState((prev) => ({ ...prev, phase: "error" }));
  }, []);

  const reset = useCallback(() => {
    setState({ phase: "idle", lastSavedLabel: "", pendingCount: 0 });
  }, []);

  return { ...state, markPending, markSyncing, markSynced, markError, reset };
}
