import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { RentalEntry } from "@/types";
import { Camera, HardDrive, Lightbulb, Package, Plane } from "lucide-react";
import { useMemo } from "react";

const equipmentIcons: Record<string, React.ElementType> = {
  camera: Camera,
  lens: HardDrive,
  drone: Plane,
  light: Lightbulb,
  other: Package,
};

interface ClientRentalsTabProps {
  clientId: string;
}

export default function ClientRentalsTab({ clientId }: ClientRentalsTabProps) {
  const { getClientRentals } = useERPStore();
  const rentals = useMemo(
    () => getClientRentals(clientId),
    [getClientRentals, clientId],
  );

  if (rentals.length === 0) {
    return (
      <div
        className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3"
        data-ocid="client_profile.rentals.empty_state"
      >
        <Package className="w-10 h-10 opacity-40" />
        <p className="font-medium">No equipment rentals</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {rentals.map((rental, i) => {
        const Icon = equipmentIcons[rental.equipmentType] ?? Package;
        return (
          <Card
            key={rental.id}
            className="border border-border"
            data-ocid={`client_profile.rental.item.${i + 1}`}
          >
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-sm text-foreground capitalize">
                      {rental.equipmentType}
                    </p>
                    <Badge
                      className={
                        rental.status === "active"
                          ? "bg-blue-100 text-blue-700 border-blue-200"
                          : "bg-green-100 text-green-700 border-green-200"
                      }
                    >
                      {rental.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Vendor: {rental.vendor}
                  </p>
                  <div className="grid grid-cols-3 gap-2 mt-2">
                    <div>
                      <p className="text-[10px] text-muted-foreground">Rent</p>
                      <p className="text-sm font-semibold text-foreground">
                        {formatCurrency(rental.rentAmount)}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-muted-foreground">Paid</p>
                      <p className="text-sm font-semibold text-green-600">
                        {formatCurrency(rental.paidAmount)}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-muted-foreground">Due</p>
                      <p
                        className={`text-sm font-semibold ${
                          rental.dueAmount > 0
                            ? "text-destructive"
                            : "text-green-600"
                        }`}
                      >
                        {formatCurrency(rental.dueAmount)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground flex-wrap">
                    <span>From: {formatDate(rental.startDate)}</span>
                    {rental.endDate && (
                      <span>To: {formatDate(rental.endDate)}</span>
                    )}
                  </div>
                  {rental.notes && (
                    <p className="text-xs text-muted-foreground mt-1">
                      {rental.notes}
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
