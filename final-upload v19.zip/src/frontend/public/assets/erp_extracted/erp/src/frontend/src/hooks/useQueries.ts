/**
 * useQueries.ts — Photography ERP
 * Single source-of-truth hooks for all ERP data.
 *
 * Design rules:
 *  - All payment totals computed from paymentHistory[]  (never from stale advancePaid/pendingAmount)
 *  - Expense auto-sync: every invoice-payment mutation triggers syncInvoicePaymentExpense
 *  - Rental sync: every rental add/edit fires syncRentalExpense
 *  - No double-counting: each expense carries a deterministic id so upserts are idempotent
 *  - Dashboard stats are always computed fresh from live invoices + expenses
 */

import { useERPStore } from "@/stores/useAppStore";
import type {
  Expense,
  Invoice,
  PaymentHistoryEntry,
  PaymentMode,
  RentalEntry,
  TeamMember,
} from "@/types";
import { useMemo } from "react";

// ─── Shared pure helpers ─────────────────────────────────────────────────────

/**
 * Compute grand total for an invoice from its line-items + GST + extras.
 * This is the single authoritative formula — used everywhere.
 */
export function computeInvoiceGrandTotal(invoice: Invoice): number {
  const dealAmount = Number(invoice.dealAmount) || 0;
  const discount = Number(invoice.discount) || 0;
  const extraChargesTotal = (invoice.packageExtraCharges ?? []).reduce(
    (sum, c) => sum + (Number(c.extraTotal) || 0),
    0,
  );
  const subtotal = dealAmount - discount + extraChargesTotal;
  const gstAmount =
    invoice.gstEnabled && (invoice.gstPercent ?? 0) > 0
      ? subtotal * ((invoice.gstPercent ?? 0) / 100)
      : 0;
  return subtotal + gstAmount;
}

/**
 * Compute total paid on an invoice from its paymentHistory[].
 * Always uses the full history array — never the stale advancePaid field.
 */
export function computeInvoiceTotalPaid(invoice: Invoice): number {
  return (invoice.paymentHistory ?? []).reduce(
    (sum, p) => sum + (Number(p.amount) || 0),
    0,
  );
}

/**
 * Compute remaining balance on an invoice. Always ≥ 0.
 */
export function computeInvoiceBalance(invoice: Invoice): number {
  return Math.max(
    0,
    computeInvoiceGrandTotal(invoice) - computeInvoiceTotalPaid(invoice),
  );
}

/**
 * Deduplicate payment history entries by id.
 * Returns entries sorted oldest→newest by date then createdAt.
 */
export function deduplicatePaymentHistory(
  entries: PaymentHistoryEntry[],
): PaymentHistoryEntry[] {
  const seen = new Set<string>();
  const deduped: PaymentHistoryEntry[] = [];
  for (const entry of entries) {
    if (!seen.has(entry.id)) {
      seen.add(entry.id);
      deduped.push(entry);
    }
  }
  return deduped.sort((a, b) => {
    const dA = new Date(a.date).getTime();
    const dB = new Date(b.date).getTime();
    if (dA !== dB) return dA - dB;
    return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
  });
}

// ─── Expense auto-sync helpers ────────────────────────────────────────────────

/**
 * Generate a deterministic expense id for an invoice payment.
 * Same payment id always → same expense id → upsert is idempotent.
 */
export function invoicePaymentExpenseId(paymentId: string): string {
  return `exp-inv-pay-${paymentId}`;
}

/**
 * Generate a deterministic expense id for a rental.
 */
export function rentalExpenseId(rentalId: string): string {
  return `exp-rental-${rentalId}`;
}

/**
 * Sync a single invoice payment to the expenses array.
 * - add: inserts a new expense (no-op if already exists with same id)
 * - edit: updates existing expense amount/date
 * - delete: removes the expense
 */
export function syncInvoicePaymentToExpenses(
  expenses: Expense[],
  op: "add" | "edit" | "delete",
  payment: PaymentHistoryEntry,
  invoice: Invoice,
): Expense[] {
  const expId = invoicePaymentExpenseId(payment.id);

  if (op === "delete") {
    return expenses.filter((e) => e.id !== expId);
  }

  const expenseEntry: Expense = {
    id: expId,
    date: payment.date,
    vendor: invoice.clientName,
    category: "Invoice Payment",
    amount: Number(payment.amount) || 0,
    paymentMode: (payment.mode as PaymentMode) ?? "other",
    notes: `Payment for invoice ${invoice.invoiceNumber} (payment-id:${payment.id})`,
    clientId: invoice.clientId,
    invoiceId: invoice.id,
    eventName: invoice.customEventName ?? invoice.eventType,
    createdAt: payment.createdAt ?? new Date().toISOString(),
  };

  if (op === "add") {
    // Idempotent: skip if already present, otherwise update
    const alreadyExists = expenses.some((e) => e.id === expId);
    if (alreadyExists) {
      return expenses.map((e) => (e.id === expId ? expenseEntry : e));
    }
    return [expenseEntry, ...expenses];
  }

  // edit
  const exists = expenses.some((e) => e.id === expId);
  if (exists) {
    return expenses.map((e) => (e.id === expId ? expenseEntry : e));
  }
  return [expenseEntry, ...expenses];
}

/**
 * Sync a rental entry to the expenses array.
 * Uses the rental id as the deterministic key.
 */
export function syncRentalToExpenses(
  expenses: Expense[],
  op: "add" | "edit" | "delete",
  rental: RentalEntry,
): Expense[] {
  const expId = rentalExpenseId(rental.id);

  if (op === "delete") {
    return expenses.filter((e) => e.id !== expId);
  }

  const expenseEntry: Expense = {
    id: expId,
    date: rental.startDate,
    vendor: rental.vendor,
    category: `Rental - ${rental.equipmentType}`,
    amount: rental.rentAmount,
    paymentMode: "other",
    notes: `Equipment rental: ${rental.equipmentType} (rental-id:${rental.id})`,
    clientId: rental.clientId,
    invoiceId: rental.invoiceId,
    createdAt: new Date().toISOString(),
  };

  const exists = expenses.some((e) => e.id === expId);
  if (op === "add") {
    if (exists) return expenses.map((e) => (e.id === expId ? expenseEntry : e));
    return [expenseEntry, ...expenses];
  }
  // edit
  if (exists) return expenses.map((e) => (e.id === expId ? expenseEntry : e));
  return [expenseEntry, ...expenses];
}

// ─── Rental conflict detection ────────────────────────────────────────────────

export interface RentalConflict {
  conflictingRental: RentalEntry;
  message: string;
}

/**
 * Detect date-range overlaps for the same equipment type across all rentals.
 * Returns an array of conflicts (empty = no conflicts).
 *
 * Two date ranges [a_start, a_end] and [b_start, b_end] overlap when:
 *   a_start <= b_end  AND  b_start <= a_end
 */
export function detectRentalConflicts(
  allRentals: RentalEntry[],
  candidateRental: Partial<RentalEntry>,
  excludeRentalId?: string,
): RentalConflict[] {
  const { equipmentType, startDate, endDate, id } = candidateRental;
  if (!equipmentType || !startDate) return [];

  const candidateEnd = endDate || startDate;
  const conflicts: RentalConflict[] = [];

  for (const existing of allRentals) {
    if (existing.id === (id ?? excludeRentalId)) continue;
    if (existing.equipmentType !== equipmentType) continue;
    if (existing.status === "returned") continue;

    const exEnd = existing.endDate || existing.startDate;
    const overlaps = startDate <= exEnd && existing.startDate <= candidateEnd;

    if (overlaps) {
      conflicts.push({
        conflictingRental: existing,
        message: `${equipmentType} is already rented from ${existing.startDate} to ${exEnd} (vendor: ${existing.vendor})`,
      });
    }
  }

  return conflicts;
}

// ─── Team payment computations ────────────────────────────────────────────────

export interface TeamMemberPaymentSummary {
  totalEarned: number;
  totalPaid: number;
  totalDue: number;
}

/**
 * Compute totalEarned / totalPaid / totalDue for a team member.
 *
 * totalEarned = sum of (rateUsed × dayType multiplier) across all work history entries.
 * totalPaid   = sum of paymentReceived across all work history entries (deduped).
 * totalDue    = totalEarned - totalPaid  (floor 0)
 *
 * Uses workHistory as the single source of truth for days worked.
 */
export function computeTeamMemberPaymentSummary(
  member: TeamMember,
): TeamMemberPaymentSummary {
  // Deduplicate work history by (assignmentId, date, program) to prevent double-counting
  const seenKeys = new Set<string>();
  const dedupedHistory: NonNullable<TeamMember["workHistory"]> = [];
  for (const entry of member.workHistory ?? []) {
    const key = `${entry.assignmentId ?? entry.invoiceId}-${entry.date}-${entry.program}`;
    if (!seenKeys.has(key)) {
      seenKeys.add(key);
      dedupedHistory.push(entry);
    }
  }

  let totalEarned = 0;
  let totalPaid = 0;

  for (const h of dedupedHistory) {
    const baseRate = Number(h.rateUsed) || 0;
    const effectiveRate = h.dayType === "half" ? baseRate * 0.5 : baseRate;
    totalEarned += effectiveRate;
    totalPaid += Number(h.paymentReceived) || 0;
  }

  return {
    totalEarned,
    totalPaid,
    totalDue: Math.max(0, totalEarned - totalPaid),
  };
}

// ─── React Hooks ──────────────────────────────────────────────────────────────

/** All invoices from the store. */
export function useInvoices() {
  return useERPStore((s) => s.invoices);
}

/** All clients. */
export function useClients() {
  return useERPStore((s) => s.clients);
}

/** All team members. */
export function useTeamMembers() {
  return useERPStore((s) => s.teamMembers);
}

/** All expenses. */
export function useExpenses() {
  return useERPStore((s) => s.expenses);
}

/** All rentals. */
export function useRentals() {
  return useERPStore((s) => s.rentals);
}

/** All delivery trackers. */
export function useDeliveryTrackers() {
  return useERPStore((s) => s.deliveryTrackers);
}

/** All packages. */
export function usePackages() {
  return useERPStore((s) => s.packages);
}

/** All services. */
export function useServices() {
  return useERPStore((s) => s.services);
}

/** Single invoice by id. */
export function useInvoice(id: string | undefined) {
  return useERPStore((s) =>
    id ? s.invoices.find((inv) => inv.id === id) : undefined,
  );
}

/** Single client by id. */
export function useClient(id: string | undefined) {
  return useERPStore((s) =>
    id ? s.clients.find((c) => c.id === id) : undefined,
  );
}

/** Single team member by id. */
export function useTeamMember(id: string | undefined) {
  return useERPStore((s) =>
    id ? s.teamMembers.find((m) => m.id === id) : undefined,
  );
}

/**
 * useInvoicePaymentHistory
 * Returns deduplicated, sorted payment history for an invoice.
 */
export function useInvoicePaymentHistory(invoiceId: string | undefined) {
  const invoice = useInvoice(invoiceId);
  return useMemo(() => {
    if (!invoice) return [];
    return deduplicatePaymentHistory(invoice.paymentHistory ?? []);
  }, [invoice]);
}

/**
 * useInvoiceBalance
 * Returns { grandTotal, totalPaid, balance } computed from live paymentHistory.
 */
export function useInvoiceBalance(invoiceId: string | undefined) {
  const invoice = useInvoice(invoiceId);
  return useMemo(() => {
    if (!invoice) return { grandTotal: 0, totalPaid: 0, balance: 0 };
    const grandTotal = computeInvoiceGrandTotal(invoice);
    const totalPaid = computeInvoiceTotalPaid(invoice);
    const balance = Math.max(0, grandTotal - totalPaid);
    return { grandTotal, totalPaid, balance };
  }, [invoice]);
}

/**
 * useTeamMemberSummary
 * Returns payment summary for a team member, computed from workHistory.
 */
export function useTeamMemberSummary(memberId: string | undefined) {
  const member = useTeamMember(memberId);
  return useMemo(() => {
    if (!member) return { totalEarned: 0, totalPaid: 0, totalDue: 0 };
    return computeTeamMemberPaymentSummary(member);
  }, [member]);
}

/**
 * useAllTeamMemberSummaries
 * Returns payment summaries for every team member.
 */
export function useAllTeamMemberSummaries() {
  const members = useTeamMembers();
  return useMemo(
    () =>
      members.map((m) => ({
        member: m,
        ...computeTeamMemberPaymentSummary(m),
      })),
    [members],
  );
}

/**
 * useClientRentals
 * Returns rentals for a specific client.
 */
export function useClientRentals(clientId: string | undefined) {
  const rentals = useRentals();
  return useMemo(
    () => (clientId ? rentals.filter((r) => r.clientId === clientId) : []),
    [rentals, clientId],
  );
}

/**
 * useClientInvoices
 * Returns invoices for a specific client.
 */
export function useClientInvoices(clientId: string | undefined) {
  const invoices = useInvoices();
  return useMemo(
    () => (clientId ? invoices.filter((inv) => inv.clientId === clientId) : []),
    [invoices, clientId],
  );
}

/**
 * useClientPaymentSummary
 * Returns real-time { totalDue, totalPaid, pendingBalance } computed
 * directly from the invoice paymentHistory — single source of truth.
 *
 * totalDue    = sum of grandTotals of all client invoices
 * totalPaid   = sum of paymentHistory amounts across all client invoices
 * pendingBalance = totalDue - totalPaid
 */
export function useClientPaymentSummary(clientId: string | undefined) {
  const invoices = useClientInvoices(clientId);
  return useMemo(() => {
    let totalDue = 0;
    let totalPaid = 0;
    for (const inv of invoices) {
      totalDue += computeInvoiceGrandTotal(inv);
      totalPaid += computeInvoiceTotalPaid(inv);
    }
    return {
      totalDue,
      totalPaid,
      pendingBalance: Math.max(0, totalDue - totalPaid),
    };
  }, [invoices]);
}

/**
 * useRentalConflictCheck
 * Checks for rental conflicts for a candidate rental.
 */
export function useRentalConflictCheck(
  candidate: Partial<RentalEntry>,
  excludeId?: string,
) {
  const rentals = useRentals();
  return useMemo(
    () => detectRentalConflicts(rentals, candidate, excludeId),
    [rentals, candidate, excludeId],
  );
}

/**
 * useRentalSummary
 * Returns { totalRentAmount, totalPaid, totalDue } across all rentals
 * or filtered by clientId.
 */
export function useRentalSummary(clientId?: string) {
  const rentals = useRentals();
  return useMemo(() => {
    const filtered = clientId
      ? rentals.filter((r) => r.clientId === clientId)
      : rentals;
    let totalRentAmount = 0;
    let totalPaid = 0;
    let totalDue = 0;
    for (const r of filtered) {
      totalRentAmount += Number(r.rentAmount) || 0;
      totalPaid += Number(r.paidAmount) || 0;
      totalDue += Number(r.dueAmount) || 0;
    }
    return { totalRentAmount, totalPaid, totalDue };
  }, [rentals, clientId]);
}

/**
 * useDashboardStats
 * All dashboard stats computed in real-time from live store data.
 * NEVER uses stale advancePaid / pendingAmount — always recomputes.
 */
export function useDashboardStats() {
  const invoices = useInvoices();
  const expenses = useExpenses();
  const teamMembers = useTeamMembers();

  return useMemo(() => {
    const now = new Date();
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const next7 = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

    let totalRevenue = 0;
    let pendingPayments = 0;
    let thisMonthRevenue = 0;
    let activeInvoices = 0;

    for (const inv of invoices) {
      const grandTotal = computeInvoiceGrandTotal(inv);
      const paid = computeInvoiceTotalPaid(inv);
      const balance = Math.max(0, grandTotal - paid);

      totalRevenue += paid;
      pendingPayments += balance;
      if (balance > 0) activeInvoices++;

      // This month revenue: payments made in current month
      for (const p of inv.paymentHistory ?? []) {
        const d = new Date(p.date);
        if (!Number.isNaN(d.getTime()) && d >= thisMonthStart) {
          thisMonthRevenue += Number(p.amount) || 0;
        }
      }
    }

    const totalExpensesAll = expenses.reduce(
      (s, e) => s + (Number(e.amount) || 0),
      0,
    );
    const thisMonthExpenses = expenses
      .filter((e) => {
        const d = new Date(e.date);
        return !Number.isNaN(d.getTime()) && d >= thisMonthStart;
      })
      .reduce((s, e) => s + (Number(e.amount) || 0), 0);

    const netProfit = totalRevenue - totalExpensesAll;
    const monthlyProfit = thisMonthRevenue - thisMonthExpenses;

    const upcomingShoots = invoices.filter((inv) => {
      if (!inv.eventStartDate) return false;
      const d = new Date(inv.eventStartDate);
      return !Number.isNaN(d.getTime()) && d >= now && d <= next7;
    }).length;

    const totalClients = new Set(
      invoices.map((inv) => inv.clientId).filter(Boolean),
    ).size;

    let totalTeamEarned = 0;
    let totalTeamPaid = 0;
    for (const m of teamMembers) {
      const s = computeTeamMemberPaymentSummary(m);
      totalTeamEarned += s.totalEarned;
      totalTeamPaid += s.totalPaid;
    }
    const totalTeamDue = Math.max(0, totalTeamEarned - totalTeamPaid);

    return {
      totalRevenue,
      pendingPayments,
      monthlyProfit,
      netProfit,
      upcomingShoots,
      totalClients,
      activeInvoices,
      totalExpenses: totalExpensesAll,
      thisMonthRevenue,
      thisMonthExpenses,
      totalTeamEarned,
      totalTeamPaid,
      totalTeamDue,
    };
  }, [invoices, expenses, teamMembers]);
}

/**
 * useExpensesByCategory
 * Returns expenses grouped by category for reports.
 */
export function useExpensesByCategory(year?: number, month?: number) {
  const expenses = useExpenses();
  return useMemo(() => {
    const filtered = expenses.filter((e) => {
      const d = new Date(e.date);
      if (Number.isNaN(d.getTime())) return false;
      if (year !== undefined && d.getFullYear() !== year) return false;
      if (month !== undefined && d.getMonth() + 1 !== month) return false;
      return true;
    });

    const grouped: Record<
      string,
      { category: string; total: number; count: number }
    > = {};
    for (const e of filtered) {
      const cat = e.category || "Uncategorized";
      if (!grouped[cat]) grouped[cat] = { category: cat, total: 0, count: 0 };
      grouped[cat].total += Number(e.amount) || 0;
      grouped[cat].count++;
    }
    return Object.values(grouped).sort((a, b) => b.total - a.total);
  }, [expenses, year, month]);
}

/**
 * useMonthlyRevenueChart
 * Returns 6-month revenue bar chart data computed from paymentHistory.
 */
export function useMonthlyRevenueChart() {
  const invoices = useInvoices();
  return useMemo(() => {
    const now = new Date();
    const months: { name: string; revenue: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push({
        name: d.toLocaleDateString("en-IN", { month: "short" }),
        revenue: 0,
      });
    }
    for (const inv of invoices) {
      for (const p of inv.paymentHistory ?? []) {
        const d = new Date(p.date);
        if (Number.isNaN(d.getTime())) continue;
        for (let i = 0; i < 6; i++) {
          const ref = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
          const refEnd = new Date(
            now.getFullYear(),
            now.getMonth() - (5 - i) + 1,
            0,
          );
          if (d >= ref && d <= refEnd) {
            months[i].revenue += Number(p.amount) || 0;
            break;
          }
        }
      }
    }
    return months;
  }, [invoices]);
}

/**
 * useInvoicesByStatus
 * Groups invoices by payment status computed from real paymentHistory.
 */
export function useInvoicesByStatus() {
  const invoices = useInvoices();
  return useMemo(() => {
    const groups: Record<string, Invoice[]> = {
      paid: [],
      partial: [],
      pending: [],
      overdue: [],
    };
    for (const inv of invoices) {
      const balance = computeInvoiceBalance(inv);
      const paid = computeInvoiceTotalPaid(inv);
      let status: string;
      if (balance <= 0) {
        status = "paid";
      } else if (paid > 0) {
        status = "partial";
      } else if (
        inv.eventStartDate &&
        new Date(inv.eventStartDate) < new Date()
      ) {
        status = "overdue";
      } else {
        status = "pending";
      }
      groups[status].push(inv);
    }
    return groups;
  }, [invoices]);
}

/**
 * useUpcomingEvents
 * Returns invoices with events in the next N days.
 */
export function useUpcomingEvents(days = 30) {
  const invoices = useInvoices();
  return useMemo(() => {
    const now = new Date();
    const cutoff = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
    return invoices
      .filter((inv) => {
        if (!inv.eventStartDate) return false;
        const d = new Date(inv.eventStartDate);
        return !Number.isNaN(d.getTime()) && d >= now && d <= cutoff;
      })
      .sort(
        (a, b) =>
          new Date(a.eventStartDate).getTime() -
          new Date(b.eventStartDate).getTime(),
      );
  }, [invoices, days]);
}

/**
 * useDeliveryTrackerForInvoice
 * Returns the delivery tracker for a specific invoice.
 */
export function useDeliveryTrackerForInvoice(invoiceId: string | undefined) {
  const trackers = useDeliveryTrackers();
  return useMemo(
    () =>
      invoiceId ? trackers.find((t) => t.invoiceId === invoiceId) : undefined,
    [trackers, invoiceId],
  );
}

/**
 * useRentalById — single rental by id.
 */
export function useRentalById(rentalId: string | undefined) {
  const rentals = useRentals();
  return useMemo(
    () => (rentalId ? rentals.find((r) => r.id === rentalId) : undefined),
    [rentals, rentalId],
  );
}

/**
 * computeRentalStatus
 * Auto-derives rental status: 'returned' if fully paid, else 'active'.
 */
export function computeRentalStatus(
  rental: RentalEntry,
): RentalEntry["status"] {
  const due = Number(rental.rentAmount) - Number(rental.paidAmount);
  return due <= 0 ? "returned" : "active";
}

/**
 * useTeamAssignmentsForInvoice
 * Returns all team assignments for an invoice.
 */
export function useTeamAssignmentsForInvoice(invoiceId: string | undefined) {
  const invoice = useInvoice(invoiceId);
  return useMemo(() => invoice?.teamAssignments ?? [], [invoice]);
}

/**
 * useSearchInvoices
 * Filter invoices by a search term across client name, invoice number, event type.
 */
export function useSearchInvoices(query: string) {
  const invoices = useInvoices();
  return useMemo(() => {
    if (!query.trim()) return invoices;
    const q = query.toLowerCase();
    return invoices.filter(
      (inv) =>
        inv.clientName.toLowerCase().includes(q) ||
        inv.invoiceNumber.toLowerCase().includes(q) ||
        inv.eventType.toLowerCase().includes(q) ||
        (inv.customEventName ?? "").toLowerCase().includes(q),
    );
  }, [invoices, query]);
}

/**
 * useSearchTeamMembers
 * Filter team members by name or role.
 */
export function useSearchTeamMembers(query: string) {
  const members = useTeamMembers();
  return useMemo(() => {
    if (!query.trim()) return members;
    const q = query.toLowerCase();
    return members.filter(
      (m) =>
        m.name.toLowerCase().includes(q) || m.role.toLowerCase().includes(q),
    );
  }, [members, query]);
}

/**
 * useSearchExpenses
 * Filter expenses by vendor, category, or notes.
 */
export function useSearchExpenses(query: string) {
  const expenses = useExpenses();
  return useMemo(() => {
    if (!query.trim()) return expenses;
    const q = query.toLowerCase();
    return expenses.filter(
      (e) =>
        (e.vendor ?? "").toLowerCase().includes(q) ||
        (e.category ?? "").toLowerCase().includes(q) ||
        (e.notes ?? "").toLowerCase().includes(q),
    );
  }, [expenses, query]);
}
