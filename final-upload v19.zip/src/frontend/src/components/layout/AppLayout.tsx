import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { useInitData } from "@/hooks/useInitData";
import { getInitials } from "@/lib/utils";
import { useAppStore } from "@/stores/useAppStore";
import { useStudioStore } from "@/stores/useStudioStore";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { Bell, Menu, Plus } from "lucide-react";
import { useEffect } from "react";
import type { ReactNode } from "react";
import Sidebar from "./Sidebar";

const PAGE_TITLES: Record<string, string> = {
  "/dashboard": "Dashboard",
  "/invoices": "Invoices",
  "/invoices/new": "Create Invoice",
  "/clients": "Clients",
  "/team": "Team Management",
  "/services": "Services",
  "/expenses": "Expenses",
  "/calendar": "Calendar",
  "/delivery": "Delivery Tracker",
  "/equipment-rental": "Equipment Rental",
  "/reports": "Reports & Analytics",
  "/settings": "Settings",
};

function getPageTitle(pathname: string): string {
  if (PAGE_TITLES[pathname]) return PAGE_TITLES[pathname];
  if (pathname.startsWith("/invoices/") && pathname.endsWith("/edit"))
    return "Edit Invoice";
  if (pathname.startsWith("/invoices/")) return "Invoice Detail";
  if (pathname.startsWith("/clients/")) return "Client Profile";
  if (pathname.startsWith("/team/")) return "Team Member";
  return "Photography Invoice Studio";
}

interface AppLayoutProps {
  children: ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const { location } = useRouterState();
  const sidebarOpen = useAppStore((s) => s.sidebarOpen);
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen);
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);
  const notifications = useAppStore((s) => s.notifications);
  const unreadCount = useAppStore((s) => s.unreadCount);
  const studioProfile = useStudioStore((s) => s.studioProfile);
  const navigate = useNavigate();
  const pageTitle = getPageTitle(location.pathname);
  const ownerInitials = getInitials(
    studioProfile?.ownerName ?? "Studio Manager",
  );

  // Hydrate cache on mount when authenticated
  useInitData();

  // Close sidebar on route change (mobile)
  // biome-ignore lint/correctness/useExhaustiveDependencies: location.pathname triggers the effect intentionally
  useEffect(() => {
    setSidebarOpen(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Desktop sidebar */}
      <div className="hidden lg:flex lg:flex-shrink-0">
        <div className="w-64">
          <Sidebar />
        </div>
      </div>

      {/* Mobile sidebar (Sheet) */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="p-0 w-64">
          <Sidebar onClose={() => setSidebarOpen(false)} />
        </SheetContent>
      </Sheet>

      {/* Main content */}
      <div className="flex flex-1 flex-col min-w-0 overflow-hidden">
        {/* Top header */}
        <header className="bg-card border-b border-border shadow-card flex items-center justify-between px-4 py-3 lg:px-6 flex-shrink-0">
          <div className="flex items-center gap-3">
            {/* Hamburger (mobile) */}
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={toggleSidebar}
              data-ocid="nav.menu.button"
            >
              <Menu className="w-5 h-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
            <h1 className="font-display font-semibold text-lg text-foreground">
              {pageTitle}
            </h1>
          </div>

          <div className="flex items-center gap-2">
            {/* Notification bell */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="relative"
                  data-ocid="nav.notifications.button"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <Badge className="absolute -top-1 -right-1 min-w-[18px] h-[18px] p-0 flex items-center justify-center text-[10px] bg-primary text-primary-foreground rounded-full">
                      {unreadCount > 9 ? "9+" : unreadCount}
                    </Badge>
                  )}
                  <span className="sr-only">Notifications</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="end"
                className="w-80"
                data-ocid="nav.notifications.popover"
              >
                <DropdownMenuLabel className="font-display">
                  Notifications
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                {notifications.length === 0 ? (
                  <div className="py-6 text-center text-sm text-muted-foreground">
                    No notifications yet
                  </div>
                ) : (
                  notifications.slice(0, 5).map((n) => (
                    <DropdownMenuItem
                      key={n.id}
                      className={`flex-col items-start gap-1 py-3 ${!n.isRead ? "bg-primary/5" : ""}`}
                    >
                      <span className="font-medium text-sm">{n.title}</span>
                      <span className="text-xs text-muted-foreground line-clamp-2">
                        {n.message}
                      </span>
                    </DropdownMenuItem>
                  ))
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User avatar + role */}
            <div className="flex items-center gap-2">
              <Avatar className="w-8 h-8">
                <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">
                  {ownerInitials}
                </AvatarFallback>
              </Avatar>
              <div className="hidden sm:block">
                <p className="text-sm font-medium text-foreground leading-none">
                  {studioProfile?.ownerName || "Studio Manager"}
                </p>
                <Badge
                  variant="secondary"
                  className="mt-0.5 text-[10px] h-4 px-1.5"
                >
                  Admin
                </Badge>
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 min-w-0 overflow-x-hidden overflow-y-auto bg-background p-4 pb-24 lg:p-6 lg:pb-6">
          {children}
        </main>
      </div>

      {/* Floating Action Button — mobile/tablet only */}
      {/* z-50 ensures visibility above all content including modals (z-50 backdrop) */}
      {/* bottom offset: 4rem (bottom-nav height) + 1.25rem gap + safe-area */}
      <button
        type="button"
        className="fixed right-4 bottom-0 z-[999] w-14 h-14 rounded-full bg-primary hover:bg-primary/90 active:scale-95 text-primary-foreground shadow-2xl transition-all duration-200 flex items-center justify-center lg:hidden"
        style={{ bottom: "calc(env(safe-area-inset-bottom, 0px) + 4.5rem)" }}
        onClick={() => navigate({ to: "/invoices/new" })}
        aria-label="Create New Invoice"
        data-ocid="fab.create_invoice_button"
      >
        <Plus className="w-7 h-7 stroke-2" />
      </button>
    </div>
  );
}
