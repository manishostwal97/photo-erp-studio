import { CalendarCheck, CalendarDays, FileText } from "lucide-react";
import { useMemo } from "react";

interface UpcomingItem {
  id: string;
  title: string;
  courseName: string;
  dueDate: string;
  points: number;
  type: string;
  source: "assignment" | "calendar";
}

export function ParentUpcomingTab({
  studentId: _studentId,
}: { studentId: string }) {
  const upcoming = useMemo((): UpcomingItem[] => {
    const items: UpcomingItem[] = [];
    const now = new Date();
    const past2Days = new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000);
    const cutoff = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000);

    // ── Curriculum assignments ──
    try {
      const raw = localStorage.getItem("edunite_curriculum");
      if (raw) {
        const curriculum = JSON.parse(raw);
        const courses = Array.isArray(curriculum.courses)
          ? curriculum.courses
          : [];
        for (const course of courses) {
          for (const unit of course.units ?? []) {
            for (const mod of unit.modules ?? []) {
              for (const a of [
                ...(mod.assignments ?? []),
                ...(mod.assessments ?? []),
              ]) {
                if (!a.dueDate) continue;
                const due = new Date(a.dueDate);
                if (due >= past2Days && due <= cutoff) {
                  items.push({
                    id: String(a.id),
                    title: a.title,
                    courseName: course.title,
                    dueDate: a.dueDate,
                    points: a.points ?? a.totalPoints ?? 0,
                    type: a.assignmentType ?? "Assessment",
                    source: "assignment",
                  });
                }
              }
            }
          }
        }
      }
    } catch {
      /* ignore */
    }

    // ── Calendar events ──
    try {
      const raw = localStorage.getItem("edunite_calendar_events");
      if (raw) {
        const events = JSON.parse(raw) as Array<{
          id: string;
          title: string;
          date: string;
          type?: string;
          courseId?: string;
        }>;
        for (const ev of events) {
          if (!ev.date) continue;
          const due = new Date(ev.date);
          if (due >= past2Days && due <= cutoff) {
            items.push({
              id: ev.id,
              title: ev.title,
              courseName: ev.type ?? "School Event",
              dueDate: ev.date,
              points: 0,
              type: ev.type ?? "Event",
              source: "calendar",
            });
          }
        }
      }
    } catch {
      /* ignore */
    }

    return items.sort(
      (a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime(),
    );
  }, []);

  if (upcoming.length === 0) {
    return (
      <div
        className="py-12 text-center"
        data-ocid="portal.upcoming.empty_state"
      >
        <CalendarCheck
          size={32}
          className="mx-auto mb-3 text-muted-foreground/30"
        />
        <p className="text-sm text-muted-foreground">
          No upcoming assignments or events in the next 2 weeks
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2 pt-4" data-ocid="portal.upcoming.list">
      <p className="text-xs text-muted-foreground mb-3">
        Assignments and events due or happening in the next 14 days
      </p>
      {upcoming.map((item, idx) => {
        const due = new Date(item.dueDate);
        const daysUntil = Math.ceil(
          (due.getTime() - Date.now()) / (1000 * 60 * 60 * 24),
        );
        const isUrgent = daysUntil >= 0 && daysUntil <= 3;
        const isPast = daysUntil < 0;
        return (
          <div
            key={`${item.id}-${item.source}-${item.dueDate}`}
            className="flex items-center justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3"
            data-ocid={`portal.upcoming.item.${idx + 1}`}
          >
            <div className="flex items-center gap-3 min-w-0">
              {item.source === "calendar" ? (
                <CalendarDays
                  size={15}
                  className="text-primary flex-shrink-0"
                />
              ) : (
                <FileText
                  size={15}
                  className="text-muted-foreground flex-shrink-0"
                />
              )}
              <div className="min-w-0">
                <p className="text-sm font-medium text-foreground truncate">
                  {item.title}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {item.courseName}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 flex-shrink-0 text-right">
              <div>
                <p className="text-xs font-medium text-foreground">
                  {due.toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                  })}
                </p>
                <p
                  className={`text-[10px] font-semibold ${
                    isPast
                      ? "text-muted-foreground"
                      : isUrgent
                        ? "text-destructive"
                        : "text-muted-foreground"
                  }`}
                >
                  {isPast
                    ? "Past"
                    : daysUntil === 0
                      ? "Today"
                      : daysUntil === 1
                        ? "Tomorrow"
                        : `${daysUntil} days`}
                </p>
              </div>
              {item.points > 0 && (
                <span className="text-xs text-muted-foreground whitespace-nowrap">
                  {item.points}pt
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
