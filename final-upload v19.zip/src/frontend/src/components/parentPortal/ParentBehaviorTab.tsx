import { Badge } from "@/components/ui/badge";
import { ShieldCheck } from "lucide-react";
import { useMemo } from "react";

interface BehaviorEntry {
  entryId?: string | number;
  studentName?: string;
  category?: string;
  severity?: string;
  description?: string;
  consequence?: string;
  entryType?: string;
  loggedAt?: number | string | bigint;
}

function formatDate(ts: number | string | bigint | undefined | null): string {
  if (ts == null) return "";
  try {
    const n = typeof ts === "bigint" ? Number(ts) / 1_000_000 : Number(ts);
    const d = new Date(n > 1e12 ? n / 1000 : n);
    if (Number.isNaN(d.getTime())) return "";
    return d.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  } catch {
    return "";
  }
}

const SEVERITY_STYLE: Record<string, string> = {
  minor: "bg-amber-100 text-amber-700 border-amber-200",
  moderate: "bg-orange-100 text-orange-700 border-orange-200",
  major: "bg-red-100 text-red-700 border-red-200",
  severe: "bg-red-100 text-red-700 border-red-200",
};

export function ParentBehaviorTab({ studentName }: { studentName: string }) {
  const entries = useMemo((): BehaviorEntry[] => {
    try {
      const raw = localStorage.getItem("edunite_behavior_logs");
      if (!raw) return [];
      const logs = JSON.parse(raw) as BehaviorEntry[];
      return logs
        .filter(
          (l) => l.studentName === studentName && l.entryType !== "praise",
        )
        .sort((a, b) => {
          const ta =
            typeof a.loggedAt === "bigint"
              ? Number(a.loggedAt)
              : Number(a.loggedAt ?? 0);
          const tb =
            typeof b.loggedAt === "bigint"
              ? Number(b.loggedAt)
              : Number(b.loggedAt ?? 0);
          return tb - ta;
        });
    } catch {
      return [];
    }
  }, [studentName]);

  if (entries.length === 0) {
    return (
      <div
        className="flex flex-col items-center gap-4 py-12 text-center"
        data-ocid="portal.behavior.empty_state"
      >
        <ShieldCheck size={36} className="text-emerald-400" />
        <div>
          <p className="text-sm font-semibold text-foreground">
            No behavior incidents recorded
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            This student has a clean behavior record.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3 pt-2" data-ocid="portal.behavior.panel">
      <p className="text-xs text-muted-foreground">
        {entries.length} behavior {entries.length === 1 ? "entry" : "entries"}{" "}
        on record, most recent first.
      </p>
      {entries.map((entry, i) => (
        <div
          key={String(entry.entryId ?? i)}
          className="rounded-xl border border-border bg-card p-4 space-y-2"
          data-ocid={`portal.behavior.item.${i + 1}`}
        >
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2 flex-wrap">
              {entry.category && (
                <Badge variant="outline" className="text-[11px]">
                  {entry.category}
                </Badge>
              )}
              {entry.severity && (
                <span
                  className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold border capitalize ${
                    SEVERITY_STYLE[entry.severity] ??
                    "bg-slate-100 text-slate-600 border-slate-200"
                  }`}
                >
                  {entry.severity}
                </span>
              )}
            </div>
            {entry.loggedAt && (
              <span className="text-[11px] text-muted-foreground">
                {formatDate(entry.loggedAt)}
              </span>
            )}
          </div>
          {entry.description && (
            <p className="text-sm text-foreground">{entry.description}</p>
          )}
          {entry.consequence && (
            <p className="text-xs text-muted-foreground">
              <span className="font-semibold">Consequence:</span>{" "}
              {entry.consequence}
            </p>
          )}
        </div>
      ))}
    </div>
  );
}
