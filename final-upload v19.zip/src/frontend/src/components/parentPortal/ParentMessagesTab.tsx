import { MessageSquare } from "lucide-react";
import { useMemo, useState } from "react";
import { getMessages } from "../../lib/communicationStore";

export function ParentMessagesTab({ studentName }: { studentName: string }) {
  const [replyTexts, setReplyTexts] = useState<Record<string, string>>({});
  const [replies, setReplies] = useState<
    Record<string, Array<{ text: string; ts: number }>>
  >(() => {
    try {
      const raw = localStorage.getItem("edunite_parent_replies");
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });

  void studentName;

  function submitReply(msgId: string | number) {
    const msgKey = String(msgId);
    const text = replyTexts[msgKey]?.trim();
    if (!text) return;
    const newReply = { text, ts: Date.now() };
    const updated = {
      ...replies,
      [msgKey]: [...(replies[msgKey] ?? []), newReply],
    };
    setReplies(updated);
    localStorage.setItem("edunite_parent_replies", JSON.stringify(updated));
    setReplyTexts((p) => ({ ...p, [msgKey]: "" }));
  }

  const messages = useMemo(() => {
    try {
      return getMessages().filter((m) =>
        m.thread?.some((t) => t.from === "parent"),
      );
    } catch {
      return [];
    }
  }, []);

  const unreadCount = useMemo(() => {
    return messages.filter(
      (m) => m.status !== "read" && m.thread.some((t) => t.from === "parent"),
    ).length;
  }, [messages]);

  if (messages.length === 0) {
    return (
      <div
        className="flex flex-col items-center gap-3 py-12 text-center"
        data-ocid="portal.messages.empty_state"
      >
        <MessageSquare className="h-10 w-10 text-muted-foreground/30" />
        <div>
          <p className="text-sm font-medium text-muted-foreground">
            No messages
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Messages from your child's teacher will appear here.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3" data-ocid="portal.messages.panel">
      {unreadCount > 0 && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/10 border border-primary/20 text-sm text-primary font-medium">
          <span className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center">
            {unreadCount}
          </span>
          {unreadCount} unread message{unreadCount !== 1 ? "s" : ""}
        </div>
      )}
      {messages.map((msg, i) => {
        const hasParentReply = msg.thread.some((t) => t.from === "parent");
        const isUnread = msg.status !== "read" && hasParentReply;
        return (
          <div
            key={msg.id}
            className={`rounded-xl border bg-card p-4 space-y-2 ${isUnread ? "border-primary/30 bg-primary/5" : "border-border"}`}
            data-ocid={`portal.messages.item.${i + 1}`}
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-sm font-semibold text-foreground">
                  {msg.subject}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {new Date(msg.sentAt).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  })}
                </p>
              </div>
              {isUnread && (
                <span
                  className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-destructive text-destructive-foreground"
                  data-ocid={`portal.messages.unread.${i + 1}`}
                >
                  New
                </span>
              )}
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {msg.body}
            </p>
            {msg.thread.length > 0 && (
              <div className="mt-3 space-y-2 border-t border-border pt-3">
                <p className="text-[10px] font-semibold text-muted-foreground">
                  Thread
                </p>
                {msg.thread.map((t) => {
                  const isParent = t.from === "parent";
                  const threadTime = t.date
                    ? new Date(t.date).toLocaleString("en-US", {
                        month: "short",
                        day: "numeric",
                        hour: "numeric",
                        minute: "2-digit",
                      })
                    : "";
                  return (
                    <div
                      key={t.id}
                      className={`flex flex-col ${isParent ? "items-end" : "items-start"}`}
                    >
                      <div
                        className={`max-w-[85%] rounded-2xl px-3 py-2 text-xs leading-relaxed ${isParent ? "bg-primary text-primary-foreground rounded-br-sm" : "bg-muted text-foreground rounded-bl-sm"}`}
                      >
                        {t.body}
                      </div>
                      <div className="flex items-center gap-1.5 mt-0.5 px-1">
                        <span className="text-[10px] text-muted-foreground capitalize font-medium">
                          {t.from}
                        </span>
                        {threadTime && (
                          <span className="text-[10px] text-muted-foreground/60">
                            {threadTime}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
                {(replies[String(msg.id)] ?? []).map((r) => (
                  <div key={r.ts} className="flex flex-col items-end">
                    <div className="max-w-[85%] rounded-2xl rounded-br-sm px-3 py-2 text-xs leading-relaxed bg-primary/80 text-primary-foreground">
                      {r.text}
                    </div>
                    <div className="flex items-center gap-1.5 mt-0.5 px-1">
                      <span className="text-[10px] text-muted-foreground font-medium">
                        You
                      </span>
                      <span className="text-[10px] text-muted-foreground/60">
                        {new Date(r.ts).toLocaleString("en-US", {
                          month: "short",
                          day: "numeric",
                          hour: "numeric",
                          minute: "2-digit",
                        })}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div
              className="mt-3 border-t border-border pt-3 flex gap-2"
              data-ocid={`portal.messages.reply.${i + 1}`}
            >
              <input
                type="text"
                placeholder="Write a reply\u2026"
                value={replyTexts[String(msg.id)] ?? ""}
                onChange={(e) =>
                  setReplyTexts((p) => ({ ...p, [msg.id]: e.target.value }))
                }
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    submitReply(msg.id);
                  }
                }}
                className="flex-1 h-8 px-3 rounded-md border border-border bg-background text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                data-ocid={`portal.messages.reply.input.${i + 1}`}
              />
              <button
                type="button"
                onClick={() => submitReply(msg.id)}
                disabled={!replyTexts[msg.id]?.trim()}
                className="h-8 px-3 rounded-md bg-primary text-primary-foreground text-xs font-medium disabled:opacity-40 hover:bg-primary/90 transition-colors"
                data-ocid={`portal.messages.reply.submit_button.${i + 1}`}
              >
                Send
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
