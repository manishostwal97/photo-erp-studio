import { CalendarCheck } from "lucide-react";
import { useMemo } from "react";

interface AttendanceRecord {
  studentId?: string;
  date?: string;
  status?: string;
}

function parseAttendanceRecords(studentId: string): AttendanceRecord[] {
  try {
    const raw = localStorage.getItem("edunite_attendance");
    if (!raw) return [];
    const data = JSON.parse(raw);
    // Support both array format and nested object format
    if (Array.isArray(data)) {
      return data.filter((r: AttendanceRecord) => r.studentId === studentId);
    }
    // Object keyed by date: { [date]: { [studentId]: { status } } }
    const records: AttendanceRecord[] = [];
    for (const [date, dayData] of Object.entries(
      data as Record<string, unknown>,
    )) {
      if (dayData && typeof dayData === "object") {
        const studentData = (dayData as Record<string, unknown>)[studentId];
        if (studentData && typeof studentData === "object") {
          const entry = studentData as { status?: string };
          if (entry.status) {
            records.push({ studentId, date, status: entry.status });
          }
        }
      }
    }
    return records;
  } catch {
    return [];
  }
}

const STATUS_COLOR: Record<string, string> = {
  present: "bg-emerald-500",
  absent: "bg-red-500",
  tardy: "bg-amber-400",
  late: "bg-amber-400",
  excused: "bg-slate-400",
  "no-data": "bg-muted",
};

const STATUS_LABEL: Record<string, string> = {
  present: "P",
  absent: "A",
  tardy: "T",
  late: "L",
  excused: "E",
  "no-data": "·",
};

export function ParentAttendanceTab({ studentId }: { studentId: string }) {
  const records = useMemo(() => parseAttendanceRecords(studentId), [studentId]);

  const stats = useMemo(() => {
    const present = records.filter((r) => r.status === "present").length;
    const absent = records.filter((r) => r.status === "absent").length;
    const tardy = records.filter(
      (r) => r.status === "tardy" || r.status === "late",
    ).length;
    const excused = records.filter((r) => r.status === "excused").length;
    const total = records.length;
    const presentPct = total > 0 ? Math.round((present / total) * 100) : 0;
    const absentPct = total > 0 ? Math.round((absent / total) * 100) : 0;
    const tardyPct = total > 0 ? Math.round((tardy / total) * 100) : 0;
    const excusedPct = total > 0 ? Math.round((excused / total) * 100) : 0;
    return {
      present,
      absent,
      tardy,
      excused,
      total,
      presentPct,
      absentPct,
      tardyPct,
      excusedPct,
    };
  }, [records]);

  // Build 4-week dot grid
  const weeks = useMemo(() => {
    const result: {
      label: string;
      days: { date: string; status: string }[];
    }[] = [];
    const today = new Date();
    for (let w = 3; w >= 0; w--) {
      const mon = new Date(today);
      const dayOfWeek = today.getDay();
      mon.setDate(
        today.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1) - w * 7,
      );
      const days: { date: string; status: string }[] = [];
      for (let d = 0; d < 5; d++) {
        const day = new Date(mon);
        day.setDate(mon.getDate() + d);
        const iso = day.toISOString().split("T")[0];
        const rec = records.find((r) => r.date === iso);
        days.push({ date: iso, status: rec?.status ?? "no-data" });
      }
      result.push({
        label: mon.toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
        }),
        days,
      });
    }
    return result;
  }, [records]);

  if (records.length === 0) {
    return (
      <div
        className="flex flex-col items-center gap-3 py-12 text-center"
        data-ocid="portal.attendance.empty_state"
      >
        <CalendarCheck className="h-10 w-10 text-muted-foreground/30" />
        <div>
          <p className="text-sm font-medium text-muted-foreground">
            No attendance records available
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Attendance is recorded by the teacher during class.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5" data-ocid="portal.attendance.panel">
      {/* Stat cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          {
            label: "Present",
            count: stats.present,
            pct: stats.presentPct,
            color: "text-emerald-600",
          },
          {
            label: "Absent",
            count: stats.absent,
            pct: stats.absentPct,
            color: "text-red-600",
          },
          {
            label: "Tardy",
            count: stats.tardy,
            pct: stats.tardyPct,
            color: "text-amber-600",
          },
          {
            label: "Excused",
            count: stats.excused,
            pct: stats.excusedPct,
            color: "text-slate-500",
          },
        ].map(({ label, count, pct, color }) => (
          <div
            key={label}
            className="rounded-xl border border-border bg-card p-4 text-center"
          >
            <p className={`text-2xl font-bold ${color}`}>{count}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
            <p className="text-[11px] font-semibold text-muted-foreground">
              {pct}%
            </p>
          </div>
        ))}
      </div>

      {/* 4-week dot grid */}
      <div className="rounded-xl border border-border bg-card p-4 space-y-3">
        <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
          4-Week History
        </p>
        <div className="space-y-2">
          <div className="grid grid-cols-6 gap-1 text-center">
            <span />
            {["Mon", "Tue", "Wed", "Thu", "Fri"].map((d) => (
              <span
                key={d}
                className="text-[10px] font-medium text-muted-foreground"
              >
                {d}
              </span>
            ))}
          </div>
          {weeks.map((week) => (
            <div
              key={week.label}
              className="grid grid-cols-6 gap-1 items-center"
            >
              <span className="text-[10px] text-muted-foreground">
                {week.label}
              </span>
              {week.days.map((day) => (
                <div
                  key={day.date}
                  title={`${day.date}: ${day.status}`}
                  className={`h-7 rounded flex items-center justify-center text-[10px] font-bold text-white ${
                    STATUS_COLOR[day.status] ?? STATUS_COLOR["no-data"]
                  }`}
                >
                  {STATUS_LABEL[day.status] ?? "·"}
                </div>
              ))}
            </div>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-4 pt-1">
          {["present", "absent", "tardy", "excused", "no-data"].map((s) => (
            <span key={s} className="flex items-center gap-1">
              <span
                className={`w-3 h-3 rounded-sm ${STATUS_COLOR[s] ?? "bg-muted"}`}
              />
              <span className="text-[10px] text-muted-foreground capitalize">
                {s === "no-data" ? "No data" : s}
              </span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
