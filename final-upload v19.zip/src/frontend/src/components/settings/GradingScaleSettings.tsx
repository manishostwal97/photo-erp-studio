import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ChevronDown, Plus, Trash2, Zap } from "lucide-react";
import type React from "react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { getAssignmentTypes } from "../../lib/assignmentTypes";
import {
  type CategoryWeights,
  autoBalanceWeights,
  getWeightsForTypes,
  saveClassWeights,
} from "../../lib/categoryWeights";
import {
  type GradingPeriod,
  getGradingPeriods,
  saveGradingPeriods,
} from "../../lib/gradingPeriods";
import { SectionCard } from "./settingsShared";

// ─── Types ───────────────────────────────────────────────────────────────────

interface GradeBand {
  id: string;
  letter: string;
  minPct: number;
  maxPct: number;
  gpa: number;
  passFail: "pass" | "fail";
}

const DEFAULT_GRADE_BANDS: GradeBand[] = [
  {
    id: "gb-A",
    letter: "A",
    minPct: 90,
    maxPct: 100,
    gpa: 4.0,
    passFail: "pass",
  },
  {
    id: "gb-B",
    letter: "B",
    minPct: 80,
    maxPct: 89,
    gpa: 3.0,
    passFail: "pass",
  },
  {
    id: "gb-C",
    letter: "C",
    minPct: 70,
    maxPct: 79,
    gpa: 2.0,
    passFail: "pass",
  },
  {
    id: "gb-D",
    letter: "D",
    minPct: 60,
    maxPct: 69,
    gpa: 1.0,
    passFail: "pass",
  },
  {
    id: "gb-F",
    letter: "F",
    minPct: 0,
    maxPct: 59,
    gpa: 0.0,
    passFail: "fail",
  },
];

const GRADING_SCALE_KEY = "edunite_grading_scale";

function loadGradeBands(): GradeBand[] {
  try {
    const raw = localStorage.getItem(GRADING_SCALE_KEY);
    if (!raw) return DEFAULT_GRADE_BANDS;
    const parsed: GradeBand[] = JSON.parse(raw);
    return parsed.map((b, i) => ({ ...b, id: b.id ?? `gb-legacy-${i}` }));
  } catch {
    return DEFAULT_GRADE_BANDS;
  }
}

function saveGradeBands(bands: GradeBand[]) {
  localStorage.setItem(GRADING_SCALE_KEY, JSON.stringify(bands));
}

function detectGaps(bands: GradeBand[]): string[] {
  const sorted = [...bands].sort((a, b) => b.minPct - a.minPct);
  const gaps: string[] = [];
  for (let i = 0; i < sorted.length - 1; i++) {
    const upper = sorted[i];
    const lower = sorted[i + 1];
    if (upper.minPct - 1 > lower.maxPct) {
      gaps.push(`Gap between ${lower.maxPct + 1}% and ${upper.minPct - 1}%`);
    }
  }
  return gaps;
}

// ─── Grading Scale Section ───────────────────────────────────────────────────

function GradingScaleSection() {
  const [bands, setBands] = useState<GradeBand[]>(() => loadGradeBands());

  function updateBand(
    index: number,
    field: keyof GradeBand,
    value: string | number,
  ) {
    setBands((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      saveGradeBands(next);
      return next;
    });
  }

  function addBand() {
    setBands((prev) => {
      const newBand: GradeBand = {
        id: `gb-new-${Date.now()}`,
        letter: "",
        minPct: 0,
        maxPct: 0,
        gpa: 0.0,
        passFail: "pass",
      };
      const next = [...prev, newBand];
      saveGradeBands(next);
      return next;
    });
  }

  function deleteBand(index: number) {
    if (bands.length <= 1) return;
    setBands((prev) => {
      const next = prev.filter((_, i) => i !== index);
      saveGradeBands(next);
      return next;
    });
  }

  const gaps = detectGaps(bands);

  return (
    <div className="space-y-4">
      <p className="text-xs text-muted-foreground">
        Configure letter grades, percentage ranges, GPA points, and pass/fail
        status.
      </p>

      {gaps.length > 0 && (
        <div
          className="rounded-lg border border-warning/40 bg-warning/5 px-4 py-3 text-sm text-warning-foreground space-y-1"
          data-ocid="settings.grading_scale.error_state"
        >
          <p className="font-semibold flex items-center gap-2">
            ⚠ Grade range gaps detected
          </p>
          {gaps.map((g) => (
            <p key={g} className="text-xs opacity-80">
              {g}
            </p>
          ))}
        </div>
      )}

      {/* Two-card layout: editor on left, live preview on right */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        {/* Left card — Grade band editor */}
        <div
          className="rounded-xl border border-border bg-card overflow-hidden"
          data-ocid="settings.grading_scale.editor"
        >
          <div className="px-4 py-3 border-b border-border bg-muted/30">
            <p className="text-xs font-semibold text-muted-foreground ">
              Grade Bands
            </p>
          </div>
          <div className="p-4 space-y-3">
            <div className="grid grid-cols-[56px_1fr_1fr_56px_72px_32px] gap-2 text-[10px] font-semibold text-muted-foreground uppercase tracking-wide px-1">
              <span>Letter</span>
              <span>Min %</span>
              <span>Max %</span>
              <span>GPA</span>
              <span>Pass</span>
              <span />
            </div>
            <div className="space-y-2">
              {bands.map((band, idx) => (
                <div
                  key={band.id}
                  className="grid grid-cols-[56px_1fr_1fr_56px_72px_32px] gap-2 items-center"
                  data-ocid={`settings.grade_band.row.${idx + 1}`}
                >
                  <input
                    type="text"
                    value={band.letter}
                    maxLength={3}
                    onChange={(e) =>
                      updateBand(idx, "letter", e.target.value.toUpperCase())
                    }
                    placeholder="A"
                    className="h-9 px-2 rounded-lg border border-border bg-background text-sm font-semibold text-foreground text-center focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
                    data-ocid={`settings.grade_band.letter.input.${idx + 1}`}
                  />
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={band.minPct}
                    onChange={(e) =>
                      updateBand(idx, "minPct", Number(e.target.value))
                    }
                    className="h-9 px-2 rounded-lg border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
                    data-ocid={`settings.grade_band.min.input.${idx + 1}`}
                  />
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={band.maxPct}
                    onChange={(e) =>
                      updateBand(idx, "maxPct", Number(e.target.value))
                    }
                    className="h-9 px-2 rounded-lg border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
                    data-ocid={`settings.grade_band.max.input.${idx + 1}`}
                  />
                  <input
                    type="number"
                    min={0}
                    max={4}
                    step={0.1}
                    value={band.gpa}
                    onChange={(e) =>
                      updateBand(idx, "gpa", Number(e.target.value))
                    }
                    className="h-9 px-2 rounded-lg border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
                    data-ocid={`settings.grade_band.gpa.input.${idx + 1}`}
                  />
                  {/* Pass/Fail checkbox — checked = Pass, unchecked = Fail */}
                  <div
                    className="flex items-center gap-2 h-11 cursor-pointer select-none px-1"
                    data-ocid={`settings.grade_band.passfail.checkbox.${idx + 1}`}
                  >
                    <Checkbox
                      id={`passfail-${idx}`}
                      checked={band.passFail === "pass"}
                      onCheckedChange={(checked) =>
                        updateBand(idx, "passFail", checked ? "pass" : "fail")
                      }
                      className="shrink-0"
                    />
                    <button
                      type="button"
                      className={`text-xs font-semibold bg-transparent border-none p-0 cursor-pointer ${
                        band.passFail === "pass"
                          ? "text-success"
                          : "text-destructive"
                      }`}
                      onClick={() =>
                        updateBand(
                          idx,
                          "passFail",
                          band.passFail === "pass" ? "fail" : "pass",
                        )
                      }
                    >
                      {band.passFail === "pass" ? "Pass" : "Fail"}
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => deleteBand(idx)}
                    disabled={bands.length <= 1}
                    className="h-9 w-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/5 transition-colors disabled:opacity-30 disabled:cursor-not-allowed border border-transparent hover:border-destructive/20"
                    data-ocid={`settings.grade_band.delete_button.${idx + 1}`}
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={addBand}
              className="flex items-center gap-1.5 text-sm text-primary hover:text-primary/80 font-medium transition-colors mt-1"
              data-ocid="settings.grade_band.add_button"
            >
              <Plus size={15} />
              Add Grade Band
            </button>
          </div>
        </div>

        {/* Right card — Live preview */}
        <div
          className="rounded-xl border border-border bg-card overflow-hidden"
          data-ocid="settings.grading_scale.preview"
        >
          <div className="px-4 py-3 border-b border-border bg-muted/30">
            <p className="text-xs font-semibold text-muted-foreground ">
              Live Preview
            </p>
          </div>
          <div className="overflow-y-auto max-h-80">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/20">
                  {["Letter", "Min %", "Max %", "GPA", "Status", "Color"].map(
                    (h) => (
                      <th
                        key={h}
                        className="text-left px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide"
                      >
                        {h}
                      </th>
                    ),
                  )}
                </tr>
              </thead>
              <tbody>
                {[...bands]
                  .sort((a, b) => (b.minPct ?? 0) - (a.minPct ?? 0))
                  .map((band, idx) => {
                    const hue =
                      band.passFail === "pass"
                        ? band.minPct >= 90
                          ? "bg-success/15 text-success"
                          : band.minPct >= 70
                            ? "bg-warning/15 text-warning-foreground"
                            : "bg-muted text-foreground"
                        : "bg-destructive/15 text-destructive";
                    const swatch =
                      band.passFail === "pass"
                        ? band.minPct >= 90
                          ? "bg-success"
                          : band.minPct >= 70
                            ? "bg-warning"
                            : "bg-muted-foreground/40"
                        : "bg-destructive";
                    return (
                      <tr
                        key={band.id || idx}
                        className="border-b border-border/50 last:border-0 hover:bg-muted/20 transition-colors"
                      >
                        <td className="px-4 py-2.5">
                          <span
                            className={`inline-flex items-center justify-center w-8 h-8 rounded-lg text-sm font-bold ${hue}`}
                          >
                            {band.letter || "—"}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-foreground font-medium">
                          {band.minPct}%
                        </td>
                        <td className="px-4 py-2.5 text-foreground font-medium">
                          {band.maxPct}%
                        </td>
                        <td className="px-4 py-2.5 text-muted-foreground">
                          {band.gpa.toFixed(1)}
                        </td>
                        <td className="px-4 py-2.5">
                          <span
                            className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                              band.passFail === "pass"
                                ? "bg-success/15 text-success"
                                : "bg-destructive/15 text-destructive"
                            }`}
                          >
                            {band.passFail === "pass" ? "Pass" : "Fail"}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-center">
                          <span
                            className={`inline-block w-4 h-4 rounded-sm ${swatch}`}
                          />
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Grading Periods Section ─────────────────────────────────────────────────

function GradingPeriodsSection() {
  const [periods, setPeriods] = useState<GradingPeriod[]>(() =>
    getGradingPeriods(),
  );
  const today = new Date();

  const isCurrentPeriod = (period: GradingPeriod): boolean => {
    if (!period.startDate || !period.endDate) return false;
    const start = new Date(period.startDate);
    const end = new Date(period.endDate);
    return today >= start && today <= end;
  };

  const handleChange = (
    index: number,
    field: keyof GradingPeriod,
    value: string,
  ) => {
    const updated = periods.map((p, i) =>
      i === index ? { ...p, [field]: value } : p,
    );
    setPeriods(updated);
    saveGradingPeriods(updated);
    toast.success("Grading periods saved", { duration: 1200 });
  };

  const handleAdd = () => {
    const newId = `period_${Date.now()}`;
    const newPeriod: GradingPeriod = {
      id: newId,
      label: `P${periods.length + 1}`,
      startDate: "",
      endDate: "",
    };
    const updated = [...periods, newPeriod];
    setPeriods(updated);
    saveGradingPeriods(updated);
    toast.success("Grading periods saved", { duration: 1200 });
  };

  const handleDelete = (index: number) => {
    if (periods.length <= 1) return;
    const updated = periods.filter((_, i) => i !== index);
    setPeriods(updated);
    saveGradingPeriods(updated);
    toast.success("Grading periods saved", { duration: 1200 });
  };

  return (
    <SectionCard title="Grading Periods">
      <p className="text-xs text-muted-foreground mb-4">
        Define your school year's grading periods. These determine how the
        gradebook filters assignments.
      </p>
      <div className="space-y-1">
        {periods.map((period, i) => (
          <div
            key={period.id}
            className="flex items-center gap-3 py-2"
            data-ocid={`settings.grading_periods.item.${i + 1}`}
          >
            <div className="flex items-center gap-2 flex-none">
              <input
                type="text"
                value={period.label}
                onChange={(e) => handleChange(i, "label", e.target.value)}
                placeholder="Q1"
                data-ocid={`settings.grading_period_label.input.${i + 1}`}
                className="h-9 px-3 rounded-lg border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors w-24"
              />
              {isCurrentPeriod(period) && (
                <Badge className="h-5 px-1.5 text-[10px] font-medium bg-success/10 text-success border-success/30">
                  Current
                </Badge>
              )}
            </div>
            <input
              type="date"
              value={period.startDate}
              onChange={(e) => handleChange(i, "startDate", e.target.value)}
              data-ocid={`settings.grading_period_start.input.${i + 1}`}
              className="h-9 px-3 rounded-lg border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors w-[145px]"
            />
            <span className="text-muted-foreground text-xs flex-none">to</span>
            <input
              type="date"
              value={period.endDate}
              onChange={(e) => handleChange(i, "endDate", e.target.value)}
              data-ocid={`settings.grading_period_end.input.${i + 1}`}
              className="h-9 px-3 rounded-lg border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors w-[145px]"
            />
            <button
              type="button"
              onClick={() => handleDelete(i)}
              disabled={periods.length <= 1}
              data-ocid={`settings.grading_period.delete_button.${i + 1}`}
              aria-label={`Delete ${period.label}`}
              className="ml-1 p-1.5 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
      <button
        type="button"
        onClick={handleAdd}
        data-ocid="settings.grading_periods.button"
        className="mt-3 flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-dashed border-border text-sm text-muted-foreground hover:text-foreground hover:border-foreground/40 transition-colors"
      >
        <Plus className="h-3.5 w-3.5" />
        Add Period
      </button>
    </SectionCard>
  );
}

// ─── Per-Class Weights Section ───────────────────────────────────────────────

const CLASSES_LIST = [
  "Period 1 — Biology",
  "Period 2 — Chemistry",
  "Period 3 — Physics",
  "Period 4 — Earth Science",
];

const DROP_LOWEST_KEY = (className: string) =>
  `edunite_drop_lowest_${className}`;

function loadDropLowest(className: string): Record<string, number> {
  try {
    const raw = localStorage.getItem(DROP_LOWEST_KEY(className));
    if (!raw) return {};
    return JSON.parse(raw) as Record<string, number>;
  } catch {
    return {};
  }
}

function saveDropLowest(
  className: string,
  drops: Record<string, number>,
): void {
  localStorage.setItem(DROP_LOWEST_KEY(className), JSON.stringify(drops));
}

function PerClassWeightsSection() {
  const [selectedClass, setSelectedClass] = useState(CLASSES_LIST[0]);
  const types = useMemo(() => getAssignmentTypes(), []);
  const [weights, setWeights] = useState<CategoryWeights>(() =>
    getWeightsForTypes(types, selectedClass),
  );
  const [dropLowest, setDropLowest] = useState<Record<string, number>>(() =>
    loadDropLowest(selectedClass),
  );

  // biome-ignore lint/correctness/useExhaustiveDependencies: types is stable (memoized on mount)
  useEffect(() => {
    setWeights(getWeightsForTypes(types, selectedClass));
    setDropLowest(loadDropLowest(selectedClass));
  }, [selectedClass]);

  const totalWeight = types.reduce((sum, t) => sum + (weights[t] ?? 0), 0);

  const handleWeightChange = (type: string, value: string) => {
    const num = Number.parseInt(value, 10);
    const clamped = Number.isNaN(num) ? 0 : Math.max(0, Math.min(100, num));
    const updated = { ...weights, [type]: clamped };
    setWeights(updated);
    saveClassWeights(selectedClass, updated);
  };

  const handleAutoBalance = () => {
    const balanced = autoBalanceWeights(types);
    setWeights(balanced);
    saveClassWeights(selectedClass, balanced);
    toast.success("Weights auto-balanced");
  };

  const handleDropChange = (type: string, value: number) => {
    const updated = { ...dropLowest, [type]: value };
    setDropLowest(updated);
    saveDropLowest(selectedClass, updated);
    toast.success("Drop setting saved", { duration: 1200 });
  };

  return (
    <SectionCard title="Per-Class Category Weights">
      <p className="text-xs text-muted-foreground mb-4">
        Configure grade calculation weights and drop-lowest settings for each
        class.
      </p>
      <div className="mb-5">
        <span className="text-xs font-medium text-muted-foreground  block mb-1.5">
          Class
        </span>
        <div className="max-w-xs">
          <Select value={selectedClass} onValueChange={setSelectedClass}>
            <SelectTrigger
              data-ocid="settings.per_class_weights.select"
              className="h-9"
            >
              <SelectValue placeholder="Select class" />
            </SelectTrigger>
            <SelectContent>
              {CLASSES_LIST.map((cls) => (
                <SelectItem key={cls} value={cls}>
                  {cls}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      {types.length === 0 ? (
        <div className="py-6 text-center text-muted-foreground text-sm">
          No assignment types configured yet.
        </div>
      ) : (
        <>
          <div
            className="space-y-1 mb-4"
            data-ocid="settings.per_class_weights.section"
          >
            <div className="grid grid-cols-[1fr_auto_auto] gap-x-4 px-3 pb-1.5 text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
              <span>Assignment Type</span>
              <span className="text-center">Weight (%)</span>
              <span className="text-center">Drop Lowest</span>
            </div>
            {types.map((type, idx) => {
              const drop = dropLowest[type] ?? 0;
              return (
                <div
                  key={type}
                  className="grid grid-cols-[1fr_auto_auto] gap-x-4 items-center px-3 py-2 rounded-lg border border-border bg-background"
                  data-ocid={`settings.per_class_weights.item.${idx + 1}`}
                >
                  <span className="text-sm font-medium text-foreground truncate">
                    {type}
                  </span>
                  <div className="flex items-center gap-1 justify-center">
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={weights[type] ?? 0}
                      onChange={(e) => handleWeightChange(type, e.target.value)}
                      onBlur={(e) => handleWeightChange(type, e.target.value)}
                      className="w-14 h-7 text-center text-xs border border-border rounded-md bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-primary transition-colors"
                      aria-label={`Weight for ${type}`}
                      data-ocid={`settings.per_class_weights.weight.input.${idx + 1}`}
                    />
                    <span className="text-[11px] text-muted-foreground">%</span>
                  </div>
                  <div className="flex items-center gap-0.5 justify-center">
                    {[0, 1, 2].map((v) => (
                      <button
                        key={v}
                        type="button"
                        onClick={() => handleDropChange(type, v)}
                        className={`w-7 h-6 rounded text-xs font-semibold border transition-colors ${
                          drop === v
                            ? "bg-primary text-primary-foreground border-primary"
                            : "border-border text-muted-foreground hover:border-primary/50"
                        }`}
                        aria-label={`Drop ${v} lowest ${type}`}
                        data-ocid={`settings.per_class_weights.drop.toggle.${idx + 1}`}
                      >
                        {v}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
          {totalWeight === 100 ? (
            <div
              className="flex items-center gap-2 px-3 py-2 rounded-lg bg-success/10 border border-success/20"
              data-ocid="settings.per_class_weights.total"
            >
              <span className="text-xs font-semibold text-success">
                ✓ Weights balance to 100%
              </span>
            </div>
          ) : totalWeight > 0 ? (
            <div
              className="flex items-center gap-3 px-3 py-2 rounded-lg bg-warning/10 border border-warning/20"
              data-ocid="settings.per_class_weights.total"
            >
              <span className="text-xs font-semibold text-warning-foreground">
                Weights total {totalWeight}% — must equal 100%
              </span>
              <button
                type="button"
                onClick={handleAutoBalance}
                disabled={types.length === 0}
                data-ocid="settings.per_class_weights.autobalance_button"
                className="flex items-center gap-1.5 h-7 px-2.5 rounded-md border border-warning/40 bg-warning/20 text-xs font-medium text-warning-foreground hover:bg-warning/30 transition-colors disabled:opacity-50"
              >
                <Zap size={11} />
                Auto-balance
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3 px-1">
              <span
                className="text-xs text-muted-foreground/70 italic"
                data-ocid="settings.per_class_weights.total"
              >
                0% = total-points grading (no weighting)
              </span>
              <button
                type="button"
                onClick={handleAutoBalance}
                disabled={types.length === 0}
                data-ocid="settings.per_class_weights.autobalance_button"
                className="flex items-center gap-1.5 h-7 px-2.5 rounded-md border border-border bg-card text-xs font-medium text-foreground hover:bg-accent transition-colors disabled:opacity-50"
              >
                <Zap size={11} />
                Auto-balance
              </button>
            </div>
          )}
          <p className="text-xs text-muted-foreground mt-3 italic">
            <span className="font-medium text-foreground">Drop Lowest</span>:
            the number of lowest-scoring graded items to exclude per type when
            calculating the final grade.
          </p>
        </>
      )}
    </SectionCard>
  );
}

// ─── Exported Component ───────────────────────────────────────────────────────

export default function GradingScaleSettings() {
  return (
    <div className="space-y-8" data-ocid="settings.grading.card">
      <GradingScaleSection />
      <GradingPeriodsSection />
      <PerClassWeightsSection />
    </div>
  );
}
