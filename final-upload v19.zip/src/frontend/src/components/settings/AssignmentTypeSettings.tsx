import { GripVertical, Percent, Plus, Trash2, Zap } from "lucide-react";
import type React from "react";
import { useCallback, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  addAssessmentType,
  deleteAssessmentType,
  getAssessmentTypes,
  reorderAssessmentTypes,
} from "../../lib/assessmentTypes";
import {
  addType,
  deleteType,
  getAssignmentTypes,
  reorderTypes,
} from "../../lib/assignmentTypes";
import {
  type CategoryWeights,
  autoBalanceWeights,
  getCategoryWeights,
  saveCategoryWeights,
} from "../../lib/categoryWeights";
import { SectionCard } from "./settingsShared";

// ─── Assignment Types Section ─────────────────────────────────────────────────

function AssignmentTypesSection() {
  const [types, setTypes] = useState<string[]>(() => getAssignmentTypes());
  const [newTypeName, setNewTypeName] = useState("");
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editingValue, setEditingValue] = useState("");
  const [deletingIndex, setDeletingIndex] = useState<number | null>(null);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const dragRef = useRef<number | null>(null);
  const [weights, setWeights] = useState<CategoryWeights>(() =>
    getCategoryWeights(),
  );

  const totalWeight = useMemo(
    () => types.reduce((sum, t) => sum + (weights[t] ?? 0), 0),
    [types, weights],
  );

  const handleWeightChange = (type: string, value: string) => {
    const num = Number.parseInt(value, 10);
    const clamped = Number.isNaN(num) ? 0 : Math.max(0, Math.min(100, num));
    const updated = { ...weights, [type]: clamped };
    setWeights(updated);
    saveCategoryWeights(updated);
  };

  const handleAutoBalance = () => {
    const balanced = autoBalanceWeights(types);
    setWeights(balanced);
    saveCategoryWeights(balanced);
    toast.success("Weights auto-balanced");
  };

  const handleAddType = () => {
    const trimmed = newTypeName.trim();
    if (!trimmed) return;
    const next = addType(trimmed);
    setTypes(next);
    setNewTypeName("");
    toast.success(`"${trimmed}" added`);
  };

  const handleDeleteType = (idx: number) => {
    const name = types[idx];
    const next = deleteType(name);
    setTypes(next);
    const updatedWeights = { ...weights };
    delete updatedWeights[name];
    setWeights(updatedWeights);
    saveCategoryWeights(updatedWeights);
    setDeletingIndex(null);
    toast.success(`"${name}" removed`);
  };

  const handleEditSave = (idx: number) => {
    const trimmed = editingValue.trim();
    if (!trimmed || trimmed === types[idx]) {
      setEditingIndex(null);
      return;
    }
    const oldName = types[idx];
    const next = types.map((t, i) => (i === idx ? trimmed : t));
    setTypes(next);
    reorderTypes(next);
    if (oldName !== trimmed) {
      const updatedWeights = { ...weights };
      updatedWeights[trimmed] = updatedWeights[oldName] ?? 0;
      delete updatedWeights[oldName];
      setWeights(updatedWeights);
      saveCategoryWeights(updatedWeights);
    }
    setEditingIndex(null);
    toast.success("Type updated");
  };

  const handleDragStart = (idx: number) => {
    setDragIndex(idx);
    dragRef.current = idx;
  };
  const handleDragOver = (e: React.DragEvent, idx: number) => {
    e.preventDefault();
    setDragOverIndex(idx);
  };
  const handleDrop = (idx: number) => {
    const from = dragRef.current;
    if (from === null || from === idx) {
      setDragIndex(null);
      setDragOverIndex(null);
      return;
    }
    const next = [...types];
    const [moved] = next.splice(from, 1);
    next.splice(idx, 0, moved);
    setTypes(next);
    reorderTypes(next);
    setDragIndex(null);
    setDragOverIndex(null);
    dragRef.current = null;
  };
  const handleDragEnd = () => {
    setDragIndex(null);
    setDragOverIndex(null);
    dragRef.current = null;
  };

  return (
    <SectionCard title="Assignment Types">
      <p className="text-xs text-muted-foreground mb-4">
        Customize the types available when creating assignments. Drag to
        reorder. Weights set here act as global defaults.
      </p>
      <div
        className="space-y-1 mb-3"
        data-ocid="settings.assignment_types.section"
      >
        {types.map((type, idx) => (
          <div
            key={type}
            draggable
            onDragStart={() => handleDragStart(idx)}
            onDragOver={(e) => handleDragOver(e, idx)}
            onDrop={() => handleDrop(idx)}
            onDragEnd={handleDragEnd}
            data-ocid={`settings.type.item.${idx + 1}`}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${dragOverIndex === idx && dragIndex !== idx ? "border-primary bg-primary/5" : "border-border bg-background"} ${dragIndex === idx ? "opacity-40" : ""}`}
          >
            <span
              className="cursor-grab active:cursor-grabbing text-muted-foreground/50 hover:text-muted-foreground transition-colors shrink-0"
              data-ocid={`settings.type.drag_handle.${idx + 1}`}
            >
              <GripVertical size={14} />
            </span>
            {editingIndex === idx ? (
              <input
                type="text"
                value={editingValue}
                onChange={(e) => setEditingValue(e.target.value)}
                onBlur={() => handleEditSave(idx)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleEditSave(idx);
                  if (e.key === "Escape") setEditingIndex(null);
                }}
                className="flex-1 text-sm bg-transparent border-b border-primary outline-none text-foreground"
              />
            ) : (
              <button
                type="button"
                className="flex-1 text-left text-sm text-foreground hover:text-primary transition-colors"
                onClick={() => {
                  setEditingIndex(idx);
                  setEditingValue(type);
                }}
                title="Click to edit"
              >
                {type}
              </button>
            )}
            <div className="flex items-center gap-1 shrink-0">
              <input
                type="number"
                min={0}
                max={100}
                value={weights[type] ?? 0}
                onChange={(e) => handleWeightChange(type, e.target.value)}
                onBlur={(e) => handleWeightChange(type, e.target.value)}
                className="w-14 h-7 text-center text-xs border border-border rounded-md bg-background text-foreground focus:outline-none focus:ring-1 focus:ring-primary transition-colors"
                aria-label={`Weight for ${type}`}
                data-ocid={`settings.weights.input.${idx + 1}`}
              />
              <Percent size={11} className="text-muted-foreground shrink-0" />
            </div>
            {deletingIndex === idx ? (
              <div className="flex items-center gap-1.5 text-xs">
                <span className="text-muted-foreground">Remove?</span>
                <button
                  type="button"
                  onClick={() => handleDeleteType(idx)}
                  className="font-medium text-destructive hover:text-destructive/80 transition-colors"
                  data-ocid={`settings.type.delete_button.${idx + 1}`}
                >
                  Delete
                </button>
                <button
                  type="button"
                  onClick={() => setDeletingIndex(null)}
                  className="font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setDeletingIndex(idx)}
                className="text-muted-foreground/50 hover:text-destructive transition-colors shrink-0"
                aria-label={`Delete ${type}`}
                data-ocid={`settings.type.delete_button.${idx + 1}`}
              >
                <Trash2 size={13} />
              </button>
            )}
          </div>
        ))}
      </div>
      {types.length > 0 && (
        <div className="flex items-center gap-3 mb-4 px-1">
          <span
            className={`text-xs font-semibold ${totalWeight === 100 ? "text-success" : totalWeight > 0 ? "text-warning-foreground" : "text-muted-foreground"}`}
          >
            Total weight: {totalWeight}%
            {totalWeight === 100
              ? " ✓"
              : totalWeight > 0
                ? " (must equal 100%)"
                : " (unweighted)"}
          </span>
          {totalWeight !== 100 && types.length > 0 && (
            <button
              type="button"
              onClick={handleAutoBalance}
              className="flex items-center gap-1.5 h-7 px-2.5 rounded-md border border-border bg-card text-xs font-medium text-foreground hover:bg-accent transition-colors"
              data-ocid="settings.types.autobalance_button"
            >
              <Zap size={11} /> Auto-balance
            </button>
          )}
        </div>
      )}
      <div className="flex items-center gap-2">
        <input
          type="text"
          value={newTypeName}
          onChange={(e) => setNewTypeName(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && newTypeName.trim()) handleAddType();
          }}
          placeholder="Add a new assignment type..."
          data-ocid="settings.type.add.input"
          className="flex-1 h-9 px-3 rounded-lg border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
        />
        <button
          type="button"
          onClick={handleAddType}
          disabled={!newTypeName.trim()}
          data-ocid="settings.type.add.button"
          className="flex items-center gap-1.5 h-9 px-3 rounded-lg border border-border bg-card text-sm font-medium text-foreground hover:bg-accent transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Plus size={13} /> Add
        </button>
      </div>
    </SectionCard>
  );
}

// ─── Assessment Types Section ─────────────────────────────────────────────────

function AssessmentTypesSection() {
  const [types, setTypes] = useState<string[]>(() => getAssessmentTypes());
  const [newTypeName, setNewTypeName] = useState("");
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editingValue, setEditingValue] = useState("");
  const [deletingIndex, setDeletingIndex] = useState<number | null>(null);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const dragRef = useRef<number | null>(null);

  const handleAddType = () => {
    const trimmed = newTypeName.trim();
    if (!trimmed) return;
    const next = addAssessmentType(trimmed);
    setTypes(next);
    setNewTypeName("");
    toast.success(`"${trimmed}" added`);
  };

  const handleDeleteType = (idx: number) => {
    const name = types[idx];
    const next = deleteAssessmentType(name);
    setTypes(next);
    setDeletingIndex(null);
    toast.success(`"${name}" removed`);
  };

  const handleEditSave = (idx: number) => {
    const trimmed = editingValue.trim();
    if (!trimmed || trimmed === types[idx]) {
      setEditingIndex(null);
      return;
    }
    const next = types.map((t, i) => (i === idx ? trimmed : t));
    setTypes(next);
    reorderAssessmentTypes(next);
    setEditingIndex(null);
    toast.success("Type updated");
  };

  const handleDragStart = (idx: number) => {
    setDragIndex(idx);
    dragRef.current = idx;
  };
  const handleDragOver = (e: React.DragEvent, idx: number) => {
    e.preventDefault();
    setDragOverIndex(idx);
  };
  const handleDrop = (idx: number) => {
    const from = dragRef.current;
    if (from === null || from === idx) {
      setDragIndex(null);
      setDragOverIndex(null);
      return;
    }
    const next = [...types];
    const [moved] = next.splice(from, 1);
    next.splice(idx, 0, moved);
    setTypes(next);
    reorderAssessmentTypes(next);
    setDragIndex(null);
    setDragOverIndex(null);
    dragRef.current = null;
  };
  const handleDragEnd = () => {
    setDragIndex(null);
    setDragOverIndex(null);
    dragRef.current = null;
  };

  return (
    <SectionCard title="Assessment Types">
      <p className="text-xs text-muted-foreground mb-4">
        Customize the types available when creating assessments. Drag to
        reorder.
      </p>
      <div
        className="space-y-1 mb-3"
        data-ocid="settings.assessment_types.section"
      >
        {types.map((type, idx) => (
          <div
            key={type}
            draggable
            onDragStart={() => handleDragStart(idx)}
            onDragOver={(e) => handleDragOver(e, idx)}
            onDrop={() => handleDrop(idx)}
            onDragEnd={handleDragEnd}
            data-ocid={`settings.assessment_type.item.${idx + 1}`}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${dragOverIndex === idx && dragIndex !== idx ? "border-primary bg-primary/5" : "border-border bg-background"} ${dragIndex === idx ? "opacity-40" : ""}`}
          >
            <span
              className="cursor-grab active:cursor-grabbing text-muted-foreground/50 hover:text-muted-foreground transition-colors shrink-0"
              data-ocid={`settings.assessment_type.drag_handle.${idx + 1}`}
            >
              <GripVertical size={14} />
            </span>
            {editingIndex === idx ? (
              <input
                type="text"
                value={editingValue}
                onChange={(e) => setEditingValue(e.target.value)}
                onBlur={() => handleEditSave(idx)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleEditSave(idx);
                  if (e.key === "Escape") setEditingIndex(null);
                }}
                className="flex-1 text-sm bg-transparent border-b border-primary outline-none text-foreground"
              />
            ) : (
              <button
                type="button"
                className="flex-1 text-left text-sm text-foreground hover:text-primary transition-colors"
                onClick={() => {
                  setEditingIndex(idx);
                  setEditingValue(type);
                }}
                title="Click to edit"
              >
                {type}
              </button>
            )}
            {deletingIndex === idx ? (
              <div className="flex items-center gap-1.5 text-xs">
                <span className="text-muted-foreground">Remove?</span>
                <button
                  type="button"
                  onClick={() => handleDeleteType(idx)}
                  className="font-medium text-destructive hover:text-destructive/80 transition-colors"
                  data-ocid={`settings.assessment_type.delete_button.${idx + 1}`}
                >
                  Delete
                </button>
                <button
                  type="button"
                  onClick={() => setDeletingIndex(null)}
                  className="font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setDeletingIndex(idx)}
                className="text-muted-foreground/50 hover:text-destructive transition-colors shrink-0"
                aria-label={`Delete ${type}`}
                data-ocid={`settings.assessment_type.delete_button.${idx + 1}`}
              >
                <Trash2 size={13} />
              </button>
            )}
          </div>
        ))}
      </div>
      <div className="flex items-center gap-2">
        <input
          type="text"
          value={newTypeName}
          onChange={(e) => setNewTypeName(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && newTypeName.trim()) handleAddType();
          }}
          placeholder="Add a new assessment type..."
          data-ocid="settings.assessment_type.add.input"
          className="flex-1 h-9 px-3 rounded-lg border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
        />
        <button
          type="button"
          onClick={handleAddType}
          disabled={!newTypeName.trim()}
          data-ocid="settings.assessment_type.add.button"
          className="flex items-center gap-1.5 h-9 px-3 rounded-lg border border-border bg-card text-sm font-medium text-foreground hover:bg-accent transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Plus size={13} /> Add
        </button>
      </div>
    </SectionCard>
  );
}

// ─── Exported Component ───────────────────────────────────────────────────────

export default function AssignmentTypeSettings() {
  return (
    <div className="space-y-8" data-ocid="settings.types.card">
      <AssignmentTypesSection />
      <AssessmentTypesSection />
    </div>
  );
}
