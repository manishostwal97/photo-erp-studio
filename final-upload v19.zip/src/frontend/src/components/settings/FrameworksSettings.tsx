import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BookOpen,
  Check,
  ChevronDown,
  ChevronRight,
  Layers,
  Library,
  Plus,
  Save,
  Trash2,
} from "lucide-react";
import type React from "react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import RubricBuilder from "../../components/curriculum/RubricBuilder";
import type {
  Rubric,
  RubricTemplate,
  UnitTemplate,
} from "../../lib/curriculumTypes";
import {
  FIELD_LIBRARY,
  type FieldLibraryEntry,
} from "../../lib/customFrameworkFieldLibrary";
import type {
  CustomFieldLevel,
  CustomFieldType,
  CustomFramework,
  CustomFrameworkField,
} from "../../lib/customFrameworks";
import {
  addFieldToFramework,
  deleteCustomFramework,
  getCustomFrameworks,
  removeFieldFromFramework,
  saveCustomFramework,
  updateFieldInFramework,
} from "../../lib/customFrameworks";
import {
  deleteRubricTemplate,
  getRubricTemplates,
  saveRubricTemplate,
  updateRubricTemplate,
} from "../../lib/rubricTemplates";
import { deleteTemplate, getTemplates } from "../../lib/unitTemplates";
import { SectionCard } from "./settingsShared";

// ─── Constants ─────────────────────────────────────────────────────────────────

const FIELD_TYPE_LABELS: Record<CustomFieldType, string> = {
  text: "Short Text",
  "long-text": "Long Text",
  list: "List",
  date: "Date",
  number: "Number",
  select: "Select (Dropdown)",
  checkbox: "Checkbox",
  url: "URL / Link",
};

const FIELD_LEVEL_LABELS: Record<CustomFieldLevel, string> = {
  course: "Course",
  unit: "Unit",
  module: "Module",
  assignment: "Assignment",
};

const FIELD_LEVEL_COLORS: Record<CustomFieldLevel, string> = {
  course: "bg-primary/10 text-primary",
  unit: "bg-accent text-accent-foreground",
  module: "bg-info/10 text-info",
  assignment: "bg-warning/10 text-warning-foreground",
};

// ─── Field Editor ───────────────────────────────────────────────────────────────

function FieldEditor({
  frameworkId,
  field,
  index,
  onUpdate,
  onRemove,
}: {
  frameworkId: string;
  field: CustomFrameworkField;
  index: number;
  onUpdate: (fw: CustomFramework) => void;
  onRemove: (fw: CustomFramework) => void;
}) {
  const [deletingField, setDeletingField] = useState(false);

  const handleFieldChange = (
    key: keyof Omit<CustomFrameworkField, "id">,
    value: string | boolean,
  ) => {
    const updated = updateFieldInFramework(frameworkId, field.id, {
      [key]: value,
    });
    if (updated) onUpdate(updated);
  };

  const handleRemove = () => {
    const updated = removeFieldFromFramework(frameworkId, field.id);
    if (updated) onRemove(updated);
    toast.success("Field removed");
  };

  return (
    <div
      className="p-3 rounded-lg border border-border bg-background space-y-3"
      data-ocid={`settings.framework.field.item.${index + 1}`}
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="space-y-1">
          <span className="text-xs font-medium text-muted-foreground">
            Field Label
          </span>
          <input
            type="text"
            value={field.label}
            onChange={(e) => handleFieldChange("label", e.target.value)}
            placeholder="Field label"
            data-ocid={`settings.framework.field.input.${index + 1}`}
            className="w-full h-8 px-2.5 rounded-md border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
          />
        </div>
        <div className="space-y-1">
          <span className="text-xs font-medium text-muted-foreground">
            Placeholder / Hint
          </span>
          <input
            type="text"
            value={field.placeholder ?? ""}
            onChange={(e) => handleFieldChange("placeholder", e.target.value)}
            placeholder="Optional helper text"
            className="w-full h-8 px-2.5 rounded-md border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
          />
        </div>
      </div>
      <div className="flex items-center gap-3 flex-wrap">
        <div className="space-y-1">
          <span className="text-xs font-medium text-muted-foreground">
            Type
          </span>
          <div>
            <Select
              value={field.type}
              onValueChange={(v) =>
                handleFieldChange("type", v as CustomFieldType)
              }
            >
              <SelectTrigger
                data-ocid={`settings.framework.field.select.${index + 1}`}
                className="h-8 text-sm"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(
                  Object.entries(FIELD_TYPE_LABELS) as [
                    CustomFieldType,
                    string,
                  ][]
                ).map(([val, label]) => (
                  <SelectItem key={val} value={val}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="space-y-1">
          <span className="text-xs font-medium text-muted-foreground">
            Appears On
          </span>
          <div>
            <Select
              value={field.level}
              onValueChange={(v) =>
                handleFieldChange("level", v as CustomFieldLevel)
              }
            >
              <SelectTrigger
                data-ocid={`settings.framework.field.level.select.${index + 1}`}
                className="h-8 text-sm"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(
                  Object.entries(FIELD_LEVEL_LABELS) as [
                    CustomFieldLevel,
                    string,
                  ][]
                ).map(([val, label]) => (
                  <SelectItem key={val} value={val}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="space-y-1">
          <span className="text-xs font-medium text-muted-foreground">
            Required
          </span>
          <label className="flex items-center gap-2 h-8 cursor-pointer">
            <input
              type="checkbox"
              checked={field.required}
              onChange={(e) => handleFieldChange("required", e.target.checked)}
              data-ocid={`settings.framework.field.checkbox.${index + 1}`}
              className="w-4 h-4 accent-primary rounded"
            />
            <span className="text-sm text-foreground">Required</span>
          </label>
        </div>
        <div className="space-y-1 ml-auto self-end">
          {deletingField ? (
            <div className="flex items-center gap-1.5 text-xs h-8">
              <span className="text-muted-foreground">Remove?</span>
              <button
                type="button"
                onClick={handleRemove}
                className="font-medium text-destructive hover:text-destructive/80 transition-colors"
                data-ocid={`settings.framework.field.delete_button.${index + 1}`}
              >
                Remove
              </button>
              <button
                type="button"
                onClick={() => setDeletingField(false)}
                className="font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setDeletingField(true)}
              className="flex items-center justify-center h-8 w-8 rounded-md text-muted-foreground/50 hover:text-destructive hover:bg-destructive/5 transition-colors"
              aria-label="Remove field"
              data-ocid={`settings.framework.field.delete_button.${index + 1}`}
            >
              <Trash2 size={13} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Field Library Panel ─────────────────────────────────────────────────────────

function FieldLibraryPanel({
  frameworkId,
  existingFields,
  onFieldAdded,
  onClose,
}: {
  frameworkId: string;
  existingFields: CustomFrameworkField[];
  onFieldAdded: (fw: CustomFramework) => void;
  onClose: () => void;
}) {
  const [search, setSearch] = useState("");

  const existingLabels = useMemo(
    () => new Set(existingFields.map((f) => f.label.toLowerCase())),
    [existingFields],
  );

  const filteredGroups = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return FIELD_LIBRARY;
    return FIELD_LIBRARY.map((g) => ({
      ...g,
      fields: g.fields.filter(
        (f) =>
          f.label.toLowerCase().includes(q) ||
          g.group.toLowerCase().includes(q) ||
          (f.description ?? "").toLowerCase().includes(q),
      ),
    })).filter((g) => g.fields.length > 0);
  }, [search]);

  const flatEntries = useMemo<
    Array<{ entry: FieldLibraryEntry; globalIdx: number }>
  >(() => {
    let idx = 0;
    const result: Array<{ entry: FieldLibraryEntry; globalIdx: number }> = [];
    for (const g of filteredGroups) {
      for (const f of g.fields) {
        result.push({ entry: f, globalIdx: idx });
        idx++;
      }
    }
    return result;
  }, [filteredGroups]);

  const handleAdd = (entry: FieldLibraryEntry) => {
    const updated = addFieldToFramework(frameworkId, {
      label: entry.label,
      type: entry.type,
      level: entry.level,
      required: false,
      placeholder: entry.placeholder ?? "",
    });
    if (updated) {
      onFieldAdded(updated);
      toast.success(`"${entry.label}" added`);
    }
  };

  void onClose;

  return (
    <div className="rounded-lg border border-border bg-muted/30 p-3 space-y-3">
      <div className="flex items-center gap-2">
        <Library size={14} className="text-muted-foreground shrink-0" />
        <span className="text-xs font-semibold text-foreground">
          Field Library
        </span>
        <span className="text-xs text-muted-foreground ml-auto">
          Click a field to add it
        </span>
      </div>
      <input
        type="text"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search fields..."
        data-ocid="settings.framework.library.search_input"
        className="w-full h-8 px-2.5 rounded-md border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
      />
      <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
        {filteredGroups.length === 0 ? (
          <p className="text-xs text-muted-foreground text-center py-4">
            No fields match "{search}"
          </p>
        ) : (
          filteredGroups.map((group) => (
            <div key={group.group}>
              <p className="text-[10px] font-semibold  text-muted-foreground mb-1.5 px-0.5">
                {group.group}
              </p>
              <div className="space-y-0.5">
                {group.fields.map((entry) => {
                  const alreadyAdded = existingLabels.has(
                    entry.label.toLowerCase(),
                  );
                  const globalEntry = flatEntries.find(
                    (fe) =>
                      fe.entry.label === entry.label &&
                      fe.entry.level === entry.level,
                  );
                  const globalIdx = globalEntry?.globalIdx ?? 0;
                  return (
                    <div
                      key={`${group.group}-${entry.label}`}
                      className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-background transition-colors group"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-medium text-foreground">
                            {entry.label}
                          </span>
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded-full ${FIELD_LEVEL_COLORS[entry.level]}`}
                          >
                            {FIELD_LEVEL_LABELS[entry.level]}
                          </span>
                          <span className="text-[10px] text-muted-foreground/70">
                            {FIELD_TYPE_LABELS[entry.type]}
                          </span>
                        </div>
                        {entry.description && (
                          <p className="text-[10px] text-muted-foreground/70 mt-0.5 leading-snug truncate">
                            {entry.description}
                          </p>
                        )}
                      </div>
                      {alreadyAdded ? (
                        <span className="flex items-center gap-1 text-[10px] text-muted-foreground shrink-0">
                          <Check size={11} className="text-success" />
                          Added
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleAdd(entry)}
                          data-ocid={`settings.framework.library.add_button.${globalIdx + 1}`}
                          className="flex items-center gap-1 text-[10px] font-medium text-primary hover:text-primary/80 transition-colors shrink-0 opacity-0 group-hover:opacity-100"
                        >
                          <Plus size={11} />
                          Add
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// ─── Framework Row ─────────────────────────────────────────────────────────────────

function FrameworkRow({
  framework,
  index,
  onUpdate,
  onDelete,
}: {
  framework: CustomFramework;
  index: number;
  onUpdate: (fw: CustomFramework) => void;
  onDelete: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [deletingFw, setDeletingFw] = useState(false);
  const [showLibrary, setShowLibrary] = useState(false);
  const [localFw, setLocalFw] = useState(framework);

  useEffect(() => {
    setLocalFw(framework);
  }, [framework]);

  const levelsUsed = Array.from(
    new Set(localFw.fields.map((f) => f.level)),
  ) as CustomFieldLevel[];

  const handleDelete = () => {
    deleteCustomFramework(localFw.id);
    onDelete();
    toast.success(`"${localFw.name}" deleted`);
  };

  const handleAddField = () => {
    const updated = addFieldToFramework(localFw.id, {
      label: "New Field",
      type: "text",
      level: "unit",
      required: false,
      placeholder: "",
    });
    if (updated) {
      setLocalFw(updated);
      onUpdate(updated);
    }
  };

  const handleFieldUpdate = (updated: CustomFramework) => {
    setLocalFw(updated);
    onUpdate(updated);
  };
  const handleLibraryFieldAdded = (updated: CustomFramework) => {
    setLocalFw(updated);
    onUpdate(updated);
  };

  return (
    <div
      className="border border-border rounded-lg overflow-hidden"
      data-ocid={`settings.framework.item.${index + 1}`}
    >
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center gap-3 px-4 py-3 bg-background hover:bg-muted/40 transition-colors text-left"
        data-ocid={`settings.framework.toggle.${index + 1}`}
      >
        {expanded ? (
          <ChevronDown size={14} className="text-muted-foreground shrink-0" />
        ) : (
          <ChevronRight size={14} className="text-muted-foreground shrink-0" />
        )}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-foreground truncate">
            {localFw.name}
          </p>
          {localFw.description && (
            <p className="text-xs text-muted-foreground truncate mt-0.5">
              {localFw.description}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs text-muted-foreground">
            {localFw.fields.length} field
            {localFw.fields.length !== 1 ? "s" : ""}
          </span>
          {levelsUsed.map((lvl) => (
            <span
              key={lvl}
              className={`text-xs px-1.5 py-0.5 rounded-full hidden sm:inline-block ${FIELD_LEVEL_COLORS[lvl]}`}
            >
              {FIELD_LEVEL_LABELS[lvl]}
            </span>
          ))}
        </div>
      </button>
      {expanded && (
        <div className="border-t border-border bg-muted/10 p-4 space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              {localFw.fields.length === 0
                ? "No fields defined yet."
                : `${localFw.fields.length} custom field${localFw.fields.length !== 1 ? "s" : ""}`}
            </p>
            {deletingFw ? (
              <div className="flex items-center gap-1.5 text-xs">
                <span className="text-muted-foreground">
                  Delete this framework?
                </span>
                <button
                  type="button"
                  onClick={handleDelete}
                  className="font-medium text-destructive hover:text-destructive/80 transition-colors"
                  data-ocid={`settings.framework.delete_button.${index + 1}`}
                >
                  Delete
                </button>
                <button
                  type="button"
                  onClick={() => setDeletingFw(false)}
                  className="font-medium text-muted-foreground hover:text-foreground transition-colors"
                  data-ocid={`settings.framework.cancel_button.${index + 1}`}
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setDeletingFw(true)}
                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-destructive transition-colors"
                data-ocid={`settings.framework.delete_button.${index + 1}`}
              >
                <Trash2 size={12} />
                Delete Framework
              </button>
            )}
          </div>
          {localFw.fields.length > 0 && (
            <div className="space-y-2">
              {localFw.fields.map((field, fi) => (
                <FieldEditor
                  key={field.id}
                  frameworkId={localFw.id}
                  field={field}
                  index={fi}
                  onUpdate={handleFieldUpdate}
                  onRemove={handleFieldUpdate}
                />
              ))}
            </div>
          )}
          <div className="flex items-center gap-3 flex-wrap">
            <button
              type="button"
              onClick={handleAddField}
              className="flex items-center gap-1.5 text-sm text-primary hover:text-primary/80 transition-colors font-medium"
              data-ocid={`settings.framework.add_field.button.${index + 1}`}
            >
              <Plus size={13} />
              Add Field
            </button>
            <button
              type="button"
              onClick={() => setShowLibrary((v) => !v)}
              className={`flex items-center gap-1.5 text-sm font-medium transition-colors ${showLibrary ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}
              data-ocid="settings.framework.add_from_library.button"
            >
              <Library size={13} />
              {showLibrary ? "Hide Library" : "Add from Library"}
            </button>
          </div>
          {showLibrary && (
            <FieldLibraryPanel
              frameworkId={localFw.id}
              existingFields={localFw.fields}
              onFieldAdded={handleLibraryFieldAdded}
              onClose={() => setShowLibrary(false)}
            />
          )}
        </div>
      )}
    </div>
  );
}

// ─── Custom Frameworks Section ─────────────────────────────────────────────────

function CustomFrameworksSection() {
  const [frameworks, setFrameworks] = useState<CustomFramework[]>(() =>
    getCustomFrameworks(),
  );
  const [showNewForm, setShowNewForm] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDescription, setNewDescription] = useState("");

  const handleCreate = () => {
    const trimmed = newName.trim();
    if (!trimmed) return;
    const fw = saveCustomFramework({
      name: trimmed,
      description: newDescription.trim() || undefined,
      fields: [],
    });
    setFrameworks((prev) => [...prev, fw]);
    setNewName("");
    setNewDescription("");
    setShowNewForm(false);
    toast.success(`"${fw.name}" created`);
  };

  const handleUpdate = (updated: CustomFramework) => {
    setFrameworks((prev) =>
      prev.map((f) => (f.id === updated.id ? updated : f)),
    );
  };
  const handleDelete = (id: string) => {
    setFrameworks((prev) => prev.filter((f) => f.id !== id));
  };

  return (
    <SectionCard title="Custom Frameworks">
      <p className="text-xs text-muted-foreground mb-4">
        Define custom planning fields that appear in the Curriculum editor when
        a course uses the "Custom" framework.
      </p>
      {showNewForm && (
        <div className="mb-4 p-4 rounded-lg border border-primary/30 bg-primary/5 space-y-3">
          <h4 className="text-sm font-semibold text-foreground">
            New Framework
          </h4>
          <div className="space-y-1">
            <span className="text-xs font-medium text-muted-foreground">
              Name <span className="text-destructive">*</span>
            </span>
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && newName.trim()) handleCreate();
                if (e.key === "Escape") setShowNewForm(false);
              }}
              placeholder="e.g. Inquiry-Based Learning"
              data-ocid="settings.new_framework.input"
              className="w-full h-9 px-3 rounded-lg border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
            />
          </div>
          <div className="space-y-1">
            <span className="text-xs font-medium text-muted-foreground">
              Description (optional)
            </span>
            <textarea
              value={newDescription}
              onChange={(e) => setNewDescription(e.target.value)}
              placeholder="Brief description..."
              rows={2}
              className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors resize-none"
            />
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCreate}
              disabled={!newName.trim()}
              data-ocid="settings.new_framework.submit_button"
              className="flex items-center gap-1.5 h-8 px-3 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              <Plus size={13} />
              Create
            </button>
            <button
              type="button"
              onClick={() => {
                setShowNewForm(false);
                setNewName("");
                setNewDescription("");
              }}
              data-ocid="settings.new_framework.cancel_button"
              className="flex items-center gap-1.5 h-8 px-3 rounded-lg border border-border text-sm font-medium text-foreground hover:bg-muted transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
      <div
        className="space-y-2 mb-3"
        data-ocid="settings.custom_frameworks.section"
      >
        {frameworks.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-10 text-center"
            data-ocid="settings.custom_frameworks.empty_state"
          >
            <Layers size={28} className="text-muted-foreground/30 mb-2" />
            <p className="text-sm text-muted-foreground font-medium">
              No custom frameworks yet
            </p>
            <p className="text-xs text-muted-foreground/60 mt-0.5">
              Create your first framework to define custom planning fields.
            </p>
          </div>
        ) : (
          frameworks.map((fw, idx) => (
            <FrameworkRow
              key={fw.id}
              framework={fw}
              index={idx}
              onUpdate={handleUpdate}
              onDelete={() => handleDelete(fw.id)}
            />
          ))
        )}
      </div>
      {!showNewForm && (
        <button
          type="button"
          onClick={() => setShowNewForm(true)}
          data-ocid="settings.new_framework.button"
          className="flex items-center gap-1.5 h-9 px-3 rounded-lg border border-border bg-card text-sm font-medium text-foreground hover:bg-accent transition-colors"
        >
          <Plus size={13} />
          New Framework
        </button>
      )}
    </SectionCard>
  );
}

// ─── Unit Templates Section ───────────────────────────────────────────────────────

function UnitTemplatesSection() {
  const [templates, setTemplates] = useState<UnitTemplate[]>(() =>
    getTemplates(),
  );
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = (id: string) => {
    deleteTemplate(id);
    setTemplates(getTemplates());
    setDeletingId(null);
    toast.success("Template deleted");
  };

  return (
    <SectionCard title="Unit Templates">
      <p className="text-xs text-muted-foreground mb-4">
        Saved unit templates for quick reuse. Create templates from any unit
        editor using "Save as Template."
      </p>
      <div className="space-y-2" data-ocid="settings.unit_templates.section">
        {templates.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <BookOpen size={28} className="text-muted-foreground/30 mb-2" />
            <p className="text-sm text-muted-foreground font-medium">
              No templates saved yet
            </p>
            <p className="text-xs text-muted-foreground/60 mt-0.5">
              Open a unit and click "Save as Template" to create one.
            </p>
          </div>
        ) : (
          templates.map((tpl, idx) => {
            const assignmentCount = tpl.modules.reduce(
              (sum, m) => sum + m.assignments.length,
              0,
            );
            const isDeleting = deletingId === tpl.id;
            return (
              <div
                key={tpl.id}
                className="flex items-center gap-3 px-4 py-3 rounded-lg border border-border bg-background"
                data-ocid={`settings.template.item.${idx + 1}`}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {tpl.name}
                  </p>
                  {tpl.description && (
                    <p className="text-xs text-muted-foreground truncate mt-0.5">
                      {tpl.description}
                    </p>
                  )}
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-muted-foreground">
                      {tpl.modules.length} module
                      {tpl.modules.length !== 1 ? "s" : ""} · {assignmentCount}{" "}
                      assignment{assignmentCount !== 1 ? "s" : ""}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {new Date(tpl.createdAt).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </span>
                  </div>
                </div>
                {isDeleting ? (
                  <div className="flex items-center gap-1.5 text-xs shrink-0">
                    <span className="text-muted-foreground">Delete?</span>
                    <button
                      type="button"
                      onClick={() => handleDelete(tpl.id)}
                      className="font-medium text-destructive hover:text-destructive/80 transition-colors"
                      data-ocid={`settings.template.delete_button.${idx + 1}`}
                    >
                      Confirm
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeletingId(null)}
                      className="font-medium text-muted-foreground hover:text-foreground transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setDeletingId(tpl.id)}
                    className="text-muted-foreground/50 hover:text-destructive transition-colors shrink-0"
                    aria-label={`Delete template ${tpl.name}`}
                    data-ocid={`settings.template.delete_button.${idx + 1}`}
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            );
          })
        )}
      </div>
    </SectionCard>
  );
}

// ─── Rubric Template Row ─────────────────────────────────────────────────────────

function RubricTemplateRow({
  template,
  index,
  onUpdate,
  onDelete,
}: {
  template: RubricTemplate;
  index: number;
  onUpdate: (updated: RubricTemplate) => void;
  onDelete: () => void;
}) {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showEditor, setShowEditor] = useState(false);
  const [editName, setEditName] = useState(template.name);
  const [editDescription, setEditDescription] = useState(template.description);
  const [editRubric, setEditRubric] = useState<Rubric | null>(template.rubric);

  const handleSave = () => {
    const trimmedName = editName.trim();
    if (!trimmedName) return;
    const updated = updateRubricTemplate(template.id, {
      name: trimmedName,
      description: editDescription.trim(),
      rubric: editRubric ?? template.rubric,
    });
    if (updated) {
      onUpdate(updated);
      toast.success("Template updated");
    }
    setShowEditor(false);
  };

  const handleCancelEdit = () => {
    setEditName(template.name);
    setEditDescription(template.description);
    setEditRubric(template.rubric);
    setShowEditor(false);
  };
  void handleCancelEdit;

  const handleDelete = () => {
    deleteRubricTemplate(template.id);
    onDelete();
    toast.success(`"${template.name}" deleted`);
  };

  return (
    <div
      className="rounded-lg border border-border overflow-hidden"
      data-ocid={`settings.rubric_template.item.${index + 1}`}
    >
      <div className="flex items-center gap-3 px-4 py-3 bg-background">
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-foreground truncate">
            {template.name}
          </p>
          {template.description && (
            <p className="text-xs text-muted-foreground truncate mt-0.5">
              {template.description}
            </p>
          )}
          <div className="flex items-center gap-2 mt-1">
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-primary/10 text-primary font-medium">
              {template.rubric.criteria.length} criteria
            </span>
            <span className="text-xs text-muted-foreground/60">
              {template.rubric.levels.map((l) => l.name).join(" · ")}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {!showDeleteConfirm && (
            <button
              type="button"
              data-ocid={`settings.rubric_template.edit_button.${index + 1}`}
              onClick={() => {
                setShowEditor((v) => !v);
                setShowDeleteConfirm(false);
              }}
              className="h-7 px-2.5 text-xs font-medium text-muted-foreground hover:text-foreground border border-border hover:border-foreground/30 rounded-md transition-colors"
            >
              {showEditor ? "Close" : "Edit"}
            </button>
          )}
          {showDeleteConfirm ? (
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-muted-foreground">Delete?</span>
              <button
                type="button"
                onClick={handleDelete}
                data-ocid={`settings.rubric_template.delete_button.${index + 1}`}
                className="font-medium text-destructive hover:text-destructive/80 transition-colors"
              >
                Confirm
              </button>
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                className="font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              type="button"
              data-ocid={`settings.rubric_template.delete_button.${index + 1}`}
              onClick={() => {
                setShowDeleteConfirm(true);
                setShowEditor(false);
              }}
              className="h-7 w-7 flex items-center justify-center text-muted-foreground/50 hover:text-destructive hover:bg-destructive/5 rounded-md transition-colors"
            >
              <Trash2 size={13} />
            </button>
          )}
        </div>
      </div>
      {showEditor && (
        <div className="border-t border-border p-4 bg-muted/20 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <span className="text-xs font-medium text-muted-foreground">
                Name
              </span>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full h-9 px-3 rounded-lg border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
              />
            </div>
            <div className="space-y-1">
              <span className="text-xs font-medium text-muted-foreground">
                Description
              </span>
              <input
                type="text"
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                className="w-full h-9 px-3 rounded-lg border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
              />
            </div>
          </div>
          <RubricBuilder rubric={editRubric} onChange={setEditRubric} />
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSave}
              disabled={!editName.trim()}
              data-ocid={`settings.rubric_template.save_button.${index + 1}`}
              className="flex items-center gap-1.5 h-8 px-3 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              <Save size={13} />
              Save
            </button>
            <button
              type="button"
              onClick={() => setShowEditor(false)}
              className="h-8 px-3 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Rubric Templates Section ───────────────────────────────────────────────────

function RubricTemplatesSection() {
  const [templates, setTemplates] = useState<RubricTemplate[]>(() =>
    getRubricTemplates(),
  );
  const [showNewForm, setShowNewForm] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newRubric, setNewRubric] = useState<Rubric | null>(null);

  const handleCreate = () => {
    const trimmedName = newName.trim();
    if (!trimmedName || !newRubric) return;
    saveRubricTemplate({
      name: trimmedName,
      description: newDescription.trim(),
      rubric: newRubric,
    });
    setTemplates(getRubricTemplates());
    setNewName("");
    setNewDescription("");
    setNewRubric(null);
    setShowNewForm(false);
    toast.success(`"${trimmedName}" template created`);
  };

  const handleUpdate = (updated: RubricTemplate) => {
    setTemplates((prev) =>
      prev.map((t) => (t.id === updated.id ? updated : t)),
    );
  };
  const handleDelete = (id: string) => {
    setTemplates((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <SectionCard title="Rubric Templates">
      <p className="text-xs text-muted-foreground mb-4">
        Reusable rubric templates that can be loaded into any assignment.
      </p>
      {showNewForm && (
        <div className="mb-4 p-4 rounded-lg border border-primary/30 bg-primary/5 space-y-4">
          <h4 className="text-sm font-semibold text-foreground">
            New Rubric Template
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <span className="text-xs font-medium text-muted-foreground">
                Name <span className="text-destructive">*</span>
              </span>
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Argumentative Essay Rubric"
                data-ocid="settings.rubric_template.name_input"
                className="w-full h-9 px-3 rounded-lg border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
              />
            </div>
            <div className="space-y-1">
              <span className="text-xs font-medium text-muted-foreground">
                Description (optional)
              </span>
              <input
                type="text"
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                placeholder="Brief description..."
                data-ocid="settings.rubric_template.description_input"
                className="w-full h-9 px-3 rounded-lg border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
              />
            </div>
          </div>
          <div>
            <span className="text-xs font-medium text-muted-foreground  block mb-2">
              Rubric <span className="text-destructive">*</span>
            </span>
            <RubricBuilder rubric={newRubric} onChange={setNewRubric} />
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCreate}
              disabled={!newName.trim() || !newRubric}
              data-ocid="settings.rubric_template.save_button"
              className="flex items-center gap-1.5 h-8 px-3 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              <Plus size={13} />
              Save Template
            </button>
            <button
              type="button"
              onClick={() => setShowNewForm(false)}
              className="h-8 px-3 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
      <div
        className="space-y-2 mb-3"
        data-ocid="settings.rubric_templates.section"
      >
        {templates.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-10 text-center"
            data-ocid="settings.rubric_templates.empty_state"
          >
            <BookOpen size={28} className="text-muted-foreground/30 mb-2" />
            <p className="text-sm text-muted-foreground font-medium">
              No rubric templates yet
            </p>
          </div>
        ) : (
          templates.map((tpl, idx) => (
            <RubricTemplateRow
              key={tpl.id}
              template={tpl}
              index={idx}
              onUpdate={handleUpdate}
              onDelete={() => handleDelete(tpl.id)}
            />
          ))
        )}
      </div>
      {!showNewForm && (
        <button
          type="button"
          onClick={() => setShowNewForm(true)}
          data-ocid="settings.rubric_template.add_button"
          className="flex items-center gap-1.5 h-9 px-3 rounded-lg border border-border bg-card text-sm font-medium text-foreground hover:bg-accent transition-colors"
        >
          <Plus size={13} />
          New Rubric Template
        </button>
      )}
    </SectionCard>
  );
}

// ─── Exported Component ───────────────────────────────────────────────────────

export default function FrameworksSettings() {
  return (
    <div className="space-y-8" data-ocid="settings.frameworks.card">
      <CustomFrameworksSection />
      <UnitTemplatesSection />
      <RubricTemplatesSection />
    </div>
  );
}
