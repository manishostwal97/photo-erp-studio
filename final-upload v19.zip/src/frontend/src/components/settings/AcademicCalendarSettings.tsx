import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Calendar,
  CalendarDays,
  GraduationCap,
  Plus,
  Trash2,
} from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

// ─── Types ────────────────────────────────────────────────────────────────────

interface AcademicTerm {
  id: string;
  name: string;
  start: string;
  end: string;
}

interface GradingPeriod {
  id: string;
  name: string;
  start: string;
  end: string;
}

interface Holiday {
  id: string;
  label: string;
  start: string;
  end: string;
}

export interface AcademicCalendarData {
  yearStart: string;
  yearEnd: string;
  terms: AcademicTerm[];
  gradingPeriods: GradingPeriod[];
  holidays: Holiday[];
}

const LS_KEY = "edunite_academic_calendar";
const LS_KEY_ALIAS = "edunite_settings_calendar";

const DEFAULT_DATA: AcademicCalendarData = {
  yearStart: `${new Date().getFullYear()}-09-04`,
  yearEnd: `${new Date().getFullYear() + 1}-06-13`,
  terms: [
    {
      id: "t1",
      name: "Semester 1",
      start: `${new Date().getFullYear()}-09-04`,
      end: `${new Date().getFullYear() + 1}-01-17`,
    },
    {
      id: "t2",
      name: "Semester 2",
      start: `${new Date().getFullYear() + 1}-01-22`,
      end: `${new Date().getFullYear() + 1}-06-13`,
    },
  ],
  gradingPeriods: [
    {
      id: "q1",
      name: "Q1",
      start: `${new Date().getFullYear()}-09-04`,
      end: `${new Date().getFullYear()}-11-08`,
    },
    {
      id: "q2",
      name: "Q2",
      start: `${new Date().getFullYear()}-11-11`,
      end: `${new Date().getFullYear() + 1}-01-17`,
    },
    {
      id: "q3",
      name: "Q3",
      start: `${new Date().getFullYear() + 1}-01-22`,
      end: `${new Date().getFullYear() + 1}-03-21`,
    },
    {
      id: "q4",
      name: "Q4",
      start: `${new Date().getFullYear() + 1}-03-24`,
      end: `${new Date().getFullYear() + 1}-06-13`,
    },
  ],
  holidays: [
    {
      id: "h1",
      label: "Fall Break",
      start: `${new Date().getFullYear()}-10-14`,
      end: `${new Date().getFullYear()}-10-18`,
    },
    {
      id: "h2",
      label: "Thanksgiving Break",
      start: `${new Date().getFullYear()}-11-27`,
      end: `${new Date().getFullYear()}-11-28`,
    },
    {
      id: "h3",
      label: "Winter Break",
      start: `${new Date().getFullYear()}-12-23`,
      end: `${new Date().getFullYear() + 1}-01-03`,
    },
    {
      id: "h4",
      label: "Spring Break",
      start: `${new Date().getFullYear() + 1}-04-07`,
      end: `${new Date().getFullYear() + 1}-04-11`,
    },
  ],
};

export function loadAcademicCalendar(): AcademicCalendarData {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw) as AcademicCalendarData;
  } catch {
    /* ignore */
  }
  return DEFAULT_DATA;
}

function saveAcademicCalendar(data: AcademicCalendarData): void {
  localStorage.setItem(LS_KEY, JSON.stringify(data));
  localStorage.setItem(LS_KEY_ALIAS, JSON.stringify(data));
}

function uid(): string {
  return Math.random().toString(36).slice(2, 9);
}

// ─── Sub-sections ─────────────────────────────────────────────────────────────

function SectionHeader({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  title: string;
  description: string;
}) {
  return (
    <div className="flex items-start gap-3 pb-4 border-b border-border">
      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
        <Icon size={16} className="text-primary" />
      </div>
      <div>
        <p className="text-sm font-semibold text-foreground">{title}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{description}</p>
      </div>
    </div>
  );
}

import type React from "react";

// ─── Main Component ───────────────────────────────────────────────────────────

export default function AcademicCalendarSettings() {
  const [data, setData] = useState<AcademicCalendarData>(() =>
    loadAcademicCalendar(),
  );

  // Keep localStorage in sync whenever data changes
  useEffect(() => {
    saveAcademicCalendar(data);
  }, [data]);

  function handleSave() {
    saveAcademicCalendar(data);
    toast.success("Academic calendar saved");
  }

  // ── Terms ─────────────────────────────────────────────────────────────────
  function addTerm() {
    setData((prev) => ({
      ...prev,
      terms: [
        ...prev.terms,
        {
          id: uid(),
          name: `Term ${prev.terms.length + 1}`,
          start: "",
          end: "",
        },
      ],
    }));
  }

  function updateTerm(id: string, patch: Partial<AcademicTerm>) {
    setData((prev) => ({
      ...prev,
      terms: prev.terms.map((t) => (t.id === id ? { ...t, ...patch } : t)),
    }));
  }

  function removeTerm(id: string) {
    setData((prev) => ({
      ...prev,
      terms: prev.terms.filter((t) => t.id !== id),
    }));
  }

  // ── Grading Periods ───────────────────────────────────────────────────────
  function addGradingPeriod() {
    setData((prev) => ({
      ...prev,
      gradingPeriods: [
        ...prev.gradingPeriods,
        {
          id: uid(),
          name: `Q${prev.gradingPeriods.length + 1}`,
          start: "",
          end: "",
        },
      ],
    }));
  }

  function updateGradingPeriod(id: string, patch: Partial<GradingPeriod>) {
    setData((prev) => ({
      ...prev,
      gradingPeriods: prev.gradingPeriods.map((gp) =>
        gp.id === id ? { ...gp, ...patch } : gp,
      ),
    }));
  }

  function removeGradingPeriod(id: string) {
    setData((prev) => ({
      ...prev,
      gradingPeriods: prev.gradingPeriods.filter((gp) => gp.id !== id),
    }));
  }

  // ── Holidays ──────────────────────────────────────────────────────────────
  function addHoliday() {
    setData((prev) => ({
      ...prev,
      holidays: [
        ...prev.holidays,
        { id: uid(), label: "Holiday", start: "", end: "" },
      ],
    }));
  }

  function updateHoliday(id: string, patch: Partial<Holiday>) {
    setData((prev) => ({
      ...prev,
      holidays: prev.holidays.map((h) =>
        h.id === id ? { ...h, ...patch } : h,
      ),
    }));
  }

  function removeHoliday(id: string) {
    setData((prev) => ({
      ...prev,
      holidays: prev.holidays.filter((h) => h.id !== id),
    }));
  }

  return (
    <div className="space-y-8" data-ocid="settings.academic_calendar.card">
      {/* Academic Year */}
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <div className="p-6 space-y-5">
          <SectionHeader
            icon={CalendarDays}
            title="Academic Year"
            description="Set the start and end dates for the current school year"
          />
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-muted-foreground">
                Year Start
              </Label>
              <Input
                type="date"
                value={data.yearStart}
                onChange={(e) =>
                  setData((prev) => ({ ...prev, yearStart: e.target.value }))
                }
                className="h-10"
                data-ocid="settings.academic_calendar.year_start.input"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-muted-foreground">
                Year End
              </Label>
              <Input
                type="date"
                value={data.yearEnd}
                onChange={(e) =>
                  setData((prev) => ({ ...prev, yearEnd: e.target.value }))
                }
                className="h-10"
                data-ocid="settings.academic_calendar.year_end.input"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Terms / Semesters */}
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <div className="p-6 space-y-5">
          <SectionHeader
            icon={Calendar}
            title="Terms / Semesters"
            description="Define your school's terms or semesters with their date ranges"
          />
          <div className="space-y-3">
            {data.terms.map((term, i) => (
              <div
                key={term.id}
                className="flex items-center gap-3 p-3 rounded-lg border border-border bg-muted/20"
                data-ocid={`settings.academic_calendar.term.item.${i + 1}`}
              >
                <Input
                  value={term.name}
                  onChange={(e) =>
                    updateTerm(term.id, { name: e.target.value })
                  }
                  placeholder="Term name"
                  className="h-9 w-36 shrink-0"
                />
                <span className="text-xs text-muted-foreground shrink-0">
                  from
                </span>
                <Input
                  type="date"
                  value={term.start}
                  onChange={(e) =>
                    updateTerm(term.id, { start: e.target.value })
                  }
                  className="h-9 flex-1"
                />
                <span className="text-xs text-muted-foreground shrink-0">
                  to
                </span>
                <Input
                  type="date"
                  value={term.end}
                  onChange={(e) => updateTerm(term.id, { end: e.target.value })}
                  className="h-9 flex-1"
                />
                <button
                  type="button"
                  onClick={() => removeTerm(term.id)}
                  className="w-8 h-8 flex items-center justify-center rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors shrink-0"
                  aria-label="Remove term"
                  data-ocid={`settings.academic_calendar.term.delete_button.${i + 1}`}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
            {data.terms.length === 0 && (
              <p
                className="text-sm text-muted-foreground py-2"
                data-ocid="settings.academic_calendar.terms.empty_state"
              >
                No terms added yet.
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={addTerm}
            className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors h-9 px-3 rounded-lg border border-dashed border-primary/30 hover:border-primary/60 hover:bg-primary/5"
            data-ocid="settings.academic_calendar.add_term.button"
          >
            <Plus size={14} />
            Add Term
          </button>
        </div>
      </div>

      {/* Grading Periods */}
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <div className="p-6 space-y-5">
          <SectionHeader
            icon={GraduationCap}
            title="Grading Periods"
            description="Define quarters, semesters, or other grading periods used in reports and gradebook"
          />
          <div className="space-y-3">
            {data.gradingPeriods.map((gp, i) => (
              <div
                key={gp.id}
                className="flex items-center gap-3 p-3 rounded-lg border border-border bg-muted/20"
                data-ocid={`settings.academic_calendar.grading_period.item.${i + 1}`}
              >
                <Input
                  value={gp.name}
                  onChange={(e) =>
                    updateGradingPeriod(gp.id, { name: e.target.value })
                  }
                  placeholder="Period name (e.g. Q1)"
                  className="h-9 w-24 shrink-0"
                />
                <span className="text-xs text-muted-foreground shrink-0">
                  from
                </span>
                <Input
                  type="date"
                  value={gp.start}
                  onChange={(e) =>
                    updateGradingPeriod(gp.id, { start: e.target.value })
                  }
                  className="h-9 flex-1"
                />
                <span className="text-xs text-muted-foreground shrink-0">
                  to
                </span>
                <Input
                  type="date"
                  value={gp.end}
                  onChange={(e) =>
                    updateGradingPeriod(gp.id, { end: e.target.value })
                  }
                  className="h-9 flex-1"
                />
                <button
                  type="button"
                  onClick={() => removeGradingPeriod(gp.id)}
                  className="w-8 h-8 flex items-center justify-center rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors shrink-0"
                  aria-label="Remove grading period"
                  data-ocid={`settings.academic_calendar.grading_period.delete_button.${i + 1}`}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
            {data.gradingPeriods.length === 0 && (
              <p
                className="text-sm text-muted-foreground py-2"
                data-ocid="settings.academic_calendar.grading_periods.empty_state"
              >
                No grading periods added yet.
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={addGradingPeriod}
            className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors h-9 px-3 rounded-lg border border-dashed border-primary/30 hover:border-primary/60 hover:bg-primary/5"
            data-ocid="settings.academic_calendar.add_grading_period.button"
          >
            <Plus size={14} />
            Add Grading Period
          </button>
        </div>
      </div>

      {/* Holidays */}
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <div className="p-6 space-y-5">
          <SectionHeader
            icon={Calendar}
            title="Holidays & Non-School Days"
            description="Mark breaks, holidays, and professional development days on the calendar"
          />
          <div className="space-y-3">
            {data.holidays.map((h, i) => (
              <div
                key={h.id}
                className="flex items-center gap-3 p-3 rounded-lg border border-border bg-muted/20"
                data-ocid={`settings.academic_calendar.holiday.item.${i + 1}`}
              >
                <Input
                  value={h.label}
                  onChange={(e) =>
                    updateHoliday(h.id, { label: e.target.value })
                  }
                  placeholder="Holiday name"
                  className="h-9 w-44 shrink-0"
                />
                <span className="text-xs text-muted-foreground shrink-0">
                  from
                </span>
                <Input
                  type="date"
                  value={h.start}
                  onChange={(e) =>
                    updateHoliday(h.id, { start: e.target.value })
                  }
                  className="h-9 flex-1"
                />
                <span className="text-xs text-muted-foreground shrink-0">
                  to
                </span>
                <Input
                  type="date"
                  value={h.end}
                  onChange={(e) => updateHoliday(h.id, { end: e.target.value })}
                  className="h-9 flex-1"
                />
                <button
                  type="button"
                  onClick={() => removeHoliday(h.id)}
                  className="w-8 h-8 flex items-center justify-center rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors shrink-0"
                  aria-label="Remove holiday"
                  data-ocid={`settings.academic_calendar.holiday.delete_button.${i + 1}`}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
            {data.holidays.length === 0 && (
              <p
                className="text-sm text-muted-foreground py-2"
                data-ocid="settings.academic_calendar.holidays.empty_state"
              >
                No holidays added yet.
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={addHoliday}
            className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors h-9 px-3 rounded-lg border border-dashed border-primary/30 hover:border-primary/60 hover:bg-primary/5"
            data-ocid="settings.academic_calendar.add_holiday.button"
          >
            <Plus size={14} />
            Add Holiday
          </button>
        </div>
      </div>

      {/* Save */}
      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          className="h-11 px-6"
          data-ocid="settings.academic_calendar.save.button"
        >
          Save Academic Calendar
        </Button>
      </div>
    </div>
  );
}
