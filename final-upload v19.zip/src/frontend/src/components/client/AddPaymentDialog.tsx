import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useERPStore } from "@/stores/useAppStore";
import type { PaymentLedgerEntry, PaymentMode } from "@/types";
import { Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

interface AddPaymentDialogProps {
  open: boolean;
  onClose: () => void;
  clientId: string;
  clientInvoices: Array<{ id: string; invoiceNumber: string }>;
  editEntry?: PaymentLedgerEntry | null;
}

const defaultForm = {
  date: "",
  amount: "",
  mode: "cash" as PaymentMode,
  note: "",
  linkedInvoiceId: "",
};

export default function AddPaymentDialog({
  open,
  onClose,
  clientId,
  clientInvoices,
  editEntry,
}: AddPaymentDialogProps) {
  const { addClientPayment, editClientPayment } = useERPStore();
  const [form, setForm] = useState(defaultForm);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      if (editEntry) {
        setForm({
          date: editEntry.date,
          amount: String(editEntry.amount),
          mode: editEntry.mode,
          note: editEntry.note ?? "",
          linkedInvoiceId: editEntry.linkedInvoiceId ?? "",
        });
      } else {
        setForm({
          ...defaultForm,
          date: new Date().toISOString().split("T")[0],
        });
      }
    }
  }, [open, editEntry]);

  const set = (field: keyof typeof form, value: string) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = Number.parseFloat(form.amount);
    if (!form.date || Number.isNaN(amount) || amount <= 0) {
      toast.error("Please enter a valid date and amount");
      return;
    }
    setSaving(true);
    try {
      if (editEntry) {
        editClientPayment(clientId, editEntry.id, {
          date: form.date,
          amount,
          mode: form.mode,
          note: form.note || undefined,
          linkedInvoiceId: form.linkedInvoiceId || undefined,
        });
        toast.success("Payment updated");
      } else {
        addClientPayment(clientId, {
          date: form.date,
          amount,
          mode: form.mode,
          note: form.note || undefined,
          linkedInvoiceId: form.linkedInvoiceId || undefined,
          linkedClientId: clientId,
        });
        toast.success("Payment added");
      }
      onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !saving && !o && onClose()}>
      <DialogContent
        className="w-[95vw] max-w-lg max-h-[90vh] overflow-y-auto sm:w-full"
        data-ocid="client_profile.payment_dialog"
      >
        <DialogHeader>
          <DialogTitle className="font-display text-lg">
            {editEntry ? "Edit Payment" : "Add Payment"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="pay-date">
                Date <span className="text-primary">*</span>
              </Label>
              <Input
                id="pay-date"
                type="date"
                value={form.date}
                onChange={(e) => set("date", e.target.value)}
                required
                data-ocid="client_profile.payment.date_input"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pay-amount">
                Amount <span className="text-primary">*</span>
              </Label>
              <Input
                id="pay-amount"
                type="number"
                min="0"
                step="0.01"
                placeholder="0.00"
                value={form.amount}
                onChange={(e) => set("amount", e.target.value)}
                required
                data-ocid="client_profile.payment.amount_input"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pay-mode">Payment Mode</Label>
            <Select
              value={form.mode}
              onValueChange={(v) => set("mode", v as PaymentMode)}
            >
              <SelectTrigger id="pay-mode">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cash">Cash</SelectItem>
                <SelectItem value="upi">UPI</SelectItem>
                <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                <SelectItem value="cheque">Cheque</SelectItem>
                <SelectItem value="card">Card</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pay-invoice">Linked Invoice</Label>
            <Select
              value={form.linkedInvoiceId}
              onValueChange={(v) =>
                set("linkedInvoiceId", v === "none" ? "" : v)
              }
            >
              <SelectTrigger id="pay-invoice">
                <SelectValue placeholder="Select invoice (optional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {clientInvoices.map((inv) => (
                  <SelectItem key={inv.id} value={inv.id}>
                    {inv.invoiceNumber}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pay-note">Note</Label>
            <Textarea
              id="pay-note"
              placeholder="Optional note"
              value={form.note}
              onChange={(e) => set("note", e.target.value)}
              rows={2}
              data-ocid="client_profile.payment.note_textarea"
            />
          </div>
          <div className="flex justify-end gap-3 pt-1">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={saving}
              data-ocid="client_profile.payment.cancel_button"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              disabled={saving}
              data-ocid="client_profile.payment.submit_button"
            >
              {saving ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : null}
              {editEntry ? "Update Payment" : "Add Payment"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
