import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatDate } from "@/lib/utils";
import type { Invoice } from "@/types";
import { useNavigate } from "@tanstack/react-router";
import { Clock, FileText, MapPin } from "lucide-react";
import { useMemo } from "react";

const sortByDateTime = (
  a: {
    date?: string;
    dateRangeStart?: string;
    startDate?: string;
    startTime?: string;
  },
  b: {
    date?: string;
    dateRangeStart?: string;
    startDate?: string;
    startTime?: string;
  },
) => {
  const dateA = new Date(
    a.date || a.dateRangeStart || a.startDate || "",
  ).getTime();
  const dateB = new Date(
    b.date || b.dateRangeStart || b.startDate || "",
  ).getTime();
  if (dateA !== dateB) return dateA - dateB;
  const timeA = (a.startTime || "").toString();
  const timeB = (b.startTime || "").toString();
  return timeA.localeCompare(timeB);
};

interface ClientProgramsTabProps {
  clientInvoices: Invoice[];
}

export default function ClientProgramsTab({
  clientInvoices,
}: ClientProgramsTabProps) {
  const navigate = useNavigate();

  const programsByInvoice = useMemo(
    () =>
      clientInvoices
        .filter((inv) => (inv.programs ?? []).some((p) => p.enabled))
        .map((inv) => ({
          invoice: inv,
          programs: (inv.programs ?? [])
            .filter((p) => p.enabled)
            .sort(sortByDateTime),
        })),
    [clientInvoices],
  );

  const totalPrograms = useMemo(
    () => programsByInvoice.reduce((sum, g) => sum + g.programs.length, 0),
    [programsByInvoice],
  );

  if (totalPrograms === 0) {
    return (
      <div
        className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3"
        data-ocid="client_profile.programs.empty_state"
      >
        <Clock className="w-10 h-10 opacity-40" />
        <p className="font-medium">No programs found</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        {totalPrograms} program{totalPrograms !== 1 ? "s" : ""} across{" "}
        {programsByInvoice.length} invoice
        {programsByInvoice.length !== 1 ? "s" : ""}
      </p>
      {programsByInvoice.map(({ invoice, programs }) => (
        <Card key={invoice.id} className="border border-border">
          <CardHeader className="pb-3">
            <CardTitle className="font-display text-base flex items-center gap-2 flex-wrap">
              <FileText className="w-4 h-4 text-primary" />
              <span>{invoice.invoiceNumber}</span>
              <span className="text-sm font-normal text-muted-foreground">
                · {invoice.eventType}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {programs.map((program, idx) => (
              <div
                key={program.id}
                className="flex items-start justify-between gap-3 p-3 rounded-lg bg-muted/30"
                data-ocid={`client_profile.program.item.${idx + 1}`}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-sm text-foreground">
                      {program.name}
                    </span>
                    {program.date && (
                      <Badge variant="secondary" className="text-xs">
                        {formatDate(program.date)}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground flex-wrap">
                    {program.startTime && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {program.startTime}
                        {program.endTime ? ` – ${program.endTime}` : ""}
                      </span>
                    )}
                    {program.location && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {program.location}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
            <button
              type="button"
              className="text-xs text-primary font-medium hover:underline mt-1"
              onClick={() => navigate({ to: `/invoices/${invoice.id}` })}
              data-ocid="client_profile.program.invoice_link"
            >
              Open Invoice
            </button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
