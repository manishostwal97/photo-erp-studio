import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useERPStore } from "@/stores/useAppStore";
import type { RentalEntry } from "@/types";
import { Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

interface AddRentalDialogProps {
  open: boolean;
  onClose: () => void;
  clientId: string;
}

const defaultForm = {
  equipmentType: "camera" as RentalEntry["equipmentType"],
  vendor: "",
  rentAmount: "",
  paidAmount: "",
  startDate: "",
  endDate: "",
  invoiceId: "",
  notes: "",
};

export default function AddRentalDialog({
  open,
  onClose,
  clientId,
}: AddRentalDialogProps) {
  const { addEquipmentRental, invoices } = useERPStore();
  const [form, setForm] = useState(defaultForm);
  const [saving, setSaving] = useState(false);

  // Get invoices for this client
  const clientInvoices = invoices.filter((inv) => inv.clientId === clientId);

  useEffect(() => {
    if (open) {
      setForm({
        ...defaultForm,
        startDate: new Date().toISOString().split("T")[0],
      });
    }
  }, [open]);

  const set = (field: keyof typeof form, value: string) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const rentAmount = Number.parseFloat(form.rentAmount);
    const paidAmount = Number.parseFloat(form.paidAmount) || 0;
    if (
      !form.vendor.trim() ||
      Number.isNaN(rentAmount) ||
      rentAmount <= 0 ||
      !form.startDate
    ) {
      toast.error("Please fill all required fields");
      return;
    }
    setSaving(true);
    try {
      const rental: RentalEntry = {
        id: `rental-${Date.now()}`,
        clientId,
        equipmentType: form.equipmentType,
        vendor: form.vendor,
        rentAmount,
        paidAmount,
        dueAmount: Math.max(0, rentAmount - paidAmount),
        startDate: form.startDate,
        endDate: form.endDate || undefined,
        invoiceId: form.invoiceId || undefined,
        status: "active",
        notes: form.notes || undefined,
        createdAt: new Date().toISOString(),
      };
      addEquipmentRental(rental);
      toast.success("Rental added");
      onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !saving && !o && onClose()}>
      <DialogContent
        className="w-[95vw] max-w-lg max-h-[90vh] overflow-y-auto sm:w-full"
        data-ocid="client_profile.rental_dialog"
      >
        <DialogHeader>
          <DialogTitle className="font-display text-lg">
            Add Equipment Rental
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="rental-type">
                Equipment Type <span className="text-primary">*</span>
              </Label>
              <Select
                value={form.equipmentType}
                onValueChange={(v) =>
                  set("equipmentType", v as RentalEntry["equipmentType"])
                }
              >
                <SelectTrigger id="rental-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="camera">Camera</SelectItem>
                  <SelectItem value="lens">Lens</SelectItem>
                  <SelectItem value="drone">Drone</SelectItem>
                  <SelectItem value="light">Light</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="rental-invoice">Linked Invoice (optional)</Label>
              <Select
                value={form.invoiceId}
                onValueChange={(v) => set("invoiceId", v)}
              >
                <SelectTrigger id="rental-invoice">
                  <SelectValue placeholder="Select invoice..." />
                </SelectTrigger>
                <SelectContent>
                  {clientInvoices.length === 0 ? (
                    <div className="px-2 py-1.5 text-xs text-muted-foreground">
                      No invoices for this client
                    </div>
                  ) : (
                    clientInvoices.map((inv) => (
                      <SelectItem key={inv.id} value={inv.id}>
                        #{inv.invoiceNumber} – {inv.eventType}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="rental-vendor">
              Vendor <span className="text-primary">*</span>
            </Label>
            <Input
              id="rental-vendor"
              placeholder="Vendor name"
              value={form.vendor}
              onChange={(e) => set("vendor", e.target.value)}
              required
              data-ocid="client_profile.rental.vendor_input"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="rental-amount">
                Rent Amount <span className="text-primary">*</span>
              </Label>
              <Input
                id="rental-amount"
                type="number"
                min="0"
                step="0.01"
                placeholder="0.00"
                value={form.rentAmount}
                onChange={(e) => set("rentAmount", e.target.value)}
                required
                data-ocid="client_profile.rental.amount_input"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="rental-paid">Paid Amount</Label>
              <Input
                id="rental-paid"
                type="number"
                min="0"
                step="0.01"
                placeholder="0.00"
                value={form.paidAmount}
                onChange={(e) => set("paidAmount", e.target.value)}
                data-ocid="client_profile.rental.paid_input"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="rental-start">
                Start Date <span className="text-primary">*</span>
              </Label>
              <Input
                id="rental-start"
                type="date"
                value={form.startDate}
                onChange={(e) => set("startDate", e.target.value)}
                required
                data-ocid="client_profile.rental.start_date_input"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="rental-end">End Date</Label>
              <Input
                id="rental-end"
                type="date"
                value={form.endDate}
                onChange={(e) => set("endDate", e.target.value)}
                data-ocid="client_profile.rental.end_date_input"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="rental-notes">Notes</Label>
            <Textarea
              id="rental-notes"
              placeholder="Optional notes"
              value={form.notes}
              onChange={(e) => set("notes", e.target.value)}
              rows={2}
              data-ocid="client_profile.rental.notes_textarea"
            />
          </div>
          <div className="flex justify-end gap-3 pt-1">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={saving}
              data-ocid="client_profile.rental.cancel_button"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              disabled={saving}
              data-ocid="client_profile.rental.submit_button"
            >
              {saving ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : null}
              Add Rental
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
