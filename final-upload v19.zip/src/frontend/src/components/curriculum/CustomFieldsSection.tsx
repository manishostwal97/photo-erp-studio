import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ExternalLink, Layers } from "lucide-react";
import type { CustomFramework } from "../../lib/customFrameworks";
import { getCustomFrameworks } from "../../lib/customFrameworks";
import TagInputInline from "./TagInputInline";

interface CustomFieldsSectionProps {
  /** The course's framework — only renders if === 'custom' */
  courseFramework: string | undefined;
  /** The custom framework ID stored on the course */
  frameworkId: string | number | undefined;
  /** Current field values */
  customFieldValues: Record<string, string | string[]>;
  /** Called with the merged next value map */
  onChange: (next: Record<string, string | string[]>) => void;
  /** Prefix for HTML id attributes to ensure uniqueness between board/standard mode */
  idPrefix?: string;
  /** Whether to show a section header with icon */
  showHeader?: boolean;
}

export default function CustomFieldsSection({
  courseFramework,
  frameworkId,
  customFieldValues,
  onChange,
  idPrefix = "custom-unit",
  showHeader = true,
}: CustomFieldsSectionProps) {
  if (courseFramework !== "custom") return null;
  if (!frameworkId) return null;

  const allFrameworks: CustomFramework[] = getCustomFrameworks();
  const fw = allFrameworks.find((f) => f.id === String(frameworkId));
  if (!fw) return null;

  const unitFields = fw.fields.filter((f) => f.level === "unit");
  if (unitFields.length === 0) return null;

  const handleChange = (fieldId: string, value: string | string[]) => {
    onChange({ ...customFieldValues, [fieldId]: value });
  };

  return (
    <div className="space-y-4 py-4">
      {showHeader && (
        <div className="flex items-center gap-2 mb-2">
          <Layers size={15} className="text-muted-foreground" />
          <h3 className="text-sm font-semibold text-foreground">
            Custom fields
          </h3>
        </div>
      )}
      {unitFields.map((f) => {
        const rawVal = customFieldValues[f.id];
        const inputId = `${idPrefix}-${f.id}`;
        return (
          <div key={f.id} className="space-y-1.5">
            <Label
              htmlFor={inputId}
              className="text-xs font-medium text-foreground"
            >
              {f.label}
              {f.required && <span className="text-destructive ml-0.5">*</span>}
            </Label>
            {f.description && (
              <p className="text-xs text-muted-foreground mt-0.5 mb-1.5">
                {f.description}
              </p>
            )}
            {f.type === "long-text" ? (
              <Textarea
                id={inputId}
                value={typeof rawVal === "string" ? rawVal : ""}
                onChange={(e) => handleChange(f.id, e.target.value)}
                placeholder={f.placeholder}
                rows={2}
              />
            ) : f.type === "list" ? (
              <TagInputInline
                values={Array.isArray(rawVal) ? rawVal : []}
                onChange={(vals) => handleChange(f.id, vals)}
                placeholder={f.placeholder}
              />
            ) : f.type === "date" ? (
              <Input
                id={inputId}
                type="date"
                value={typeof rawVal === "string" ? rawVal : ""}
                onChange={(e) => handleChange(f.id, e.target.value)}
              />
            ) : f.type === "number" ? (
              <Input
                id={inputId}
                type="number"
                value={typeof rawVal === "string" ? rawVal : ""}
                onChange={(e) => handleChange(f.id, e.target.value)}
                placeholder={f.placeholder}
                className="w-40"
              />
            ) : f.type === "select" ? (
              <Select
                value={typeof rawVal === "string" ? rawVal : ""}
                onValueChange={(v) => handleChange(f.id, v)}
                disabled={!f.options?.length}
              >
                <SelectTrigger id={inputId} className="h-9 text-sm">
                  <SelectValue
                    placeholder={
                      f.options?.length
                        ? "Select an option…"
                        : "No options defined"
                    }
                  />
                </SelectTrigger>
                <SelectContent>
                  {(f.options ?? []).map((opt) => (
                    <SelectItem key={opt} value={opt}>
                      {opt}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : f.type === "checkbox" ? (
              <div className="flex items-center gap-2">
                <Checkbox
                  id={inputId}
                  checked={rawVal === "true"}
                  onCheckedChange={(checked) =>
                    handleChange(f.id, String(checked))
                  }
                />
                <label
                  htmlFor={inputId}
                  className="text-sm text-foreground cursor-pointer"
                >
                  {f.label}
                </label>
              </div>
            ) : f.type === "url" ? (
              <div className="relative">
                <Input
                  id={inputId}
                  type="url"
                  value={typeof rawVal === "string" ? rawVal : ""}
                  onChange={(e) => handleChange(f.id, e.target.value)}
                  placeholder={f.placeholder || "https://…"}
                  className="pr-8"
                />
                {typeof rawVal === "string" && rawVal && (
                  <a
                    href={rawVal}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    <ExternalLink size={13} />
                  </a>
                )}
              </div>
            ) : (
              <Input
                id={inputId}
                value={typeof rawVal === "string" ? rawVal : ""}
                onChange={(e) => handleChange(f.id, e.target.value)}
                placeholder={f.placeholder}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
