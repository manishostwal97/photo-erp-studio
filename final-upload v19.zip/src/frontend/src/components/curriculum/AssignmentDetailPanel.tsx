export default function AssignmentDetailPanel() {
  return null;
}
