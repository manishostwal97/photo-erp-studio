import { toast } from "sonner";

export type PresetId = "ubd" | "minimal" | "assessment";

export interface PresetUpdate {
  enduringUnderstandings?: string;
  essentialQuestion?: string;
  learningObjectives?: string[];
}

const PRESETS: Array<{
  id: PresetId;
  label: string;
  desc: string;
  update: PresetUpdate;
}> = [
  {
    id: "ubd",
    label: "Full UbD",
    desc: "Enduring Understanding + Essential Questions + Learning Objectives",
    update: {
      enduringUnderstandings:
        "Students will understand that skilled readers analyze how authors use language, structure, and perspective to construct meaning and shape audience response.",
      essentialQuestion:
        "How do authors use craft and structure to persuade, inform, and inspire?",
      learningObjectives: [
        "Analyze rhetorical strategies in nonfiction texts",
        "Evaluate how an author's choices affect meaning and tone",
        "Construct evidence-based arguments about a text's effectiveness",
      ],
    },
  },
  {
    id: "minimal",
    label: "Minimal Planning",
    desc: "1 Learning Objective, all other framework fields cleared",
    update: {
      enduringUnderstandings: "",
      essentialQuestion: "",
      learningObjectives: [
        "Students will be able to demonstrate mastery of unit concepts through structured tasks.",
      ],
    },
  },
  {
    id: "assessment",
    label: "Assessment-Focused",
    desc: "Essential Question + Summative Assessment objective",
    update: {
      essentialQuestion:
        "How will students demonstrate deep understanding of this unit's core concepts?",
      learningObjectives: [
        "Summative Assessment: Students will produce a culminating project or exam demonstrating mastery of unit standards.",
      ],
    },
  },
];

interface UnitPresetPickerProps {
  /** ocid scope prefix — board uses 'curriculum.unit', structure uses 'curriculum.structure.unit' */
  ocidPrefix?: string;
  onApply: (update: PresetUpdate, label: string) => void;
  onClose: () => void;
}

export default function UnitPresetPicker({
  ocidPrefix = "curriculum.unit",
  onApply,
  onClose,
}: UnitPresetPickerProps) {
  return (
    <div
      className="border-b border-border/20 px-5 py-4 bg-muted/30 flex-shrink-0"
      data-ocid={`${ocidPrefix}.preset.panel`}
    >
      <p className="text-xs font-medium text-muted-foreground mb-3">
        Apply preset
      </p>
      <div className="space-y-1">
        {PRESETS.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => {
              onApply(p.update, p.label);
              toast.success(`Applied "${p.label}" preset`);
            }}
            className="w-full text-left px-4 py-3 rounded-lg hover:bg-background border border-transparent hover:border-border transition-all group"
            data-ocid={`${ocidPrefix}.preset.${p.id}.button`}
          >
            <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
              {p.label}
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">{p.desc}</p>
          </button>
        ))}
      </div>
      <button
        type="button"
        onClick={onClose}
        className="mt-2 text-xs text-muted-foreground hover:text-foreground transition-colors"
        data-ocid={`${ocidPrefix}.preset.close_button`}
      >
        Cancel
      </button>
    </div>
  );
}
