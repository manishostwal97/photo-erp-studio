import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  BookOpen,
  Calculator,
  Check,
  ChevronRight,
  FlaskConical,
  Globe,
  Plus,
  X,
} from "lucide-react";
import { useState } from "react";
import {
  CURRICULUM_TEMPLATES,
  type CurriculumTemplate,
} from "../../data/curriculumTemplates";

interface CourseTemplatePickerPanelProps {
  onSelect: (templateId: string) => void;
  onDismiss: () => void;
}

const SUBJECT_ICONS: Record<CurriculumTemplate["subject"], React.ReactNode> = {
  ela: <BookOpen size={20} />,
  science: <FlaskConical size={20} />,
  "social-studies": <Globe size={20} />,
  math: <Calculator size={20} />,
  blank: <Plus size={20} />,
};

const SUBJECT_COLORS: Record<
  CurriculumTemplate["subject"],
  { bg: string; text: string }
> = {
  ela: { bg: "bg-violet-100", text: "text-violet-700" },
  science: { bg: "bg-teal-100", text: "text-teal-700" },
  "social-studies": { bg: "bg-amber-100", text: "text-amber-700" },
  math: { bg: "bg-blue-100", text: "text-blue-700" },
  blank: { bg: "bg-muted", text: "text-muted-foreground" },
};

const FRAMEWORK_LABELS: Record<string, string> = {
  ubd: "UbD",
  backwards: "Backwards Design",
  "5e": "5E Model",
  ims: "EdUnite Simple",
  udl: "UDL",
  pbl: "PBL",
  di: "DI",
  ib: "IB MYP",
  minimal: "Minimal",
  siop: "SIOP",
  custom: "Custom",
};

export function CourseTemplatePickerPanel({
  onSelect,
  onDismiss,
}: CourseTemplatePickerPanelProps) {
  const [selected, setSelected] = useState<string | null>(null);

  const handleConfirm = () => {
    if (selected) {
      onSelect(selected);
    }
  };

  return (
    <div
      className="border border-border rounded-xl bg-card mb-4 overflow-hidden"
      data-ocid="curriculum.template_picker.panel"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-border">
        <div>
          <h3 className="text-sm font-semibold text-foreground">
            Start from a template
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Choose a starter or begin with a blank course.
          </p>
        </div>
        <button
          type="button"
          onClick={onDismiss}
          className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          aria-label="Dismiss template picker"
          data-ocid="curriculum.template_picker.close_button"
        >
          <X size={15} />
        </button>
      </div>

      {/* Template Grid */}
      <div className="p-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
        {CURRICULUM_TEMPLATES.map((tpl) => {
          const isSelected = selected === tpl.id;
          const colors = SUBJECT_COLORS[tpl.subject];
          return (
            <button
              key={tpl.id}
              type="button"
              onClick={() => setSelected(isSelected ? null : tpl.id)}
              className={[
                "relative text-left rounded-xl border-2 p-4 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                isSelected
                  ? "border-primary bg-primary/5 shadow-sm"
                  : "border-border bg-background hover:border-primary/40 hover:bg-accent/40",
              ].join(" ")}
              data-ocid={`curriculum.template_picker.item.${CURRICULUM_TEMPLATES.indexOf(tpl) + 1}`}
            >
              {/* Selected check */}
              {isSelected && (
                <span className="absolute top-2.5 right-2.5 w-5 h-5 rounded-full bg-primary flex items-center justify-center">
                  <Check size={11} className="text-primary-foreground" />
                </span>
              )}

              {/* Icon */}
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${colors.bg} ${colors.text}`}
              >
                {SUBJECT_ICONS[tpl.subject]}
              </div>

              {/* Name */}
              <p className="text-sm font-semibold text-foreground leading-tight mb-1">
                {tpl.name}
              </p>

              {/* Description */}
              <p className="text-[11px] text-muted-foreground leading-relaxed mb-3 line-clamp-2">
                {tpl.description}
              </p>

              {/* Footer metadata */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {tpl.framework ? (
                  <Badge
                    variant="secondary"
                    className="text-[10px] px-1.5 py-0 h-4"
                  >
                    {FRAMEWORK_LABELS[tpl.framework] ?? tpl.framework}
                  </Badge>
                ) : null}
                {tpl.units.length > 0 ? (
                  <span className="text-[10px] text-muted-foreground">
                    {tpl.units.length} units
                  </span>
                ) : (
                  <span className="text-[10px] text-muted-foreground">
                    Empty start
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Action bar */}
      <div className="px-4 pb-4 flex items-center gap-2">
        <Button
          size="sm"
          disabled={!selected}
          onClick={handleConfirm}
          className="gap-1.5"
          data-ocid="curriculum.template_picker.use_button"
        >
          Use this template
          <ChevronRight size={14} />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={onDismiss}
          data-ocid="curriculum.template_picker.skip_button"
        >
          Skip — blank course
        </Button>
      </div>
    </div>
  );
}
