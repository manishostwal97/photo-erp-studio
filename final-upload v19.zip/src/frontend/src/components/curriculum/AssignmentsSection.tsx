export default function AssignmentsSection() {
  return null;
}
