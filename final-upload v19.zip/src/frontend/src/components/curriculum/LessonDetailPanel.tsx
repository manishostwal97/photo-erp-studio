export default function LessonDetailPanel() {
  return null;
}
