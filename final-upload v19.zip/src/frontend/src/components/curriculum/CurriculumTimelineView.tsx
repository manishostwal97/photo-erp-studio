export default function CurriculumTimelineView() {
  return null;
}
