export default function UnitDetailPanel() {
  return null;
}
