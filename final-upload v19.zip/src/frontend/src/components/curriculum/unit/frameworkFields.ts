// ─── Framework Planning Field Definitions ────────────────────────────────────
// Extracted from UnitDetailPanel.tsx for maintainability.

export interface FwFieldDef {
  key: string;
  label: string;
  placeholder: string;
  multiline?: boolean;
}

export const FRAMEWORK_PLANNING_FIELDS: Record<string, FwFieldDef[]> = {
  ubd: [
    {
      key: "transferGoals",
      label: "Transfer Goals",
      placeholder: "What should students be able to do long-term?",
      multiline: true,
    },
    {
      key: "enduringUnderstandings",
      label: "Enduring Understandings",
      placeholder: "Big ideas students should retain beyond this unit...",
      multiline: true,
    },
    {
      key: "essentialQuestions",
      label: "Essential Questions",
      placeholder: "Open-ended questions that drive inquiry...",
      multiline: true,
    },
    {
      key: "performanceTasks",
      label: "Performance Tasks",
      placeholder: "How students demonstrate understanding...",
      multiline: true,
    },
    {
      key: "learningActivities",
      label: "Learning Activities",
      placeholder: "Key instructional activities and experiences...",
      multiline: true,
    },
  ],
  backwards: [
    {
      key: "desiredGoals",
      label: "Desired Goals",
      placeholder: "What should students know, understand, and be able to do?",
      multiline: true,
    },
    {
      key: "assessmentEvidence",
      label: "Assessment Evidence",
      placeholder: "How will you know they've learned it?",
      multiline: true,
    },
    {
      key: "essentialQuestions",
      label: "Essential Questions",
      placeholder: "Open-ended questions that frame the unit...",
      multiline: true,
    },
    {
      key: "learningExperiences",
      label: "Learning Experiences",
      placeholder: "Planned activities and instructional sequence...",
      multiline: true,
    },
  ],
  "5e": [
    {
      key: "engagePhase",
      label: "Engage",
      placeholder: "Hook students and activate prior knowledge...",
      multiline: true,
    },
    {
      key: "explorePhase",
      label: "Explore",
      placeholder: "Hands-on investigation and student discovery...",
      multiline: true,
    },
    {
      key: "explainPhase",
      label: "Explain",
      placeholder: "Direct instruction and concept clarification...",
      multiline: true,
    },
    {
      key: "elaboratePhase",
      label: "Elaborate",
      placeholder: "Apply concepts to new contexts and deepen understanding...",
      multiline: true,
    },
    {
      key: "evaluatePhase",
      label: "Evaluate",
      placeholder: "Formal and informal assessment criteria...",
      multiline: true,
    },
  ],
  ims: [
    {
      key: "learningIntention",
      label: "Learning Intention",
      placeholder: "What will students learn in this unit?",
      multiline: false,
    },
    {
      key: "successCriteria",
      label: "Success Criteria",
      placeholder: "How will students know they've succeeded?",
      multiline: true,
    },
    {
      key: "keyActivities",
      label: "Key Activities",
      placeholder: "Core activities and instructional sequence...",
      multiline: true,
    },
  ],
  udl: [
    {
      key: "engagementStrategies",
      label: "Multiple Means of Engagement",
      placeholder: "How will you motivate and engage all learners?",
      multiline: true,
    },
    {
      key: "representationOptions",
      label: "Multiple Means of Representation",
      placeholder: "How will you present content in multiple formats?",
      multiline: true,
    },
    {
      key: "actionExpressionOptions",
      label: "Multiple Means of Action & Expression",
      placeholder:
        "How can students demonstrate understanding in different ways?",
      multiline: true,
    },
    {
      key: "barriersSupports",
      label: "Barriers & Supports",
      placeholder:
        "Anticipated barriers and planned supports for all learners...",
      multiline: true,
    },
  ],
  pbl: [
    {
      key: "drivingQuestion",
      label: "Driving Question",
      placeholder:
        "The central, open-ended question that anchors the project...",
      multiline: false,
    },
    {
      key: "sustainedInquiry",
      label: "Sustained Inquiry",
      placeholder: "How will students develop and refine questions over time?",
      multiline: true,
    },
    {
      key: "authenticContext",
      label: "Authentic Context",
      placeholder: "Real-world problem, audience, or community connection...",
      multiline: true,
    },
    {
      key: "critiqueRevision",
      label: "Critique & Revision Plan",
      placeholder: "How will students give and receive structured feedback?",
      multiline: true,
    },
    {
      key: "publicProductDescription",
      label: "Public Product",
      placeholder:
        "What will students create and share with an authentic audience?",
      multiline: true,
    },
  ],
  di: [
    {
      key: "contentDifferentiation",
      label: "Content Differentiation",
      placeholder:
        "How will you vary what students learn by readiness, interest, or learning profile?",
      multiline: true,
    },
    {
      key: "processDifferentiation",
      label: "Process Differentiation",
      placeholder:
        "How will you vary activities so all students make sense of the ideas?",
      multiline: true,
    },
    {
      key: "productDifferentiation",
      label: "Product Differentiation",
      placeholder: "What different ways can students demonstrate mastery?",
      multiline: true,
    },
    {
      key: "groupingStrategy",
      label: "Student Grouping Strategy",
      placeholder: "e.g. Flexible groups by readiness, interest-based pairs...",
      multiline: false,
    },
  ],
  ib: [
    {
      key: "keyConcept",
      label: "Key Concept",
      placeholder:
        "The overarching concept (e.g. Change, Communication, Relationships)...",
      multiline: false,
    },
    {
      key: "relatedConcepts",
      label: "Related Concepts",
      placeholder: "Subject-specific concepts that add depth...",
      multiline: false,
    },
    {
      key: "globalContext",
      label: "Global Context",
      placeholder:
        "The lens for inquiry (e.g. Identities and Relationships, Fairness and Development)...",
      multiline: false,
    },
    {
      key: "statementOfInquiry",
      label: "Statement of Inquiry",
      placeholder:
        "Meaningful statement connecting key concept, related concepts, and global context...",
      multiline: true,
    },
    {
      key: "atlSkills",
      label: "ATL Skills",
      placeholder: "Approaches to Learning skills this unit develops...",
      multiline: true,
    },
    {
      key: "summativeTask",
      label: "Summative Assessment Task",
      placeholder:
        "How students will demonstrate understanding at the end of the unit...",
      multiline: true,
    },
  ],
  siop: [
    {
      key: "contentObjective",
      label: "Content Objective",
      placeholder: "What content knowledge or skill will students learn today?",
      multiline: false,
    },
    {
      key: "languageObjective",
      label: "Language Objective",
      placeholder:
        "What language function will students practice (e.g. describe, compare, explain)?",
      multiline: false,
    },
    {
      key: "buildingBackground",
      label: "Building Background",
      placeholder:
        "Key vocabulary, content connections, and links to student experience...",
      multiline: true,
    },
    {
      key: "interactionStrategies",
      label: "Interaction Strategies",
      placeholder:
        "Planned student-student and student-teacher interaction structures...",
      multiline: true,
    },
    {
      key: "reviewAssessment",
      label: "Review / Assessment",
      placeholder:
        "How will you review key vocabulary and concepts and assess understanding?",
      multiline: true,
    },
  ],
};

export const FRAMEWORK_LABELS: Record<string, string> = {
  ubd: "UbD Planning Fields",
  backwards: "Backwards Design Fields",
  "5e": "5E Model Fields",
  ims: "EdUnite Simple Fields",
  udl: "UDL Planning Fields",
  pbl: "PBL Planning Fields",
  di: "Differentiated Instruction Fields",
  ib: "IB MYP Planning Fields",
  siop: "SIOP Planning Fields",
  minimal: "Unit Details",
  custom: "Custom Fields",
};
