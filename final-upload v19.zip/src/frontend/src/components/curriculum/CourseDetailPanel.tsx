export default function CourseDetailPanel() {
  return null;
}
