export default function CurriculumImportExport() {
  return null;
}
