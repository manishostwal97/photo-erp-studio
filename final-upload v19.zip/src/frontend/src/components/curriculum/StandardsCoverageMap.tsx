export default function StandardsCoverageMap() {
  return null;
}
