import { Input } from "@/components/ui/input";
import { X } from "lucide-react";
import { useState } from "react";

export default function TagInputInline({
  values,
  onChange,
  placeholder,
}: {
  values: string[];
  onChange: (vals: string[]) => void;
  placeholder?: string;
}) {
  const [input, setInput] = useState("");
  return (
    <div className="space-y-1.5">
      <div className="flex flex-wrap gap-1.5">
        {values.map((v) => (
          <span
            key={v}
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium"
          >
            {v}
            <button
              type="button"
              onClick={() => onChange(values.filter((x) => x !== v))}
              aria-label={`Remove ${v}`}
            >
              <X size={10} />
            </button>
          </span>
        ))}
      </div>
      <Input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => {
          if ((e.key === "Enter" || e.key === ",") && input.trim()) {
            e.preventDefault();
            const trimmed = input.trim().replace(/,$/, "");
            if (trimmed) {
              onChange([...values, trimmed]);
              setInput("");
            }
          }
        }}
        placeholder={placeholder ?? "Type and press Enter to add..."}
        className="text-sm"
      />
    </div>
  );
}
