export default function ModuleDetailPanel() {
  return null;
}
