export default function CourseMapView() {
  return null;
}
