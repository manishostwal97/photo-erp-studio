import { PillTabs } from "@/components/shared/PillTabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import {
  Calendar,
  ChevronDown,
  ChevronUp,
  Clock,
  Mail,
  MessageSquare,
  Send,
  Users,
  X,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import {
  type ScheduledMessage,
  type SentMessage,
  type ThreadEntry,
  addMessage,
  addThreadEntry,
  cancelScheduledMessage,
  getMessages,
  getScheduledMessages,
  markMessageRead,
  scheduleMessage,
  updateMessageStatus,
} from "../../lib/communicationStore";
import MessageTemplates from "./MessageTemplates";

// Load real class names from localStorage timetable/classes data
function loadClassOptions(): Array<{
  value: string;
  label: string;
  count: number;
}> {
  const base: Array<{ value: string; label: string; count: number }> = [
    { value: "all_parents", label: "All Parents", count: 0 },
  ];
  try {
    const ttRaw = localStorage.getItem("edunite_timetable");
    const studRaw = localStorage.getItem("edunite_students");
    const students: Array<{ classId?: string }> = studRaw
      ? JSON.parse(studRaw)
      : [];
    if (ttRaw) {
      const tt = JSON.parse(ttRaw);
      const periods: Array<{ id?: string; name: string; subject?: string }> =
        Array.isArray(tt.periods) ? tt.periods : Array.isArray(tt) ? tt : [];
      if (periods.length > 0) {
        const opts = periods.slice(0, 8).map((p, i) => {
          const label = p.subject ? `${p.name} — ${p.subject}` : p.name;
          const count = students.filter((s) => s.classId === p.id).length || 0;
          return { value: p.id ?? `period_${i + 1}`, label, count };
        });
        base[0].count = opts.reduce((s, o) => s + o.count, 0);
        return [...base, ...opts];
      }
    }
    const clsRaw = localStorage.getItem("edunite_classes");
    if (clsRaw) {
      const classes = JSON.parse(clsRaw);
      const list: Array<{
        id?: string;
        name: string;
        subject?: string;
        studentCount?: number;
      }> = Array.isArray(classes) ? classes : [];
      if (list.length > 0) {
        const opts = list.slice(0, 8).map((c, i) => ({
          value: c.id ?? `class_${i + 1}`,
          label: c.subject ? `${c.name} — ${c.subject}` : c.name,
          count: c.studentCount ?? 0,
        }));
        base[0].count = opts.reduce((s, o) => s + o.count, 0);
        return [...base, ...opts];
      }
    }
  } catch {
    // ignore
  }
  // No class data available yet — return base only (no fake periods)
  return base;
}

function getRecipientCount(
  to: string,
  options: ReturnType<typeof loadClassOptions>,
): number {
  return options.find((o) => o.value === to)?.count ?? 0;
}

function getRecipientLabel(
  to: string,
  options: ReturnType<typeof loadClassOptions>,
): string {
  return options.find((o) => o.value === to)?.label ?? to;
}

function advanceStatuses(messages: SentMessage[]): SentMessage[] {
  const now = Date.now();
  return messages.map((m) => {
    if (m.status === "sent" && now - m.sentAt > 30000) {
      updateMessageStatus(m.id, "delivered");
      return { ...m, status: "delivered" as const };
    }
    if (m.status === "delivered" && now - m.sentAt > 120000) {
      updateMessageStatus(m.id, "read");
      return { ...m, status: "read" as const };
    }
    return m;
  });
}

function StatusBadge({ status }: { status: SentMessage["status"] }) {
  if (status === "read")
    return (
      <Badge className="text-xs bg-success/10 text-success border-success/20 hover:bg-success/10">
        Read
      </Badge>
    );
  if (status === "delivered")
    return (
      <Badge className="text-xs bg-info/10 text-info border-info/20 hover:bg-info/10">
        Delivered
      </Badge>
    );
  return (
    <Badge variant="secondary" className="text-xs">
      Sent
    </Badge>
  );
}

function ThreadEntryRow({ entry }: { entry: ThreadEntry }) {
  const isTeacher = entry.from === "teacher";
  return (
    <div
      className={`flex gap-2 ${isTeacher ? "justify-end" : "justify-start"}`}
    >
      {!isTeacher && (
        <div className="w-7 h-7 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0 mt-0.5 border border-indigo-200">
          <span className="text-[9px] font-bold text-indigo-600">P</span>
        </div>
      )}
      <div
        className={`px-3 py-2 rounded-xl text-sm max-w-[76%] ${
          isTeacher
            ? "bg-primary text-primary-foreground rounded-br-sm"
            : "bg-slate-100 text-foreground border border-slate-200 rounded-bl-sm"
        }`}
      >
        <p
          className={`font-semibold text-xs mb-1 ${isTeacher ? "text-primary-foreground/70" : "text-indigo-600"}`}
        >
          {isTeacher ? "You" : "Parent"} ·{" "}
          {format(new Date(entry.date), "MMM d, h:mm a")}
        </p>
        <p className="leading-relaxed">{entry.body}</p>
        {entry.outcome && (
          <p
            className={`text-xs mt-1 italic ${isTeacher ? "text-primary-foreground/60" : "text-muted-foreground"}`}
          >
            Outcome: {entry.outcome}
          </p>
        )}
      </div>
      {isTeacher && (
        <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5 border border-primary/20">
          <span className="text-[9px] font-bold text-primary">T</span>
        </div>
      )}
    </div>
  );
}

function ReplyForm({
  messageId,
  onSaved,
}: {
  messageId: number;
  onSaved: () => void;
}) {
  const [from, setFrom] = useState<"parent" | "teacher">("parent");
  const [body, setBody] = useState("");
  const [outcome, setOutcome] = useState("");
  const [error, setError] = useState("");

  function handleSave() {
    if (!body.trim()) {
      setError("Reply text is required.");
      return;
    }
    const entry: ThreadEntry = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      date: new Date().toISOString(),
      from,
      body: body.trim(),
      outcome: outcome.trim() || undefined,
    };
    addThreadEntry(messageId, entry);
    setBody("");
    setOutcome("");
    setError("");
    onSaved();
    toast.success("Reply note added");
  }

  return (
    <div
      className="bg-muted/20 border border-border/60 rounded-lg p-3 space-y-2.5"
      data-ocid="communication.messages.reply.panel"
    >
      <p className="text-xs font-semibold text-muted-foreground">
        Add Reply Note
      </p>

      <div data-ocid="communication.messages.reply.toggle">
        <PillTabs
          tabs={[
            { value: "parent", label: "From Parent" },
            { value: "teacher", label: "From Me" },
          ]}
          activeTab={from}
          onChange={(v) => setFrom(v as "parent" | "teacher")}
          className="mb-0 mt-0"
        />
      </div>

      <Textarea
        value={body}
        onChange={(e) => {
          setBody(e.target.value);
          if (error) setError("");
        }}
        placeholder="Log what was said..."
        rows={2}
        className="text-sm resize-none"
        data-ocid="communication.messages.reply.textarea"
      />
      {error && <p className="text-xs text-destructive">{error}</p>}

      <input
        type="text"
        value={outcome}
        onChange={(e) => setOutcome(e.target.value)}
        placeholder="Outcome (optional)"
        className="w-full h-8 px-3 rounded-md border border-border bg-background text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        data-ocid="communication.messages.reply.outcome.input"
      />

      <div className="flex justify-end">
        <Button
          type="button"
          size="sm"
          className="h-7 text-xs gap-1"
          onClick={handleSave}
          data-ocid="communication.messages.reply.save.button"
        >
          Save Note
        </Button>
      </div>
    </div>
  );
}

function SentMessageRow({
  msg,
  index,
  onRefresh,
}: {
  msg: SentMessage;
  index: number;
  onRefresh: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [isUnread, setIsUnread] = useState(msg.unread ?? false);

  function handleExpand() {
    setExpanded((prev) => {
      if (!prev && isUnread) {
        markMessageRead(msg.id);
        setIsUnread(false);
        onRefresh();
      }
      return !prev;
    });
  }

  return (
    <div
      className={`border-b border-border/40 last:border-0 ${isUnread ? "bg-indigo-50/50 dark:bg-indigo-950/20" : ""}`}
      data-ocid={`communication.messages.sent.item.${index + 1}`}
    >
      <button
        type="button"
        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-muted/20 transition-colors text-left group"
        onClick={handleExpand}
        data-ocid={`communication.messages.sent.row.${index + 1}`}
      >
        <div className="relative flex-shrink-0">
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
            <Mail className="h-4 w-4 text-primary" />
          </div>
          {isUnread && (
            <span className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-indigo-500 border-2 border-background" />
          )}
        </div>
        <div className="flex-1 min-w-0 space-y-0.5">
          <div className="flex items-center gap-2">
            <span
              className={`text-sm truncate ${isUnread ? "font-bold text-foreground" : "font-semibold text-foreground"}`}
            >
              {getRecipientLabel(msg.to, loadClassOptions())}
            </span>
            <StatusBadge status={msg.status} />
            {msg.thread.length > 0 && (
              <Badge
                variant="secondary"
                className="text-xs whitespace-nowrap bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800"
              >
                {msg.thread.length} repl{msg.thread.length === 1 ? "y" : "ies"}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-1 min-w-0">
            <span className="text-xs text-primary/70 font-medium flex-shrink-0">
              {msg.thread.length > 0 ? "Re: " : ""}
            </span>
            <span className="text-xs text-muted-foreground truncate">
              {msg.subject}
            </span>
          </div>
          <p className="text-xs text-muted-foreground/70 truncate">
            {msg.body.slice(0, 80)}
            {msg.body.length > 80 ? "…" : ""}
          </p>
        </div>
        <div className="flex-shrink-0 flex flex-col items-end gap-1">
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            {format(new Date(msg.sentAt), "MMM d")}
          </span>
          {msg.status === "read" && (
            <span className="text-xs text-slate-400 whitespace-nowrap">
              Seen
            </span>
          )}
          {msg.status === "delivered" && (
            <span className="text-xs text-slate-400 whitespace-nowrap">
              Delivered
            </span>
          )}
          <Badge variant="outline" className="text-xs whitespace-nowrap">
            {msg.recipientCount}
          </Badge>
          <div className="text-muted-foreground group-hover:text-foreground transition-colors">
            {expanded ? (
              <ChevronUp className="h-4 w-4" />
            ) : (
              <ChevronDown className="h-4 w-4" />
            )}
          </div>
        </div>
      </button>

      {expanded && (
        <div className="px-4 pb-4 space-y-3 border-t border-border/30 bg-muted/10">
          <div className="pt-3">
            <p className="text-xs font-semibold text-muted-foreground mb-1.5">
              Message
            </p>
            <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">
              {msg.body}
            </p>
          </div>

          {msg.thread.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-semibold text-muted-foreground">
                Thread ({msg.thread.length})
              </p>
              <div className="border-l-2 border-primary/20 pl-3 space-y-2">
                {msg.thread.map((entry) => (
                  <ThreadEntryRow key={entry.id} entry={entry} />
                ))}
              </div>
            </div>
          )}

          <ReplyForm messageId={msg.id} onSaved={onRefresh} />

          {/* Simulate parent reply — dev only */}
          {import.meta.env.DEV && (
            <div className="flex justify-start">
              <button
                type="button"
                className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors px-2 py-1 rounded-md hover:bg-primary/5"
                data-ocid={`communication.messages.simulate_reply.button.${index + 1}`}
                onClick={() => {
                  const student = msg.to
                    .replace("All Parents", "your child")

                    .replace("Period 4 — Earth Science", "your child");
                  const replies = [
                    `Thank you for letting me know. I\'ll follow up with ${student === "All Parents" ? "them" : "them"} tonight.`,
                    "We appreciate the update! We'll have a conversation about this at home.",
                    "Thanks for reaching out. We'll make sure they come prepared.",
                    "Understood — we'll reinforce this at home. Thank you!",
                  ];
                  const body =
                    replies[Math.floor(Math.random() * replies.length)];
                  addThreadEntry(msg.id, {
                    id: `sim_${Date.now()}`,
                    date: new Date().toISOString(),
                    from: "parent",
                    body,
                  });
                  onRefresh();
                  toast.success("Simulated parent reply added");
                }}
              >
                <MessageSquare size={12} />
                Simulate parent reply
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function MessagesView() {
  const classOptions = loadClassOptions();
  const [to, setTo] = useState("all_parents");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [scheduleEnabled, setScheduleEnabled] = useState(false);
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("08:00");

  // Status advancement is done eagerly in the initializer — no useEffect needed
  const [sentMessages, setSentMessages] = useState<SentMessage[]>(() =>
    advanceStatuses(getMessages().sort((a, b) => b.sentAt - a.sentAt)),
  );
  const [scheduledMessages, setScheduledMessages] = useState<
    ScheduledMessage[]
  >(() => getScheduledMessages().sort((a, b) => a.scheduledAt - b.scheduledAt));
  const [errors, setErrors] = useState<{
    subject?: string;
    body?: string;
    scheduleDate?: string;
  }>({});

  function refreshMessages() {
    setSentMessages(
      advanceStatuses(getMessages().sort((a, b) => b.sentAt - a.sentAt)),
    );
  }

  function validate(): boolean {
    const newErrors: typeof errors = {};
    if (!subject.trim()) newErrors.subject = "Subject is required.";
    if (!body.trim()) newErrors.body = "Message body is required.";
    if (scheduleEnabled && !scheduleDate)
      newErrors.scheduleDate = "Please choose a date.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  function handleTemplateSelect(tplSubject: string, tplBody: string) {
    setSubject(tplSubject);
    setBody(tplBody);
    setErrors((p) => ({ ...p, subject: undefined, body: undefined }));
  }

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    const recipientCount = getRecipientCount(to, classOptions);
    const label = getRecipientLabel(to, classOptions);

    if (scheduleEnabled && scheduleDate) {
      const scheduledAt = new Date(`${scheduleDate}T${scheduleTime}`).getTime();
      const sm = scheduleMessage(
        label,
        subject.trim(),
        body.trim(),
        recipientCount,
        scheduledAt,
      );
      setScheduledMessages((prev) =>
        [...prev, sm].sort((a, b) => a.scheduledAt - b.scheduledAt),
      );
      toast.success(
        `Message scheduled for ${format(new Date(scheduledAt), "MMM d 'at' h:mm a")}`,
      );
    } else {
      setIsSending(true);
      await new Promise((r) => setTimeout(r, 600));
      const msg = addMessage(
        label,
        subject.trim(),
        body.trim(),
        recipientCount,
      );
      setSentMessages((prev) => [msg, ...prev]);
      toast.success(
        `Message sent to ${recipientCount} recipient${
          recipientCount !== 1 ? "s" : ""
        }`,
      );
      setIsSending(false);
    }

    setSubject("");
    setBody("");
    setScheduleEnabled(false);
    setScheduleDate("");
    setScheduleTime("08:00");
    setErrors({});
  }

  function handleCancelScheduled(id: number) {
    cancelScheduledMessage(id);
    setScheduledMessages(
      getScheduledMessages().sort((a, b) => a.scheduledAt - b.scheduledAt),
    );
    toast.success("Scheduled message cancelled");
  }

  return (
    <div className="space-y-6">
      {/* Compose Form */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="px-5 py-4 border-b border-border bg-muted/20">
          <div className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">
              Compose Message
            </h3>
          </div>
        </div>
        <form onSubmit={handleSend} className="px-5 py-4 space-y-4">
          {/* Templates */}
          <MessageTemplates onSelect={handleTemplateSelect} />

          {/* To */}
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold text-muted-foreground">
              To
            </Label>
            <Select value={to} onValueChange={setTo}>
              <SelectTrigger
                className="h-9 text-sm"
                data-ocid="communication.messages.to.select"
              >
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-60 overflow-y-auto">
                {classOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    <span className="flex items-center gap-2">
                      {opt.label}
                      <span className="text-muted-foreground text-xs">
                        ({opt.count} parents)
                      </span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Subject */}
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold text-muted-foreground">
              Subject
            </Label>
            <input
              type="text"
              value={subject}
              onChange={(e) => {
                setSubject(e.target.value);
                if (errors.subject)
                  setErrors((p) => ({ ...p, subject: undefined }));
              }}
              placeholder="e.g. Upcoming field trip — permission slip required"
              className="w-full h-9 px-3 rounded-md border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors"
              data-ocid="communication.messages.subject.input"
            />
            {errors.subject && (
              <p
                className="text-xs text-destructive"
                data-ocid="communication.messages.subject.error_state"
              >
                {errors.subject}
              </p>
            )}
          </div>

          {/* Body */}
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold text-muted-foreground">
              Message
            </Label>
            <Textarea
              value={body}
              onChange={(e) => {
                setBody(e.target.value);
                if (errors.body) setErrors((p) => ({ ...p, body: undefined }));
              }}
              placeholder="Type your message here..."
              rows={5}
              className="text-sm resize-none"
              data-ocid="communication.messages.body.textarea"
            />
            {errors.body && (
              <p
                className="text-xs text-destructive"
                data-ocid="communication.messages.body.error_state"
              >
                {errors.body}
              </p>
            )}
          </div>

          {/* Schedule toggle */}
          <div className="space-y-2">
            <label
              className="flex items-center gap-2 cursor-pointer w-fit"
              data-ocid="communication.messages.schedule.toggle"
            >
              <input
                type="checkbox"
                checked={scheduleEnabled}
                onChange={(e) => {
                  setScheduleEnabled(e.target.checked);
                  if (!e.target.checked)
                    setErrors((p) => ({ ...p, scheduleDate: undefined }));
                }}
                className="h-3.5 w-3.5 accent-primary"
              />
              <span className="text-sm text-foreground flex items-center gap-1">
                <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                Schedule for later
              </span>
            </label>

            {scheduleEnabled && (
              <div className="flex items-start gap-3 pl-5">
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Date</Label>
                  <input
                    type="date"
                    value={scheduleDate}
                    onChange={(e) => {
                      setScheduleDate(e.target.value);
                      setErrors((p) => ({ ...p, scheduleDate: undefined }));
                    }}
                    min={new Date().toISOString().split("T")[0]}
                    className="h-8 px-2 rounded-md border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    data-ocid="communication.messages.schedule-date.input"
                  />
                  {errors.scheduleDate && (
                    <p className="text-xs text-destructive">
                      {errors.scheduleDate}
                    </p>
                  )}
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Time</Label>
                  <input
                    type="time"
                    value={scheduleTime}
                    onChange={(e) => setScheduleTime(e.target.value)}
                    className="h-8 px-2 rounded-md border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    data-ocid="communication.messages.schedule-time.input"
                  />
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between pt-1">
            <p className="text-xs text-muted-foreground flex items-center gap-1.5">
              <Users className="h-3.5 w-3.5" />
              Sending to {getRecipientCount(to, classOptions)} parent
              {getRecipientCount(to, classOptions) !== 1 ? "s" : ""}
            </p>
            <Button
              type="submit"
              size="sm"
              disabled={isSending}
              className="gap-1.5"
              data-ocid="communication.messages.send.button"
            >
              {isSending ? (
                <>
                  <div className="h-3.5 w-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  Sending…
                </>
              ) : scheduleEnabled ? (
                <>
                  <Calendar className="h-3.5 w-3.5" />
                  Schedule
                </>
              ) : (
                <>
                  <Send className="h-3.5 w-3.5" />
                  Send Message
                </>
              )}
            </Button>
          </div>
        </form>
      </div>

      {/* Scheduled Queue */}
      {scheduledMessages.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <h3 className="text-sm font-semibold text-foreground">Scheduled</h3>
            <Badge variant="secondary" className="text-xs">
              {scheduledMessages.length}
            </Badge>
          </div>
          <div
            className="bg-card border border-border rounded-lg overflow-hidden divide-y divide-border/40"
            data-ocid="communication.messages.scheduled.list"
          >
            {scheduledMessages.map((sm, i) => (
              <div
                key={sm.id}
                className="flex items-center gap-3 px-4 py-3"
                data-ocid={`communication.messages.scheduled.item.${i + 1}`}
              >
                <Clock className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {sm.to}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    {sm.subject}
                  </p>
                </div>
                <span className="text-xs text-muted-foreground whitespace-nowrap flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {format(new Date(sm.scheduledAt), "MMM d 'at' h:mm a")}
                </span>
                <button
                  type="button"
                  onClick={() => handleCancelScheduled(sm.id)}
                  className="flex items-center gap-1 px-2 py-1 rounded text-xs font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors flex-shrink-0"
                  data-ocid={`communication.messages.scheduled.cancel.button.${i + 1}`}
                >
                  <X className="h-3 w-3" />
                  Cancel
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sent Messages */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Mail className="h-4 w-4 text-muted-foreground" />
          <h3 className="text-sm font-semibold text-foreground">
            Sent Messages
          </h3>
          {sentMessages.length > 0 && (
            <Badge variant="secondary" className="text-xs">
              {sentMessages.length}
            </Badge>
          )}
        </div>

        {sentMessages.length === 0 ? (
          <div
            className="py-10 text-center text-muted-foreground"
            data-ocid="communication.messages.sent.empty_state"
          >
            <Mail className="h-8 w-8 mx-auto mb-2 opacity-25" />
            <p className="text-sm font-medium">No messages sent yet</p>
            <p className="text-xs mt-1 opacity-70 mb-3">
              Messages you send to parents will appear here. When parents reply
              via the Parent Portal, their replies will thread below your
              original message. Compose your first message above to get started.
            </p>
            <Button
              size="sm"
              variant="outline"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="gap-1.5"
              data-ocid="communication.messages.sent.primary_button"
            >
              <Send className="h-3.5 w-3.5" />
              Compose Message
            </Button>
          </div>
        ) : (
          <div
            className="bg-card border border-border rounded-lg overflow-hidden"
            data-ocid="communication.messages.sent.table"
          >
            {sentMessages.map((msg, i) => (
              <SentMessageRow
                key={msg.id}
                msg={msg}
                index={i}
                onRefresh={refreshMessages}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
