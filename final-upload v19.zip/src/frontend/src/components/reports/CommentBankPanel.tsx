import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  ChevronDown,
  ChevronUp,
  Plus,
  RotateCcw,
  Search,
  Trash2,
} from "lucide-react";
import { useMemo, useState } from "react";
import {
  type BankComment,
  COMMENT_CATEGORIES,
  COMMENT_SUBJECTS,
  type CommentCategory,
  type CommentSubject,
  PERFORMANCE_LEVELS,
  type PerformanceLevel,
  addBankComment,
  deleteBankComment,
  getBankComments,
  resetBankToDefaults,
} from "../../lib/commentBank";

interface CommentBankPanelProps {
  onInsert: (text: string) => void;
}

const LEVEL_COLORS: Record<PerformanceLevel, string> = {
  Exceeds: "bg-success/15 text-success border-success/20",
  Meets: "bg-info/15 text-info border-info/20",
  Approaching: "bg-warning/15 text-warning-foreground border-warning/20",
  Below: "bg-destructive/15 text-destructive border-destructive/20",
};

function HighlightedText({ text, query }: { text: string; query: string }) {
  if (!query.trim()) return <>{text}</>;
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return <>{text}</>;
  return (
    <>
      {text.slice(0, idx)}
      <mark className="bg-warning/30 text-foreground rounded-sm px-0.5 not-italic font-medium">
        {text.slice(idx, idx + query.length)}
      </mark>
      {text.slice(idx + query.length)}
    </>
  );
}

export default function CommentBankPanel({ onInsert }: CommentBankPanelProps) {
  const [activeCategory, setActiveCategory] = useState<CommentCategory>(
    "Academic Performance",
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [levelFilter, setLevelFilter] = useState<PerformanceLevel | "All">(
    "All",
  );
  const [subjectFilter, setSubjectFilter] = useState<CommentSubject | "All">(
    "All",
  );
  const [allComments, setAllComments] = useState<BankComment[]>(() =>
    getBankComments(),
  );
  const [showAddForm, setShowAddForm] = useState(false);
  const [newText, setNewText] = useState("");
  const [newSubject, setNewSubject] = useState<CommentSubject>("General");
  const [newLevel, setNewLevel] = useState<PerformanceLevel>("Meets");
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const filteredComments = useMemo(() => {
    return allComments.filter((c) => {
      if (c.category !== activeCategory) return false;
      if (levelFilter !== "All" && c.level !== levelFilter) return false;
      if (subjectFilter !== "All" && c.subject !== subjectFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          c.text.toLowerCase().includes(q) ||
          c.subject.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [allComments, activeCategory, levelFilter, subjectFilter, searchQuery]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const cat of COMMENT_CATEGORIES) {
      counts[cat] = allComments.filter((c) => c.category === cat).length;
    }
    return counts;
  }, [allComments]);

  function handleAdd() {
    if (!newText.trim()) return;
    addBankComment(newText.trim(), activeCategory, newSubject, newLevel);
    setAllComments(getBankComments());
    setNewText("");
    setShowAddForm(false);
  }

  function handleDelete(id: number) {
    deleteBankComment(id);
    setAllComments(getBankComments());
  }

  function handleReset() {
    resetBankToDefaults();
    setAllComments(getBankComments());
    setShowResetConfirm(false);
  }

  return (
    <div className="rounded-lg border border-border bg-muted/20 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-card">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-muted-foreground">
            Comment Bank
          </span>
          <Badge variant="secondary" className="text-xs">
            {allComments.length}
          </Badge>
        </div>
        <div className="flex items-center gap-1.5">
          {showResetConfirm ? (
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-muted-foreground">
                Reset to defaults?
              </span>
              <button
                type="button"
                onClick={handleReset}
                className="text-xs text-destructive font-medium hover:underline"
                data-ocid="comment_bank.reset.confirm_button"
              >
                Reset
              </button>
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                className="text-xs text-muted-foreground hover:underline"
                data-ocid="comment_bank.reset.cancel_button"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setShowResetConfirm(true)}
              className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              title="Reset to defaults"
              data-ocid="comment_bank.reset.button"
            >
              <RotateCcw className="h-3.5 w-3.5" />
            </button>
          )}
          <button
            type="button"
            onClick={() => setShowAddForm((v) => !v)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium border border-border bg-background hover:bg-muted transition-colors"
            data-ocid="comment_bank.add.open_modal_button"
          >
            {showAddForm ? (
              <ChevronUp className="h-3 w-3" />
            ) : (
              <Plus className="h-3 w-3" />
            )}
            {showAddForm ? "Close" : "Add"}
          </button>
        </div>
      </div>

      {/* Category pills */}
      <div className="px-4 py-2.5 border-b border-border flex flex-wrap gap-1.5">
        {COMMENT_CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setActiveCategory(cat)}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${
              activeCategory === cat
                ? "bg-primary text-primary-foreground"
                : "bg-background text-muted-foreground hover:text-foreground border border-border"
            }`}
            data-ocid="comment_bank.category.tab"
          >
            {cat}
            <span
              className={`text-[10px] rounded-full px-1 leading-4 ${
                activeCategory === cat
                  ? "bg-white/20 text-primary-foreground"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {categoryCounts[cat] ?? 0}
            </span>
          </button>
        ))}
      </div>

      {/* Filters row */}
      <div className="px-4 py-2 border-b border-border flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-40">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground pointer-events-none" />
          <Input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search comments…"
            className="h-7 pl-7 pr-3 text-xs rounded-md"
            data-ocid="comment_bank.search.input"
          />
        </div>
        {/* Level filter */}
        <div className="flex gap-1">
          {(["All", ...PERFORMANCE_LEVELS] as const).map((l) => (
            <button
              key={l}
              type="button"
              onClick={() => setLevelFilter(l as typeof levelFilter)}
              className={`px-2 py-0.5 rounded text-[10px] font-medium border transition-colors ${
                levelFilter === l
                  ? l === "All"
                    ? "bg-foreground text-background border-foreground"
                    : `border ${LEVEL_COLORS[l as PerformanceLevel]}`
                  : "bg-background text-muted-foreground border-border hover:border-foreground/30"
              }`}
              data-ocid="comment_bank.level.toggle"
            >
              {l}
            </button>
          ))}
        </div>
        {/* Subject filter */}
        <div className="flex gap-1">
          {(["All", ...COMMENT_SUBJECTS] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSubjectFilter(s as typeof subjectFilter)}
              className={`px-2 py-0.5 rounded text-[10px] font-medium border transition-colors ${
                subjectFilter === s
                  ? "bg-primary/10 text-primary border-primary/30"
                  : "bg-background text-muted-foreground border-border hover:border-primary/30"
              }`}
              data-ocid="comment_bank.subject.toggle"
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Add form (inline, collapsible) */}
      {showAddForm && (
        <div className="px-4 py-3 border-b border-border bg-background/50 space-y-2.5">
          <textarea
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            placeholder="Enter comment text…"
            rows={2}
            className="w-full text-xs rounded-md border border-border bg-background px-3 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-ring"
            data-ocid="comment_bank.add.textarea"
          />
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-medium text-muted-foreground">
                Subject:
              </span>
              {COMMENT_SUBJECTS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setNewSubject(s)}
                  className={`px-2 py-0.5 rounded text-[10px] font-medium border transition-colors ${
                    newSubject === s
                      ? "bg-primary/10 text-primary border-primary/30"
                      : "bg-background text-muted-foreground border-border"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-medium text-muted-foreground">
                Level:
              </span>
              {PERFORMANCE_LEVELS.map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => setNewLevel(l)}
                  className={`px-2 py-0.5 rounded text-[10px] font-medium border transition-colors ${
                    newLevel === l
                      ? `${LEVEL_COLORS[l]}`
                      : "bg-background text-muted-foreground border-border"
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={handleAdd}
              disabled={!newText.trim()}
              className="ml-auto px-3 py-1 text-xs font-medium rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40 transition-colors"
              data-ocid="comment_bank.add.button"
            >
              Add Comment
            </button>
          </div>
        </div>
      )}

      {/* Comment list */}
      <div className="max-h-64 overflow-y-auto divide-y divide-border">
        {filteredComments.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-8 text-center"
            data-ocid="comment_bank.list.empty_state"
          >
            <p className="text-xs text-muted-foreground">
              {searchQuery
                ? "No comments match your search."
                : "No comments in this category yet."}
            </p>
          </div>
        ) : (
          filteredComments.map((comment) => (
            <div
              key={comment.id}
              className="flex items-start gap-2.5 px-4 py-3 hover:bg-muted/30 transition-colors group"
            >
              <div className="flex-1 min-w-0">
                <p className="text-xs text-foreground leading-relaxed">
                  <HighlightedText text={comment.text} query={searchQuery} />
                </p>
                <div className="flex items-center gap-1.5 mt-1.5">
                  <span
                    className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium border ${LEVEL_COLORS[comment.level]}`}
                  >
                    {comment.level}
                  </span>
                  {comment.subject !== "General" && (
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium border border-border bg-muted text-muted-foreground">
                      {comment.subject}
                    </span>
                  )}
                  {comment.isCustom && (
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium border border-dashed border-primary/40 text-primary/70">
                      Custom
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-1 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity pt-0.5">
                <button
                  type="button"
                  onClick={() => onInsert(comment.text)}
                  className="px-2.5 py-1 text-[10px] font-semibold rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors min-h-[28px]"
                  data-ocid="comment_bank.comment.button"
                >
                  Use
                </button>
                {comment.isCustom && (
                  <button
                    type="button"
                    onClick={() => handleDelete(comment.id)}
                    className="p-1 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                    aria-label="Delete comment"
                    data-ocid="comment_bank.comment.delete_button"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
