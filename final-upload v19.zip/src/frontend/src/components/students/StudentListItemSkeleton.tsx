import { Skeleton } from "@/components/ui/skeleton";
import React from "react";

export default function StudentListItemSkeleton() {
  return null;
}
