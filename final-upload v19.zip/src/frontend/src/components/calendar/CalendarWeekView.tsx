// ─── CalendarWeekView ────────────────────────────────────────────────────────
// Week view extracted from Calendar.tsx.

import type React from "react";
import {
  type CalendarEvent,
  EventChip,
  type TimetablePeriodLocal,
  getAbDayLabel,
  toDateStr,
} from "./calendarTypes";

interface CalendarWeekViewProps {
  weekDays: Date[];
  eventsByDate: Record<string, CalendarEvent[]>;
  todayDateStr: string;
  timetablePeriodsByDay: Record<string, TimetablePeriodLocal[]>;
  onDragStart: (e: React.DragEvent, id: string) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, dateStr: string) => void;
}

export function CalendarWeekView({
  weekDays,
  eventsByDate,
  todayDateStr,
  timetablePeriodsByDay,
  onDragStart,
  onDragOver,
  onDrop,
}: CalendarWeekViewProps) {
  return (
    <div className="flex-1 min-h-0 grid grid-cols-7 overflow-auto">
      {weekDays.map((date) => {
        const dateStr = toDateStr(date);
        const dayEvents = eventsByDate[dateStr] ?? [];
        const isToday = dateStr === todayDateStr;
        const dayName = [
          "Sunday",
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
        ][date.getDay()];
        const dayPeriods = timetablePeriodsByDay[dayName] ?? [];

        return (
          <div
            key={dateStr}
            className={`border-r border-border last:border-r-0 flex flex-col ${isToday ? "bg-primary/3" : ""}`}
            onDragOver={onDragOver}
            onDrop={(e) => onDrop(e, dateStr)}
          >
            {/* Day number header */}
            <div
              className={`flex flex-col items-center py-2 border-b border-border flex-shrink-0 ${isToday ? "bg-primary/5" : ""}`}
            >
              <span
                className={`text-xs font-medium w-7 h-7 flex items-center justify-center rounded-full ${
                  isToday
                    ? "bg-primary text-primary-foreground font-bold"
                    : "text-foreground"
                }`}
              >
                {date.getDate()}
              </span>
              {date.getDay() !== 0 && date.getDay() !== 6 && (
                <span
                  className={`text-[9px] font-semibold mt-0.5 px-1.5 py-0 rounded-full ${
                    getAbDayLabel(date) === "A"
                      ? "bg-primary/10 text-primary/70"
                      : "bg-accent text-muted-foreground"
                  }`}
                >
                  Day {getAbDayLabel(date)}
                </span>
              )}
            </div>

            {/* Timetable period bands */}
            {dayPeriods.length > 0 && (
              <div className="flex flex-col gap-px flex-shrink-0 border-b border-border/20">
                {dayPeriods.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center gap-1.5 px-2 py-1.5 bg-primary/5 border-l-2 border-primary/30"
                  >
                    <span className="text-[10px] text-primary/70 font-semibold truncate leading-none">
                      {p.name}
                    </span>
                    {p.courseName && (
                      <span className="text-[9px] text-muted-foreground truncate leading-none flex-1 min-w-0">
                        {p.courseName}
                      </span>
                    )}
                    <span className="text-[9px] text-muted-foreground/60 truncate leading-none hidden lg:block flex-none">
                      {p.startTime}&#8211;{p.endTime}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Events for the day */}
            <div className="flex-1 p-1.5 flex flex-col gap-1 overflow-y-auto">
              {dayEvents.length === 0 ? (
                <div className="flex-1 flex items-center justify-center">
                  <span className="text-[10px] text-muted-foreground/40">
                    —
                  </span>
                </div>
              ) : (
                dayEvents.map((ev) => (
                  <EventChip
                    key={ev.id}
                    event={ev}
                    draggable={ev.source === "custom"}
                    onDragStart={onDragStart}
                  />
                ))
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
