// ─── CalendarYearView ────────────────────────────────────────────────────────
// Year overview extracted from Calendar.tsx.

import {
  type CalendarEvent,
  MONTH_NAMES,
  getMonthGrid,
  toDateStr,
} from "./calendarTypes";

interface CalendarYearViewProps {
  currentDate: Date;
  eventsByDate: Record<string, CalendarEvent[]>;
  todayDateStr: string;
  onNavigateToMonth: (monthIdx: number, dateStr: string) => void;
}

export function CalendarYearView({
  currentDate,
  eventsByDate,
  todayDateStr,
  onNavigateToMonth,
}: CalendarYearViewProps) {
  return (
    <div className="flex-1 min-h-0 overflow-auto">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 p-1">
        {MONTH_NAMES.map((monthName, monthIdx) => {
          const grid = getMonthGrid(currentDate.getFullYear(), monthIdx);
          return (
            <div
              key={monthName}
              className="bg-card rounded-lg border border-border p-3 hover:border-primary/30 transition-colors"
            >
              <h4 className="text-xs font-semibold text-foreground mb-2">
                {monthName}
              </h4>
              <div className="grid grid-cols-7 mb-1">
                {(
                  ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] as const
                ).map((dayKey) => (
                  <div
                    key={dayKey}
                    className="text-[9px] text-center text-muted-foreground/60 font-medium"
                  >
                    {dayKey[0]}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-0.5">
                {grid.map((date, pos) => {
                  const dateStr = date ? toDateStr(date) : null;
                  const dayEvents = dateStr
                    ? (eventsByDate[dateStr] ?? [])
                    : [];
                  const isToday = dateStr === todayDateStr;
                  const hasEvents = dayEvents.length > 0;
                  return (
                    <button
                      key={dateStr ?? `empty-yr-${monthIdx}-${pos}`}
                      type="button"
                      onClick={() => {
                        if (!dateStr) return;
                        onNavigateToMonth(monthIdx, dateStr);
                      }}
                      className={`relative w-full aspect-square flex items-center justify-center rounded text-[10px] transition-colors ${
                        date
                          ? "hover:bg-primary/10 cursor-pointer"
                          : "cursor-default"
                      } ${isToday ? "bg-primary text-primary-foreground font-bold" : "text-foreground"}`}
                      disabled={!date}
                    >
                      {date ? date.getDate() : ""}
                      {hasEvents && !isToday && (
                        <span className="absolute bottom-0 left-1/2 -translate-x-1/2 flex gap-0.5">
                          {dayEvents.slice(0, 3).map((ev, ei) => (
                            <span
                              key={`${ev.id}-${ei}`}
                              className={`w-1 h-1 rounded-full inline-block ${
                                ev.type === "incident"
                                  ? "bg-destructive"
                                  : ev.type === "absence"
                                    ? "bg-warning"
                                    : ev.type === "assignment"
                                      ? "bg-primary"
                                      : "bg-muted-foreground/40"
                              }`}
                            />
                          ))}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
