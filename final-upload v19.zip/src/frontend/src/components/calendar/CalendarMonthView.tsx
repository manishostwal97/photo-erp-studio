// ─── CalendarMonthView ────────────────────────────────────────────────────────
// Month grid view extracted from Calendar.tsx.

import type React from "react";
import type { AcademicCalendarData } from "../settings/AcademicCalendarSettings";
import {
  type CalendarEvent,
  DAY_LABELS,
  DAY_LABELS_SHORT,
  EventChip,
  EventDot,
  type TimetablePeriodLocal,
  toDateStr,
} from "./calendarTypes";

interface CalendarMonthViewProps {
  monthGrid: (Date | null)[];
  eventsByDate: Record<string, CalendarEvent[]>;
  selectedDay: string | null;
  todayDateStr: string;
  holidayDates: Map<string, string>;
  termBoundaryDates: Set<string>;
  showTimetableEvents: boolean;
  timetablePeriodsByDay: Record<string, TimetablePeriodLocal[]>;
  currentDate: Date;
  academicCalendar: AcademicCalendarData;
  draggedEventId: string | null;
  onSelectDay: (day: string | null, showAdd?: boolean) => void;
  onDragStart: (e: React.DragEvent, id: string) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, dateStr: string) => void;
}

export function CalendarMonthView({
  monthGrid,
  eventsByDate,
  selectedDay,
  todayDateStr,
  holidayDates,
  termBoundaryDates,
  showTimetableEvents,
  timetablePeriodsByDay,
  currentDate,
  academicCalendar,
  onSelectDay,
  onDragStart,
  onDragOver,
  onDrop,
}: CalendarMonthViewProps) {
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const firstStr = toDateStr(new Date(year, month, 1));
  const lastStr = toDateStr(new Date(year, month + 1, 0));
  const activeTerm = academicCalendar.terms.find(
    (t) => t.start && t.end && t.start <= lastStr && t.end >= firstStr,
  );
  const activeGP = academicCalendar.gradingPeriods.find(
    (gp) => gp.start && gp.end && gp.start <= lastStr && gp.end >= firstStr,
  );

  return (
    <>
      {/* Term / grading period strip */}
      {(activeTerm || activeGP) && (
        <div className="flex items-center gap-3 px-4 py-1.5 border-b border-border/30 bg-primary/3 flex-shrink-0 flex-wrap">
          {activeTerm && (
            <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-primary/80">
              <span className="w-2 h-2 rounded-full bg-primary/50 inline-block" />
              {activeTerm.name}
              {activeTerm.start && activeTerm.end && (
                <span className="text-[10px] text-muted-foreground font-normal">
                  {new Date(`${activeTerm.start}T12:00:00`).toLocaleDateString(
                    "en-US",
                    { month: "short", day: "numeric" },
                  )}
                  {" – "}
                  {new Date(`${activeTerm.end}T12:00:00`).toLocaleDateString(
                    "en-US",
                    { month: "short", day: "numeric" },
                  )}
                </span>
              )}
            </span>
          )}
          {activeGP && (
            <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-muted-foreground">
              <span className="w-2 h-2 rounded-sm bg-success/50 inline-block" />
              {activeGP.name}
              {activeGP.start && activeGP.end && (
                <span className="text-[10px] text-muted-foreground/70 font-normal">
                  {new Date(`${activeGP.start}T12:00:00`).toLocaleDateString(
                    "en-US",
                    { month: "short", day: "numeric" },
                  )}
                  {" – "}
                  {new Date(`${activeGP.end}T12:00:00`).toLocaleDateString(
                    "en-US",
                    { month: "short", day: "numeric" },
                  )}
                </span>
              )}
            </span>
          )}
        </div>
      )}

      {/* Day header row */}
      <div className="grid grid-cols-7 border-b border-border flex-shrink-0">
        {DAY_LABELS.map((d, i) => (
          <div
            key={d}
            className="py-2 text-center text-xs font-medium text-muted-foreground border-r border-border last:border-r-0"
          >
            <span className="hidden sm:inline">{d}</span>
            <span className="sm:hidden">{DAY_LABELS_SHORT[i]}</span>
          </div>
        ))}
      </div>

      {/* Month grid */}
      <div
        className="flex-1 min-h-0 grid grid-cols-7 overflow-auto"
        style={{
          gridTemplateRows: `repeat(${monthGrid.length / 7}, minmax(80px, 1fr))`,
        }}
      >
        {monthGrid.map((date, pos) => {
          const dateStr = date ? toDateStr(date) : null;
          const cellKey = dateStr ?? `empty-${pos}`;
          const dayEvents = dateStr ? (eventsByDate[dateStr] ?? []) : [];
          const isToday = dateStr === todayDateStr;
          const isSelected = dateStr === selectedDay;
          const isCurrentMonth = date ? date.getMonth() === month : false;
          const isHoliday = dateStr ? holidayDates.has(dateStr) : false;
          const isTermBoundary = dateStr
            ? termBoundaryDates.has(dateStr)
            : false;
          const holidayLabel = dateStr ? (holidayDates.get(dateStr) ?? "") : "";

          return (
            <div
              key={cellKey}
              role={date ? "button" : undefined}
              tabIndex={date ? 0 : undefined}
              data-ocid={date ? `calendar.item.${pos + 1}` : undefined}
              onDragOver={dateStr ? onDragOver : undefined}
              onDrop={dateStr ? (e) => onDrop(e, dateStr) : undefined}
              onClick={() => {
                if (!dateStr) return;
                if (selectedDay === dateStr) {
                  onSelectDay(null, false);
                } else {
                  const dayEvs = eventsByDate[dateStr] ?? [];
                  onSelectDay(dateStr, dayEvs.length === 0);
                }
              }}
              onKeyDown={(e) => {
                if ((e.key === "Enter" || e.key === " ") && dateStr) {
                  e.preventDefault();
                  onSelectDay(selectedDay === dateStr ? null : dateStr, false);
                }
              }}
              className={`border-b border-r border-border last:border-r-0 p-1.5 flex flex-col gap-1 transition-colors ${
                !date
                  ? "bg-muted/20"
                  : isSelected
                    ? "bg-primary/5 ring-inset ring-1 ring-primary/30"
                    : isHoliday
                      ? "bg-warning-subtle/40 hover:bg-warning-subtle/60 cursor-pointer"
                      : "hover:bg-accent/40 cursor-pointer"
              }`}
            >
              {date && (
                <>
                  {isHoliday && (
                    <div className="text-[9px] text-warning-foreground font-medium truncate -mt-0.5 mb-0.5 opacity-80">
                      {holidayLabel}
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-medium w-6 h-6 flex items-center justify-center rounded-full transition-colors ${
                        isToday
                          ? "bg-primary text-primary-foreground font-bold"
                          : isTermBoundary && !isHoliday
                            ? "ring-2 ring-success/60 text-foreground font-semibold"
                            : isCurrentMonth
                              ? "text-foreground"
                              : "text-muted-foreground/50"
                      }`}
                    >
                      {date.getDate()}
                    </span>
                    {dayEvents.length > 0 && (
                      <div className="flex gap-0.5 flex-wrap justify-end">
                        {dayEvents.slice(0, 4).map((ev) => (
                          <EventDot key={ev.id} type={ev.type} />
                        ))}
                        {dayEvents.length > 4 && (
                          <span className="text-[9px] text-muted-foreground">
                            +{dayEvents.length - 4}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="hidden lg:flex flex-col gap-0.5 overflow-hidden">
                    {dayEvents.slice(0, 2).map((ev) => (
                      <EventChip
                        key={ev.id}
                        event={ev}
                        draggable={ev.source === "custom"}
                        onDragStart={onDragStart}
                      />
                    ))}
                    {dayEvents.length > 2 && (
                      <div className="text-[10px] text-muted-foreground pl-1">
                        +{dayEvents.length - 2} more
                      </div>
                    )}
                  </div>
                  {showTimetableEvents &&
                    (() => {
                      const dayName = [
                        "Sunday",
                        "Monday",
                        "Tuesday",
                        "Wednesday",
                        "Thursday",
                        "Friday",
                        "Saturday",
                      ][date.getDay()];
                      const periods = timetablePeriodsByDay[dayName] ?? [];
                      return periods.length > 0 ? (
                        <div className="hidden lg:flex items-center gap-1 mt-auto pt-0.5">
                          <span className="text-[9px] text-primary/60 font-medium leading-none">
                            {periods.length} period
                            {periods.length !== 1 ? "s" : ""}
                          </span>
                        </div>
                      ) : null;
                    })()}
                </>
              )}
            </div>
          );
        })}
      </div>
    </>
  );
}
