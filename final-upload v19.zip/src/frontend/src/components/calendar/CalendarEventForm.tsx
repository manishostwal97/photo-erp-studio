// ─── CalendarEventForm ─────────────────────────────────────────────────────────
// Extracted from Calendar.tsx InlineEventForm. Inline event creation form shown
// when clicking a calendar day.

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import React, { useEffect, useMemo, useRef, useState } from "react";

// ── Types (mirror Calendar.tsx) ──────────────────────────────────────────────

export interface TimetablePeriodLocal {
  id: string;
  name: string;
  startTime: string;
  endTime: string;
  courseName?: string;
  room?: string;
}

interface TimetableAssignmentLocal {
  periodId: string;
  day: string;
  courseName: string;
  room: string;
}

interface TimetableDataLocal {
  periods: TimetablePeriodLocal[];
  assignments: TimetableAssignmentLocal[];
}

export interface CustomStoredEvent {
  id: string;
  title: string;
  type: "Assignment" | "Assessment" | "School Event" | "Holiday" | "PD Day";
  date: string;
}

function loadTimetableForForm(): TimetableDataLocal {
  try {
    const raw = localStorage.getItem("edunite_timetable");
    if (!raw) return { periods: [], assignments: [] };
    return JSON.parse(raw);
  } catch {
    return { periods: [], assignments: [] };
  }
}

// ── Component ─────────────────────────────────────────────────────────────────

export interface CalendarEventFormProps {
  date: string;
  onSave: (ev: CustomStoredEvent) => void;
  onCancel: () => void;
}

export function CalendarEventForm({
  date,
  onSave,
  onCancel,
}: CalendarEventFormProps) {
  const [title, setTitle] = useState("");
  const [type, setType] = useState<CustomStoredEvent["type"]>("School Event");
  const [notes, setNotes] = useState("");
  const titleRef = useRef<HTMLInputElement>(null);

  const nearestPeriod = useMemo(() => {
    const timetable = loadTimetableForForm();
    const dayName = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ][new Date(`${date}T12:00:00`).getDay()];
    const periodsForDay = timetable.assignments
      .filter((a) => a.day === dayName)
      .map((a) => timetable.periods.find((p) => p.id === a.periodId))
      .filter((p): p is TimetablePeriodLocal => !!p);
    if (periodsForDay.length === 0) return null;
    return periodsForDay.sort((a, b) =>
      a.startTime.localeCompare(b.startTime),
    )[0];
  }, [date]);

  const [startTime, setStartTime] = useState(nearestPeriod?.startTime ?? "");
  const [endTime, setEndTime] = useState(nearestPeriod?.endTime ?? "");

  useEffect(() => {
    titleRef.current?.focus();
  }, []);

  const handleSave = () => {
    if (!title.trim()) return;
    const timePart = startTime
      ? ` (${startTime}${endTime ? `–${endTime}` : ""})`
      : "";
    const fullTitle = notes.trim()
      ? `${title.trim()}${timePart} — ${notes.trim()}`
      : `${title.trim()}${timePart}`;
    onSave({
      id: `custom-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      title: fullTitle,
      type,
      date,
    });
    setTitle("");
    setNotes("");
  };

  return (
    <div
      className="mt-3 p-3 rounded-lg border border-primary/20 bg-primary/5"
      data-ocid="calendar.event.panel"
    >
      <p className="text-xs font-semibold text-foreground mb-2">
        Add event for{" "}
        {new Date(`${date}T12:00:00`).toLocaleDateString("en-US", {
          weekday: "short",
          month: "short",
          day: "numeric",
        })}
      </p>
      <div className="flex flex-col gap-2">
        <input
          ref={titleRef}
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") handleSave();
            if (e.key === "Escape") onCancel();
          }}
          placeholder="Event title..."
          data-ocid="calendar.event.input"
          className="w-full px-3 py-2 text-sm rounded-md border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
        />
        <Select
          value={type}
          onValueChange={(v) => setType(v as CustomStoredEvent["type"])}
        >
          <SelectTrigger
            className="w-full h-9 text-sm"
            data-ocid="calendar.event.select"
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Assignment">Assignment Due</SelectItem>
            <SelectItem value="Assessment">Assessment</SelectItem>
            <SelectItem value="School Event">School Event</SelectItem>
            <SelectItem value="Holiday">Holiday</SelectItem>
            <SelectItem value="PD Day">PD Day</SelectItem>
          </SelectContent>
        </Select>
        <input
          type="text"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Notes (optional)"
          data-ocid="calendar.event.notes.input"
          className="w-full px-3 py-2 text-sm rounded-md border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
        />
        <div className="flex gap-2">
          <div className="flex-1">
            <label
              htmlFor="cal-ev-start"
              className="text-[10px] text-muted-foreground mb-0.5 block"
            >
              Start time
            </label>
            <input
              id="cal-ev-start"
              type="time"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              data-ocid="calendar.event.starttime.input"
              className="w-full px-3 py-2 text-sm rounded-md border border-border bg-card text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
          <div className="flex-1">
            <label
              htmlFor="cal-ev-end"
              className="text-[10px] text-muted-foreground mb-0.5 block"
            >
              End time
            </label>
            <input
              id="cal-ev-end"
              type="time"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
              data-ocid="calendar.event.endtime.input"
              className="w-full px-3 py-2 text-sm rounded-md border border-border bg-card text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
        </div>
        {nearestPeriod && (
          <p className="text-[10px] text-muted-foreground">
            Pre-filled from{" "}
            <span className="font-medium">{nearestPeriod.name}</span> timetable
            period
          </p>
        )}
        <div className="flex gap-2 justify-end">
          <button
            type="button"
            onClick={onCancel}
            data-ocid="calendar.event.cancel_button"
            className="px-4 py-2 text-sm rounded-md border border-border bg-card hover:bg-accent text-muted-foreground transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!title.trim()}
            data-ocid="calendar.event.save_button"
            className="px-4 py-2 text-sm font-medium rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40 transition-colors"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
