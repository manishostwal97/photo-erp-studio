import { useMemo } from "react";

export function AttendanceSparkline() {
  const points = useMemo(() => {
    try {
      const raw = localStorage.getItem("edunite_attendance");
      if (!raw) return [];
      const records: Array<{ date: string; status: string }> = JSON.parse(raw);
      const now = new Date();
      const days: number[] = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(now.getDate() - i);
        const dateStr = d.toISOString().slice(0, 10);
        const dayRecords = records.filter((r) => r.date === dateStr);
        if (dayRecords.length === 0) {
          days.push(-1); // no data
        } else {
          const present = dayRecords.filter(
            (r) => r.status === "present" || r.status === "Present",
          ).length;
          days.push(Math.round((present / dayRecords.length) * 100));
        }
      }
      return days;
    } catch {
      return [];
    }
  }, []);

  const validPoints = points.filter((p) => p >= 0);
  if (validPoints.length < 2) return null;

  const W = 44;
  const H = 20;
  const min = 0;
  const max = 100;

  const coords = points
    .map((p, i) => {
      if (p < 0) return null;
      const x = (i / 6) * W;
      const y = H - ((p - min) / (max - min)) * H;
      return `${x},${y}`;
    })
    .filter(Boolean) as string[];

  const lastVal = validPoints[validPoints.length - 1];
  const color =
    lastVal >= 90 ? "#16a34a" : lastVal >= 80 ? "#ca8a04" : "#dc2626";

  return (
    <svg width={W} height={H} className="opacity-70" aria-hidden="true">
      <polyline
        points={coords.join(" ")}
        fill="none"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

// ── MissingWorkDrilldown: inline panel showing top students with missing assignments ────
