import { useMemo } from "react";

export function MissingWorkDrilldown({
  allAssignments,
}: {
  allAssignments: Array<{
    id: number;
    title: string;
    dueDate?: string;
    courseId?: number;
  }>;
}) {
  // Per-student missing work counts from edunite_gradebook
  const studentMissingCounts = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const thirtyDaysAgo = new Date(today);
    thirtyDaysAgo.setDate(today.getDate() - 30);
    const missingByStudent: Record<
      string,
      { count: number; assignments: string[] }
    > = {};
    try {
      const gbRaw = localStorage.getItem("edunite_gradebook");
      if (!gbRaw) return [];
      // Structure: { courseId: { studentId: { assignmentId: score } } }
      const store = JSON.parse(gbRaw) as Record<
        string,
        Record<string, Record<string, unknown>>
      >;
      // Build set of overdue assignment IDs
      const overdueIds = new Set(
        allAssignments
          .filter((a) => {
            if (!a.dueDate) return false;
            const d = new Date(a.dueDate);
            return d < today && d >= thirtyDaysAgo;
          })
          .map((a) => String(a.id)),
      );
      const idToTitle: Record<string, string> = {};
      for (const a of allAssignments) idToTitle[String(a.id)] = a.title;

      for (const courseGrades of Object.values(store)) {
        for (const [studentId, studentGrades] of Object.entries(courseGrades)) {
          for (const aId of overdueIds) {
            if (studentGrades[aId] == null) {
              if (!missingByStudent[studentId])
                missingByStudent[studentId] = { count: 0, assignments: [] };
              missingByStudent[studentId].count++;
              if (missingByStudent[studentId].assignments.length < 2) {
                missingByStudent[studentId].assignments.push(
                  idToTitle[aId] ?? "Assignment",
                );
              }
            }
          }
        }
      }
    } catch {
      /* ignore */
    }

    // Try to resolve student names from edunite_students
    let nameMap: Record<string, string> = {};
    try {
      const sRaw = localStorage.getItem("edunite_students");
      if (sRaw) {
        const students = JSON.parse(sRaw) as Array<{
          studentId: string;
          givenNames?: string;
          preferredName?: string;
          familyName?: string;
        }>;
        for (const s of students) {
          nameMap[s.studentId] = s.preferredName
            ? `${s.preferredName} ${s.familyName ?? ""}`
            : `${s.givenNames ?? ""} ${s.familyName ?? ""}`.trim();
        }
      }
    } catch {
      /* ignore */
    }

    return Object.entries(missingByStudent)
      .map(([id, data]) => ({
        id,
        name: nameMap[id] ?? id,
        count: data.count,
        assignments: data.assignments,
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [allAssignments]);

  // Fallback: assignment-level list when no per-student data
  const missingAssignments = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const thirtyDaysAgo = new Date(today);
    thirtyDaysAgo.setDate(today.getDate() - 30);
    if (studentMissingCounts.length > 0) return [];
    const gradedIds = new Set<string>();
    try {
      const raw = localStorage.getItem("edunite_gradebook");
      if (raw) {
        const store = JSON.parse(raw) as Record<
          string,
          Record<string, Record<string, unknown>>
        >;
        for (const courseVal of Object.values(store)) {
          for (const studentVal of Object.values(courseVal)) {
            for (const [aId, score] of Object.entries(studentVal)) {
              if (score != null) gradedIds.add(aId);
            }
          }
        }
      }
    } catch {
      /* ignore */
    }
    return allAssignments
      .filter((a) => {
        if (!a.dueDate) return false;
        const d = new Date(a.dueDate);
        return d < today && d >= thirtyDaysAgo && !gradedIds.has(String(a.id));
      })
      .sort(
        (a, b) =>
          new Date(a.dueDate ?? "").getTime() -
          new Date(b.dueDate ?? "").getTime(),
      )
      .slice(0, 5);
  }, [allAssignments, studentMissingCounts.length]);

  const isEmpty =
    studentMissingCounts.length === 0 && missingAssignments.length === 0;

  if (isEmpty) {
    return (
      <div
        className="mt-0 px-4 py-3 rounded-b-lg border border-t-0 border-border bg-card text-xs text-muted-foreground"
        data-ocid="dashboard.missing_work.empty_state"
      >
        No overdue ungraded assignments in the last 30 days.
      </div>
    );
  }

  return (
    <div
      className="mt-0 border border-t-0 border-border rounded-b-lg bg-card overflow-hidden"
      data-ocid="dashboard.missing_work.panel"
    >
      <div className="divide-y divide-border max-h-56 overflow-y-auto">
        {studentMissingCounts.length > 0
          ? studentMissingCounts.map((s, i) => (
              <div
                key={s.id}
                className="px-4 py-2.5 flex items-start justify-between gap-2"
                data-ocid={`dashboard.missing_work.item.${i + 1}`}
              >
                <div className="min-w-0">
                  <span className="text-xs font-medium text-foreground block truncate">
                    {s.name}
                  </span>
                  {s.assignments.length > 0 && (
                    <span className="text-[10px] text-muted-foreground truncate block">
                      {s.assignments.join(", ")}
                      {s.count > s.assignments.length
                        ? ` +${s.count - s.assignments.length} more`
                        : ""}
                    </span>
                  )}
                </div>
                <span className="text-[10px] text-warning font-semibold whitespace-nowrap flex-shrink-0 mt-0.5">
                  {s.count} missing
                </span>
              </div>
            ))
          : missingAssignments.map((a, i) => (
              <div
                key={a.id}
                className="px-4 py-2 flex items-center justify-between gap-2"
                data-ocid={`dashboard.missing_work.item.${i + 1}`}
              >
                <span className="text-xs text-foreground truncate">
                  {a.title}
                </span>
                <span className="text-[10px] text-warning font-medium whitespace-nowrap flex-shrink-0">
                  Due{" "}
                  {new Date(a.dueDate ?? "").toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                  })}
                </span>
              </div>
            ))}
      </div>
    </div>
  );
}
