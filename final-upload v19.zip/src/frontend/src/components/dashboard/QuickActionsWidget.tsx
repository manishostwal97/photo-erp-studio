import { Link } from "@tanstack/react-router";
import {
  AlertTriangle,
  BookOpen,
  CalendarCheck,
  GraduationCap,
  MessageSquare,
} from "lucide-react";
import React from "react";

export const QuickActionsWidget = React.memo(function QuickActionsWidget() {
  return (
    <div
      className="flex flex-wrap gap-2"
      data-ocid="dashboard.quick_actions.section"
    >
      {[
        {
          label: "Log Behavior",
          icon: AlertTriangle,
          to: "/behavior",
          search: { quickLog: "true" },
          ocid: "dashboard.quick_actions.log_behavior.button",
        },
        {
          label: "Attendance",
          icon: CalendarCheck,
          to: "/classes",
          search: { tab: "today" },
          ocid: "dashboard.quick_actions.attendance.button",
        },
        {
          label: "Add Assignment",
          icon: BookOpen,
          to: "/curriculum",
          search: { view: "structure" },
          ocid: "dashboard.quick_actions.add_assignment.button",
        },
        {
          label: "Message Parents",
          icon: MessageSquare,
          to: "/communication",
          search: { tab: "messages" },
          ocid: "dashboard.quick_actions.message_parents.button",
        },
        {
          label: "Gradebook",
          icon: GraduationCap,
          to: "/classes",
          search: { tab: "gradebook" },
          ocid: "dashboard.quick_actions.gradebook.button",
        },
      ].map(({ label, icon: Icon, to, search, ocid }) => (
        <Link
          key={label}
          to={to as any}
          search={search as any}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-card text-xs font-medium text-foreground hover:bg-muted/50 hover:border-primary/30 transition-colors min-h-[36px]"
          data-ocid={ocid}
        >
          <Icon className="h-3.5 w-3.5 text-muted-foreground" />
          {label}
        </Link>
      ))}
    </div>
  );
});
