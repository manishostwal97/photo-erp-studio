import { useNavigate } from "@tanstack/react-router";
import { AlertTriangle, X } from "lucide-react";
import React, { useState } from "react";

export const SeedDataBanner = React.memo(function SeedDataBanner() {
  const navigate = useNavigate();

  const [visible] = useState(() => {
    try {
      const dismissed = localStorage.getItem("edunite_seed_banner_dismissed");
      if (dismissed === "true") return false;
      const settings = JSON.parse(
        localStorage.getItem("edunite_settings") || "{}",
      );
      return !settings.teacherName;
    } catch {
      return false;
    }
  });

  const [dismissed, setDismissed] = useState(false);

  if (!visible || dismissed) return null;

  return (
    <div
      className="flex items-center gap-3 rounded-xl border border-warning/30 bg-warning/10 px-4 py-3 mb-4"
      data-ocid="dashboard.seed_banner.section"
    >
      <AlertTriangle className="h-4 w-4 shrink-0 text-warning" />
      <p className="flex-1 text-sm text-foreground">
        You're viewing sample data — complete your setup to replace it with your
        own classroom.
      </p>
      <button
        type="button"
        onClick={() => navigate({ to: "/settings" })}
        className="shrink-0 rounded-lg border border-warning/30 bg-transparent px-3 py-1 text-xs font-medium text-foreground transition-colors hover:bg-warning/20"
        data-ocid="dashboard.seed_banner.button"
      >
        Complete setup
      </button>
      <button
        type="button"
        aria-label="Dismiss banner"
        onClick={() => {
          localStorage.setItem("edunite_seed_banner_dismissed", "true");
          setDismissed(true);
        }}
        className="shrink-0 rounded p-1 text-warning transition-colors hover:bg-warning/20"
        data-ocid="dashboard.seed_banner.close_button"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
});
