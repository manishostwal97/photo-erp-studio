// ── AuthContext (local stub) ──────────────────────────────────────────────────
// No Firebase listener — initializes immediately from persisted authStore state.
import { useAuthStore } from "@/stores/authStore";
import { type ReactNode, createContext, useContext, useEffect } from "react";

const AuthContext = createContext<null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { setLoading, setInitialized } = useAuthStore();

  useEffect(() => {
    // No async Firebase listener — just mark as initialized so ProtectedRoute
    // can read persisted authStore state immediately.
    setLoading(false);
    setInitialized(true);
  }, [setLoading, setInitialized]);

  return <AuthContext.Provider value={null}>{children}</AuthContext.Provider>;
}

export function useAuthContext() {
  return useContext(AuthContext);
}
