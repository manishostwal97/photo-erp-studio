// ── Firebase stub ────────────────────────────────────────────────────────────
// Real Firebase SDK is intentionally NOT initialized here.
// Authentication is handled locally via useAuth.ts stubs.
// Replace this file with real Firebase initialization when connecting Firebase.

export const app = null;
export const auth = null;
export const db = null;
