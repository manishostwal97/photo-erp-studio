import type { ClassValue } from "clsx";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import type { Invoice, InvoiceService, PaymentHistoryEntry } from "../types";

export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/** Format a number as Indian currency: ₹1,00,000 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

/** Format ISO/date-string to "15 Jan 2025" */
export function formatDate(dateStr: string): string {
  if (!dateStr) return "—";
  const d = new Date(dateStr);
  if (Number.isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

/** Format ISO/date-string to "15 Jan" */
export function formatDateShort(dateStr: string): string {
  if (!dateStr) return "—";
  const d = new Date(dateStr);
  if (Number.isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}

/** Get uppercase initials from a name: "Sarah Johnson" → "SJ" */
export function getInitials(name: string): string {
  if (!name) return "?";
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join("");
}

/** Build a WhatsApp deep-link URL */
export function generateWhatsAppLink(phone: string, message: string): string {
  const clean = phone.replace(/[^0-9+]/g, "");
  return `https://wa.me/${clean}?text=${encodeURIComponent(message)}`;
}

/**
 * Interpolate a WhatsApp template string.
 * Supports both {variable} and {{variable}} syntax.
 * Any missing value is replaced with a safe fallback ("—" by default).
 */
export function interpolateTemplate(
  template: string,
  vars: Record<string, string | number | undefined | null>,
  fallback = "—",
): string {
  if (!template) return "";
  return template.replace(/\{\{?(\w+)\}?\}/g, (_match, key: string) => {
    const val = vars[key];
    if (val === undefined || val === null || val === "") return fallback;
    return String(val);
  });
}

// ─── Invoice Number (YYMMXX) ────────────────────────────────────────────────

/**
 * Display helper: return the invoice number as-is (already YYMMXX).
 * Falls back gracefully for legacy YYYY-MM-XXXX numbers.
 */
export function formatInvoiceNumber(raw: string): string {
  if (!raw) return "—";
  return raw;
}

/**
 * Generate the next invoice number in YYMMXX format.
 *
 * - YY = 2-digit year  (e.g. 26 for 2026)
 * - MM = 2-digit month (e.g. 05 for May)
 * - XX = running sequence, reset each month (01, 02, …)
 *
 * @param existingInvoices - all invoices already stored
 */
export function getNextInvoiceNumber(
  existingInvoices: Array<{ invoiceNumber: string }>,
): string {
  const now = new Date();
  const yy = String(now.getFullYear()).slice(-2); // "26"
  const mm = String(now.getMonth() + 1).padStart(2, "0"); // "05"
  const prefix = yy + mm; // "2605"

  let highest = 0;
  for (const inv of existingInvoices) {
    const n = inv.invoiceNumber;
    // Match both new YYMMXX and any existing numbers that start with the same YYMM prefix
    if (typeof n === "string" && n.startsWith(prefix) && n.length >= 6) {
      const seq = Number.parseInt(n.slice(4), 10);
      if (!Number.isNaN(seq) && seq > highest) highest = seq;
    }
  }

  // Ensure uniqueness: keep incrementing until no collision is found
  const existingSet = new Set(existingInvoices.map((inv) => inv.invoiceNumber));
  let candidate: string;
  do {
    highest += 1;
    candidate = prefix + String(highest).padStart(2, "0"); // e.g. "260501"
  } while (existingSet.has(candidate));

  return candidate;
}

/**
 * Safe number coercion: parse any value as float, return 0 for NaN / Infinity.
 */
export function safeNumber(val: unknown): number {
  const n = Number.parseFloat(String(val));
  return Number.isFinite(n) ? n : 0;
}

// ─── Auto Calculation ────────────────────────────────────────────────────────

/** Auto-calc subtotal, GST amount and grand total from services */
export function computeAutoCalc(
  services: Array<{ total: number }>,
  gstPercent = 0,
): { subtotal: number; gstAmount: number; grandTotal: number } {
  const subtotal = services.reduce((s, r) => s + r.total, 0);
  const gstAmount = subtotal * (gstPercent / 100);
  return { subtotal, gstAmount, grandTotal: subtotal + gstAmount };
}

/**
 * Minimum required advance = MAX(50% of grandTotal, ₹20,000)
 */
export function getMinimumAdvance(grandTotal: number): number {
  return Math.max(grandTotal * 0.5, 20000);
}

/**
 * Balance due = grandTotal - total payments made
 */
export function getBalanceDue(
  grandTotal: number,
  payments: Array<{ amount: number }>,
): number {
  const totalPaid = payments.reduce((s, p) => s + p.amount, 0);
  return grandTotal - totalPaid;
}

// ─── Payment Schedule ────────────────────────────────────────────────────────

export interface ComputedPaymentSchedule {
  advance: number;
  advanceDue: string;
  secondInstallment: number;
  secondDue: string;
  thirdInstallment: number;
  thirdDue: string;
}

/**
 * Auto-generate payment schedule from event dates + total amount.
 *
 * RULE 1: Advance = MAX(50% of total, ₹20,000)
 * RULE 2: Remaining 50% split equally into 2nd + 3rd installments
 * RULE 3: 2nd installment due on event start date
 * RULE 4: 3rd installment due exactly 1 month after event end date
 */
export function calculatePaymentSchedule(
  totalAmount: number,
  eventStartDate: string,
  eventEndDate?: string,
): ComputedPaymentSchedule | null {
  if (!totalAmount || !eventStartDate) return null;

  const advance = getMinimumAdvance(totalAmount);
  const remaining = totalAmount - advance;
  const half = Math.ceil(remaining / 2);

  const now = new Date();
  const advanceDue = now.toISOString().split("T")[0];

  // 2nd installment: on event start date
  const secondDue = eventStartDate;

  // 3rd installment: 1 month after event end (or start if no end)
  const endDate = new Date(eventEndDate || eventStartDate);
  endDate.setMonth(endDate.getMonth() + 1);
  const thirdDue = endDate.toISOString().split("T")[0];

  return {
    advance,
    advanceDue,
    secondInstallment: half,
    secondDue,
    thirdInstallment: remaining - half,
    thirdDue,
  };
}

// ─── Delivery Tracker Helpers ────────────────────────────────────────────────

export type DeliveryStageType =
  | "RAW_BACKUP"
  | "SELECTION_PENDING"
  | "EDITING"
  | "ALBUM_DESIGNING"
  | "PRINTING"
  | "READY"
  | "DELIVERED";

const DELIVERY_STAGE_ORDER: DeliveryStageType[] = [
  "RAW_BACKUP",
  "SELECTION_PENDING",
  "EDITING",
  "ALBUM_DESIGNING",
  "PRINTING",
  "READY",
  "DELIVERED",
];

const DELIVERY_STAGE_LABELS: Record<DeliveryStageType, string> = {
  RAW_BACKUP: "Raw Backup",
  SELECTION_PENDING: "Selection Pending",
  EDITING: "Editing",
  ALBUM_DESIGNING: "Album Designing",
  PRINTING: "Printing",
  READY: "Ready",
  DELIVERED: "Delivered",
};

export function getDeliveryStageProgress(stage: string): number {
  const idx = DELIVERY_STAGE_ORDER.indexOf(stage as DeliveryStageType);
  if (idx < 0) return 0;
  return Math.round(((idx + 1) / DELIVERY_STAGE_ORDER.length) * 100);
}

export function getDeliveryStageLabel(stage: string): string {
  return DELIVERY_STAGE_LABELS[stage as DeliveryStageType] ?? stage;
}

// ─── Invoice Balance & Status ─────────────────────────────────────────────────

export function computeInvoiceBalance(invoice: Invoice): number {
  if (!invoice) return 0;
  const history = invoice.paymentHistory ?? [];
  const totalPaid = history.reduce(
    (sum, p: PaymentHistoryEntry) => sum + (Number(p.amount) || 0),
    0,
  );
  const dealAmount = Number(invoice.dealAmount) || 0;
  const discount = Number(invoice.discount) || 0;
  const discounted = dealAmount - discount;
  const extraChargesTotal = (invoice.packageExtraCharges ?? []).reduce(
    (sum, c) => sum + (Number(c.extraTotal) || 0),
    0,
  );
  const subtotal = discounted + extraChargesTotal;
  const gstAmount =
    invoice.gstEnabled && (invoice.gstPercent ?? 0) > 0
      ? subtotal * ((invoice.gstPercent ?? 0) / 100)
      : 0;
  const grandTotal = subtotal + gstAmount;
  return Math.max(0, grandTotal - totalPaid);
}

/**
 * Safe helper: returns the remaining balance for an invoice,
 * always ≥ 0. Handles null/undefined invoice gracefully.
 */
export function getInvoiceBalance(invoice: Invoice | null | undefined): number {
  if (!invoice) return 0;
  return Math.max(0, computeInvoiceBalance(invoice));
}

export type PaymentStatusType = "paid" | "partial" | "pending" | "overdue";

export function getPaymentStatus(invoice: Invoice): PaymentStatusType {
  const balance = computeInvoiceBalance(invoice);
  if (balance <= 0) return "paid";
  const totalPaid = (invoice.paymentHistory ?? []).reduce(
    (sum, p: PaymentHistoryEntry) => sum + (Number(p.amount) || 0),
    0,
  );
  if (totalPaid > 0) return "partial";
  if (invoice.eventStartDate) {
    const eventDate = new Date(invoice.eventStartDate);
    if (!Number.isNaN(eventDate.getTime()) && eventDate < new Date())
      return "overdue";
  }
  return "pending";
}

export function getStatusColor(status: string): string {
  switch (status) {
    case "paid":
      return "bg-green-100 text-green-700 border-green-200";
    case "partial":
      return "bg-yellow-100 text-yellow-700 border-yellow-200";
    case "pending":
      return "bg-blue-100 text-blue-700 border-blue-200";
    case "overdue":
      return "bg-red-100 text-red-700 border-red-200";
    case "active":
      return "bg-green-100 text-green-700 border-green-200";
    case "cancelled":
      return "bg-muted text-muted-foreground border-border";
    default:
      return "bg-muted text-muted-foreground border-border";
  }
}

// Re-export for convenience
export type { InvoiceService };
