import type { Invoice, StudioProfile } from "@/types";
import jsPDF from "jspdf";

// ── Template definitions (must match InvoiceTemplateEngine.tsx) ──────────────
export interface InvoiceTemplate {
  id: string;
  name: string;
  primaryColor: [number, number, number];
  accentColor: [number, number, number];
  backgroundColor: [number, number, number];
  textColor: [number, number, number];
  headerBg: [number, number, number];
  headerText: [number, number, number];
}

const TEMPLATES: Record<string, InvoiceTemplate> = {
  classic: {
    id: "classic",
    name: "Classic Professional",
    primaryColor: [220, 38, 38],
    accentColor: [220, 38, 38],
    backgroundColor: [255, 255, 255],
    textColor: [30, 30, 30],
    headerBg: [220, 38, 38],
    headerText: [255, 255, 255],
  },
  luxury: {
    id: "luxury",
    name: "Luxury Black & Gold",
    primaryColor: [212, 175, 55],
    accentColor: [212, 175, 55],
    backgroundColor: [18, 18, 18],
    textColor: [240, 235, 210],
    headerBg: [12, 12, 12],
    headerText: [212, 175, 55],
  },
  cinematic: {
    id: "cinematic",
    name: "Cinematic Dark",
    primaryColor: [150, 150, 160],
    accentColor: [180, 180, 200],
    backgroundColor: [28, 30, 36],
    textColor: [220, 220, 230],
    headerBg: [20, 22, 28],
    headerText: [200, 200, 210],
  },
  wedding: {
    id: "wedding",
    name: "Wedding Elegance",
    primaryColor: [182, 120, 90],
    accentColor: [182, 120, 90],
    backgroundColor: [255, 252, 248],
    textColor: [60, 40, 30],
    headerBg: [182, 120, 90],
    headerText: [255, 252, 248],
  },
  minimal: {
    id: "minimal",
    name: "Modern Minimal",
    primaryColor: [20, 20, 20],
    accentColor: [80, 80, 80],
    backgroundColor: [255, 255, 255],
    textColor: [20, 20, 20],
    headerBg: [240, 240, 240],
    headerText: [20, 20, 20],
  },
};

function getTemplate(): InvoiceTemplate {
  const id =
    typeof localStorage !== "undefined"
      ? (localStorage.getItem("invoiceTemplate") ?? "classic")
      : "classic";
  return TEMPLATES[id] ?? TEMPLATES.classic;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function currency(n: number) {
  const safe = Number.isFinite(n) ? n : 0;
  return `Rs.${Math.round(safe).toLocaleString("en-IN")}`;
}

const safeStr = (v: unknown) => (v != null ? String(v) : "");

function fmtDate(d: string | number | undefined | null): string {
  if (!d) return "";
  try {
    return new Date(d).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  } catch {
    return safeStr(d);
  }
}

function fmtDateTime(d: string | number | undefined | null) {
  if (!d) return { date: "", time: "" };
  try {
    const dt = new Date(d);
    return {
      date: dt.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }),
      time: dt.toLocaleTimeString("en-IN", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
      }),
    };
  } catch {
    return { date: safeStr(d), time: "" };
  }
}

/**
 * Loads a data-URL image and returns it together with its natural dimensions.
 * Resolves immediately with null on any error so callers can skip gracefully.
 */
async function loadImageData(
  src: string,
): Promise<{ data: string; w: number; h: number } | null> {
  return new Promise((resolve) => {
    if (!src) {
      resolve(null);
      return;
    }
    const img = new Image();
    img.onload = () =>
      resolve({ data: src, w: img.naturalWidth, h: img.naturalHeight });
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

/** Computes logo display dimensions preserving aspect ratio. */
function logoDisplaySize(
  naturalW: number,
  naturalH: number,
  maxW = 55,
  maxH = 22,
): { w: number; h: number } {
  if (!naturalW || !naturalH) return { w: maxH, h: maxH };
  const ratio = naturalW / naturalH;
  let w = maxW;
  let h = w / ratio;
  if (h > maxH) {
    h = maxH;
    w = h * ratio;
  }
  return { w: Math.round(w * 10) / 10, h: Math.round(h * 10) / 10 };
}

const PAGE_W = 210;
const PAGE_H = 297;
const MARGIN = 14;
const CONTENT_W = PAGE_W - MARGIN * 2;

// ── Font size constants ───────────────────────────────────────────────────────
const FS_TITLE = 18;
const FS_HEADING = 12;
const FS_BODY = 10;
const FS_SMALL = 8;

// ── Main export ───────────────────────────────────────────────────────────────

export async function generateInvoicePDF(
  invoice: Invoice,
  studioProfile: StudioProfile | null,
): Promise<Blob> {
  const tpl = getTemplate();
  const doc = new jsPDF("p", "mm", "a4");
  let y = MARGIN;

  // ── Color helpers bound to template ──────────────────────────────────────
  const setPrimary = () => doc.setTextColor(...tpl.primaryColor);
  const setBody = () => doc.setTextColor(...tpl.textColor);
  const setMuted = () => {
    const [r, g, b] = tpl.textColor;
    doc.setTextColor(
      Math.min(255, r + 70),
      Math.min(255, g + 70),
      Math.min(255, b + 70),
    );
  };

  const checkPage = (needed = 10) => {
    if (y + needed > PAGE_H - MARGIN) {
      doc.addPage();
      // Page background for dark templates
      if (tpl.backgroundColor[0] < 240) {
        doc.setFillColor(...tpl.backgroundColor);
        doc.rect(0, 0, PAGE_W, PAGE_H, "F");
      }
      y = MARGIN;
    }
  };

  // ── Page background (for dark/luxury templates) ──────────────────────────
  if (tpl.backgroundColor[0] < 240) {
    doc.setFillColor(...tpl.backgroundColor);
    doc.rect(0, 0, PAGE_W, PAGE_H, "F");
  }

  // ── Load images in parallel ───────────────────────────────────────────────
  const [logoImg, sigImg] = await Promise.all([
    loadImageData(studioProfile?.logo ?? ""),
    loadImageData(studioProfile?.signature ?? ""),
  ]);

  // ── HEADER BACKGROUND BAND ──────────────────────────────────────────────
  const HEADER_H = 38;
  doc.setFillColor(...tpl.headerBg);
  doc.rect(0, 0, PAGE_W, HEADER_H, "F");

  // ── TOP ACCENT BAR ────────────────────────────────────────────────────────
  doc.setFillColor(...tpl.primaryColor);
  doc.rect(0, 0, PAGE_W, 2.5, "F");

  const hTop = 6;
  let studioInfoX = MARGIN;

  // Logo (left, aspect-ratio strictly preserved)
  if (logoImg) {
    try {
      const { w: lw, h: lh } = logoDisplaySize(logoImg.w, logoImg.h, 28, 28);
      const logoY = hTop + (HEADER_H - hTop - lh) / 2;
      doc.addImage(logoImg.data, "PNG", MARGIN, logoY, lw, lh);
      studioInfoX = MARGIN + lw + 5;
    } catch {
      studioInfoX = MARGIN;
    }
  }

  // Studio name — large, bold, white-ish (uses headerText color)
  doc.setFont("helvetica", "bold");
  doc.setFontSize(FS_TITLE);
  doc.setTextColor(...tpl.headerText);
  const studioName = safeStr(studioProfile?.name || "Photography Studio");
  doc.text(studioName, studioInfoX, hTop + 8);

  // Studio sub-info — smaller, slightly muted
  doc.setFont("helvetica", "normal");
  doc.setFontSize(FS_SMALL);
  const hTextMuted: [number, number, number] = [
    Math.min(255, tpl.headerText[0] * 0.75 + 50),
    Math.min(255, tpl.headerText[1] * 0.75 + 50),
    Math.min(255, tpl.headerText[2] * 0.75 + 50),
  ];
  doc.setTextColor(...hTextMuted);
  let infoY = hTop + 14;
  const subInfoParts: string[] = [];
  if (studioProfile?.ownerName) subInfoParts.push(studioProfile.ownerName);
  if (studioProfile?.phone) subInfoParts.push(`Ph: ${studioProfile.phone}`);
  if (subInfoParts.length) {
    doc.text(subInfoParts.join("  ·  "), studioInfoX, infoY);
    infoY += 4.5;
  }
  if (studioProfile?.email) {
    doc.text(safeStr(studioProfile.email), studioInfoX, infoY);
    infoY += 4.5;
  }
  if (studioProfile?.address) {
    const centerColW = 95;
    const lines = doc.splitTextToSize(
      safeStr(studioProfile.address),
      centerColW,
    ) as string[];
    for (const line of lines.slice(0, 2)) {
      doc.text(line, studioInfoX, infoY);
      infoY += 4.5;
    }
  }

  // Right column: INVOICE label + number (prominent in header)
  const boxW = 52;
  const _boxX = PAGE_W - MARGIN - boxW;
  const created = fmtDateTime(invoice?.createdAt ?? Date.now());

  // "INVOICE" label
  doc.setFont("helvetica", "bold");
  doc.setFontSize(FS_SMALL);
  setPrimary();
  doc.text("INVOICE", PAGE_W - MARGIN, hTop + 5, { align: "right" });

  // Invoice number — large, prominent
  doc.setFont("helvetica", "bold");
  doc.setFontSize(FS_HEADING + 4);
  doc.setTextColor(...tpl.headerText);
  doc.text(safeStr(invoice?.invoiceNumber), PAGE_W - MARGIN, hTop + 13, {
    align: "right",
  });

  // Date / time / GSTIN — smaller
  doc.setFont("helvetica", "normal");
  doc.setFontSize(FS_SMALL);
  doc.setTextColor(...hTextMuted);
  let metaY = hTop + 19;
  const metaRows: [string, string][] = [["Date", created.date]];
  if (created.time) metaRows.push(["Time", created.time]);
  if (studioProfile?.gstNumber) {
    metaRows.push(["GSTIN", safeStr(studioProfile.gstNumber).substring(0, 18)]);
  }
  for (const [lbl, val] of metaRows) {
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...hTextMuted);
    doc.text(`${lbl}: `, PAGE_W - MARGIN - 35, metaY);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...tpl.headerText);
    doc.text(val, PAGE_W - MARGIN, metaY, { align: "right" });
    metaY += 4.5;
  }

  y = HEADER_H + 6;

  // ── DIVIDER below header ──────────────────────────────────────────────────
  doc.setDrawColor(...tpl.primaryColor);
  doc.setLineWidth(0.6);
  doc.line(MARGIN, HEADER_H, PAGE_W - MARGIN, HEADER_H);

  // ── CLIENT + EVENT (two-column) ──────────────────────────────────────────
  checkPage(42);
  const colW = (CONTENT_W - 5) / 2;
  const leftX = MARGIN;
  const rightColX = MARGIN + colW + 5;

  // Client box
  const boxAlpha = tpl.backgroundColor[0] < 100 ? 28 : 10;
  const BOX_H = 36;
  doc.setFillColor(
    Math.min(255, tpl.backgroundColor[0] + boxAlpha),
    Math.min(255, tpl.backgroundColor[1] + boxAlpha),
    Math.min(255, tpl.backgroundColor[2] + boxAlpha),
  );
  doc.rect(leftX, y, colW, BOX_H, "F");
  doc.setDrawColor(
    Math.min(255, tpl.backgroundColor[0] + 30),
    Math.min(255, tpl.backgroundColor[1] + 30),
    Math.min(255, tpl.backgroundColor[2] + 30),
  );
  doc.setLineWidth(0.2);
  doc.rect(leftX, y, colW, BOX_H);
  // Left accent strip
  doc.setFillColor(...tpl.primaryColor);
  doc.rect(leftX, y, 1.5, BOX_H, "F");

  setPrimary();
  doc.setFont("helvetica", "bold");
  doc.setFontSize(FS_SMALL - 1);
  doc.text("BILL TO", leftX + 4, y + 5.5);

  setBody();
  doc.setFont("helvetica", "bold");
  doc.setFontSize(FS_BODY + 1);
  doc.text(
    safeStr(invoice?.clientName || "Client").substring(0, 28),
    leftX + 4,
    y + 12,
  );

  doc.setFont("helvetica", "normal");
  doc.setFontSize(FS_BODY - 1);
  setMuted();
  let ci = y + 18;
  if (invoice?.clientPhone) {
    doc.text(`Ph: ${invoice.clientPhone}`, leftX + 4, ci);
    ci += 4.5;
  }
  if (
    (invoice?.clientWhatsapp ?? "") &&
    invoice.clientWhatsapp !== invoice.clientPhone
  ) {
    doc.text(`WA: ${invoice.clientWhatsapp}`, leftX + 4, ci);
    ci += 4.5;
  }
  if (invoice?.clientAddress) {
    doc.text(safeStr(invoice.clientAddress).substring(0, 34), leftX + 4, ci);
  }

  // Event box
  doc.setFillColor(
    Math.min(255, tpl.backgroundColor[0] + boxAlpha),
    Math.min(255, tpl.backgroundColor[1] + boxAlpha),
    Math.min(255, tpl.backgroundColor[2] + boxAlpha),
  );
  doc.rect(rightColX, y, colW, BOX_H, "F");
  doc.rect(rightColX, y, colW, BOX_H);
  doc.setFillColor(...tpl.primaryColor);
  doc.rect(rightColX, y, 1.5, BOX_H, "F");

  setPrimary();
  doc.setFont("helvetica", "bold");
  doc.setFontSize(FS_SMALL - 1);
  doc.text("EVENT DETAILS", rightColX + 4, y + 5.5);

  setBody();
  doc.setFont("helvetica", "bold");
  doc.setFontSize(FS_BODY + 1);
  const evtLabel = invoice?.customEventName || invoice?.eventType || "";
  doc.text(safeStr(evtLabel).substring(0, 28), rightColX + 4, y + 12);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(FS_BODY - 1);
  setMuted();
  let ei = y + 18;
  if (invoice?.eventStartDate) {
    const endPart =
      invoice?.eventEndDate && invoice.eventEndDate !== invoice.eventStartDate
        ? ` – ${fmtDate(invoice.eventEndDate)}`
        : "";
    doc.text(`${fmtDate(invoice.eventStartDate)}${endPart}`, rightColX + 4, ei);
    ei += 4.5;
  }
  if (invoice?.eventVenueName) {
    doc.text(
      safeStr(invoice.eventVenueName).substring(0, 28),
      rightColX + 4,
      ei,
    );
    ei += 4.5;
  }
  if (invoice?.eventVenueAddress) {
    doc.text(
      safeStr(invoice.eventVenueAddress).substring(0, 31),
      rightColX + 4,
      ei,
    );
  }

  y += BOX_H + 8;

  // ── PROGRAMS TABLE ────────────────────────────────────────────────────────
  const programs = (invoice?.programs ?? []).filter((p) => p.enabled);
  if (programs.length > 0) {
    checkPage(24);
    sectionHeading(doc, "PROGRAMS", y, tpl);
    y += 3;

    const pc = [
      { x: MARGIN, w: 36, label: "Program" },
      { x: MARGIN + 37, w: 26, label: "Date" },
      { x: MARGIN + 64, w: 22, label: "Time" },
      { x: MARGIN + 87, w: 35, label: "Location" },
      { x: MARGIN + 123, w: 57, label: "Assigned Team" },
    ];
    const rH = 6.5;

    // Header row
    doc.setFillColor(...tpl.headerBg);
    doc.rect(MARGIN, y, CONTENT_W, 8, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(FS_SMALL);
    doc.setTextColor(...tpl.headerText);
    for (const col of pc) doc.text(col.label, col.x + 2, y + 5.5);
    y += 8;

    doc.setFont("helvetica", "normal");
    doc.setFontSize(FS_BODY - 1);
    for (const [idx, p] of programs.entries()) {
      checkPage(rH + 2);
      const rowY = y;
      const rowBg =
        tpl.backgroundColor[0] < 100
          ? idx % 2 === 0
            ? ([
                tpl.backgroundColor[0] + 18,
                tpl.backgroundColor[1] + 18,
                tpl.backgroundColor[2] + 18,
              ] as [number, number, number])
            : ([
                tpl.backgroundColor[0] + 10,
                tpl.backgroundColor[1] + 10,
                tpl.backgroundColor[2] + 10,
              ] as [number, number, number])
          : idx % 2 === 0
            ? ([250, 250, 250] as [number, number, number])
            : ([244, 244, 244] as [number, number, number]);
      doc.setFillColor(...rowBg);
      doc.rect(MARGIN, rowY, CONTENT_W, rH, "F");
      doc.setDrawColor(
        Math.min(255, tpl.backgroundColor[0] + 30),
        Math.min(255, tpl.backgroundColor[1] + 30),
        Math.min(255, tpl.backgroundColor[2] + 30),
      );
      doc.setLineWidth(0.15);
      doc.rect(MARGIN, rowY, CONTENT_W, rH);

      const teamNames = (p.teamAssignments ?? [])
        .map((a) => a.teamMemberName)
        .join(", ");
      setBody();
      doc.text(safeStr(p.name).substring(0, 20), pc[0].x + 2, rowY + rH - 2);
      setMuted();
      doc.text(p.date ? fmtDate(p.date) : "", pc[1].x + 2, rowY + rH - 2);
      doc.text(
        safeStr(
          `${p.startTime ?? ""}${p.endTime ? `–${p.endTime}` : ""}`,
        ).substring(0, 13),
        pc[2].x + 2,
        rowY + rH - 2,
      );
      doc.text(
        safeStr(p.location ?? "").substring(0, 20),
        pc[3].x + 2,
        rowY + rH - 2,
      );
      doc.text(safeStr(teamNames).substring(0, 30), pc[4].x + 2, rowY + rH - 2);
      y += rH;
    }
    y += 6;
  }

  // ── SERVICES TABLE ────────────────────────────────────────────────────────
  const services = invoice?.services ?? [];
  if (services.length > 0) {
    checkPage(28);
    divider(doc, y, tpl);
    y += 4;
    sectionHeading(doc, "SERVICES", y, tpl);
    y += 3;

    const svcW = CONTENT_W * 0.5;
    const qtyX = MARGIN + svcW;
    const rateX = qtyX + CONTENT_W * 0.12;
    const totalX = PAGE_W - MARGIN;
    const sHdrH = 7;
    const sRowH = 7;

    // Header
    doc.setFillColor(...tpl.headerBg);
    doc.rect(MARGIN, y, CONTENT_W, sHdrH, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(FS_SMALL);
    doc.setTextColor(...tpl.headerText);
    doc.text("Service", MARGIN + 2, y + 5.2);
    doc.text("Qty", qtyX + 2, y + 5.2);
    doc.text("Rate", rateX + 2, y + 5.2);
    doc.text("Amount", totalX - 2, y + 5.2, { align: "right" });
    y += sHdrH;

    let svcSubtotal = 0;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(FS_BODY);
    for (const [idx, s] of services.entries()) {
      checkPage(sRowH + 2);
      const rowBg =
        tpl.backgroundColor[0] < 100
          ? idx % 2 === 0
            ? ([
                tpl.backgroundColor[0] + 15,
                tpl.backgroundColor[1] + 15,
                tpl.backgroundColor[2] + 15,
              ] as [number, number, number])
            : ([
                tpl.backgroundColor[0] + 8,
                tpl.backgroundColor[1] + 8,
                tpl.backgroundColor[2] + 8,
              ] as [number, number, number])
          : idx % 2 === 0
            ? ([250, 250, 250] as [number, number, number])
            : ([244, 244, 244] as [number, number, number]);
      doc.setFillColor(...rowBg);
      doc.rect(MARGIN, y, CONTENT_W, sRowH, "F");
      doc.setDrawColor(
        Math.min(255, tpl.backgroundColor[0] + 30),
        Math.min(255, tpl.backgroundColor[1] + 30),
        Math.min(255, tpl.backgroundColor[2] + 30),
      );
      doc.setLineWidth(0.15);
      doc.rect(MARGIN, y, CONTENT_W, sRowH);

      const qty = s.quantity || 1;
      const rate = s.unitPrice || 0;
      const total = s.total || rate * qty;
      svcSubtotal += total;

      setBody();
      doc.text(safeStr(s.name).substring(0, 38), MARGIN + 2, y + 5.2);
      setMuted();
      doc.text(String(qty), qtyX + 2, y + 5.2);
      doc.text(currency(rate), rateX + 2, y + 5.2);
      doc.setFont("helvetica", "bold");
      setBody();
      doc.text(currency(total), totalX - 2, y + 5.2, { align: "right" });
      doc.setFont("helvetica", "normal");
      y += sRowH;
    }

    // Sub-total row
    checkPage(8);
    doc.setFillColor(
      Math.min(255, tpl.backgroundColor[0] + 15),
      Math.min(255, tpl.backgroundColor[1] + 15),
      Math.min(255, tpl.backgroundColor[2] + 15),
    );
    doc.rect(MARGIN, y, CONTENT_W, 7, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(FS_BODY);
    setMuted();
    doc.text("Services Sub-total", MARGIN + 2, y + 5.2);
    setPrimary();
    doc.text(currency(svcSubtotal), totalX - 2, y + 5.2, { align: "right" });
    y += 7 + 8;
  }

  // ── PACKAGE EXTRA CHARGES ─────────────────────────────────────────────────
  const extras = invoice?.packageExtraCharges ?? [];
  if (extras.length > 0) {
    checkPage(28);
    divider(doc, y, tpl);
    y += 4;
    sectionHeading(doc, "PACKAGE EXTRA CHARGES", y, tpl);
    y += 3;

    const excW = CONTENT_W * 0.45;
    const excInclX = MARGIN + excW;
    const excActX = excInclX + 25;
    const excTotalX = PAGE_W - MARGIN;

    doc.setFillColor(212, 160, 20);
    doc.rect(MARGIN, y, CONTENT_W, 7, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.setTextColor(255, 252, 230);
    doc.text("Service", MARGIN + 2, y + 4.8);
    doc.text("Included", excInclX + 2, y + 4.8);
    doc.text("Actual", excActX + 2, y + 4.8);
    doc.text("Extra Total", excTotalX - 2, y + 4.8, { align: "right" });
    y += 7;

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    for (const e of extras) {
      checkPage(7);
      doc.setFillColor(255, 251, 230);
      doc.rect(MARGIN, y, CONTENT_W, 6.5, "F");
      doc.setTextColor(80, 50, 0);
      doc.text(safeStr(e.ruleName).substring(0, 36), MARGIN + 2, y + 4.3);
      doc.text(String(e.includedQuantity), excInclX + 2, y + 4.3);
      doc.text(String(e.actualQuantity), excActX + 2, y + 4.3);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(180, 90, 0);
      doc.text(`+${currency(Number(e.extraTotal))}`, excTotalX - 2, y + 4.3, {
        align: "right",
      });
      doc.setFont("helvetica", "normal");
      setBody();
      y += 6.5;
    }
    y += 6;
  }

  // ── PAYMENT SUMMARY ───────────────────────────────────────────────────────
  checkPage(70);
  divider(doc, y, tpl);
  y += 5;
  sectionHeading(doc, "PAYMENT SUMMARY", y, tpl);
  y += 6;

  const extrasTotal = extras.reduce((s, c) => s + Number(c.extraTotal), 0);
  const dealAmt = Number(invoice?.dealAmount) || 0;
  const disc = Number(invoice?.discount) || 0;
  const pSubtotal = dealAmt - disc;
  const gstPct =
    invoice?.gstEnabled && (invoice?.gstPercent ?? 0) > 0
      ? (invoice.gstPercent ?? 0)
      : 0;
  const gstAmt =
    Number(invoice?.gstAmount) || (pSubtotal + extrasTotal) * (gstPct / 100);
  const pTotal =
    Number(invoice?.totalAmount) || pSubtotal + extrasTotal + gstAmt;
  // Prefer paymentHistory sum as source of truth; fall back to advancePaid field
  const pPaidFromHistory = (invoice?.paymentHistory ?? []).reduce(
    (s, p) => s + (Number(p.amount) || 0),
    0,
  );
  const pPaid =
    pPaidFromHistory > 0 ? pPaidFromHistory : Number(invoice?.advancePaid) || 0;
  const pBalance = Math.max(
    0,
    Number(invoice?.pendingAmount) > 0
      ? Number(invoice.pendingAmount)
      : pTotal - pPaid,
  );

  // Payment status badge text
  const statusText = pBalance <= 0 ? "PAID" : pPaid > 0 ? "PARTIAL" : "PENDING";

  const summaryRows: Array<{
    label: string;
    value: string;
    bold?: boolean;
    dividerBefore?: boolean;
    color?: "green" | "red" | "amber" | "primary";
  }> = [
    { label: "Deal Amount", value: currency(dealAmt) },
    ...(disc > 0
      ? [
          {
            label: "Discount",
            value: `- ${currency(disc)}`,
            color: "green" as const,
          },
        ]
      : []),
    ...(extrasTotal > 0
      ? [
          {
            label: "Extra Charges",
            value: `+ ${currency(extrasTotal)}`,
            color: "amber" as const,
          },
        ]
      : []),
    { label: "Subtotal", value: currency(pSubtotal + extrasTotal) },
    ...(gstPct > 0
      ? [{ label: `GST (${gstPct}%)`, value: currency(gstAmt) }]
      : []),
    {
      label: "Grand Total",
      value: currency(pTotal),
      bold: true,
      dividerBefore: true,
    },
    {
      label: "Advance Paid",
      value: currency(pPaid),
      color: "green" as const,
      dividerBefore: true,
    },
    {
      label: "Payment Status",
      value: statusText,
      color:
        pBalance <= 0
          ? ("green" as const)
          : pPaid > 0
            ? ("amber" as const)
            : ("red" as const),
    },
    {
      label: "Balance Due",
      value: currency(pBalance),
      bold: true,
      dividerBefore: true,
      color: pBalance > 0 ? ("red" as const) : ("green" as const),
    },
  ];

  const boxW2 = 78;
  const boxX2 = MARGIN + CONTENT_W - boxW2;
  const rowHt = 8;
  const boxHt = summaryRows.length * rowHt + 8;

  // Box background
  doc.setFillColor(
    Math.min(
      255,
      tpl.backgroundColor[0] + (tpl.backgroundColor[0] < 100 ? 22 : -6),
    ),
    Math.min(
      255,
      tpl.backgroundColor[1] + (tpl.backgroundColor[1] < 100 ? 22 : -6),
    ),
    Math.min(
      255,
      tpl.backgroundColor[2] + (tpl.backgroundColor[2] < 100 ? 22 : -6),
    ),
  );
  doc.rect(boxX2, y - 3, boxW2, boxHt, "F");
  doc.setDrawColor(...tpl.primaryColor);
  doc.setLineWidth(0.3);
  doc.rect(boxX2, y - 3, boxW2, boxHt);
  // Primary color top border accent on the box
  doc.setFillColor(...tpl.primaryColor);
  doc.rect(boxX2, y - 3, boxW2, 1.5, "F");

  for (const [idx, row] of summaryRows.entries()) {
    const ry = y + idx * rowHt + 2;
    if (row.dividerBefore) {
      doc.setDrawColor(
        Math.min(255, tpl.backgroundColor[0] + 50),
        Math.min(255, tpl.backgroundColor[1] + 50),
        Math.min(255, tpl.backgroundColor[2] + 50),
      );
      doc.setLineWidth(0.25);
      doc.line(boxX2 + 2, ry - 4, boxX2 + boxW2 - 2, ry - 4);
    }
    doc.setFont("helvetica", row.bold ? "bold" : "normal");
    doc.setFontSize(row.bold ? FS_BODY : FS_BODY - 1);

    // Label — muted
    setMuted();
    doc.text(row.label, boxX2 + 4, ry);

    // Value — colored & right-aligned
    doc.setFont("helvetica", row.bold ? "bold" : "normal");
    if (row.color === "red") doc.setTextColor(220, 38, 38);
    else if (row.color === "green") doc.setTextColor(22, 163, 74);
    else if (row.color === "amber") doc.setTextColor(180, 120, 0);
    else setBody();
    doc.text(row.value, boxX2 + boxW2 - 4, ry, { align: "right" });
  }
  y += boxHt + 8;

  // ── PAYMENT SCHEDULE ──────────────────────────────────────────────────────
  const schedule = invoice?.paymentSchedule;
  if (schedule) {
    checkPage(40);
    divider(doc, y, tpl);
    y += 4;
    sectionHeading(doc, "PAYMENT SCHEDULE", y, tpl);
    y += 3;

    doc.setFillColor(...tpl.headerBg);
    doc.rect(MARGIN, y, CONTENT_W, 7, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.setTextColor(...tpl.headerText);
    doc.text("Installment", MARGIN + 2, y + 4.8);
    doc.text("Due Date", MARGIN + 70, y + 4.8);
    doc.text("Amount", MARGIN + 120, y + 4.8);
    doc.text("Status", PAGE_W - MARGIN - 2, y + 4.8, { align: "right" });
    y += 7;

    const insts = [
      {
        name: "1st – Advance",
        dueDate: schedule.advanceDue,
        amount: schedule.advance,
      },
      {
        name: "2nd Installment",
        dueDate: schedule.secondDue,
        amount: schedule.secondInstallment,
      },
      {
        name: "3rd Installment",
        dueDate: schedule.thirdDue,
        amount: schedule.thirdInstallment,
      },
    ];

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    for (const [idx, inst] of insts.entries()) {
      checkPage(7);
      const rowBg =
        tpl.backgroundColor[0] < 100
          ? idx % 2 === 0
            ? ([
                tpl.backgroundColor[0] + 15,
                tpl.backgroundColor[1] + 15,
                tpl.backgroundColor[2] + 15,
              ] as [number, number, number])
            : ([
                tpl.backgroundColor[0] + 8,
                tpl.backgroundColor[1] + 8,
                tpl.backgroundColor[2] + 8,
              ] as [number, number, number])
          : idx % 2 === 0
            ? ([250, 250, 250] as [number, number, number])
            : ([244, 244, 244] as [number, number, number]);
      doc.setFillColor(...rowBg);
      doc.rect(MARGIN, y, CONTENT_W, 6.5, "F");
      doc.setLineWidth(0.15);
      doc.rect(MARGIN, y, CONTENT_W, 6.5);

      const isOverdue = !!inst.dueDate && new Date(inst.dueDate) < new Date();
      setBody();
      doc.text(inst.name, MARGIN + 2, y + 4.3);
      setMuted();
      doc.text(inst.dueDate ? fmtDate(inst.dueDate) : "", MARGIN + 70, y + 4.3);
      doc.setFont("helvetica", "bold");
      setBody();
      doc.text(currency(inst.amount), MARGIN + 120, y + 4.3);
      if (isOverdue) doc.setTextColor(220, 38, 38);
      else doc.setTextColor(120, 120, 120);
      doc.text(
        isOverdue ? "Overdue" : "Pending",
        PAGE_W - MARGIN - 2,
        y + 4.3,
        { align: "right" },
      );
      doc.setFont("helvetica", "normal");
      y += 6.5;
    }
    y += 6;
  }

  // ── PAYMENT HISTORY ───────────────────────────────────────────────────────
  const payments = [...(invoice?.paymentHistory ?? [])].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
  );
  if (payments.length > 0) {
    checkPage(28);
    divider(doc, y, tpl);
    y += 4;
    sectionHeading(doc, "PAYMENT HISTORY", y, tpl);
    y += 3;

    // Header
    doc.setFillColor(...tpl.headerBg);
    doc.rect(MARGIN, y, CONTENT_W, 7, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.setTextColor(...tpl.headerText);
    doc.text("Date", MARGIN + 2, y + 4.8);
    doc.text("Time", MARGIN + 38, y + 4.8);
    doc.text("Mode", MARGIN + 72, y + 4.8);
    doc.text("Amount", MARGIN + 108, y + 4.8);
    doc.text("Remaining", PAGE_W - MARGIN - 2, y + 4.8, { align: "right" });
    y += 7;

    let running = pTotal;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    for (const [idx, p] of payments.entries()) {
      checkPage(7);
      running -= Number(p.amount) || 0;
      const rowBg =
        tpl.backgroundColor[0] < 100
          ? idx % 2 === 0
            ? ([
                tpl.backgroundColor[0] + 15,
                tpl.backgroundColor[1] + 15,
                tpl.backgroundColor[2] + 15,
              ] as [number, number, number])
            : ([
                tpl.backgroundColor[0] + 8,
                tpl.backgroundColor[1] + 8,
                tpl.backgroundColor[2] + 8,
              ] as [number, number, number])
          : idx % 2 === 0
            ? ([250, 250, 250] as [number, number, number])
            : ([244, 244, 244] as [number, number, number]);
      doc.setFillColor(...rowBg);
      doc.rect(MARGIN, y, CONTENT_W, 6.5, "F");
      doc.setLineWidth(0.15);
      doc.rect(MARGIN, y, CONTENT_W, 6.5);

      const payDT = fmtDateTime(
        (p as unknown as Record<string, unknown>).createdAt
          ? ((p as unknown as Record<string, unknown>).createdAt as string)
          : p.date,
      );

      setMuted();
      doc.text(payDT.date, MARGIN + 2, y + 4.3);
      doc.text(payDT.time, MARGIN + 38, y + 4.3);

      // Mode pill
      doc.setFillColor(
        Math.min(255, tpl.backgroundColor[0] + 35),
        Math.min(255, tpl.backgroundColor[1] + 35),
        Math.min(255, tpl.backgroundColor[2] + 35),
      );
      doc.roundedRect(MARGIN + 70, y + 1, 28, 4.5, 1, 1, "F");
      setMuted();
      doc.setFontSize(7.5);
      doc.text(
        safeStr(p.mode).toUpperCase().substring(0, 10),
        MARGIN + 72,
        y + 4.3,
      );
      doc.setFontSize(8.5);

      doc.setFont("helvetica", "bold");
      doc.setTextColor(22, 163, 74); // green — amount received
      doc.text(currency(p.amount), MARGIN + 108, y + 4.3);

      // Remaining balance: red if > 0, green if 0
      const rem = Math.max(0, running);
      if (rem > 0) doc.setTextColor(220, 38, 38);
      else doc.setTextColor(22, 163, 74);
      doc.text(currency(rem), PAGE_W - MARGIN - 2, y + 4.3, { align: "right" });

      doc.setFont("helvetica", "normal");
      setBody();
      y += 6.5;
    }
    y += 6;
  }

  // ── TERMS & SIGNATURE ─────────────────────────────────────────────────────
  if (invoice?.termsAndConditions) {
    checkPage(24);
    divider(doc, y, tpl);
    y += 4;
    sectionHeading(doc, "TERMS & CONDITIONS", y, tpl);
    y += 4;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    setMuted();
    const tcLines = doc.splitTextToSize(
      invoice.termsAndConditions,
      CONTENT_W,
    ) as string[];
    for (const line of tcLines) {
      checkPage(5);
      doc.text(line, MARGIN, y);
      y += 4.5;
    }
    y += 3;
  }

  // Signature block
  checkPage(28);
  divider(doc, y, tpl);
  y += 6;
  const sigW = 40;
  const sigX = PAGE_W - MARGIN - sigW;
  if (sigImg) {
    try {
      const { w: sw, h: sh } = logoDisplaySize(sigImg.w, sigImg.h, sigW, 14);
      doc.addImage(sigImg.data, "PNG", sigX + (sigW - sw) / 2, y, sw, sh);
      y += 16;
    } catch {
      y += 16;
    }
  } else {
    doc.setDrawColor(...tpl.primaryColor);
    doc.setLineWidth(0.5);
    doc.line(sigX, y + 14, sigX + sigW, y + 14);
    y += 16;
  }
  setMuted();
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text("Authorized Signature", sigX + sigW / 2, y, { align: "center" });
  y += 8;

  // ── FOOTER (all pages) ────────────────────────────────────────────────────
  const numPages = doc.getNumberOfPages();
  for (let pg = 1; pg <= numPages; pg++) {
    doc.setPage(pg);
    const fY = PAGE_H - 10;

    doc.setFillColor(...tpl.primaryColor);
    doc.rect(0, fY - 2, PAGE_W, 0.5, "F");

    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    setMuted();

    if (pg === numPages && studioProfile?.upiId) {
      doc.text(
        `UPI: ${studioProfile.upiId}   |   Thank you for choosing us!`,
        MARGIN,
        fY + 4,
      );
    }

    doc.text(`Page ${pg} of ${numPages}`, PAGE_W / 2, fY + 4, {
      align: "center",
    });
    doc.setTextColor(160, 160, 160);
    doc.text(
      "Generated by Photography Invoice Studio",
      PAGE_W - MARGIN,
      fY + 4,
      { align: "right" },
    );
  }

  return doc.output("blob");
}

// ── Shared drawing helpers ────────────────────────────────────────────────────

function divider(doc: jsPDF, y: number, tpl: InvoiceTemplate) {
  doc.setDrawColor(
    Math.min(255, tpl.backgroundColor[0] + 50),
    Math.min(255, tpl.backgroundColor[1] + 50),
    Math.min(255, tpl.backgroundColor[2] + 50),
  );
  doc.setLineWidth(0.3);
  doc.line(MARGIN, y, PAGE_W - MARGIN, y);
}

function sectionHeading(
  doc: jsPDF,
  text: string,
  y: number,
  tpl: InvoiceTemplate,
) {
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(...tpl.primaryColor);
  doc.text(text, MARGIN, y);
}
