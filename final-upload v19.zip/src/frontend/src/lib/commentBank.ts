// ─── Categorized Comment Bank ─────────────────────────────────────────────────
// localStorage-backed store for teacher comments organized by category.

const COMMENT_BANK_KEY = "edunite_comment_bank";

export type CommentCategory =
  | "Academic Performance"
  | "Effort & Engagement"
  | "Behavior & Social"
  | "Attendance"
  | "Improvement Areas";

export const COMMENT_CATEGORIES: CommentCategory[] = [
  "Academic Performance",
  "Effort & Engagement",
  "Behavior & Social",
  "Attendance",
  "Improvement Areas",
];

export type CommentSubject =
  | "General"
  | "English"
  | "Math"
  | "Science"
  | "History";
export type PerformanceLevel = "Exceeds" | "Meets" | "Approaching" | "Below";

export const COMMENT_SUBJECTS: CommentSubject[] = [
  "General",
  "English",
  "Math",
  "Science",
  "History",
];
export const PERFORMANCE_LEVELS: PerformanceLevel[] = [
  "Exceeds",
  "Meets",
  "Approaching",
  "Below",
];

export interface BankComment {
  id: number;
  text: string;
  category: CommentCategory;
  subject: CommentSubject;
  level: PerformanceLevel;
  createdAt: number;
  isCustom?: boolean;
}

const SEED_COMMENTS: Omit<BankComment, "id" | "createdAt">[] = [
  // ── Academic Performance ──────────────────────────────────────────────────────
  {
    category: "Academic Performance",
    subject: "General",
    level: "Exceeds",
    text: "Demonstrates outstanding command of all course content and consistently exceeds curriculum expectations.",
  },
  {
    category: "Academic Performance",
    subject: "General",
    level: "Exceeds",
    text: "Produces work of exceptional quality, showing sophisticated analytical thinking and creativity.",
  },
  {
    category: "Academic Performance",
    subject: "General",
    level: "Meets",
    text: "Has a solid understanding of the course material and meets all curriculum expectations.",
  },
  {
    category: "Academic Performance",
    subject: "General",
    level: "Meets",
    text: "Consistently submits work that meets or exceeds assignment expectations.",
  },
  {
    category: "Academic Performance",
    subject: "General",
    level: "Approaching",
    text: "Is developing a foundational understanding of the material; continued practice will build confidence.",
  },
  {
    category: "Academic Performance",
    subject: "General",
    level: "Below",
    text: "Struggles with core concepts and would benefit from additional targeted support and review.",
  },
  {
    category: "Academic Performance",
    subject: "English",
    level: "Exceeds",
    text: "Writes with exceptional clarity, structure, and voice; literary analysis demonstrates advanced critical thinking.",
  },
  {
    category: "Academic Performance",
    subject: "English",
    level: "Meets",
    text: "Communicates ideas clearly in writing and demonstrates solid reading comprehension skills.",
  },
  {
    category: "Academic Performance",
    subject: "English",
    level: "Approaching",
    text: "Is developing skills in written expression; focus on paragraph structure and textual evidence will help.",
  },
  {
    category: "Academic Performance",
    subject: "English",
    level: "Below",
    text: "Needs significant support with reading comprehension and written communication skills.",
  },
  {
    category: "Academic Performance",
    subject: "Math",
    level: "Exceeds",
    text: "Demonstrates excellent mathematical reasoning and applies concepts accurately to complex problems.",
  },
  {
    category: "Academic Performance",
    subject: "Math",
    level: "Meets",
    text: "Solves problems correctly and shows clear working; meets all mathematical curriculum expectations.",
  },
  {
    category: "Academic Performance",
    subject: "Math",
    level: "Approaching",
    text: "Is building mathematical fluency; regular practice with core skills will strengthen performance.",
  },
  {
    category: "Academic Performance",
    subject: "Math",
    level: "Below",
    text: "Requires additional support with foundational mathematical concepts and problem-solving strategies.",
  },
  {
    category: "Academic Performance",
    subject: "Science",
    level: "Exceeds",
    text: "Applies scientific inquiry with exceptional rigor; lab reports and data analysis are exemplary.",
  },
  {
    category: "Academic Performance",
    subject: "Science",
    level: "Meets",
    text: "Understands scientific processes and concepts and meets all expectations for the grade level.",
  },
  {
    category: "Academic Performance",
    subject: "History",
    level: "Exceeds",
    text: "Analyzes historical events with nuanced perspective and strong use of primary and secondary sources.",
  },
  {
    category: "Academic Performance",
    subject: "History",
    level: "Meets",
    text: "Demonstrates a solid understanding of historical events and their context; meets curriculum goals.",
  },

  // ── Effort & Engagement ───────────────────────────────────────────────────────
  {
    category: "Effort & Engagement",
    subject: "General",
    level: "Exceeds",
    text: "Brings consistent enthusiasm and curiosity to every lesson; a genuinely engaged learner.",
  },
  {
    category: "Effort & Engagement",
    subject: "General",
    level: "Exceeds",
    text: "Asks thoughtful questions, participates actively in class discussions, and goes above and beyond on tasks.",
  },
  {
    category: "Effort & Engagement",
    subject: "General",
    level: "Meets",
    text: "Participates regularly in class activities and consistently puts forth good effort.",
  },
  {
    category: "Effort & Engagement",
    subject: "General",
    level: "Approaching",
    text: "Shows potential but would benefit from more consistent effort and active class participation.",
  },
  {
    category: "Effort & Engagement",
    subject: "General",
    level: "Below",
    text: "Engagement and effort have been inconsistent this period; increased focus would significantly improve outcomes.",
  },

  // ── Behavior & Social ─────────────────────────────────────────────────────────
  {
    category: "Behavior & Social",
    subject: "General",
    level: "Exceeds",
    text: "An exemplary classroom citizen who supports peers and contributes positively to the learning environment.",
  },
  {
    category: "Behavior & Social",
    subject: "General",
    level: "Exceeds",
    text: "Demonstrates exceptional respect for peers and staff; a role model for collaborative and constructive behavior.",
  },
  {
    category: "Behavior & Social",
    subject: "General",
    level: "Meets",
    text: "Works cooperatively with classmates and follows classroom expectations consistently.",
  },
  {
    category: "Behavior & Social",
    subject: "General",
    level: "Approaching",
    text: "Is developing social skills; at times needs reminders about classroom expectations.",
  },
  {
    category: "Behavior & Social",
    subject: "General",
    level: "Below",
    text: "Behavioral concerns this period have affected both personal learning and the classroom environment; a support plan is in place.",
  },

  // ── Attendance ────────────────────────────────────────────────────────────────
  {
    category: "Attendance",
    subject: "General",
    level: "Exceeds",
    text: "Has maintained excellent attendance and punctuality throughout the entire grading period.",
  },
  {
    category: "Attendance",
    subject: "General",
    level: "Meets",
    text: "Attendance has been satisfactory with only occasional, explained absences.",
  },
  {
    category: "Attendance",
    subject: "General",
    level: "Approaching",
    text: "Attendance has been inconsistent; several unexplained absences may be impacting academic progress.",
  },
  {
    category: "Attendance",
    subject: "General",
    level: "Below",
    text: "Frequent absences and tardiness have had a significant impact on learning; a support conversation with the family is recommended.",
  },

  // ── Improvement Areas ─────────────────────────────────────────────────────────
  {
    category: "Improvement Areas",
    subject: "General",
    level: "Approaching",
    text: "Focus on completing and submitting all assignments on time to prevent gaps in learning.",
  },
  {
    category: "Improvement Areas",
    subject: "General",
    level: "Approaching",
    text: "Would benefit from spending additional time reviewing class notes and key vocabulary each week.",
  },
  {
    category: "Improvement Areas",
    subject: "General",
    level: "Below",
    text: "Strong additional support is recommended, including regular check-ins, targeted intervention sessions, and family communication.",
  },
  {
    category: "Improvement Areas",
    subject: "English",
    level: "Approaching",
    text: "Encourage daily reading and practice with citing evidence from texts to strengthen literacy skills.",
  },
  {
    category: "Improvement Areas",
    subject: "Math",
    level: "Approaching",
    text: "Regular practice with core number skills and problem-solving will build the confidence needed to reach the next level.",
  },
  {
    category: "Improvement Areas",
    subject: "Science",
    level: "Approaching",
    text: "Reviewing lab safety procedures and scientific notation will provide a stronger foundation for the next unit.",
  },
];

function loadBank(): BankComment[] {
  try {
    const raw = localStorage.getItem(COMMENT_BANK_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as BankComment[];
    // migrate old comments without subject/level
    return parsed.map((c) => ({
      ...c,
      subject: c.subject ?? "General",
      level: c.level ?? "Meets",
    }));
  } catch {
    return [];
  }
}

function persistBank(comments: BankComment[]): void {
  localStorage.setItem(COMMENT_BANK_KEY, JSON.stringify(comments));
}

function ensureSeeded(): BankComment[] {
  const existing = loadBank();
  if (existing.length > 0) return existing;
  const seeded = SEED_COMMENTS.map((s, i) => ({
    ...s,
    id: Date.now() + i,
    createdAt: Date.now() + i,
  }));
  persistBank(seeded);
  return seeded;
}

export function getBankComments(): BankComment[] {
  return ensureSeeded();
}

export function getBankCommentsByCategory(
  category: CommentCategory,
): BankComment[] {
  return ensureSeeded().filter((c) => c.category === category);
}

export function addBankComment(
  text: string,
  category: CommentCategory,
  subject: CommentSubject = "General",
  level: PerformanceLevel = "Meets",
): BankComment {
  const all = ensureSeeded();
  const comment: BankComment = {
    id: Date.now(),
    text: text.trim(),
    category,
    subject,
    level,
    createdAt: Date.now(),
    isCustom: true,
  };
  persistBank([...all, comment]);
  return comment;
}

export function deleteBankComment(id: number): void {
  persistBank(loadBank().filter((c) => c.id !== id));
}

export function resetBankToDefaults(): void {
  localStorage.removeItem(COMMENT_BANK_KEY);
}
