import {
  syncInvoicePaymentToExpenses,
  syncRentalToExpenses,
} from "@/hooks/useQueries";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type {
  AppRole,
  AppUser,
  Client,
  ClientPaymentLedger,
  CustomEventTemplate,
  CustomProgramTemplate,
  DeliveryTracker,
  Expense,
  Invoice,
  Notification,
  Package,
  PaymentLedgerEntry,
  RentalEntry,
  Service,
  TeamAssignment,
  TeamMember,
  WorkHistoryEntry,
} from "../types";

// ─── UI State (theme, sidebar, notifications) ─────────────────────────────────

interface UIState {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  currentUser: AppUser | null;
  setCurrentUser: (user: AppUser | null) => void;
  notifications: Notification[];
  unreadCount: number;
  setNotifications: (notifications: Notification[]) => void;
  markNotificationRead: (id: string) => void;
  theme: "light" | "dark";
  toggleTheme: () => void;
  setTheme: (theme: "light" | "dark") => void;
}

export const useAppStore = create<UIState>()(
  persist(
    (set, get) => ({
      sidebarOpen: false,
      toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      currentUser: null,
      setCurrentUser: (user) => set({ currentUser: user }),
      notifications: [],
      unreadCount: 0,
      setNotifications: (notifications) =>
        set({
          notifications,
          unreadCount: notifications.filter((n) => !n.isRead).length,
        }),
      markNotificationRead: (id) =>
        set((s) => {
          const updated = s.notifications.map((n) =>
            n.id === id ? { ...n, isRead: true } : n,
          );
          return {
            notifications: updated,
            unreadCount: updated.filter((n) => !n.isRead).length,
          };
        }),
      theme: "light",
      toggleTheme: () => {
        const next = get().theme === "light" ? "dark" : "light";
        set({ theme: next });
        document.documentElement.classList.toggle("dark", next === "dark");
      },
      setTheme: (theme) => {
        set({ theme });
        document.documentElement.classList.toggle("dark", theme === "dark");
      },
    }),
    {
      name: "photography-app-ui",
      partialize: (s) => ({ theme: s.theme, currentUser: s.currentUser }),
    },
  ),
);

// ─── ERP Data Store ───────────────────────────────────────────────────────────

interface ERPState {
  // Data
  invoices: Invoice[];
  clients: Client[];
  services: Service[];
  packages: Package[];
  teamMembers: TeamMember[];
  expenses: Expense[];
  deliveryTrackers: DeliveryTracker[];
  customProgramTemplates: CustomProgramTemplate[];
  customEventTemplates: CustomEventTemplate[];

  // Payment Ledger
  clientPaymentLedgers: Record<string, ClientPaymentLedger>;
  addClientPayment: (
    clientId: string,
    entry: Omit<PaymentLedgerEntry, "id" | "balanceAfterPayment" | "createdAt">,
  ) => void;
  editClientPayment: (
    clientId: string,
    entryId: string,
    updates: Partial<Omit<PaymentLedgerEntry, "id" | "linkedClientId">>,
  ) => void;
  deleteClientPayment: (clientId: string, entryId: string) => void;
  getClientPaymentSummary: (clientId: string) => {
    totalPaid: number;
    totalDue: number;
    pendingBalance: number;
  };
  getClientPaymentHistory: (clientId: string) => PaymentLedgerEntry[];

  // Equipment Rental
  rentals: RentalEntry[];
  addEquipmentRental: (rental: RentalEntry) => void;
  getClientRentals: (clientId: string) => RentalEntry[];
  getAllRentals: () => RentalEntry[];

  // Expense Sync
  updateExpenseSync: () => void;

  // Invoice CRUD
  addInvoice: (invoice: Invoice) => void;
  updateInvoice: (id: string, updates: Partial<Invoice>) => void;
  deleteInvoice: (id: string) => void;
  getInvoiceById: (id: string) => Invoice | undefined;
  /**
   * Atomically append a payment entry to an invoice and recompute
   * advancePaid / pendingAmount so every subscribed component re-renders
   * with the correct balance immediately — no page reload required.
   */
  addPaymentToInvoice: (
    invoiceId: string,
    entry: import("../types").PaymentHistoryEntry,
  ) => void;
  /**
   * Edit an existing payment entry in place and recompute advancePaid /
   * pendingAmount from the full paymentHistory sum.
   */
  editPaymentInInvoice: (
    invoiceId: string,
    oldPaymentId: string,
    updatedEntry: import("../types").PaymentHistoryEntry,
  ) => void;
  /**
   * Delete a payment entry and recompute advancePaid / pendingAmount
   * from the remaining paymentHistory sum.
   */
  deletePaymentInInvoice: (invoiceId: string, paymentId: string) => void;

  // Client CRUD
  addClient: (client: Client) => void;
  updateClient: (id: string, updates: Partial<Client>) => void;
  deleteClient: (id: string) => void;
  getClientById: (id: string) => Client | undefined;
  upsertClientByName: (
    name: string,
    phone: string,
    extra?: Partial<Client>,
  ) => Client;

  // Service CRUD
  addService: (service: Service) => void;
  updateService: (id: string, updates: Partial<Service>) => void;
  deleteService: (id: string) => void;

  // Package CRUD
  addPackage: (pkg: Package) => void;
  updatePackage: (id: string, updates: Partial<Package>) => void;
  deletePackage: (id: string) => void;

  // Team CRUD
  addTeamMember: (member: TeamMember) => void;
  updateTeamMember: (id: string, updates: Partial<TeamMember>) => void;
  deleteTeamMember: (id: string) => void;
  getTeamMemberById: (id: string) => TeamMember | undefined;
  /** Create a new assignment with optional date range, syncs to invoice + workHistory */
  addTeamAssignment: (assignment: TeamAssignment & { id: string }) => void;
  /** Update an existing assignment by id, regenerates WorkHistoryEntries */
  updateTeamAssignment: (
    assignmentId: string,
    updates: Partial<TeamAssignment>,
  ) => void;
  /** Delete an assignment by id, removes from member + invoice + workHistory */
  deleteTeamAssignment: (assignmentId: string) => void;
  /** Record a payment against an assignment by its id + date */
  recordPaymentByAssignmentId: (
    assignmentId: string,
    amount: number,
    date?: string,
  ) => void;
  /** Record a payment against a specific assignment identified by invoiceId + program */
  /** Record a payment against a specific assignment identified by invoiceId + program */
  addTeamAssignmentPayment: (
    memberId: string,
    invoiceId: string,
    program: string,
    amount: number,
  ) => void;

  // Expense CRUD
  addExpense: (expense: Expense) => void;
  updateExpense: (id: string, updates: Partial<Expense>) => void;
  deleteExpense: (id: string) => void;

  // Delivery Tracker CRUD
  addDeliveryTracker: (tracker: DeliveryTracker) => void;
  updateDeliveryTracker: (
    id: string,
    updates: Partial<DeliveryTracker>,
  ) => void;
  deleteDeliveryTracker: (id: string) => void;
  getTrackerByInvoiceId: (invoiceId: string) => DeliveryTracker | undefined;

  // Custom Templates
  addCustomProgramTemplate: (tpl: CustomProgramTemplate) => void;
  deleteCustomProgramTemplate: (id: string) => void;
  addCustomEventTemplate: (tpl: CustomEventTemplate) => void;
  deleteCustomEventTemplate: (id: string) => void;
}

export const useERPStore = create<ERPState>()(
  persist(
    (set, get) => ({
      // ── Initial data ──────────────────────────────────────────────────────
      invoices: [],
      clients: [],
      services: [
        {
          id: "svc-1",
          name: "Candid Photography",
          category: "Traditional",
          price: 15000,
          isCustom: false,
        },
        {
          id: "svc-2",
          name: "Cinematic Video",
          category: "Cinematic",
          price: 20000,
          isCustom: false,
        },
        {
          id: "svc-3",
          name: "Traditional Video",
          category: "Traditional",
          price: 12000,
          isCustom: false,
        },
        {
          id: "svc-4",
          name: "Drone Shoot",
          category: "Drone",
          price: 8000,
          isCustom: false,
        },
        {
          id: "svc-5",
          name: "Album Design (50 sheets)",
          category: "Album",
          price: 10000,
          isCustom: false,
        },
        {
          id: "svc-6",
          name: "Photo Editing",
          category: "Editing",
          price: 5000,
          isCustom: false,
        },
      ],
      packages: [
        {
          id: "pkg-1",
          name: "Silver Package",
          basePrice: 40000,
          totalDays: 1,
          services: [
            {
              id: "svc-1",
              name: "Candid Photography",
              category: "Traditional",
              price: 15000,
            },
            {
              id: "svc-3",
              name: "Traditional Video",
              category: "Traditional",
              price: 12000,
            },
          ],
          includedLimits: { albumSheets: 50, videoHours: 5 },
          extraChargeRules: [
            {
              serviceName: "Extra Album Sheet",
              includedLimit: 50,
              unit: "sheet",
              extraChargePerUnit: 200,
            },
            {
              serviceName: "Extra Video Hour",
              includedLimit: 5,
              unit: "hour",
              extraChargePerUnit: 1500,
            },
          ],
          isActive: true,
          createdAt: new Date().toISOString(),
        },
        {
          id: "pkg-2",
          name: "Gold Package",
          basePrice: 75000,
          totalDays: 2,
          services: [
            {
              id: "svc-1",
              name: "Candid Photography",
              category: "Traditional",
              price: 15000,
            },
            {
              id: "svc-2",
              name: "Cinematic Video",
              category: "Cinematic",
              price: 20000,
            },
            {
              id: "svc-4",
              name: "Drone Shoot",
              category: "Drone",
              price: 8000,
            },
          ],
          includedLimits: { albumSheets: 100, videoHours: 8, eventDays: 2 },
          extraChargeRules: [
            {
              serviceName: "Extra Album Sheet",
              includedLimit: 100,
              unit: "sheet",
              extraChargePerUnit: 150,
            },
            {
              serviceName: "Extra Video Hour",
              includedLimit: 8,
              unit: "hour",
              extraChargePerUnit: 1200,
            },
          ],
          isActive: true,
          createdAt: new Date().toISOString(),
        },
      ],
      teamMembers: [],
      expenses: [],
      deliveryTrackers: [],
      customProgramTemplates: [
        { id: "tpl-1", name: "Mata ji Pujan", isDefault: true },
        { id: "tpl-2", name: "Ganesh Pujan / Chak", isDefault: true },
        { id: "tpl-3", name: "Haldi", isDefault: true },
        { id: "tpl-4", name: "Mehendi", isDefault: true },
        { id: "tpl-5", name: "Sangeet / DJ Night", isDefault: true },
        { id: "tpl-6", name: "Wedding / Fere", isDefault: true },
        { id: "tpl-7", name: "Reception", isDefault: true },
        { id: "tpl-8", name: "Gangoj", isDefault: true },
        { id: "tpl-9", name: "Mamera", isDefault: true },
        { id: "tpl-10", name: "Bindoli / Procession", isDefault: true },
      ],
      customEventTemplates: [],
      clientPaymentLedgers: {},
      rentals: [],

      // ── Invoice Actions ───────────────────────────────────────────────────
      addInvoice: (invoice) => {
        set((s) => {
          // Sync team work history for each assignment on the new invoice
          const assignments = invoice.teamAssignments ?? [];
          const updatedMembers = s.teamMembers.map((m) => {
            const myAssignments = assignments.filter(
              (a) => a.teamMemberId === m.id,
            );
            if (myAssignments.length === 0) return m;
            const existingHistory = m.workHistory ?? [];
            const newEntries = myAssignments
              .filter(
                (a) =>
                  !existingHistory.some(
                    (h) =>
                      h.invoiceId === invoice.id &&
                      h.program === (a.program ?? ""),
                  ),
              )
              .map((a) => ({
                invoiceId: invoice.id,
                clientName: invoice.clientName,
                eventName: invoice.customEventName ?? invoice.eventType,
                program: a.program ?? "",
                date: a.date ?? "",
                startTime: a.startTime ?? "",
                endTime: a.endTime ?? "",
                location: a.location ?? "",
                role: a.role ?? "",
                dayType: a.dayType ?? "full",
                rateUsed: a.rateUsed ?? 0,
                paymentReceived: a.paymentReceived ?? 0,
                paymentPending: a.paymentPending ?? a.rateUsed ?? 0,
                recordedAt: new Date().toISOString(),
              }));
            if (newEntries.length === 0) return m;
            return { ...m, workHistory: [...existingHistory, ...newEntries] };
          });
          return {
            invoices: [invoice, ...s.invoices],
            teamMembers: updatedMembers,
          };
        });
      },
      updateInvoice: (id, updates) =>
        set((s) => {
          const merged = {
            ...s.invoices.find((i) => i.id === id),
            ...updates,
          } as Invoice;
          const assignments = merged.teamAssignments ?? [];
          const updatedMembers = s.teamMembers.map((m) => {
            const myAssignments = assignments.filter(
              (a) => a.teamMemberId === m.id,
            );
            if (myAssignments.length === 0) return m;
            const existingHistory = m.workHistory ?? [];
            const newEntries = myAssignments
              .filter(
                (a) =>
                  !existingHistory.some(
                    (h) =>
                      h.invoiceId === id && h.program === (a.program ?? ""),
                  ),
              )
              .map((a) => ({
                invoiceId: id,
                clientName: merged.clientName,
                eventName: merged.customEventName ?? merged.eventType,
                program: a.program ?? "",
                date: a.date ?? "",
                startTime: a.startTime ?? "",
                endTime: a.endTime ?? "",
                location: a.location ?? "",
                role: a.role ?? "",
                dayType: a.dayType ?? "full",
                rateUsed: a.rateUsed ?? 0,
                paymentReceived: a.paymentReceived ?? 0,
                paymentPending: a.paymentPending ?? a.rateUsed ?? 0,
                recordedAt: new Date().toISOString(),
              }));
            if (newEntries.length === 0) return m;
            return { ...m, workHistory: [...existingHistory, ...newEntries] };
          });
          return {
            invoices: s.invoices.map((inv) =>
              inv.id === id
                ? { ...inv, ...updates, updatedAt: new Date().toISOString() }
                : inv,
            ),
            teamMembers: updatedMembers,
          };
        }),
      deleteInvoice: (id) =>
        set((s) => ({
          invoices: s.invoices.filter((inv) => inv.id !== id),
          deliveryTrackers: s.deliveryTrackers.filter(
            (t) => t.invoiceId !== id,
          ),
        })),
      getInvoiceById: (id) => get().invoices.find((inv) => inv.id === id),

      addPaymentToInvoice: (invoiceId, entry) => {
        // Duplicate-payment guard: reject if last payment has same amount added < 5000ms ago
        const existing = get().invoices.find((inv) => inv.id === invoiceId);
        if (existing) {
          const history = existing.paymentHistory ?? [];
          if (history.length > 0) {
            const last = history[history.length - 1];
            const lastTs = last.createdAt
              ? new Date(last.createdAt).getTime()
              : 0;
            if (
              last.amount === entry.amount &&
              lastTs > 0 &&
              Date.now() - lastTs < 5000
            ) {
              console.warn(
                "[addPaymentToInvoice] Duplicate payment suppressed — same amount submitted within 5 seconds.",
              );
              return;
            }
          }
        }
        // Stamp createdAt on the incoming entry so future duplicate checks work
        const stampedEntry = {
          ...entry,
          createdAt: entry.createdAt ?? new Date().toISOString(),
        };
        set((s) => {
          const updatedInvoices = s.invoices.map((inv) => {
            if (inv.id !== invoiceId) return inv;
            const updatedHistory = [
              ...(inv.paymentHistory ?? []),
              stampedEntry,
            ];
            const newTotalPaid = updatedHistory.reduce(
              (sum, p) => sum + (Number(p.amount) || 0),
              0,
            );
            const dealAmount = Number(inv.dealAmount) || 0;
            const discount = Number(inv.discount) || 0;
            const extraChargesTotal = (inv.packageExtraCharges ?? []).reduce(
              (sum, c) => sum + (Number(c.extraTotal) || 0),
              0,
            );
            const subtotal = dealAmount - discount + extraChargesTotal;
            const gstAmount =
              inv.gstEnabled && (inv.gstPercent ?? 0) > 0
                ? subtotal * ((inv.gstPercent ?? 0) / 100)
                : 0;
            const grandTotal = subtotal + gstAmount;
            const pending = Math.max(0, grandTotal - newTotalPaid);
            const status =
              pending <= 0
                ? ("paid" as const)
                : newTotalPaid > 0
                  ? ("partial" as const)
                  : ("pending" as const);
            return {
              ...inv,
              paymentHistory: updatedHistory,
              advancePaid: newTotalPaid,
              pendingAmount: pending,
              status,
              updatedAt: new Date().toISOString(),
            };
          });
          const invoice = updatedInvoices.find((inv) => inv.id === invoiceId);
          const updatedExpenses = invoice
            ? syncInvoicePaymentToExpenses(
                s.expenses,
                "add",
                stampedEntry,
                invoice,
              )
            : s.expenses;
          return { invoices: updatedInvoices, expenses: updatedExpenses };
        });
      },

      editPaymentInInvoice: (invoiceId, oldPaymentId, updatedEntry) =>
        set((s) => {
          const updatedInvoices = s.invoices.map((inv) => {
            if (inv.id !== invoiceId) return inv;
            const updatedHistory = (inv.paymentHistory ?? []).map((p) =>
              p.id === oldPaymentId ? updatedEntry : p,
            );
            const newTotalPaid = updatedHistory.reduce(
              (sum, p) => sum + (Number(p.amount) || 0),
              0,
            );
            const dealAmt = Number(inv.dealAmount) || 0;
            const disc = Number(inv.discount) || 0;
            const extraChargesTotal = (inv.packageExtraCharges ?? []).reduce(
              (sum, c) => sum + (Number(c.extraTotal) || 0),
              0,
            );
            const subtotal = dealAmt - disc + extraChargesTotal;
            const gstAmount =
              inv.gstEnabled && (inv.gstPercent ?? 0) > 0
                ? subtotal * ((inv.gstPercent ?? 0) / 100)
                : 0;
            const grandTotal = subtotal + gstAmount;
            const pending = Math.max(0, grandTotal - newTotalPaid);
            const status =
              pending <= 0
                ? ("paid" as const)
                : newTotalPaid > 0
                  ? ("partial" as const)
                  : ("pending" as const);
            return {
              ...inv,
              paymentHistory: updatedHistory,
              advancePaid: newTotalPaid,
              pendingAmount: pending,
              status,
              updatedAt: new Date().toISOString(),
            };
          });
          const invoice = updatedInvoices.find((inv) => inv.id === invoiceId);
          const updatedExpenses = invoice
            ? syncInvoicePaymentToExpenses(
                s.expenses,
                "edit",
                updatedEntry,
                invoice,
              )
            : s.expenses;
          return { invoices: updatedInvoices, expenses: updatedExpenses };
        }),

      deletePaymentInInvoice: (invoiceId, paymentId) =>
        set((s) => {
          // Capture the payment entry before removing it (needed for sync)
          const sourceInvoice = s.invoices.find((inv) => inv.id === invoiceId);
          const deletedEntry = sourceInvoice?.paymentHistory?.find(
            (p) => p.id === paymentId,
          );
          const updatedInvoices = s.invoices.map((inv) => {
            if (inv.id !== invoiceId) return inv;
            const updatedHistory = (inv.paymentHistory ?? []).filter(
              (p) => p.id !== paymentId,
            );
            const newTotalPaid = updatedHistory.reduce(
              (sum, p) => sum + (Number(p.amount) || 0),
              0,
            );
            const dealAmt = Number(inv.dealAmount) || 0;
            const disc = Number(inv.discount) || 0;
            const extraChargesTotal = (inv.packageExtraCharges ?? []).reduce(
              (sum, c) => sum + (Number(c.extraTotal) || 0),
              0,
            );
            const subtotal = dealAmt - disc + extraChargesTotal;
            const gstAmount =
              inv.gstEnabled && (inv.gstPercent ?? 0) > 0
                ? subtotal * ((inv.gstPercent ?? 0) / 100)
                : 0;
            const grandTotal = subtotal + gstAmount;
            const pending = Math.max(0, grandTotal - newTotalPaid);
            const status =
              pending <= 0
                ? ("paid" as const)
                : newTotalPaid > 0
                  ? ("partial" as const)
                  : ("pending" as const);
            return {
              ...inv,
              paymentHistory: updatedHistory,
              advancePaid: newTotalPaid,
              pendingAmount: pending,
              status,
              updatedAt: new Date().toISOString(),
            };
          });
          const invoice = updatedInvoices.find((inv) => inv.id === invoiceId);
          const updatedExpenses =
            deletedEntry && invoice
              ? syncInvoicePaymentToExpenses(
                  s.expenses,
                  "delete",
                  deletedEntry,
                  invoice,
                )
              : s.expenses;
          return { invoices: updatedInvoices, expenses: updatedExpenses };
        }),

      // ── Client Actions ────────────────────────────────────────────────────
      addClient: (client) => set((s) => ({ clients: [client, ...s.clients] })),
      updateClient: (id, updates) =>
        set((s) => ({
          clients: s.clients.map((c) =>
            c.id === id ? { ...c, ...updates } : c,
          ),
        })),
      deleteClient: (id) => {
        const { invoices } = get();
        const linked = invoices.filter((inv) => inv.clientId === id).length;
        if (linked > 0) {
          throw new Error(`Cannot delete: ${linked} linked invoice(s) exist`);
        }
        set((s) => ({ clients: s.clients.filter((c) => c.id !== id) }));
      },
      getClientById: (id) => get().clients.find((c) => c.id === id),
      upsertClientByName: (name, phone, extra) => {
        const existing = get().clients.find(
          (c) =>
            c.name.toLowerCase() === name.toLowerCase() && c.phone === phone,
        );
        if (existing) return existing;
        const newClient: Client = {
          id: `client-${Date.now()}`,
          name,
          phone,
          createdAt: new Date().toISOString(),
          ...extra,
        };
        set((s) => ({ clients: [newClient, ...s.clients] }));
        return newClient;
      },

      // ── Service Actions ───────────────────────────────────────────────────
      addService: (service) =>
        set((s) => ({ services: [...s.services, service] })),
      updateService: (id, updates) =>
        set((s) => ({
          services: s.services.map((svc) =>
            svc.id === id ? { ...svc, ...updates } : svc,
          ),
        })),
      deleteService: (id) =>
        set((s) => ({ services: s.services.filter((svc) => svc.id !== id) })),

      // ── Package Actions ───────────────────────────────────────────────────
      addPackage: (pkg) => set((s) => ({ packages: [...s.packages, pkg] })),
      updatePackage: (id, updates) =>
        set((s) => ({
          packages: s.packages.map((p) =>
            p.id === id ? { ...p, ...updates } : p,
          ),
        })),
      deletePackage: (id) =>
        set((s) => ({ packages: s.packages.filter((p) => p.id !== id) })),

      // ── Team Actions ──────────────────────────────────────────────────────
      addTeamMember: (member) =>
        set((s) => ({ teamMembers: [...s.teamMembers, member] })),
      updateTeamMember: (id, updates) =>
        set((s) => ({
          teamMembers: s.teamMembers.map((m) =>
            m.id === id ? { ...m, ...updates } : m,
          ),
        })),
      deleteTeamMember: (id) => {
        const { invoices } = get();
        let count = 0;
        for (const inv of invoices) {
          for (const a of inv.teamAssignments ?? []) {
            if (a.teamMemberId === id) count++;
          }
        }
        if (count > 0) {
          throw new Error(
            `Cannot delete: member has ${count} linked assignment(s)`,
          );
        }
        set((s) => ({ teamMembers: s.teamMembers.filter((m) => m.id !== id) }));
      },
      getTeamMemberById: (id) => get().teamMembers.find((m) => m.id === id),

      addTeamAssignment: (assignment) =>
        set((s) => {
          // Helper: generate list of ISO date strings in a range
          function datesInRange(start: string, end: string): string[] {
            const dates: string[] = [];
            const cur = new Date(start);
            const endD = new Date(end);
            while (cur <= endD) {
              dates.push(cur.toISOString().split("T")[0]);
              cur.setDate(cur.getDate() + 1);
            }
            return dates;
          }

          const rangeStart = assignment.dateRangeStart ?? assignment.date ?? "";
          const rangeEnd =
            assignment.dateRangeEnd ?? assignment.date ?? rangeStart;
          const allDates = rangeStart
            ? datesInRange(rangeStart, rangeEnd)
            : assignment.date
              ? [assignment.date]
              : [];

          // Build one WorkHistoryEntry per date
          // Effective rate applies the 50% multiplier for half-day assignments
          const baseRate = assignment.rateUsed ?? 0;
          const effectiveRate =
            assignment.dayType === "half" ? baseRate * 0.5 : baseRate;
          const newHistoryEntries: WorkHistoryEntry[] = allDates.map((d) => ({
            invoiceId: assignment.invoiceId ?? "",
            clientName: "",
            eventName: "",
            program: assignment.program ?? "",
            date: d,
            startTime: assignment.startTime ?? "",
            endTime: assignment.endTime ?? "",
            location: assignment.location ?? "",
            role: assignment.role ?? "",
            dayType: assignment.dayType ?? "full",
            rateUsed: baseRate,
            paymentReceived: 0,
            paymentPending: effectiveRate,
            recordedAt: new Date().toISOString(),
            assignmentId: assignment.id,
          }));

          // Update member
          const updatedMembers = s.teamMembers.map((m) => {
            if (m.id !== assignment.teamMemberId) return m;
            // Enrich history entries with client/event name from invoice if linked
            const invoice = assignment.invoiceId
              ? s.invoices.find((inv) => inv.id === assignment.invoiceId)
              : undefined;
            const enrichedEntries = newHistoryEntries.map((h) => ({
              ...h,
              clientName: invoice?.clientName ?? "",
              eventName: invoice?.customEventName ?? invoice?.eventType ?? "",
            }));
            return {
              ...m,
              assignments: [...(m.assignments ?? []), assignment],
              workHistory: [...(m.workHistory ?? []), ...enrichedEntries],
            };
          });

          // Sync to invoice teamAssignments if invoiceId provided
          const updatedInvoices = assignment.invoiceId
            ? s.invoices.map((inv) => {
                if (inv.id !== assignment.invoiceId) return inv;
                return {
                  ...inv,
                  teamAssignments: [...(inv.teamAssignments ?? []), assignment],
                  updatedAt: new Date().toISOString(),
                };
              })
            : s.invoices;

          return { teamMembers: updatedMembers, invoices: updatedInvoices };
        }),

      updateTeamAssignment: (assignmentId, updates) =>
        set((s) => {
          function datesInRange(start: string, end: string): string[] {
            const dates: string[] = [];
            const cur = new Date(start);
            const endD = new Date(end);
            while (cur <= endD) {
              dates.push(cur.toISOString().split("T")[0]);
              cur.setDate(cur.getDate() + 1);
            }
            return dates;
          }

          const updatedMembers = s.teamMembers.map((m) => {
            const aIdx = (m.assignments ?? []).findIndex(
              (a) => a.id === assignmentId,
            );
            if (aIdx === -1) return m;
            const merged: TeamAssignment & { id: string } = {
              ...(m.assignments![aIdx] as TeamAssignment & { id: string }),
              ...updates,
            };
            const newAssignments = m.assignments!.map((a) =>
              a.id === assignmentId ? merged : a,
            );

            // Rebuild work history entries for this assignment
            const rangeStart = merged.dateRangeStart ?? merged.date ?? "";
            const rangeEnd = merged.dateRangeEnd ?? merged.date ?? rangeStart;
            const allDates = rangeStart
              ? datesInRange(rangeStart, rangeEnd)
              : [];

            // Find invoice for client/event name
            const invoice = merged.invoiceId
              ? s.invoices.find((inv) => inv.id === merged.invoiceId)
              : undefined;

            // Recompute effective rate for updated assignment
            const updatedBaseRate = merged.rateUsed ?? 0;
            const updatedEffectiveRate =
              merged.dayType === "half"
                ? updatedBaseRate * 0.5
                : updatedBaseRate;
            const newEntries: WorkHistoryEntry[] = allDates.map((d) => ({
              invoiceId: merged.invoiceId ?? "",
              clientName: invoice?.clientName ?? "",
              eventName: invoice?.customEventName ?? invoice?.eventType ?? "",
              program: merged.program ?? "",
              date: d,
              startTime: merged.startTime ?? "",
              endTime: merged.endTime ?? "",
              location: merged.location ?? "",
              role: merged.role ?? "",
              dayType: merged.dayType ?? "full",
              rateUsed: updatedBaseRate,
              paymentReceived: 0,
              paymentPending: updatedEffectiveRate,
              recordedAt: new Date().toISOString(),
              assignmentId,
            }));

            // Remove old entries for this assignmentId, insert new
            const filteredHistory = (m.workHistory ?? []).filter(
              (h) => h.assignmentId !== assignmentId,
            );

            return {
              ...m,
              assignments: newAssignments,
              workHistory: [...filteredHistory, ...newEntries],
            };
          });

          // Also update invoice teamAssignments
          const updatedInvoices = s.invoices.map((inv) => {
            const aIdx = (inv.teamAssignments ?? []).findIndex(
              (a) => a.id === assignmentId,
            );
            if (aIdx === -1) return inv;
            const newAssignments = inv.teamAssignments!.map((a) =>
              a.id === assignmentId ? { ...a, ...updates } : a,
            );
            return {
              ...inv,
              teamAssignments: newAssignments,
              updatedAt: new Date().toISOString(),
            };
          });

          return { teamMembers: updatedMembers, invoices: updatedInvoices };
        }),

      deleteTeamAssignment: (assignmentId) =>
        set((s) => ({
          teamMembers: s.teamMembers.map((m) => ({
            ...m,
            assignments: (m.assignments ?? []).filter(
              (a) => a.id !== assignmentId,
            ),
            workHistory: (m.workHistory ?? []).filter(
              (h) => h.assignmentId !== assignmentId,
            ),
          })),
          invoices: s.invoices.map((inv) => ({
            ...inv,
            teamAssignments: (inv.teamAssignments ?? []).filter(
              (a) => a.id !== assignmentId,
            ),
          })),
        })),

      recordPaymentByAssignmentId: (assignmentId, amount, date) =>
        set((s) => ({
          teamMembers: s.teamMembers.map((m) => {
            const hasAssignment = (m.assignments ?? []).some(
              (a) => a.id === assignmentId,
            );
            if (!hasAssignment) return m;
            const updatedAssignments = (m.assignments ?? []).map((a) => {
              if (a.id !== assignmentId) return a;
              // For aggregate assignment, sum payments across matching work history dates
              const historyEntries = (m.workHistory ?? []).filter(
                (h) =>
                  h.assignmentId === assignmentId && (!date || h.date === date),
              );
              const newTotalReceived =
                historyEntries.reduce(
                  (sum, h) => sum + (h.paymentReceived ?? 0),
                  0,
                ) + amount;
              // Effective rate on assignment = rateUsed × multiplier
              const aEffective =
                a.dayType === "half"
                  ? (a.rateUsed ?? 0) * 0.5
                  : (a.rateUsed ?? 0);
              const pending = Math.max(0, aEffective - newTotalReceived);
              return {
                ...a,
                paymentReceived: newTotalReceived,
                paymentPending: pending,
              };
            });
            const updatedHistory = (m.workHistory ?? []).map((h) => {
              if (h.assignmentId !== assignmentId) return h;
              // When a specific date is given, only update that date's entry
              if (date && h.date && h.date !== date) return h;
              const received = (h.paymentReceived ?? 0) + amount;
              // Effective rate per work history entry
              const hEffective =
                h.dayType === "half"
                  ? (h.rateUsed ?? 0) * 0.5
                  : (h.rateUsed ?? 0);
              const pending = Math.max(0, hEffective - received);
              return {
                ...h,
                paymentReceived: received,
                paymentPending: pending,
              };
            });
            return {
              ...m,
              assignments: updatedAssignments,
              workHistory: updatedHistory,
            };
          }),
          invoices: s.invoices.map((inv) => {
            const aIdx = (inv.teamAssignments ?? []).findIndex(
              (a) => a.id === assignmentId,
            );
            if (aIdx === -1) return inv;
            const updatedAssignments = inv.teamAssignments!.map((a) => {
              if (a.id !== assignmentId) return a;
              const received = (a.paymentReceived ?? 0) + amount;
              const aEffective =
                a.dayType === "half"
                  ? (a.rateUsed ?? 0) * 0.5
                  : (a.rateUsed ?? 0);
              const pending = Math.max(0, aEffective - received);
              return {
                ...a,
                paymentReceived: received,
                paymentPending: pending,
              };
            });
            return {
              ...inv,
              teamAssignments: updatedAssignments,
              updatedAt: new Date().toISOString(),
            };
          }),
        })),

      addTeamAssignmentPayment: (memberId, invoiceId, program, amount) =>
        set((s) => ({
          teamMembers: s.teamMembers.map((m) => {
            if (m.id !== memberId) return m;
            // Update workHistory entry
            const updatedHistory = (m.workHistory ?? []).map((h) => {
              if (h.invoiceId !== invoiceId || (h.program ?? "") !== program)
                return h;
              const received = (h.paymentReceived ?? 0) + amount;
              const effectiveRate =
                h.dayType === "half"
                  ? (h.rateUsed ?? 0) * 0.5
                  : (h.rateUsed ?? 0);
              const pending = Math.max(0, effectiveRate - received);
              return {
                ...h,
                paymentReceived: received,
                paymentPending: pending,
              };
            });
            // Also update assignments array
            const updatedAssignments = (m.assignments ?? []).map((a) => {
              if (a.teamMemberId !== memberId) return a;
              if ((a.program ?? "") !== program) return a;
              const received = (a.paymentReceived ?? 0) + amount;
              const effectiveRate =
                a.dayType === "half"
                  ? (a.rateUsed ?? 0) * 0.5
                  : (a.rateUsed ?? 0);
              const pending = Math.max(0, effectiveRate - received);
              return {
                ...a,
                paymentReceived: received,
                paymentPending: pending,
              };
            });
            return {
              ...m,
              workHistory: updatedHistory,
              assignments: updatedAssignments,
            };
          }),
          // Also update invoice team assignment
          invoices: s.invoices.map((inv) => {
            if (inv.id !== invoiceId) return inv;
            const updatedAssignments = (inv.teamAssignments ?? []).map((a) => {
              if (a.teamMemberId !== memberId || (a.program ?? "") !== program)
                return a;
              const received = (a.paymentReceived ?? 0) + amount;
              const effectiveRate =
                a.dayType === "half"
                  ? (a.rateUsed ?? 0) * 0.5
                  : (a.rateUsed ?? 0);
              const pending = Math.max(0, effectiveRate - received);
              return {
                ...a,
                paymentReceived: received,
                paymentPending: pending,
              };
            });
            return {
              ...inv,
              teamAssignments: updatedAssignments,
              updatedAt: new Date().toISOString(),
            };
          }),
        })),

      // ── Expense Actions ───────────────────────────────────────────────────
      addExpense: (expense) =>
        set((s) => ({ expenses: [expense, ...s.expenses] })),
      updateExpense: (id, updates) =>
        set((s) => ({
          expenses: s.expenses.map((e) =>
            e.id === id ? { ...e, ...updates } : e,
          ),
        })),
      deleteExpense: (id) =>
        set((s) => ({ expenses: s.expenses.filter((e) => e.id !== id) })),

      // ── Delivery Tracker Actions ──────────────────────────────────────────
      addDeliveryTracker: (tracker) =>
        set((s) => ({ deliveryTrackers: [tracker, ...s.deliveryTrackers] })),
      updateDeliveryTracker: (id, updates) =>
        set((s) => ({
          deliveryTrackers: s.deliveryTrackers.map((t) =>
            t.id === id ? { ...t, ...updates } : t,
          ),
        })),
      deleteDeliveryTracker: (id) =>
        set((s) => ({
          deliveryTrackers: s.deliveryTrackers.filter((t) => t.id !== id),
        })),
      getTrackerByInvoiceId: (invoiceId) =>
        get().deliveryTrackers.find((t) => t.invoiceId === invoiceId),

      // ── Custom Template Actions ───────────────────────────────────────────
      addCustomProgramTemplate: (tpl) =>
        set((s) => ({
          customProgramTemplates: [...s.customProgramTemplates, tpl],
        })),
      deleteCustomProgramTemplate: (id) =>
        set((s) => ({
          customProgramTemplates: s.customProgramTemplates.filter(
            (t) => t.id !== id,
          ),
        })),
      addCustomEventTemplate: (tpl) =>
        set((s) => ({
          customEventTemplates: [...s.customEventTemplates, tpl],
        })),
      deleteCustomEventTemplate: (id) =>
        set((s) => ({
          customEventTemplates: s.customEventTemplates.filter(
            (t) => t.id !== id,
          ),
        })),

      // ── Payment Ledger Actions ──────────────────────────────────────────
      addClientPayment: (clientId, entry) =>
        set((s) => {
          const ledger = s.clientPaymentLedgers[clientId] ?? {
            clientId,
            totalPaid: 0,
            totalDue: 0,
            runningBalance: 0,
            entries: [],
          };
          const newEntry: PaymentLedgerEntry = {
            ...entry,
            id: `pay-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            linkedClientId: clientId,
            balanceAfterPayment: 0,
            createdAt: new Date().toISOString(),
          };
          const allEntries = [...ledger.entries, newEntry].sort(
            (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
          );
          let runningBalance = 0;
          const updatedEntries = allEntries.map((e) => {
            runningBalance += e.amount;
            return { ...e, balanceAfterPayment: runningBalance };
          });
          const totalPaid = updatedEntries.reduce(
            (sum, e) => sum + e.amount,
            0,
          );
          const clientInvoices = s.invoices.filter(
            (i) => i.clientId === clientId,
          );
          const totalDue = clientInvoices.reduce((sum, inv) => {
            const dealAmt = Number(inv.dealAmount) || 0;
            const disc = Number(inv.discount) || 0;
            const extraChargesTotal = (inv.packageExtraCharges ?? []).reduce(
              (sum2, c) => sum2 + (Number(c.extraTotal) || 0),
              0,
            );
            const subtotal = dealAmt - disc + extraChargesTotal;
            const gstAmount =
              inv.gstEnabled && (inv.gstPercent ?? 0) > 0
                ? subtotal * ((inv.gstPercent ?? 0) / 100)
                : 0;
            return sum + subtotal + gstAmount;
          }, 0);
          return {
            clientPaymentLedgers: {
              ...s.clientPaymentLedgers,
              [clientId]: {
                ...ledger,
                totalPaid,
                totalDue,
                runningBalance: Math.max(0, totalDue - totalPaid),
                entries: updatedEntries,
              },
            },
          };
        }),

      editClientPayment: (clientId, entryId, updates) =>
        set((s) => {
          const ledger = s.clientPaymentLedgers[clientId];
          if (!ledger) return {};
          const updatedEntries = ledger.entries
            .map((e) => (e.id === entryId ? { ...e, ...updates } : e))
            .sort(
              (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
            );
          let runningBalance = 0;
          const recalculatedEntries = updatedEntries.map((e) => {
            runningBalance += e.amount;
            return { ...e, balanceAfterPayment: runningBalance };
          });
          const totalPaid = recalculatedEntries.reduce(
            (sum, e) => sum + e.amount,
            0,
          );
          const clientInvoices = s.invoices.filter(
            (i) => i.clientId === clientId,
          );
          const totalDue = clientInvoices.reduce((sum, inv) => {
            const dealAmt = Number(inv.dealAmount) || 0;
            const disc = Number(inv.discount) || 0;
            const extraChargesTotal = (inv.packageExtraCharges ?? []).reduce(
              (sum2, c) => sum2 + (Number(c.extraTotal) || 0),
              0,
            );
            const subtotal = dealAmt - disc + extraChargesTotal;
            const gstAmount =
              inv.gstEnabled && (inv.gstPercent ?? 0) > 0
                ? subtotal * ((inv.gstPercent ?? 0) / 100)
                : 0;
            return sum + subtotal + gstAmount;
          }, 0);
          return {
            clientPaymentLedgers: {
              ...s.clientPaymentLedgers,
              [clientId]: {
                ...ledger,
                totalPaid,
                totalDue,
                runningBalance: Math.max(0, totalDue - totalPaid),
                entries: recalculatedEntries,
              },
            },
          };
        }),

      deleteClientPayment: (clientId, entryId) =>
        set((s) => {
          const ledger = s.clientPaymentLedgers[clientId];
          if (!ledger) return {};
          const filteredEntries = ledger.entries
            .filter((e) => e.id !== entryId)
            .sort(
              (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
            );
          let runningBalance = 0;
          const recalculatedEntries = filteredEntries.map((e) => {
            runningBalance += e.amount;
            return { ...e, balanceAfterPayment: runningBalance };
          });
          const totalPaid = recalculatedEntries.reduce(
            (sum, e) => sum + e.amount,
            0,
          );
          const clientInvoices = s.invoices.filter(
            (i) => i.clientId === clientId,
          );
          const totalDue = clientInvoices.reduce((sum, inv) => {
            const dealAmt = Number(inv.dealAmount) || 0;
            const disc = Number(inv.discount) || 0;
            const extraChargesTotal = (inv.packageExtraCharges ?? []).reduce(
              (sum2, c) => sum2 + (Number(c.extraTotal) || 0),
              0,
            );
            const subtotal = dealAmt - disc + extraChargesTotal;
            const gstAmount =
              inv.gstEnabled && (inv.gstPercent ?? 0) > 0
                ? subtotal * ((inv.gstPercent ?? 0) / 100)
                : 0;
            return sum + subtotal + gstAmount;
          }, 0);
          return {
            clientPaymentLedgers: {
              ...s.clientPaymentLedgers,
              [clientId]: {
                ...ledger,
                totalPaid,
                totalDue,
                runningBalance: Math.max(0, totalDue - totalPaid),
                entries: recalculatedEntries,
              },
            },
          };
        }),

      getClientPaymentSummary: (clientId) => {
        const ledger = get().clientPaymentLedgers[clientId];
        if (!ledger) return { totalPaid: 0, totalDue: 0, pendingBalance: 0 };
        return {
          totalPaid: ledger.totalPaid,
          totalDue: ledger.totalDue,
          pendingBalance: ledger.runningBalance,
        };
      },

      getClientPaymentHistory: (clientId) => {
        const ledger = get().clientPaymentLedgers[clientId];
        return ledger
          ? [...ledger.entries].sort(
              (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
            )
          : [];
      },

      // ── Equipment Rental Actions ──────────────────────────────────────────
      addEquipmentRental: (rental) =>
        set((s) => ({
          rentals: [rental, ...s.rentals],
          expenses: syncRentalToExpenses(s.expenses, "add", rental),
        })),

      getClientRentals: (clientId) =>
        get().rentals.filter((r) => r.clientId === clientId),

      getAllRentals: () => get().rentals,

      // ── Expense Sync ──────────────────────────────────────────────────────
      updateExpenseSync: () =>
        set((s) => {
          const newExpenses: Expense[] = [];
          for (const rental of s.rentals) {
            const exists = s.expenses.some(
              (e) =>
                e.notes?.includes(`rental-id:${rental.id}`) ||
                e.id === `exp-rental-${rental.id}`,
            );
            if (!exists) {
              newExpenses.push({
                id: `exp-rental-${rental.id}`,
                date: rental.startDate,
                vendor: rental.vendor,
                category: `Rental - ${rental.equipmentType}`,
                amount: rental.rentAmount,
                paymentMode: "other",
                notes: `Equipment rental: ${rental.equipmentType} (rental-id:${rental.id})`,
                clientId: rental.clientId,
                invoiceId: rental.invoiceId,
                createdAt: new Date().toISOString(),
              });
            }
          }

          const updatedLedgers: Record<string, ClientPaymentLedger> = {};
          for (const [clientId, ledger] of Object.entries(
            s.clientPaymentLedgers,
          )) {
            const clientInvoices = s.invoices.filter(
              (i) => i.clientId === clientId,
            );
            const totalDue = clientInvoices.reduce((sum, inv) => {
              const dealAmt = Number(inv.dealAmount) || 0;
              const disc = Number(inv.discount) || 0;
              const extraChargesTotal = (inv.packageExtraCharges ?? []).reduce(
                (sum2, c) => sum2 + (Number(c.extraTotal) || 0),
                0,
              );
              const subtotal = dealAmt - disc + extraChargesTotal;
              const gstAmount =
                inv.gstEnabled && (inv.gstPercent ?? 0) > 0
                  ? subtotal * ((inv.gstPercent ?? 0) / 100)
                  : 0;
              return sum + subtotal + gstAmount;
            }, 0);

            const sortedEntries = [...ledger.entries].sort(
              (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
            );
            let runningBalance = 0;
            const recalculatedEntries = sortedEntries.map((e) => {
              runningBalance += e.amount;
              return { ...e, balanceAfterPayment: runningBalance };
            });
            const totalPaid = recalculatedEntries.reduce(
              (sum, e) => sum + e.amount,
              0,
            );

            updatedLedgers[clientId] = {
              ...ledger,
              totalDue,
              totalPaid,
              runningBalance: Math.max(0, totalDue - totalPaid),
              entries: recalculatedEntries,
            };
          }

          return {
            expenses: [...newExpenses, ...s.expenses],
            clientPaymentLedgers: updatedLedgers,
          };
        }),
    }),
    {
      name: "photography-erp-store",
    },
  ),
);
