import { create } from "zustand";
import { persist } from "zustand/middleware";

export type UserRole = "admin" | "team_member" | "staff";

export interface AuthUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

interface AuthState {
  user: AuthUser | null;
  userRole: UserRole | null;
  loading: boolean;
  initialized: boolean;
  error: string | null;
  isAuthenticated: boolean;
  setUser: (user: AuthUser | null) => void;
  setUserRole: (role: UserRole | null) => void;
  setLoading: (loading: boolean) => void;
  setInitialized: (initialized: boolean) => void;
  setError: (error: string | null) => void;
  clearAuth: () => void;
  /** Legacy compat — triggers Firebase signOut via useAuth hook */
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      userRole: null,
      loading: true,
      initialized: false,
      error: null,
      isAuthenticated: false,
      setUser: (user) => set({ user, isAuthenticated: !!user }),
      setUserRole: (userRole) => set({ userRole }),
      setLoading: (loading) => set({ loading }),
      setInitialized: (initialized) => set({ initialized }),
      setError: (error) => set({ error }),
      clearAuth: () =>
        set({
          user: null,
          userRole: null,
          isAuthenticated: false,
          error: null,
          loading: false,
          initialized: true,
        }),
      // Overridden at runtime by useAuth — safe no-op default
      logout: () => {},
    }),
    {
      name: "photo-erp-auth",
      partialize: (state) => ({
        user: state.user,
        userRole: state.userRole,
        isAuthenticated: state.isAuthenticated,
      }),
    },
  ),
);
