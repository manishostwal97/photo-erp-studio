import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { StudioProfile } from "../types";

interface StudioState {
  studioProfile: StudioProfile | null;
  isSetupComplete: boolean;
  isHydrated: boolean;
  setProfile: (profile: StudioProfile | null) => void;
  updateStudioProfile: (updates: Partial<StudioProfile>) => void;
  setHydrated: (value: boolean) => void;
}

const defaultProfile: StudioProfile = {
  name: "Photography Studio",
  ownerName: "",
  phone: "",
  gstEnabled: false,
  gstPercent: 18,
  whatsappTemplates: {
    eventReminder:
      "Hello {clientName},\nReminder for your upcoming event:\nEvent: {eventName}\nProgram: {programName}\nDate: {eventDate}\nVenue: {venue}\nInvoice: {invoiceNumber}\nPending Amount: {balance}\nPlease ensure payment is cleared before the event. Thank you!",
    advanceReminder:
      "Hello {clientName},\n\nThank you for booking with us! \uD83D\uDCF8\n\nThis is a reminder that your advance payment for Invoice #{invoiceNumber} is due.\n\nEvent: {eventName}\nEvent Date: {eventDate}\nVenue: {venue}\nBalance Remaining: {balance}\n\nKindly make the payment at your earliest convenience. Thank you!",
    balanceReminder:
      "Hello {clientName},\n\nYour event memories are ready! \u2728\n\nThis is a friendly reminder that the remaining balance of {balance} for Invoice #{invoiceNumber} is pending.\n\nEvent: {eventName}\nEvent Date: {eventDate}\nAssigned Team: {assignedTeam}\n\nPlease clear the dues so we can proceed with delivery. Thank you!",
    paymentReceived:
      "Hello {clientName},\n\nWe have received your payment! \uD83C\uDF89\n\nInvoice: #{invoiceNumber}\nEvent: {eventName}\nRemaining Balance: {balance}\n\nThank you for your prompt payment!",
    deliveryReady:
      "Hello {clientName},\n\nGreat news! \uD83C\uDF89 Your {eventName} photos/videos are ready for delivery!\n\nInvoice: #{invoiceNumber}\nPlease contact us to arrange delivery of your cherished memories. Thank you for choosing us!",
    finalThankYou:
      "Hello {clientName},\n\nThank you for choosing us for your {eventName}! \uD83D\uDE4F\n\nIt was a pleasure capturing your special moments.\n\nInvoice: #{invoiceNumber}\nEvent Date: {eventDate}\nVenue: {venue}\n\nWe hope to see you again!",
    teamReminder:
      "Hello {teamMemberName},\nYou are assigned for:\nClient: {clientName}\nProgram: {programName}\nDate: {eventDate}\nTime: {eventTime}\nLocation: {venue}\nRole: {assignedTeam}\n\nPlease confirm your availability. Thank you!",
  },
};

export const useStudioStore = create<StudioState>()(
  persist(
    (set, get) => ({
      studioProfile: null,
      isSetupComplete: false,
      isHydrated: false,
      setProfile: (profile) =>
        set({ studioProfile: profile, isSetupComplete: profile !== null }),
      updateStudioProfile: (updates) => {
        const current = get().studioProfile ?? defaultProfile;
        const updated = { ...current, ...updates };
        set({ studioProfile: updated, isSetupComplete: true });
      },
      setHydrated: (value) => set({ isHydrated: value }),
    }),
    {
      name: "photography-studio-profile",
      onRehydrateStorage: () => (state) => {
        if (state) state.setHydrated(true);
      },
    },
  ),
);

export { defaultProfile };
