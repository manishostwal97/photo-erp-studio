import { ErrorBoundary } from "@/components/ErrorBoundary";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import {
  Navigate,
  Outlet,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import { Suspense, lazy } from "react";

// ── Page Loader ──────────────────────────────────────────────────────────────
function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="w-10 h-10 rounded-full border-4 border-primary border-t-transparent animate-spin" />
    </div>
  );
}

// ── Lazy Pages ───────────────────────────────────────────────────────────────
const SplashPage = lazy(() => import("@/pages/SplashPage"));
const LoginPage = lazy(() => import("@/pages/auth/LoginPage"));
const SignupPage = lazy(() => import("@/pages/auth/SignupPage"));
const OTPPage = lazy(() => import("@/pages/auth/OTPPage"));
const ForgotPasswordPage = lazy(
  () => import("@/pages/auth/ForgotPasswordPage"),
);
const UnauthorizedPage = lazy(() => import("@/pages/auth/UnauthorizedPage"));
const DashboardPage = lazy(() => import("@/pages/DashboardPage"));
const InvoicesPage = lazy(() => import("@/pages/InvoicesPage"));
const CreateInvoicePage = lazy(() => import("@/pages/CreateInvoicePage"));
const EditInvoicePage = lazy(() => import("@/pages/EditInvoicePage"));
const InvoiceDetailPage = lazy(() => import("@/pages/InvoiceDetailPage"));
const ClientsPage = lazy(() => import("@/pages/ClientsPage"));
const ClientProfilePage = lazy(() => import("@/pages/ClientProfilePage"));
const DeliveryPage = lazy(() => import("@/pages/DeliveryPage"));
const ReportsPage = lazy(() => import("@/pages/ReportsPage"));
const ExpensesPage = lazy(() => import("@/pages/ExpensesPage"));
const TeamPage = lazy(() => import("@/pages/TeamPage"));
const TeamMemberPage = lazy(() => import("@/pages/TeamMemberPage"));
const ServicesPage = lazy(() => import("@/pages/ServicesPage"));
const SettingsPage = lazy(() => import("@/pages/SettingsPage"));
const SetupPage = lazy(() => import("@/pages/SetupPage"));
const CalendarPage = lazy(() => import("@/pages/CalendarPage"));
const EquipmentRentalPage = lazy(() => import("@/pages/EquipmentRentalPage"));

// ── Root Route ───────────────────────────────────────────────────────────────
const rootRoute = createRootRoute({
  component: () => (
    <ErrorBoundary>
      <Suspense fallback={<PageLoader />}>
        <Outlet />
      </Suspense>
    </ErrorBoundary>
  ),
});

// ── Public Routes ─────────────────────────────────────────────────────────────
const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: () => <Navigate to="/splash" />,
});

const splashRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/splash",
  component: SplashPage,
});

const loginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/login",
  component: LoginPage,
});

const signupRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/signup",
  component: SignupPage,
});

const forgotPasswordRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/forgot-password",
  component: ForgotPasswordPage,
});

const otpLoginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/otp-login",
  component: OTPPage,
});

const unauthorizedRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/unauthorized",
  component: UnauthorizedPage,
});

// ── Protected Layout Route ───────────────────────────────────────────────────
// NOTE: Pages like DashboardPage already import and render AppLayout internally,
// so the protected route only needs to enforce authentication — no AppLayout wrapper.
const protectedLayoutRoute = createRoute({
  getParentRoute: () => rootRoute,
  id: "protected",
  component: () => (
    <ProtectedRoute>
      <Outlet />
    </ProtectedRoute>
  ),
});

// ── Protected Child Routes ────────────────────────────────────────────────────
const dashboardRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/dashboard",
  component: DashboardPage,
});

const invoicesRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/invoices",
  component: InvoicesPage,
});

const createInvoiceRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/invoices/new",
  component: CreateInvoicePage,
});

const invoiceDetailRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/invoices/$invoiceId",
  component: InvoiceDetailPage,
});

const editInvoiceRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/invoices/$invoiceId/edit",
  component: EditInvoicePage,
});

const clientsRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/clients",
  component: ClientsPage,
});

const clientProfileRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/clients/$clientId",
  component: ClientProfilePage,
});

const deliveryRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/delivery",
  component: DeliveryPage,
});

const reportsRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/reports",
  component: ReportsPage,
});

const expensesRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/expenses",
  component: ExpensesPage,
});

const teamRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/team",
  component: TeamPage,
});

const teamMemberRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/team/$memberId",
  component: TeamMemberPage,
});

const servicesRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/services",
  component: ServicesPage,
});

const settingsRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/settings",
  component: SettingsPage,
});

const setupRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/setup",
  component: SetupPage,
});

const calendarRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/calendar",
  component: CalendarPage,
});

const equipmentRentalRoute = createRoute({
  getParentRoute: () => protectedLayoutRoute,
  path: "/equipment-rental",
  component: EquipmentRentalPage,
});

// ── Route Tree ────────────────────────────────────────────────────────────────
const routeTree = rootRoute.addChildren([
  indexRoute,
  splashRoute,
  loginRoute,
  signupRoute,
  forgotPasswordRoute,
  otpLoginRoute,
  unauthorizedRoute,
  protectedLayoutRoute.addChildren([
    dashboardRoute,
    invoicesRoute,
    createInvoiceRoute,
    invoiceDetailRoute,
    editInvoiceRoute,
    clientsRoute,
    clientProfileRoute,
    deliveryRoute,
    reportsRoute,
    expensesRoute,
    teamRoute,
    teamMemberRoute,
    servicesRoute,
    settingsRoute,
    setupRoute,
    calendarRoute,
    equipmentRentalRoute,
  ]),
]);

// ── Router ────────────────────────────────────────────────────────────────────
export const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}
