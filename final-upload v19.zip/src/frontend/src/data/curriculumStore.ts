import type {
  Assessment,
  Assignment,
  Course,
  Lesson,
  Module,
  Unit,
} from "../lib/curriculumTypes";

// ─── Curriculum (client-side in-memory store) ────────────────────────────────

export const curriculumState = {
  courseStore: [] as Course[],
  unitStore: [] as Unit[],
  _lessonStore: [] as Lesson[],
  moduleStore: [] as Module[],
  assignmentStore: [] as Assignment[],
  assessmentStore: [] as Assessment[],
  nextCourseId: 1,
  nextUnitId: 1,
  _nextLessonId: 1,
  nextModuleId: 1,
  nextAssignmentId: 1,
  nextAssessmentId: 1,
  seedInitialized: false,
};

// Convenience aliases for backward compatibility
export function getCourseStore() {
  return curriculumState.courseStore;
}
export function getUnitStore() {
  return curriculumState.unitStore;
}
export function getModuleStore() {
  return curriculumState.moduleStore;
}
export function getAssignmentStore() {
  return curriculumState.assignmentStore;
}
export function getAssessmentStore() {
  return curriculumState.assessmentStore;
}

function daysFromNow(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().split("T")[0];
}

export function initSeedData() {
  if (curriculumState.seedInitialized) return;
  curriculumState.seedInitialized = true;

  // Course: English 10
  const course1: Course = {
    id: curriculumState.nextCourseId++,
    title: "English 10",
    subject: "English",
    gradeBand: "9-12",
    description:
      "A survey of American literature from colonial times to the present, with emphasis on close reading, analytical writing, and standards-based assessment.",
    framework: "ubd",
    frameworkFields: {
      ubd: {
        transferGoals: [
          "Craft arguments with evidence across contexts",
          "Evaluate complex texts independently",
        ],
        enduringUnderstandings: [
          "Literature reflects and shapes cultural identity",
          "Writers make purposeful choices that affect meaning",
        ],
        essentialQuestions: [
          "How does place shape identity?",
          "What makes a text worth reading?",
        ],
        knowledgeSkills: [
          "Close reading",
          "Textual evidence",
          "Argument construction",
          "Rhetorical analysis",
        ],
        performanceTasks: [
          "Argumentative essay on colonial identity",
          "Socratic seminar",
          "Literary analysis portfolio",
        ],
        learningActivities: [
          "Annotation workshops",
          "Collaborative discussions",
          "Writing conferences",
        ],
      },
    },
    standards: ["CCSS.ELA-LITERACY.RL.9-10.1", "CCSS.ELA-LITERACY.W.9-10.1"],
    tags: ["ELA", "American Literature", "Grade 10"],
    draftStatus: "published",
    version: 2,
    versionHistory: [
      {
        version: 1,
        savedAt: Date.now() - 1000 * 60 * 60 * 24 * 30,
        snapshot: "{}",
      },
      {
        version: 2,
        savedAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
        snapshot: "{}",
      },
    ],
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 60,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
  };
  curriculumState.courseStore = [course1];

  // Unit 1: Colonial Literature
  const unit1: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: course1.id,
    title: "Colonial Literature",
    description:
      "Exploring the writings of early American colonists including Puritan authors and Native American oral traditions.",
    essentialQuestion: "How does place shape identity?",
    durationValue: 3,
    durationUnit: "weeks",
    standards: ["CCSS.ELA-LITERACY.RL.9-10.1"],
    tags: ["Colonial", "Puritan", "American Literature"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 50,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 14,
  };

  // Unit 2: Romantic Literature
  const unit2: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: course1.id,
    title: "Romantic Literature",
    description:
      "The American Romantic period, including Transcendentalism and the emergence of the American Dream.",
    essentialQuestion: "What is the American Dream?",
    durationValue: 4,
    durationUnit: "weeks",
    standards: ["CCSS.ELA-LITERACY.RL.9-10.3"],
    tags: ["Romanticism", "Transcendentalism"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 45,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 10,
  };
  curriculumState.unitStore = [unit1, unit2];

  // Module 1: Puritan Literature
  const mod1: Module = {
    id: curriculumState.nextModuleId++,
    unitId: unit1.id,
    courseId: course1.id,
    title: "Puritan Literature",
    description: "Reading and analyzing key texts from Puritan New England.",
    learningObjectives: [
      "Analyze Puritan themes of covenant and providence",
      "Close read Bradford's 'Of Plymouth Plantation'",
      "Identify rhetorical devices in colonial texts",
    ],
    vocabulary: [
      "providence",
      "covenant",
      "typology",
      "jeremiad",
      "predestination",
    ],
    standards: ["CCSS.ELA-LITERACY.RL.9-10.1", "CCSS.ELA-LITERACY.RL.9-10.4"],
    tags: ["Puritan", "Bradford", "Close Reading"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 45,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
  };

  // Module 2: Native American Voices
  const mod2: Module = {
    id: curriculumState.nextModuleId++,
    unitId: unit1.id,
    courseId: course1.id,
    title: "Native American Voices",
    description: "Examining oral traditions and written narratives.",
    learningObjectives: [
      "Identify elements of oral tradition",
      "Compare narrative perspectives across cultures",
    ],
    vocabulary: ["oral tradition", "myth", "trickster figure", "narrative"],
    standards: ["CCSS.ELA-LITERACY.RL.9-10.6"],
    tags: ["Native American", "Oral Tradition"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 40,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 5,
  };

  // Module 3: Transcendentalism
  const mod3: Module = {
    id: curriculumState.nextModuleId++,
    unitId: unit2.id,
    courseId: course1.id,
    title: "Transcendentalism",
    description:
      "Emerson, Thoreau, and the philosophy of self-reliance and nature.",
    learningObjectives: [
      "Define transcendentalist ideals",
      "Analyze 'Self-Reliance' and 'Walden' excerpts",
      "Connect transcendentalism to modern individualism",
    ],
    vocabulary: ["self-reliance", "oversoul", "civil disobedience", "nature"],
    standards: ["CCSS.ELA-LITERACY.RL.9-10.2", "CCSS.ELA-LITERACY.W.9-10.1"],
    tags: ["Emerson", "Thoreau", "Transcendentalism"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 35,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
  };
  curriculumState.moduleStore = [mod1, mod2, mod3];
  curriculumState._lessonStore = curriculumState.moduleStore;

  // Assignment 1: Bradford Essay
  const assign1: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: mod1.id,
    courseId: course1.id,
    title: "Bradford Essay",
    description: "Argumentative essay analyzing colonial identity in Bradford.",
    instructions:
      "Write a 4-5 paragraph essay analyzing how William Bradford uses narrative perspective to construct colonial identity. Use at least three specific textual examples and address the question: How does Bradford's Puritan worldview shape his account of events?",
    points: 100,
    assignmentType: "writing",
    dueDate: daysFromNow(14),
    standards: ["CCSS.ELA-LITERACY.W.9-10.1", "CCSS.ELA-LITERACY.RL.9-10.1"],
    tags: ["Essay", "Bradford", "Argumentative"],
    rubric: {
      levels: [
        { name: "Exemplary", points: 4 },
        { name: "Proficient", points: 3 },
        { name: "Developing", points: 2 },
        { name: "Beginning", points: 1 },
      ],
      criteria: [
        {
          id: "thesis",
          name: "Thesis",
          descriptions: {
            Exemplary:
              "Clear, arguable thesis that responds precisely to the prompt.",
            Proficient: "Clear thesis present but may be overly broad.",
            Developing: "Thesis is vague or does not address the prompt fully.",
            Beginning: "No discernible thesis.",
          },
        },
        {
          id: "evidence",
          name: "Evidence",
          descriptions: {
            Exemplary:
              "Three or more well-chosen quotes with insightful analysis.",
            Proficient: "Two or more quotes, analysis present but uneven.",
            Developing: "Quotes present but analysis is minimal.",
            Beginning: "No textual evidence or misquoted.",
          },
        },
      ],
    },
    frameworkFields: {},
    lessonId: mod1.id,
    pointsPossible: 100,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 20,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  };

  // Assignment 2: Reading Response
  const assign2: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: mod2.id,
    courseId: course1.id,
    title: "Reading Response",
    description: "Short formative response to assigned readings.",
    instructions:
      "In 150-200 words, respond to the following: What elements of oral tradition do you notice in the text, and how do they affect your reading experience?",
    points: 20,
    assignmentType: "formative",
    dueDate: daysFromNow(7),
    standards: ["CCSS.ELA-LITERACY.RL.9-10.6"],
    tags: ["Formative", "Reading Response"],
    rubric: null,
    frameworkFields: {},
    lessonId: mod2.id,
    pointsPossible: 20,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 15,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
  };

  // Assignment 3: Nature Journal
  const assign3: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: mod3.id,
    courseId: course1.id,
    title: "Nature Journal",
    description:
      "Two-week nature journal inspired by Thoreau's Walden practice.",
    instructions:
      "Over the next two weeks, keep a nature journal with at least 5 entries. Each entry should include observation, reflection, and connection to a transcendentalist idea from our readings. Final journal submitted with a 1-page reflection essay.",
    points: 75,
    assignmentType: "project",
    dueDate: daysFromNow(21),
    standards: ["CCSS.ELA-LITERACY.W.9-10.3"],
    tags: ["Thoreau", "Project", "Nature"],
    rubric: null,
    frameworkFields: {},
    lessonId: mod3.id,
    pointsPossible: 75,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 12,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
  };

  // Assignment 4: Weekly Reading
  const assign4: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: mod3.id,
    courseId: course1.id,
    title: "Weekly Reading",
    description: "Assigned reading for the week.",
    instructions:
      "Complete assigned Emerson and Thoreau readings. Annotate for key transcendentalist ideas.",
    points: 10,
    assignmentType: "homework",
    dueDate: daysFromNow(5),
    standards: ["CCSS.ELA-LITERACY.RL.9-10.1"],
    tags: ["Homework", "Reading"],
    rubric: null,
    frameworkFields: {},
    lessonId: mod3.id,
    pointsPossible: 10,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 8,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
  };
  curriculumState.assignmentStore = [assign1, assign2, assign3, assign4];

  // Assessment 1: Colonial Unit Quiz
  const assess1: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: mod1.id,
    courseId: course1.id,
    title: "Colonial Unit Quiz",
    description: "Short quiz covering Puritan literature and key terms.",
    assessmentType: "Quiz",
    items: [
      "Identify the author of 'Of Plymouth Plantation'",
      "Define 'covenant theology' and explain its significance",
      "Analyze a short passage for rhetorical devices",
      "Explain the Puritan concept of providence with an example",
      "Short answer: How did Puritan beliefs shape colonial writing?",
    ],
    scoringModel: "points",
    totalPoints: 50,
    difficulty: "medium",
    dueDate: daysFromNow(10),
    standards: ["CCSS.ELA-LITERACY.RL.9-10.1", "CCSS.ELA-LITERACY.RL.9-10.4"],
    tags: ["Quiz", "Colonial", "Formative"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 18,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  };

  // Assessment 2: Unit 2 Exam
  const assess2: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: mod3.id,
    courseId: course1.id,
    title: "Unit 2 Exam",
    description: "Comprehensive end-of-unit exam on Romantic Literature.",
    assessmentType: "Exam",
    items: [
      "Multiple choice: Transcendentalist key concepts (20 items)",
      "Short answer: Compare Emerson and Thoreau (2 questions)",
      "Essay: Analyze how transcendentalist ideals challenge social norms",
    ],
    scoringModel: "rubric",
    totalPoints: 100,
    difficulty: "hard",
    dueDate: daysFromNow(35),
    standards: [
      "CCSS.ELA-LITERACY.RL.9-10.2",
      "CCSS.ELA-LITERACY.W.9-10.1",
      "CCSS.ELA-LITERACY.RL.9-10.3",
    ],
    tags: ["Exam", "Summative", "Romanticism"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 10,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
  };
  curriculumState.assessmentStore = [assess1, assess2];

  // ── Additional units, modules, assignments, and assessments ─────────────

  // Unit 3: Identity & Coming of Age
  const unit3: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: course1.id,
    title: "Identity & Coming of Age",
    description:
      "Exploring how authors use narrative to examine the formation of identity through adolescence and cultural experience.",
    essentialQuestion: "How do our experiences shape who we become?",
    durationValue: 4,
    durationUnit: "weeks",
    standards: ["CCSS.ELA-LITERACY.RL.9-10.3", "CCSS.ELA-LITERACY.W.9-10.3"],
    tags: ["Identity", "Coming of Age", "Narrative"],
    frameworkFields: {},
    order: 3,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 30,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 5,
  };

  // Unit 4: Power & Resistance
  const unit4: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: course1.id,
    title: "Power & Resistance",
    description:
      "Analyzing texts that examine power structures and how individuals and communities resist oppression.",
    essentialQuestion: "What does it mean to resist?",
    durationValue: 3,
    durationUnit: "weeks",
    standards: ["CCSS.ELA-LITERACY.RL.9-10.6", "CCSS.ELA-LITERACY.W.9-10.1"],
    tags: ["Power", "Resistance", "Social Justice"],
    frameworkFields: {},
    order: 4,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 20,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
  };

  curriculumState.unitStore.push(unit3, unit4);

  // Modules for Unit 3
  const mod4: Module = {
    id: curriculumState.nextModuleId++,
    unitId: unit3.id,
    courseId: course1.id,
    title: "The Outsider Narrative",
    description:
      "Texts featuring protagonists who feel alienated from society.",
    learningObjectives: [
      "Identify characteristics of the outsider archetype",
      "Analyze how setting reinforces themes of alienation",
      "Compare narrative voice across two texts",
    ],
    vocabulary: ["alienation", "archetype", "unreliable narrator", "motif"],
    standards: ["CCSS.ELA-LITERACY.RL.9-10.3"],
    tags: ["Outsider", "Archetype", "Narrative Voice"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 28,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 4,
  };

  const mod5: Module = {
    id: curriculumState.nextModuleId++,
    unitId: unit3.id,
    courseId: course1.id,
    title: "Cultural Identity & Language",
    description:
      "How language shapes and reflects cultural identity in literary texts.",
    learningObjectives: [
      "Analyze code-switching as a literary device",
      "Evaluate how authors use dialect to convey character",
      "Write a personal narrative exploring cultural identity",
    ],
    vocabulary: ["dialect", "code-switching", "bilingualism", "vernacular"],
    standards: ["CCSS.ELA-LITERACY.RL.9-10.4", "CCSS.ELA-LITERACY.W.9-10.3"],
    tags: ["Culture", "Language", "Identity"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 25,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
  };

  const mod6: Module = {
    id: curriculumState.nextModuleId++,
    unitId: unit3.id,
    courseId: course1.id,
    title: "Rites of Passage",
    description: "Examining coming-of-age rituals and transformative moments.",
    learningObjectives: [
      "Define rite of passage in literary and cultural contexts",
      "Trace a protagonist's transformation across a narrative arc",
      "Compose a reflective essay on personal growth",
    ],
    vocabulary: ["bildungsroman", "epiphany", "initiation", "transformation"],
    standards: ["CCSS.ELA-LITERACY.RL.9-10.2", "CCSS.ELA-LITERACY.W.9-10.3"],
    tags: ["Bildungsroman", "Coming of Age", "Reflection"],
    frameworkFields: {},
    order: 3,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 22,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  };

  // Modules for Unit 4
  const mod7: Module = {
    id: curriculumState.nextModuleId++,
    unitId: unit4.id,
    courseId: course1.id,
    title: "Voices of Protest",
    description:
      "Reading protest literature from the civil rights era and beyond.",
    learningObjectives: [
      "Analyze rhetorical strategies in protest speeches",
      "Evaluate the effectiveness of King's 'Letter from Birmingham Jail'",
      "Craft a persuasive letter addressing a contemporary issue",
    ],
    vocabulary: ["rhetoric", "pathos", "ethos", "logos", "anaphora"],
    standards: ["CCSS.ELA-LITERACY.RI.9-10.6", "CCSS.ELA-LITERACY.W.9-10.1"],
    tags: ["Civil Rights", "Rhetoric", "Protest"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 18,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  };

  const mod8: Module = {
    id: curriculumState.nextModuleId++,
    unitId: unit4.id,
    courseId: course1.id,
    title: "Dystopia & Social Critique",
    description:
      "How dystopian fiction serves as a vehicle for social and political commentary.",
    learningObjectives: [
      "Identify dystopian conventions in fiction",
      "Analyze how authors critique real-world power structures",
      "Write a short dystopian narrative",
    ],
    vocabulary: ["dystopia", "utopia", "allegory", "totalitarianism", "satire"],
    standards: ["CCSS.ELA-LITERACY.RL.9-10.6", "CCSS.ELA-LITERACY.W.9-10.3"],
    tags: ["Dystopia", "Social Critique", "Allegory"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 15,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
  };

  curriculumState.moduleStore.push(mod4, mod5, mod6, mod7, mod8);
  curriculumState._lessonStore = curriculumState.moduleStore;

  // Assignments for new modules
  const assign5: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: mod4.id,
    courseId: course1.id,
    title: "Outsider Character Analysis",
    description:
      "Analytical essay examining the outsider protagonist in an assigned novel.",
    instructions:
      "In a 4-5 paragraph essay, analyze how the author develops the outsider protagonist. Discuss at least two literary devices used to convey alienation. Support all claims with textual evidence.",
    points: 100,
    assignmentType: "writing",
    dueDate: daysFromNow(-5),
    standards: ["CCSS.ELA-LITERACY.RL.9-10.3"],
    tags: ["Essay", "Character Analysis"],
    rubric: null,
    frameworkFields: {},
    lessonId: mod4.id,
    pointsPossible: 100,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 26,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
  };

  const assign6: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: mod5.id,
    courseId: course1.id,
    title: "Personal Narrative: Cultural Identity",
    description:
      "Students write a personal narrative exploring a moment of cultural identity.",
    instructions:
      "Write a 2-3 page personal narrative about a time when your cultural identity played a significant role in an experience. Incorporate specific sensory details and reflection on what the experience taught you about yourself.",
    points: 80,
    assignmentType: "writing",
    dueDate: daysFromNow(3),
    standards: ["CCSS.ELA-LITERACY.W.9-10.3"],
    tags: ["Personal Narrative", "Culture"],
    rubric: null,
    frameworkFields: {},
    lessonId: mod5.id,
    pointsPossible: 80,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 20,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  };

  const assign7: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: mod6.id,
    courseId: course1.id,
    title: "Coming-of-Age Reflection Essay",
    description:
      "Reflective essay connecting a rite of passage in the text to a personal experience.",
    instructions:
      "Identify a key rite-of-passage moment in the novel and write a 3-4 paragraph reflective essay. In the first half, analyze the character's transformation. In the second half, connect this transformation to your own experience of growth.",
    points: 75,
    assignmentType: "writing",
    dueDate: daysFromNow(12),
    standards: ["CCSS.ELA-LITERACY.RL.9-10.2", "CCSS.ELA-LITERACY.W.9-10.3"],
    tags: ["Reflection", "Coming of Age"],
    rubric: null,
    frameworkFields: {},
    lessonId: mod6.id,
    pointsPossible: 75,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 18,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
  };

  const assign8: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: mod7.id,
    courseId: course1.id,
    title: "Persuasive Letter",
    description:
      "Students craft a persuasive letter modeled on King's 'Letter from Birmingham Jail'.",
    instructions:
      "Choose a contemporary injustice or issue you care about. Write a persuasive letter of 2-3 pages addressed to a specific audience. Incorporate at least two of the three rhetorical appeals (ethos, pathos, logos). Include evidence and a call to action.",
    points: 100,
    assignmentType: "writing",
    dueDate: daysFromNow(18),
    standards: ["CCSS.ELA-LITERACY.RI.9-10.6", "CCSS.ELA-LITERACY.W.9-10.1"],
    tags: ["Persuasion", "Rhetoric", "Letter"],
    rubric: null,
    frameworkFields: {},
    lessonId: mod7.id,
    pointsPossible: 100,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 14,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
  };

  const assign9: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: mod8.id,
    courseId: course1.id,
    title: "Dystopian Short Story",
    description:
      "Students write an original short dystopian story that critiques a real-world power structure.",
    instructions:
      "Write a 2-3 page original dystopian short story. Your story must include at least one dystopian convention (surveillance, oppressive government, controlled information), a protagonist who challenges the system, and an implicit critique of a real-world issue. Include a brief author's note explaining your social commentary.",
    points: 90,
    assignmentType: "project",
    dueDate: daysFromNow(25),
    standards: ["CCSS.ELA-LITERACY.W.9-10.3", "CCSS.ELA-LITERACY.RL.9-10.6"],
    tags: ["Creative Writing", "Dystopia", "Project"],
    rubric: null,
    frameworkFields: {},
    lessonId: mod8.id,
    pointsPossible: 90,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 10,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
  };

  curriculumState.assignmentStore.push(
    assign5,
    assign6,
    assign7,
    assign8,
    assign9,
  );

  // Assessments for new modules
  const assess3: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: mod3.id,
    courseId: course1.id,
    title: "Identity Unit Exam",
    description:
      "End-of-unit exam covering themes of identity, cultural language, and coming of age.",
    assessmentType: "Exam",
    items: [
      "Multiple choice: Literary terms and devices (15 items)",
      "Short answer: Explain how dialect functions in a given passage (2 questions)",
      "Extended response: How does the protagonist's cultural identity shape the narrative?",
    ],
    scoringModel: "rubric",
    totalPoints: 100,
    difficulty: "medium",
    dueDate: daysFromNow(20),
    standards: ["CCSS.ELA-LITERACY.RL.9-10.3", "CCSS.ELA-LITERACY.RL.9-10.4"],
    tags: ["Exam", "Identity", "Summative"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 8,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
  };

  const assess4: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: mod7.id,
    courseId: course1.id,
    title: "Rhetoric & Resistance Quiz",
    description:
      "Short assessment on rhetorical devices and protest literature.",
    assessmentType: "Quiz",
    items: [
      "Identify the rhetorical appeal in each excerpt (ethos, pathos, logos)",
      "Explain how King uses anaphora in the Letter from Birmingham Jail",
      "Short response: What makes protest writing effective?",
    ],
    scoringModel: "points",
    totalPoints: 40,
    difficulty: "medium",
    dueDate: daysFromNow(8),
    standards: ["CCSS.ELA-LITERACY.RI.9-10.6"],
    tags: ["Quiz", "Rhetoric", "Formative"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 6,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 1,
  };

  curriculumState.assessmentStore.push(assess3, assess4);

  // ── 3 Additional Courses: US History 11, AP Biology, Algebra II ─────────
  // Skip IDs 2 and 3 which are used by Math 10 / Biology 11 in the gradebook
  curriculumState.nextCourseId = 4;

  // ──────────────────────────────────────────────────────────────────────────
  // Course 2: US History 11 — UbD Framework
  // ──────────────────────────────────────────────────────────────────────────
  const courseHist: Course = {
    id: curriculumState.nextCourseId++,
    title: "US History 11",
    subject: "History",
    gradeBand: "9-12",
    description:
      "A chronological survey of United States history from colonial settlement through Reconstruction, emphasizing primary source analysis, causation, and civic literacy.",
    framework: "ubd",
    frameworkFields: {
      ubd: {
        transferGoals: [
          "Analyze how historical events shape present-day society",
          "Evaluate primary sources for perspective, bias, and reliability",
        ],
        enduringUnderstandings: [
          "Competing visions of liberty and equality have defined American history",
          "Historical events have multiple causes and far-reaching consequences",
        ],
        essentialQuestions: [
          "Whose voices shape our understanding of history?",
          "How have Americans defined freedom differently over time?",
        ],
        knowledgeSkills: [
          "Primary source analysis",
          "Causation and continuity",
          "Historical argumentation",
          "Contextualizing events",
        ],
        performanceTasks: [
          "Document-based question essay",
          "Socratic seminar on constitutional debates",
          "Civil War cause-and-effect poster",
        ],
        learningActivities: [
          "Primary source close reads",
          "Timeline construction",
          "Structured academic controversy",
        ],
      },
    },
    standards: ["NCSS-1", "CCSS.ELA-LITERACY.RH.11-12.1"],
    tags: ["US History", "Grade 11", "Social Studies"],
    draftStatus: "published",
    version: 1,
    versionHistory: [],
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 90,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 5,
  };
  curriculumState.courseStore = [...curriculumState.courseStore, courseHist];

  // Units for US History 11
  const histUnit1: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: courseHist.id,
    title: "Colonial America",
    description:
      "Examining the founding and development of the American colonies, including European colonization, conflict with Native peoples, and the emergence of colonial identity.",
    essentialQuestion:
      "Why did people come to the Americas, and what did they find?",
    durationValue: 4,
    durationUnit: "weeks",
    standards: ["NCSS-1", "NCSS-2"],
    tags: ["Colonial", "Settlement", "Native Americans"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 88,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 20,
  };

  const histUnit2: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: courseHist.id,
    title: "Revolution & Constitution",
    description:
      "The causes and course of the American Revolution, the founding documents, and the debates over ratification.",
    essentialQuestion:
      "What ideals shaped the American republic, and whose ideals were left out?",
    durationValue: 5,
    durationUnit: "weeks",
    standards: ["NCSS-2", "CCSS.ELA-LITERACY.RH.11-12.1"],
    tags: ["Revolution", "Constitution", "Founding Era"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 70,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 14,
  };

  const histUnit3: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: courseHist.id,
    title: "Civil War & Reconstruction",
    description:
      "The sectional crisis, causes of the Civil War, the war itself, and the successes and failures of Reconstruction.",
    essentialQuestion: "What does it mean to rebuild a nation after war?",
    durationValue: 5,
    durationUnit: "weeks",
    standards: ["NCSS-2", "NCSS-4"],
    tags: ["Civil War", "Slavery", "Reconstruction"],
    frameworkFields: {},
    order: 3,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 50,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
  };
  curriculumState.unitStore.push(histUnit1, histUnit2, histUnit3);

  // Modules — Colonial America
  const histMod1: Module = {
    id: curriculumState.nextModuleId++,
    unitId: histUnit1.id,
    courseId: courseHist.id,
    title: "European Colonization",
    description:
      "Motives, methods, and consequences of Spanish, French, and English colonization.",
    learningObjectives: [
      "Compare the colonial strategies of Spain, France, and England",
      "Analyze the Columbian Exchange and its global impact",
      "Evaluate primary accounts of first contact",
    ],
    vocabulary: [
      "colonization",
      "mercantilism",
      "encomienda",
      "Columbian Exchange",
      "joint-stock company",
    ],
    standards: ["NCSS-1"],
    tags: ["Colonization", "Spain", "England", "France"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 85,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 18,
  };

  const histMod2: Module = {
    id: curriculumState.nextModuleId++,
    unitId: histUnit1.id,
    courseId: courseHist.id,
    title: "Colonial Society & Conflict",
    description:
      "Daily life in colonial America, social hierarchies, and conflicts between settlers and Native peoples.",
    learningObjectives: [
      "Describe the social structure of colonial New England vs. the South",
      "Analyze Bacon's Rebellion as a social and political turning point",
      "Evaluate competing perspectives on colonial expansion",
    ],
    vocabulary: [
      "indentured servitude",
      "headright system",
      "Bacon's Rebellion",
      "Great Awakening",
    ],
    standards: ["NCSS-2"],
    tags: ["Colonial Society", "Conflict", "Slavery"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 80,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 16,
  };

  // Modules — Revolution & Constitution
  const histMod3: Module = {
    id: curriculumState.nextModuleId++,
    unitId: histUnit2.id,
    courseId: courseHist.id,
    title: "Road to Revolution",
    description:
      "The political and economic causes of the American Revolution.",
    learningObjectives: [
      "Trace the escalating tensions from 1763 to 1775",
      "Analyze the arguments of Patriots and Loyalists",
      "Evaluate the significance of the Declaration of Independence",
    ],
    vocabulary: [
      "taxation without representation",
      "Stamp Act",
      "Continental Congress",
      "Loyalist",
      "Patriot",
    ],
    standards: ["NCSS-2", "CCSS.ELA-LITERACY.RH.11-12.6"],
    tags: ["Revolution", "Taxes", "Declaration"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 68,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 12,
  };

  const histMod4: Module = {
    id: curriculumState.nextModuleId++,
    unitId: histUnit2.id,
    courseId: courseHist.id,
    title: "Creating a Government",
    description:
      "The Articles of Confederation, Constitutional Convention, and the debate over ratification.",
    learningObjectives: [
      "Compare the Articles of Confederation to the Constitution",
      "Analyze the Federalist Papers as arguments for ratification",
      "Explain the Bill of Rights and its purpose",
    ],
    vocabulary: [
      "federalism",
      "checks and balances",
      "separation of powers",
      "Federalist",
      "Anti-Federalist",
    ],
    standards: ["NCSS-6", "CCSS.ELA-LITERACY.RH.11-12.1"],
    tags: ["Constitution", "Federalism", "Bill of Rights"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 62,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 10,
  };

  // Modules — Civil War & Reconstruction
  const histMod5: Module = {
    id: curriculumState.nextModuleId++,
    unitId: histUnit3.id,
    courseId: courseHist.id,
    title: "Causes of the Civil War",
    description:
      "Examining the long- and short-term causes of the Civil War, including slavery, sectionalism, and political crisis.",
    learningObjectives: [
      "Identify economic, political, and social causes of the Civil War",
      "Analyze the role of slavery in the sectional conflict",
      "Evaluate the significance of the election of 1860",
    ],
    vocabulary: [
      "sectionalism",
      "states' rights",
      "abolitionism",
      "secession",
      "Confederate States",
    ],
    standards: ["NCSS-4"],
    tags: ["Civil War Causes", "Slavery", "Sectionalism"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 48,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 6,
  };

  const histMod6: Module = {
    id: curriculumState.nextModuleId++,
    unitId: histUnit3.id,
    courseId: courseHist.id,
    title: "Reconstruction & Its Legacy",
    description:
      "The promises and failures of Reconstruction, and its long-term impact on race and politics in America.",
    learningObjectives: [
      "Explain the key Reconstruction Amendments and their significance",
      "Analyze why Reconstruction failed to deliver lasting equality",
      "Evaluate competing interpretations of Reconstruction",
    ],
    vocabulary: [
      "Freedmen's Bureau",
      "Black Codes",
      "Radical Reconstruction",
      "sharecropping",
      "Jim Crow",
    ],
    standards: ["NCSS-4", "CCSS.ELA-LITERACY.RH.11-12.1"],
    tags: ["Reconstruction", "Civil Rights", "Amendments"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 43,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 4,
  };

  curriculumState.moduleStore.push(
    histMod1,
    histMod2,
    histMod3,
    histMod4,
    histMod5,
    histMod6,
  );
  curriculumState._lessonStore = curriculumState.moduleStore;

  // Assignments — US History 11
  const histAssign1: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: histMod1.id,
    courseId: courseHist.id,
    title: "Columbian Exchange Graphic Organizer",
    description:
      "Students map the biological and cultural exchanges resulting from European contact.",
    instructions:
      "Using your notes and the provided readings, complete a graphic organizer identifying at least 5 items exchanged in each direction (Europe to Americas, Americas to Europe) and explain two significant consequences.",
    points: 25,
    assignmentType: "homework",
    dueDate: daysFromNow(-60),
    standards: ["NCSS-1"],
    tags: ["Columbian Exchange", "Graphic Organizer"],
    rubric: null,
    frameworkFields: {},
    lessonId: histMod1.id,
    pointsPossible: 25,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 84,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 17,
  };

  const histAssign2: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: histMod1.id,
    courseId: courseHist.id,
    title: "Primary Source Analysis: Columbus Journal",
    description:
      "Close reading of Columbus's 1492 journal entry describing first contact.",
    instructions:
      "Read the provided excerpt from Columbus's journal. Answer the analysis questions: (1) What is Columbus's purpose for writing? (2) How does he describe the Taíno people, and what assumptions are revealed? (3) What evidence of bias can you identify? Write 2-3 paragraphs.",
    points: 40,
    assignmentType: "writing",
    dueDate: daysFromNow(-54),
    standards: ["CCSS.ELA-LITERACY.RH.11-12.6"],
    tags: ["Primary Source", "Columbus", "Analysis"],
    rubric: null,
    frameworkFields: {},
    lessonId: histMod1.id,
    pointsPossible: 40,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 82,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 15,
  };

  const histAssign3: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: histMod1.id,
    courseId: courseHist.id,
    title: "Colonial Powers Comparison Chart",
    description: "Compare colonial strategies of Spain, France, and England.",
    instructions:
      "Complete the three-column comparison chart for Spanish, French, and English colonial strategies. Include: primary motivation, relationship with Native peoples, economic model, and one lasting consequence. Be specific and use evidence from class readings.",
    points: 30,
    assignmentType: "homework",
    dueDate: daysFromNow(-50),
    standards: ["NCSS-1"],
    tags: ["Comparison", "Colonization"],
    rubric: null,
    frameworkFields: {},
    lessonId: histMod1.id,
    pointsPossible: 30,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 80,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 13,
  };

  const histAssign4: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: histMod2.id,
    courseId: courseHist.id,
    title: "Colonial Society DBQ Essay",
    description:
      "Document-based question essay on the development of slavery in colonial Virginia.",
    instructions:
      "Using the 5 documents provided, write a well-organized essay that explains how and why slavery became entrenched in colonial Virginia by 1700. Your essay must use evidence from at least 4 documents, have a clear thesis, and demonstrate historical reasoning.",
    points: 100,
    assignmentType: "essay",
    dueDate: daysFromNow(-44),
    standards: ["CCSS.ELA-LITERACY.WHST.11-12.1"],
    tags: ["DBQ", "Slavery", "Essay"],
    rubric: null,
    frameworkFields: {},
    lessonId: histMod2.id,
    pointsPossible: 100,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 76,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 11,
  };

  const histAssign5: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: histMod3.id,
    courseId: courseHist.id,
    title: "Declaration of Independence Close Read",
    description:
      "Annotated close reading of key passages from the Declaration of Independence.",
    instructions:
      "Annotate the assigned passages from the Declaration of Independence (paragraphs 1-3 and 5 grievances of your choice). For each section, identify: main claim, rhetorical appeal used (ethos/pathos/logos), and one question the passage raises.",
    points: 35,
    assignmentType: "homework",
    dueDate: daysFromNow(-35),
    standards: ["CCSS.ELA-LITERACY.RH.11-12.1"],
    tags: ["Declaration", "Close Reading", "Rhetoric"],
    rubric: null,
    frameworkFields: {},
    lessonId: histMod3.id,
    pointsPossible: 35,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 65,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 9,
  };

  const histAssign6: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: histMod3.id,
    courseId: courseHist.id,
    title: "Loyalist vs. Patriot Debate Prep",
    description:
      "Students prepare arguments for a structured debate on whether to support the Revolution.",
    instructions:
      "You have been assigned either the Loyalist or Patriot position. Prepare three strong arguments supporting your position, each backed by at least one piece of historical evidence. Be prepared to respond to counterarguments.",
    points: 50,
    assignmentType: "project",
    dueDate: daysFromNow(-28),
    standards: ["NCSS-2"],
    tags: ["Debate", "Revolution", "Argument"],
    rubric: null,
    frameworkFields: {},
    lessonId: histMod3.id,
    pointsPossible: 50,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 60,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 8,
  };

  const histAssign7: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: histMod4.id,
    courseId: courseHist.id,
    title: "Federalist No. 51 Analysis",
    description: "Analysis of Madison's argument for separation of powers.",
    instructions:
      "Read Federalist No. 51 and answer: (1) What problem is Madison trying to solve? (2) What solution does he propose? (3) Why does he believe human nature makes this structure necessary? Write a 3-paragraph analytical response.",
    points: 45,
    assignmentType: "writing",
    dueDate: daysFromNow(-18),
    standards: ["CCSS.ELA-LITERACY.RH.11-12.8"],
    tags: ["Federalist Papers", "Constitution", "Analysis"],
    rubric: null,
    frameworkFields: {},
    lessonId: histMod4.id,
    pointsPossible: 45,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 55,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
  };

  const histAssign8: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: histMod5.id,
    courseId: courseHist.id,
    title: "Causes of the Civil War Research Notes",
    description:
      "Research and organize evidence for the causes of the Civil War.",
    instructions:
      "Using your textbook and at least one primary source, create organized research notes identifying the major causes of the Civil War. Group causes into: economic, political, social/cultural. Include specific evidence for each cause.",
    points: 30,
    assignmentType: "homework",
    dueDate: daysFromNow(5),
    standards: ["NCSS-4"],
    tags: ["Civil War", "Research", "Notes"],
    rubric: null,
    frameworkFields: {},
    lessonId: histMod5.id,
    pointsPossible: 30,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 45,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 5,
  };

  const histAssign9: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: histMod5.id,
    courseId: courseHist.id,
    title: "Emancipation Proclamation Analysis",
    description:
      "Historical context and impact analysis of the Emancipation Proclamation.",
    instructions:
      "Read the Emancipation Proclamation and Lincoln's draft versions. Write a 4-paragraph essay addressing: What did the Proclamation actually do? What were Lincoln's political motivations? How did freedpeople and abolitionists respond? What were its limitations?",
    points: 80,
    assignmentType: "essay",
    dueDate: daysFromNow(12),
    standards: ["CCSS.ELA-LITERACY.RH.11-12.1"],
    tags: ["Emancipation", "Lincoln", "Essay"],
    rubric: null,
    frameworkFields: {},
    lessonId: histMod5.id,
    pointsPossible: 80,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 42,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
  };

  const histAssign10: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: histMod6.id,
    courseId: courseHist.id,
    title: "Reconstruction Amendments Explainer",
    description:
      "Students create a visual explainer of the 13th, 14th, and 15th Amendments.",
    instructions:
      "Create a one-page visual explainer (poster, infographic, or illustrated notes) covering the 13th, 14th, and 15th Amendments. For each: state what it does in plain language, explain why it was needed, and identify one way it has been applied or challenged since ratification.",
    points: 40,
    assignmentType: "project",
    dueDate: daysFromNow(20),
    standards: ["NCSS-4"],
    tags: ["Reconstruction", "Amendments", "Visual"],
    rubric: null,
    frameworkFields: {},
    lessonId: histMod6.id,
    pointsPossible: 40,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 38,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  };

  curriculumState.assignmentStore.push(
    histAssign1,
    histAssign2,
    histAssign3,
    histAssign4,
    histAssign5,
    histAssign6,
    histAssign7,
    histAssign8,
    histAssign9,
    histAssign10,
  );

  // Assessments — US History 11
  const histAssess1: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: histMod1.id,
    courseId: courseHist.id,
    title: "Colonial Era Unit Quiz",
    description:
      "Quiz covering European colonization and the Columbian Exchange.",
    assessmentType: "quiz",
    items: ["Multiple choice", "Short answer", "Map identification"],
    scoringModel: "points",
    totalPoints: 50,
    difficulty: "medium",
    dueDate: daysFromNow(-57),
    standards: ["NCSS-1"],
    tags: ["Colonial", "Quiz"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 83,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 16,
  };

  const histAssess2: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: histMod2.id,
    courseId: courseHist.id,
    title: "Colonial Society Unit Test",
    description: "Unit test covering colonial society, slavery, and conflicts.",
    assessmentType: "test",
    items: ["Multiple choice", "Short answer", "Essay"],
    scoringModel: "points",
    totalPoints: 100,
    difficulty: "medium",
    dueDate: daysFromNow(-47),
    standards: ["NCSS-2"],
    tags: ["Colonial Society", "Unit Test"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 75,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 12,
  };

  const histAssess3: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: histMod3.id,
    courseId: courseHist.id,
    title: "Revolution & Causes Assessment",
    description:
      "Assessment covering the causes and course of the American Revolution.",
    assessmentType: "test",
    items: ["Multiple choice", "Primary source analysis", "Short essay"],
    scoringModel: "points",
    totalPoints: 100,
    difficulty: "hard",
    dueDate: daysFromNow(-22),
    standards: ["NCSS-2"],
    tags: ["Revolution", "Assessment"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 58,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 8,
  };

  const histAssess4: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: histMod5.id,
    courseId: courseHist.id,
    title: "Civil War Causes DBQ Assessment",
    description: "Document-based question assessment on Civil War causation.",
    assessmentType: "essay",
    items: ["Document analysis", "Thesis construction", "Corroboration"],
    scoringModel: "rubric",
    totalPoints: 100,
    difficulty: "hard",
    dueDate: daysFromNow(15),
    standards: ["NCSS-4"],
    tags: ["DBQ", "Civil War", "Essay"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 40,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  };

  curriculumState.assessmentStore.push(
    histAssess1,
    histAssess2,
    histAssess3,
    histAssess4,
  );

  // ──────────────────────────────────────────────────────────────────────────
  // Course 3: AP Biology — 5E Framework
  // ──────────────────────────────────────────────────────────────────────────
  const courseBio: Course = {
    id: curriculumState.nextCourseId++,
    title: "AP Biology",
    subject: "Science",
    gradeBand: "9-12",
    description:
      "College-level biology covering cell biology, genetics, and evolution, with emphasis on scientific inquiry, laboratory investigation, and the AP exam.",
    framework: "5e",
    frameworkFields: {
      fiveE: {
        engage: [
          "Driving question phenomenon",
          "Video hooks",
          "Discrepant events",
        ],
        explore: [
          "Hands-on lab investigations",
          "Collaborative data collection",
        ],
        explain: [
          "Direct instruction",
          "Model building",
          "Socratic questioning",
        ],
        elaborate: ["Extension labs", "Research projects", "AP FRQ practice"],
        evaluate: ["Lab reports", "Unit tests", "AP practice exams"],
      },
    },
    standards: ["AP-BIO-ENE-1", "AP-BIO-IST-1", "AP-BIO-EVO-1"],
    tags: ["AP", "Biology", "Grade 11", "Science"],
    draftStatus: "published",
    version: 2,
    versionHistory: [
      {
        version: 1,
        savedAt: Date.now() - 1000 * 60 * 60 * 24 * 60,
        snapshot: "{}",
      },
    ],
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 95,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 4,
  };
  curriculumState.courseStore = [...curriculumState.courseStore, courseBio];

  // Units for AP Biology
  const bioUnit1: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: courseBio.id,
    title: "Cell Biology",
    description:
      "Structure and function of cells, membranes, organelles, cellular energetics, and cell communication.",
    essentialQuestion:
      "How do cells maintain life through structure and chemical processes?",
    durationValue: 6,
    durationUnit: "weeks",
    standards: ["AP-BIO-ENE-1", "AP-BIO-ENE-2"],
    tags: ["Cells", "Membranes", "Energetics"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 93,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 22,
  };

  const bioUnit2: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: courseBio.id,
    title: "Genetics",
    description:
      "Heredity, Mendelian and non-Mendelian genetics, molecular genetics, gene expression, and biotechnology.",
    essentialQuestion:
      "How is genetic information stored, transmitted, and expressed?",
    durationValue: 7,
    durationUnit: "weeks",
    standards: ["AP-BIO-IST-1", "AP-BIO-IST-2"],
    tags: ["Genetics", "DNA", "Heredity"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 75,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 15,
  };

  const bioUnit3: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: courseBio.id,
    title: "Evolution",
    description:
      "Natural selection, population genetics, speciation, phylogenetics, and the origin of life.",
    essentialQuestion:
      "How does evolution explain the diversity and unity of life?",
    durationValue: 4,
    durationUnit: "weeks",
    standards: ["AP-BIO-EVO-1", "AP-BIO-EVO-2"],
    tags: ["Evolution", "Natural Selection", "Phylogeny"],
    frameworkFields: {},
    order: 3,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 55,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 8,
  };
  curriculumState.unitStore.push(bioUnit1, bioUnit2, bioUnit3);

  // Modules — Cell Biology
  const bioMod1: Module = {
    id: curriculumState.nextModuleId++,
    unitId: bioUnit1.id,
    courseId: courseBio.id,
    title: "Cell Structure & Function",
    description:
      "Prokaryotic and eukaryotic cell structure, organelles, and the endomembrane system.",
    learningObjectives: [
      "Compare prokaryotic and eukaryotic cell organization",
      "Explain the structure and function of key organelles",
      "Describe the endomembrane system and vesicle trafficking",
    ],
    vocabulary: [
      "organelle",
      "endomembrane system",
      "endosymbiotic theory",
      "cytoskeleton",
      "ribosome",
    ],
    standards: ["AP-BIO-ENE-1"],
    tags: ["Cell Structure", "Organelles", "Prokaryote"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 90,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 20,
  };

  const bioMod2: Module = {
    id: curriculumState.nextModuleId++,
    unitId: bioUnit1.id,
    courseId: courseBio.id,
    title: "Cellular Energetics",
    description:
      "Photosynthesis and cellular respiration, energy transformation, and enzyme function.",
    learningObjectives: [
      "Trace the flow of energy through photosynthesis and cellular respiration",
      "Explain how enzymes lower activation energy",
      "Interpret graphs of enzyme activity under different conditions",
    ],
    vocabulary: [
      "ATP",
      "photosynthesis",
      "cellular respiration",
      "enzyme",
      "activation energy",
      "chemiosmosis",
    ],
    standards: ["AP-BIO-ENE-1", "AP-BIO-ENE-2"],
    tags: ["Photosynthesis", "Respiration", "ATP"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 80,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 16,
  };

  const bioMod3: Module = {
    id: curriculumState.nextModuleId++,
    unitId: bioUnit1.id,
    courseId: courseBio.id,
    title: "Cell Communication & Division",
    description:
      "Signal transduction, cell cycle, mitosis, meiosis, and apoptosis.",
    learningObjectives: [
      "Describe the stages of the cell cycle and their regulation",
      "Compare mitosis and meiosis in terms of process and outcome",
      "Explain signal transduction pathways and their role in cell division",
    ],
    vocabulary: [
      "signal transduction",
      "cell cycle",
      "mitosis",
      "meiosis",
      "apoptosis",
      "cyclin",
    ],
    standards: ["AP-BIO-IST-1"],
    tags: ["Cell Division", "Mitosis", "Meiosis", "Signaling"],
    frameworkFields: {},
    order: 3,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 72,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 12,
  };

  // Modules — Genetics
  const bioMod4: Module = {
    id: curriculumState.nextModuleId++,
    unitId: bioUnit2.id,
    courseId: courseBio.id,
    title: "Mendelian & Non-Mendelian Genetics",
    description:
      "Inheritance patterns, Punnett squares, incomplete dominance, codominance, linkage, and sex-linked traits.",
    learningObjectives: [
      "Apply Mendel's laws to predict offspring ratios",
      "Distinguish between complete dominance, incomplete dominance, and codominance",
      "Solve genetics problems involving linked genes and sex-linked traits",
    ],
    vocabulary: [
      "allele",
      "genotype",
      "phenotype",
      "incomplete dominance",
      "codominance",
      "linkage",
    ],
    standards: ["AP-BIO-IST-1"],
    tags: ["Mendel", "Genetics", "Inheritance"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 68,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 10,
  };

  const bioMod5: Module = {
    id: curriculumState.nextModuleId++,
    unitId: bioUnit2.id,
    courseId: courseBio.id,
    title: "Molecular Genetics & Gene Expression",
    description:
      "DNA structure, replication, transcription, translation, and gene regulation.",
    learningObjectives: [
      "Explain the central dogma of molecular biology",
      "Describe the processes of DNA replication, transcription, and translation",
      "Analyze gene regulation in prokaryotes and eukaryotes",
    ],
    vocabulary: [
      "central dogma",
      "DNA replication",
      "transcription",
      "translation",
      "codon",
      "operon",
    ],
    standards: ["AP-BIO-IST-2"],
    tags: ["DNA", "Gene Expression", "Central Dogma"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 58,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 8,
  };

  // Modules — Evolution
  const bioMod6: Module = {
    id: curriculumState.nextModuleId++,
    unitId: bioUnit3.id,
    courseId: courseBio.id,
    title: "Natural Selection & Adaptation",
    description:
      "Darwin's theory, evidence for evolution, population genetics, and the Hardy-Weinberg equilibrium.",
    learningObjectives: [
      "Explain the mechanisms of natural selection",
      "Apply the Hardy-Weinberg principle to analyze allele frequencies",
      "Evaluate multiple lines of evidence for evolution",
    ],
    vocabulary: [
      "natural selection",
      "fitness",
      "adaptation",
      "Hardy-Weinberg equilibrium",
      "genetic drift",
    ],
    standards: ["AP-BIO-EVO-1"],
    tags: ["Natural Selection", "Darwin", "Hardy-Weinberg"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 50,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 6,
  };

  const bioMod7: Module = {
    id: curriculumState.nextModuleId++,
    unitId: bioUnit3.id,
    courseId: courseBio.id,
    title: "Speciation & Phylogenetics",
    description:
      "Mechanisms of speciation, reproductive isolation, phylogenetic trees, and the origin of life.",
    learningObjectives: [
      "Distinguish between allopatric and sympatric speciation",
      "Construct and interpret phylogenetic trees",
      "Describe hypotheses for the origin of life",
    ],
    vocabulary: [
      "speciation",
      "reproductive isolation",
      "allopatric",
      "sympatric",
      "phylogenetic tree",
      "cladistics",
    ],
    standards: ["AP-BIO-EVO-2"],
    tags: ["Speciation", "Phylogeny", "Cladistics"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 44,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 4,
  };

  curriculumState.moduleStore.push(
    bioMod1,
    bioMod2,
    bioMod3,
    bioMod4,
    bioMod5,
    bioMod6,
    bioMod7,
  );
  curriculumState._lessonStore = curriculumState.moduleStore;

  // Assignments — AP Biology
  const bioAssign1: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: bioMod1.id,
    courseId: courseBio.id,
    title: "Cell Organelle Diagram & Function Chart",
    description:
      "Label a diagram of a eukaryotic cell and complete the function chart.",
    instructions:
      "Label the provided eukaryotic cell diagram (15 structures). For each labeled structure, write 1-2 sentences describing its function. Then answer: How does the endosymbiotic theory explain the origin of mitochondria and chloroplasts?",
    points: 40,
    assignmentType: "homework",
    dueDate: daysFromNow(-72),
    standards: ["AP-BIO-ENE-1"],
    tags: ["Cell Structure", "Diagram", "Organelles"],
    rubric: null,
    frameworkFields: {},
    lessonId: bioMod1.id,
    pointsPossible: 40,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 88,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 19,
  };

  const bioAssign2: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: bioMod1.id,
    courseId: courseBio.id,
    title: "Microscopy Lab: Observing Cell Types",
    description:
      "Use compound microscopes to observe and sketch prokaryotic and eukaryotic cells.",
    instructions:
      "Station 1: Observe and sketch a prepared slide of E. coli (prokaryote). Station 2: Observe onion root cells (plant eukaryote). Station 3: Observe cheek cells (animal eukaryote). For each: create a labeled sketch, record magnification, and answer the post-lab questions.",
    points: 50,
    assignmentType: "lab",
    dueDate: daysFromNow(-66),
    standards: ["AP-BIO-ENE-1"],
    tags: ["Lab", "Microscopy", "Cell Types"],
    rubric: null,
    frameworkFields: {},
    lessonId: bioMod1.id,
    pointsPossible: 50,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 85,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 18,
  };

  const bioAssign3: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: bioMod2.id,
    courseId: courseBio.id,
    title: "Photosynthesis Lab Report",
    description:
      "Floating leaf disk experiment investigating factors that affect the rate of photosynthesis.",
    instructions:
      "Conduct the floating leaf disk experiment varying: (1) light intensity, (2) CO2 concentration (baking soda), (3) leaf type. Graph your results for each variable, calculate rates, and write a formal lab report including introduction, methods, results, discussion, and conclusion. Minimum 3 pages.",
    points: 100,
    assignmentType: "lab",
    dueDate: daysFromNow(-52),
    standards: ["AP-BIO-ENE-1"],
    tags: ["Photosynthesis", "Lab Report", "Experiment"],
    rubric: null,
    frameworkFields: {},
    lessonId: bioMod2.id,
    pointsPossible: 100,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 76,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 14,
  };

  const bioAssign4: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: bioMod2.id,
    courseId: courseBio.id,
    title: "Enzyme Activity Problem Set",
    description:
      "Problem set on enzyme kinetics, inhibition, and environmental factors.",
    instructions:
      "Complete all 20 problems covering: enzyme-substrate interactions, Michaelis-Menten kinetics, competitive vs. noncompetitive inhibition, and the effect of pH and temperature on enzyme activity. Show all work where calculations are required.",
    points: 60,
    assignmentType: "homework",
    dueDate: daysFromNow(-45),
    standards: ["AP-BIO-ENE-2"],
    tags: ["Enzymes", "Problem Set", "Kinetics"],
    rubric: null,
    frameworkFields: {},
    lessonId: bioMod2.id,
    pointsPossible: 60,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 70,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 12,
  };

  const bioAssign5: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: bioMod3.id,
    courseId: courseBio.id,
    title: "Cell Cycle & Cancer Research Brief",
    description:
      "Students research how disruption of the cell cycle leads to cancer.",
    instructions:
      "Research a specific type of cancer and write a 1-2 page research brief explaining: (1) which checkpoint(s) are disrupted, (2) which genes/proteins are mutated, (3) how this leads to uncontrolled cell division. Cite at least two peer-reviewed sources.",
    points: 75,
    assignmentType: "project",
    dueDate: daysFromNow(-30),
    standards: ["AP-BIO-IST-1"],
    tags: ["Cancer", "Cell Cycle", "Research"],
    rubric: null,
    frameworkFields: {},
    lessonId: bioMod3.id,
    pointsPossible: 75,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 64,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 10,
  };

  const bioAssign6: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: bioMod4.id,
    courseId: courseBio.id,
    title: "Genetics Problem Set: Mendelian Crosses",
    description:
      "Punnett square problems and probability calculations for monohybrid and dihybrid crosses.",
    instructions:
      "Solve all 15 genetics problems including: monohybrid crosses, dihybrid crosses, testcrosses, incomplete dominance, and codominance. For each, show your Punnett square (where applicable), list all possible genotypes and phenotypes, and calculate the probability ratios.",
    points: 50,
    assignmentType: "homework",
    dueDate: daysFromNow(-15),
    standards: ["AP-BIO-IST-1"],
    tags: ["Genetics", "Punnett Square", "Probability"],
    rubric: null,
    frameworkFields: {},
    lessonId: bioMod4.id,
    pointsPossible: 50,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 55,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 8,
  };

  const bioAssign7: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: bioMod5.id,
    courseId: courseBio.id,
    title: "DNA Replication & Transcription Flowchart",
    description:
      "Students create a detailed flowchart of DNA replication and transcription.",
    instructions:
      "Create a detailed, labeled flowchart showing: (1) DNA replication (initiation → elongation → termination), (2) transcription, and (3) translation. Include all key enzymes, molecules, and directionality (5' → 3'). Your flowchart must be detailed enough to explain the process step-by-step.",
    points: 45,
    assignmentType: "homework",
    dueDate: daysFromNow(2),
    standards: ["AP-BIO-IST-2"],
    tags: ["DNA", "Replication", "Transcription", "Flowchart"],
    rubric: null,
    frameworkFields: {},
    lessonId: bioMod5.id,
    pointsPossible: 45,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 48,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 5,
  };

  const bioAssign8: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: bioMod6.id,
    courseId: courseBio.id,
    title: "Hardy-Weinberg Problem Set",
    description:
      "Apply the Hardy-Weinberg principle to calculate allele and genotype frequencies.",
    instructions:
      "Solve 10 Hardy-Weinberg problems. For each scenario, determine whether the population is in Hardy-Weinberg equilibrium, calculate allele frequencies (p and q), and calculate expected genotype frequencies. Identify which of the 5 H-W conditions is violated in non-equilibrium populations.",
    points: 40,
    assignmentType: "homework",
    dueDate: daysFromNow(10),
    standards: ["AP-BIO-EVO-1"],
    tags: ["Hardy-Weinberg", "Population Genetics", "Problem Set"],
    rubric: null,
    frameworkFields: {},
    lessonId: bioMod6.id,
    pointsPossible: 40,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 42,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
  };

  const bioAssign9: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: bioMod7.id,
    courseId: courseBio.id,
    title: "Phylogenetic Tree Construction Lab",
    description:
      "Students construct phylogenetic trees from protein sequence data.",
    instructions:
      "Using the provided amino acid sequences for cytochrome c from 6 species, calculate the number of differences between each pair of species, build a distance matrix, and construct a phylogenetic tree. Annotate your tree with at least 3 evolutionary events. Write a paragraph explaining your tree's meaning.",
    points: 60,
    assignmentType: "lab",
    dueDate: daysFromNow(18),
    standards: ["AP-BIO-EVO-2"],
    tags: ["Phylogeny", "Lab", "Cladistics"],
    rubric: null,
    frameworkFields: {},
    lessonId: bioMod7.id,
    pointsPossible: 60,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 36,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  };

  curriculumState.assignmentStore.push(
    bioAssign1,
    bioAssign2,
    bioAssign3,
    bioAssign4,
    bioAssign5,
    bioAssign6,
    bioAssign7,
    bioAssign8,
    bioAssign9,
  );

  // Assessments — AP Biology
  const bioAssess1: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: bioMod1.id,
    courseId: courseBio.id,
    title: "Cell Structure Unit Quiz",
    description:
      "Quiz on prokaryotic vs. eukaryotic cells and organelle functions.",
    assessmentType: "quiz",
    items: ["Multiple choice", "Diagram labeling", "Short answer"],
    scoringModel: "points",
    totalPoints: 50,
    difficulty: "medium",
    dueDate: daysFromNow(-68),
    standards: ["AP-BIO-ENE-1"],
    tags: ["Cell Structure", "Quiz"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 86,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 18,
  };

  const bioAssess2: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: bioMod2.id,
    courseId: courseBio.id,
    title: "Cellular Energetics AP FRQ Practice",
    description:
      "Free-response questions on photosynthesis and cellular respiration.",
    assessmentType: "exam",
    items: ["Long free-response", "Short free-response", "Data analysis"],
    scoringModel: "rubric",
    totalPoints: 100,
    difficulty: "hard",
    dueDate: daysFromNow(-38),
    standards: ["AP-BIO-ENE-2"],
    tags: ["FRQ", "Photosynthesis", "Respiration"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 65,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 10,
  };

  const bioAssess3: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: bioMod4.id,
    courseId: courseBio.id,
    title: "Genetics Unit Test",
    description: "Comprehensive test on Mendelian and non-Mendelian genetics.",
    assessmentType: "test",
    items: ["Multiple choice", "Genetics problems", "Short essay"],
    scoringModel: "points",
    totalPoints: 100,
    difficulty: "hard",
    dueDate: daysFromNow(-8),
    standards: ["AP-BIO-IST-1"],
    tags: ["Genetics", "Unit Test"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 50,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 6,
  };

  const bioAssess4: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: bioMod6.id,
    courseId: courseBio.id,
    title: "Evolution AP Practice Exam",
    description:
      "AP-style practice exam covering natural selection, population genetics, and speciation.",
    assessmentType: "exam",
    items: [
      "AP multiple choice",
      "Data analysis FRQ",
      "Evolution scenario FRQ",
    ],
    scoringModel: "points",
    totalPoints: 100,
    difficulty: "hard",
    dueDate: daysFromNow(22),
    standards: ["AP-BIO-EVO-1", "AP-BIO-EVO-2"],
    tags: ["AP Exam", "Evolution", "Practice"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 38,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  };

  curriculumState.assessmentStore.push(
    bioAssess1,
    bioAssess2,
    bioAssess3,
    bioAssess4,
  );

  // ──────────────────────────────────────────────────────────────────────────
  // Course 4: Algebra II — EdUnite Simple (IMS) Framework
  // ──────────────────────────────────────────────────────────────────────────
  const courseAlg: Course = {
    id: curriculumState.nextCourseId++,
    title: "Algebra II",
    subject: "Mathematics",
    gradeBand: "9-12",
    description:
      "Advanced algebraic concepts including polynomials, rational expressions, trigonometry, and introductory statistics, preparing students for pre-calculus and standardized tests.",
    framework: "ims",
    frameworkFields: {
      ims: {
        intent: [
          "Students will extend algebraic reasoning to complex functions and real-world modeling",
          "Students will build fluency with polynomial and trigonometric operations",
        ],
        method: [
          "Direct instruction with guided practice",
          "Collaborative problem solving",
          "Technology integration (graphing calculator, Desmos)",
        ],
        scope: [
          "Polynomials and rational functions",
          "Exponential and logarithmic functions",
          "Trigonometric functions and identities",
          "Statistics and probability",
        ],
      },
    },
    standards: [
      "CCSS.MATH.HSA-APR.A.1",
      "CCSS.MATH.HSF-TF.A.1",
      "CCSS.MATH.HSS-IC.A.1",
    ],
    tags: ["Algebra II", "Mathematics", "Grade 11"],
    draftStatus: "published",
    version: 1,
    versionHistory: [],
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 88,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
  };
  curriculumState.courseStore = [...curriculumState.courseStore, courseAlg];

  // Units for Algebra II
  const algUnit1: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: courseAlg.id,
    title: "Polynomials & Rational Expressions",
    description:
      "Operations with polynomials, factoring techniques, polynomial functions, rational expressions, and equations.",
    essentialQuestion:
      "How can polynomial and rational models represent and solve real-world problems?",
    durationValue: 5,
    durationUnit: "weeks",
    standards: ["CCSS.MATH.HSA-APR.A.1", "CCSS.MATH.HSA-APR.B.2"],
    tags: ["Polynomials", "Factoring", "Rational Expressions"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 86,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 22,
  };

  const algUnit2: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: courseAlg.id,
    title: "Trigonometry",
    description:
      "Right triangle trigonometry, the unit circle, trigonometric functions and their graphs, and trigonometric identities.",
    essentialQuestion:
      "How do trigonometric functions model periodic phenomena in the real world?",
    durationValue: 6,
    durationUnit: "weeks",
    standards: ["CCSS.MATH.HSF-TF.A.1", "CCSS.MATH.HSF-TF.B.5"],
    tags: ["Trigonometry", "Unit Circle", "Graphing"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 65,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 14,
  };

  const algUnit3: Unit = {
    id: curriculumState.nextUnitId++,
    courseId: courseAlg.id,
    title: "Statistics & Probability",
    description:
      "Descriptive statistics, probability, normal distribution, linear regression, and statistical inference.",
    essentialQuestion:
      "How do we use data and probability to make informed decisions?",
    durationValue: 4,
    durationUnit: "weeks",
    standards: ["CCSS.MATH.HSS-IC.A.1", "CCSS.MATH.HSS-ID.B.6"],
    tags: ["Statistics", "Probability", "Data Analysis"],
    frameworkFields: {},
    order: 3,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 45,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
  };
  curriculumState.unitStore.push(algUnit1, algUnit2, algUnit3);

  // Modules — Polynomials
  const algMod1: Module = {
    id: curriculumState.nextModuleId++,
    unitId: algUnit1.id,
    courseId: courseAlg.id,
    title: "Polynomial Operations & Factoring",
    description:
      "Adding, subtracting, multiplying polynomials; factoring by GCF, grouping, special products.",
    learningObjectives: [
      "Perform operations on polynomial expressions",
      "Factor polynomials using GCF, trinomial factoring, and special patterns",
      "Apply the Factor Theorem to find roots of polynomial functions",
    ],
    vocabulary: [
      "polynomial",
      "degree",
      "leading coefficient",
      "GCF",
      "factor theorem",
      "synthetic division",
    ],
    standards: ["CCSS.MATH.HSA-APR.A.1"],
    tags: ["Polynomials", "Factoring", "Operations"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 84,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 20,
  };

  const algMod2: Module = {
    id: curriculumState.nextModuleId++,
    unitId: algUnit1.id,
    courseId: courseAlg.id,
    title: "Rational Expressions & Equations",
    description:
      "Simplifying, multiplying, dividing rational expressions; solving rational equations and inequalities.",
    learningObjectives: [
      "Simplify rational expressions by factoring and canceling common factors",
      "Perform operations on rational expressions",
      "Solve rational equations and identify extraneous solutions",
    ],
    vocabulary: [
      "rational expression",
      "restriction",
      "LCD",
      "extraneous solution",
      "asymptote",
    ],
    standards: ["CCSS.MATH.HSA-APR.D.6"],
    tags: ["Rational", "Expressions", "Equations"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 76,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 16,
  };

  const algMod3: Module = {
    id: curriculumState.nextModuleId++,
    unitId: algUnit1.id,
    courseId: courseAlg.id,
    title: "Polynomial Functions & Their Graphs",
    description:
      "Graphing polynomial functions, identifying zeros, end behavior, and turning points.",
    learningObjectives: [
      "Identify zeros, multiplicity, and end behavior of polynomial functions",
      "Graph polynomial functions by hand and using technology",
      "Apply the Intermediate Value Theorem to approximate zeros",
    ],
    vocabulary: [
      "zeros",
      "multiplicity",
      "end behavior",
      "turning point",
      "Intermediate Value Theorem",
    ],
    standards: ["CCSS.MATH.HSF-IF.C.7"],
    tags: ["Graphing", "Polynomial Functions", "Zeros"],
    frameworkFields: {},
    order: 3,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 68,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 12,
  };

  // Modules — Trigonometry
  const algMod4: Module = {
    id: curriculumState.nextModuleId++,
    unitId: algUnit2.id,
    courseId: courseAlg.id,
    title: "The Unit Circle & Trigonometric Functions",
    description:
      "Angles in standard position, radian measure, the unit circle, and basic trig function values.",
    learningObjectives: [
      "Convert between degrees and radians",
      "Identify coordinates on the unit circle",
      "Evaluate trigonometric functions at key angles",
    ],
    vocabulary: [
      "unit circle",
      "radian",
      "arc length",
      "sine",
      "cosine",
      "tangent",
      "reference angle",
    ],
    standards: ["CCSS.MATH.HSF-TF.A.1", "CCSS.MATH.HSF-TF.A.2"],
    tags: ["Unit Circle", "Trigonometry", "Radians"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 62,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 10,
  };

  const algMod5: Module = {
    id: curriculumState.nextModuleId++,
    unitId: algUnit2.id,
    courseId: courseAlg.id,
    title: "Graphing & Transformations of Trig Functions",
    description:
      "Graphs of sin, cos, tan; amplitude, period, phase shift, vertical shift, and applications.",
    learningObjectives: [
      "Graph y = a sin(bx + c) + d identifying all transformations",
      "Determine amplitude, period, and phase shift from an equation or graph",
      "Model real-world periodic phenomena with trigonometric functions",
    ],
    vocabulary: [
      "amplitude",
      "period",
      "phase shift",
      "vertical shift",
      "periodic function",
    ],
    standards: ["CCSS.MATH.HSF-TF.B.5"],
    tags: ["Graphing", "Transformations", "Periodic Functions"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 52,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 8,
  };

  // Modules — Statistics
  const algMod6: Module = {
    id: curriculumState.nextModuleId++,
    unitId: algUnit3.id,
    courseId: courseAlg.id,
    title: "Descriptive Statistics & Normal Distribution",
    description:
      "Measures of center and spread, box plots, histograms, normal distribution, and z-scores.",
    learningObjectives: [
      "Calculate and interpret mean, median, mode, range, IQR, and standard deviation",
      "Construct and interpret histograms and box plots",
      "Use the normal distribution and z-scores to find probabilities",
    ],
    vocabulary: [
      "mean",
      "median",
      "standard deviation",
      "IQR",
      "z-score",
      "normal distribution",
    ],
    standards: ["CCSS.MATH.HSS-ID.A.2"],
    tags: ["Statistics", "Normal Distribution", "Descriptive"],
    frameworkFields: {},
    order: 1,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 42,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 5,
  };

  const algMod7: Module = {
    id: curriculumState.nextModuleId++,
    unitId: algUnit3.id,
    courseId: courseAlg.id,
    title: "Linear Regression & Statistical Inference",
    description:
      "Scatter plots, correlation, least-squares regression, residuals, and intro to inference.",
    learningObjectives: [
      "Construct and interpret scatter plots and describe association",
      "Calculate and interpret the least-squares regression line",
      "Distinguish between correlation and causation",
    ],
    vocabulary: [
      "correlation",
      "regression",
      "r-value",
      "residual",
      "causation",
      "extrapolation",
    ],
    standards: ["CCSS.MATH.HSS-ID.B.6", "CCSS.MATH.HSS-IC.A.1"],
    tags: ["Regression", "Correlation", "Data Analysis"],
    frameworkFields: {},
    order: 2,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 35,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
  };

  curriculumState.moduleStore.push(
    algMod1,
    algMod2,
    algMod3,
    algMod4,
    algMod5,
    algMod6,
    algMod7,
  );
  curriculumState._lessonStore = curriculumState.moduleStore;

  // Assignments — Algebra II
  const algAssign1: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: algMod1.id,
    courseId: courseAlg.id,
    title: "Polynomial Operations Practice",
    description:
      "Worksheet on adding, subtracting, and multiplying polynomials.",
    instructions:
      "Complete problems 1-30: 10 addition/subtraction problems, 10 multiplication problems (including FOIL and special products), and 10 mixed review problems. Show all work. Circle your final answers.",
    points: 30,
    assignmentType: "homework",
    dueDate: daysFromNow(-70),
    standards: ["CCSS.MATH.HSA-APR.A.1"],
    tags: ["Polynomials", "Operations", "Practice"],
    rubric: null,
    frameworkFields: {},
    lessonId: algMod1.id,
    pointsPossible: 30,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 83,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 19,
  };

  const algAssign2: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: algMod1.id,
    courseId: courseAlg.id,
    title: "Factoring Techniques Worksheet",
    description:
      "Practice factoring by GCF, grouping, trinomials, and special patterns.",
    instructions:
      "Factor completely: 5 GCF problems, 5 grouping problems, 10 trinomial problems, 5 difference of squares, 5 sum/difference of cubes. If a polynomial is prime, state that. Show all steps.",
    points: 40,
    assignmentType: "homework",
    dueDate: daysFromNow(-63),
    standards: ["CCSS.MATH.HSA-APR.B.2"],
    tags: ["Factoring", "Polynomials", "Practice"],
    rubric: null,
    frameworkFields: {},
    lessonId: algMod1.id,
    pointsPossible: 40,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 80,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 17,
  };

  const algAssign3: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: algMod1.id,
    courseId: courseAlg.id,
    title: "Polynomial Applications Project",
    description:
      "Students apply polynomial functions to model real-world situations.",
    instructions:
      "Choose ONE application: (A) model a projectile's height using a quadratic; (B) model profit/revenue for a small business using a cubic; (C) model population growth using a polynomial. Write a 1-page report, include your function, graph it using Desmos, find key features, and interpret them in context.",
    points: 80,
    assignmentType: "project",
    dueDate: daysFromNow(-55),
    standards: ["CCSS.MATH.HSF-IF.C.7"],
    tags: ["Applications", "Polynomials", "Project"],
    rubric: null,
    frameworkFields: {},
    lessonId: algMod1.id,
    pointsPossible: 80,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 76,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 14,
  };

  const algAssign4: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: algMod2.id,
    courseId: courseAlg.id,
    title: "Rational Expressions Problem Set",
    description:
      "Simplifying, multiplying, dividing, adding, and subtracting rational expressions.",
    instructions:
      "Complete all 25 problems. Show all work including factoring steps and identifying restrictions. For addition/subtraction, show the LCD clearly. Circle final answers and list any restrictions on the variable.",
    points: 50,
    assignmentType: "homework",
    dueDate: daysFromNow(-46),
    standards: ["CCSS.MATH.HSA-APR.D.6"],
    tags: ["Rational Expressions", "Simplifying"],
    rubric: null,
    frameworkFields: {},
    lessonId: algMod2.id,
    pointsPossible: 50,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 70,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 12,
  };

  const algAssign5: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: algMod4.id,
    courseId: courseAlg.id,
    title: "Unit Circle Memorization Quiz Practice",
    description:
      "Blank unit circle practice sheet to build fluency with key angles.",
    instructions:
      "Complete the blank unit circle by filling in all angle measures (degrees and radians) and the (cos, sin) coordinates at each key angle. Aim to complete in under 10 minutes. Check your answers and note any angles that need more practice.",
    points: 20,
    assignmentType: "homework",
    dueDate: daysFromNow(-30),
    standards: ["CCSS.MATH.HSF-TF.A.2"],
    tags: ["Unit Circle", "Practice", "Memorization"],
    rubric: null,
    frameworkFields: {},
    lessonId: algMod4.id,
    pointsPossible: 20,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 58,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 9,
  };

  const algAssign6: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: algMod4.id,
    courseId: courseAlg.id,
    title: "Right Triangle Trig Application Problems",
    description:
      "Apply sine, cosine, and tangent to solve real-world right triangle problems.",
    instructions:
      "Solve 12 application problems involving angle of elevation, angle of depression, navigation, and surveying scenarios. Draw a diagram for each problem, write the trig ratio used, and round to the nearest tenth. Include units.",
    points: 35,
    assignmentType: "homework",
    dueDate: daysFromNow(-22),
    standards: ["CCSS.MATH.HSF-TF.A.1"],
    tags: ["Trigonometry", "Applications", "Right Triangles"],
    rubric: null,
    frameworkFields: {},
    lessonId: algMod4.id,
    pointsPossible: 35,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 52,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
  };

  const algAssign7: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: algMod5.id,
    courseId: courseAlg.id,
    title: "Graphing Trig Functions Activity",
    description:
      "Use Desmos to graph and analyze transformations of sin and cos functions.",
    instructions:
      "In Desmos, graph each of the following and record: (1) y = sin(x), (2) y = 3sin(x), (3) y = sin(2x), (4) y = sin(x - π/4), (5) y = sin(x) + 2. For each transformation, identify what changed and describe the effect. Then write the equation for a sinusoidal function with amplitude 4, period π, and phase shift π/3 right.",
    points: 45,
    assignmentType: "homework",
    dueDate: daysFromNow(-12),
    standards: ["CCSS.MATH.HSF-TF.B.5"],
    tags: ["Graphing", "Trig Functions", "Desmos"],
    rubric: null,
    frameworkFields: {},
    lessonId: algMod5.id,
    pointsPossible: 45,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 46,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 5,
  };

  const algAssign8: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: algMod6.id,
    courseId: courseAlg.id,
    title: "Statistics Project: Data Collection & Analysis",
    description:
      "Students collect real data and produce a descriptive statistics report.",
    instructions:
      "Collect at least 30 data points on a topic of your choice (e.g., heights, reaction times, test scores). Calculate: mean, median, mode, range, IQR, and standard deviation. Create a histogram and box plot. Identify any outliers. Write a 1-page summary interpreting your results and what they reveal about your topic.",
    points: 100,
    assignmentType: "project",
    dueDate: daysFromNow(8),
    standards: ["CCSS.MATH.HSS-ID.A.2"],
    tags: ["Statistics", "Data Collection", "Project"],
    rubric: null,
    frameworkFields: {},
    lessonId: algMod6.id,
    pointsPossible: 100,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 38,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 3,
  };

  const algAssign9: Assignment = {
    id: curriculumState.nextAssignmentId++,
    moduleId: algMod7.id,
    courseId: courseAlg.id,
    title: "Linear Regression Technology Lab",
    description:
      "Use graphing calculator or Desmos to find and interpret regression lines.",
    instructions:
      "Enter the provided dataset (age vs. height of 20 children) into your graphing calculator or Desmos. Find the least-squares regression line, record the equation and r-value. Make a prediction for x = 8 and x = 20 and explain why one prediction is more reliable. Create a residual plot and describe what it tells you.",
    points: 50,
    assignmentType: "lab",
    dueDate: daysFromNow(16),
    standards: ["CCSS.MATH.HSS-ID.B.6"],
    tags: ["Regression", "Technology", "Lab"],
    rubric: null,
    frameworkFields: {},
    lessonId: algMod7.id,
    pointsPossible: 50,
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 30,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  };

  curriculumState.assignmentStore.push(
    algAssign1,
    algAssign2,
    algAssign3,
    algAssign4,
    algAssign5,
    algAssign6,
    algAssign7,
    algAssign8,
    algAssign9,
  );

  // Assessments — Algebra II
  const algAssess1: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: algMod1.id,
    courseId: courseAlg.id,
    title: "Polynomials & Factoring Unit Test",
    description: "Comprehensive test on polynomial operations and factoring.",
    assessmentType: "test",
    items: ["Multiple choice", "Short answer", "Open-ended problem solving"],
    scoringModel: "points",
    totalPoints: 100,
    difficulty: "medium",
    dueDate: daysFromNow(-58),
    standards: ["CCSS.MATH.HSA-APR.A.1"],
    tags: ["Polynomials", "Factoring", "Unit Test"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 82,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 18,
  };

  const algAssess2: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: algMod3.id,
    courseId: courseAlg.id,
    title: "Polynomial Functions Quiz",
    description:
      "Quiz on graphing polynomial functions and identifying key features.",
    assessmentType: "quiz",
    items: [
      "Graph sketching",
      "Identify zeros and multiplicity",
      "End behavior",
    ],
    scoringModel: "points",
    totalPoints: 50,
    difficulty: "medium",
    dueDate: daysFromNow(-38),
    standards: ["CCSS.MATH.HSF-IF.C.7"],
    tags: ["Polynomial Functions", "Graphing", "Quiz"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 65,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 11,
  };

  const algAssess3: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: algMod4.id,
    courseId: courseAlg.id,
    title: "Trigonometry Mid-Unit Test",
    description:
      "Test covering the unit circle, radian measure, and basic trig function values.",
    assessmentType: "test",
    items: [
      "Unit circle values",
      "Radian-degree conversion",
      "Exact value problems",
    ],
    scoringModel: "points",
    totalPoints: 100,
    difficulty: "medium",
    dueDate: daysFromNow(-18),
    standards: ["CCSS.MATH.HSF-TF.A.1", "CCSS.MATH.HSF-TF.A.2"],
    tags: ["Trigonometry", "Unit Circle", "Test"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 50,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
  };

  const algAssess4: Assessment = {
    id: curriculumState.nextAssessmentId++,
    moduleId: algMod6.id,
    courseId: courseAlg.id,
    title: "Statistics Unit Assessment",
    description:
      "Cumulative assessment on descriptive statistics and the normal distribution.",
    assessmentType: "test",
    items: [
      "Multiple choice",
      "Calculation problems",
      "Interpretation questions",
    ],
    scoringModel: "points",
    totalPoints: 100,
    difficulty: "medium",
    dueDate: daysFromNow(25),
    standards: ["CCSS.MATH.HSS-ID.A.2", "CCSS.MATH.HSS-IC.A.1"],
    tags: ["Statistics", "Unit Assessment"],
    frameworkFields: {},
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 35,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  };

  curriculumState.assessmentStore.push(
    algAssess1,
    algAssess2,
    algAssess3,
    algAssess4,
  );

  // ── Seed gradebook data ────────────────────────────────────────────────────
  // Only seed if no gradebook data exists
  if (!localStorage.getItem("edunite_gradebook")) {
    const gradeData: Record<
      string,
      Record<string, Record<string, number | null>>
    > = {
      "1": {
        // course id 1 = English 10
        S001: {
          "assign-1": 88,
          "assign-2": 92,
          "assign-3": 76,
          "assign-4": 95,
          "assess-1": 82,
          "assess-2": 89,
        },
        S002: {
          "assign-1": 72,
          "assign-2": 68,
          "assign-3": 80,
          "assign-4": 85,
          "assess-1": 70,
          "assess-2": 74,
        },
        S003: {
          "assign-1": 95,
          "assign-2": 98,
          "assign-3": 91,
          "assign-4": 100,
          "assess-1": 94,
          "assess-2": 97,
        },
        S004: {
          "assign-1": 60,
          "assign-2": 55,
          "assign-3": 62,
          "assign-4": 70,
          "assess-1": 58,
          "assess-2": 65,
        },
        S005: {
          "assign-1": 84,
          "assign-2": 87,
          "assign-3": 79,
          "assign-4": 90,
          "assess-1": 83,
          "assess-2": 86,
        },
        S006: {
          "assign-1": 91,
          "assign-2": 94,
          "assign-3": 88,
          "assign-4": 92,
          "assess-1": 90,
          "assess-2": 93,
        },
        S007: {
          "assign-1": 78,
          "assign-2": 74,
          "assign-3": 82,
          "assign-4": 80,
          "assess-1": 76,
          "assess-2": 79,
        },
        S008: {
          "assign-1": 65,
          "assign-2": 70,
          "assign-3": 68,
          "assign-4": 72,
          "assess-1": 63,
          "assess-2": 67,
        },
        S009: {
          "assign-1": 87,
          "assign-2": 89,
          "assign-3": 85,
          "assign-4": 91,
          "assess-1": 88,
          "assess-2": 90,
        },
        S010: {
          "assign-1": 93,
          "assign-2": 91,
          "assign-3": 95,
          "assign-4": 98,
          "assess-1": 92,
          "assess-2": 94,
        },
        S011: {
          "assign-1": 55,
          "assign-2": 60,
          "assign-3": 52,
          "assign-4": 65,
          "assess-1": 54,
          "assess-2": 58,
        },
        S012: {
          "assign-1": 80,
          "assign-2": 83,
          "assign-3": 77,
          "assign-4": 85,
          "assess-1": 79,
          "assess-2": 82,
        },
        S013: {
          "assign-1": 74,
          "assign-2": 78,
          "assign-3": 72,
          "assign-4": 80,
          "assess-1": 73,
          "assess-2": 76,
        },
        S014: {
          "assign-1": 96,
          "assign-2": 99,
          "assign-3": 94,
          "assign-4": 100,
          "assess-1": 95,
          "assess-2": 98,
        },
        S015: {
          "assign-1": 69,
          "assign-2": 72,
          "assign-3": 66,
          "assign-4": 74,
          "assess-1": 68,
          "assess-2": 71,
        },
        S016: {
          "assign-1": 82,
          "assign-2": 80,
          "assign-3": 84,
          "assign-4": 88,
          "assess-1": 81,
          "assess-2": 83,
        },
        S017: {
          "assign-1": 77,
          "assign-2": 73,
          "assign-3": 79,
          "assign-4": 82,
          "assess-1": 75,
          "assess-2": 78,
        },
        S018: {
          "assign-1": 88,
          "assign-2": 90,
          "assign-3": 86,
          "assign-4": 92,
          "assess-1": 87,
          "assess-2": 89,
        },
      },
    };
    try {
      localStorage.setItem("edunite_gradebook", JSON.stringify(gradeData));
    } catch {
      /* ignore quota errors */
    }
  }

  curriculumState._nextLessonId = curriculumState.nextModuleId;
  // Sync curriculum to localStorage so other modules can read live data
  syncCurriculumToStorage();
}

// ─── Curriculum → localStorage sync ──────────────────────────────────────────
// Writes the in-memory curriculum to "edunite_curriculum" so that other modules
// (Header notifications, ReportCards, gradeUtils, ParentPortal) can read live data.
export function syncCurriculumToStorage(): void {
  try {
    const nestedCourses = curriculumState.courseStore.map((course) => {
      const units = curriculumState.unitStore
        .filter((u) => u.courseId === course.id)
        .sort((a, b) => a.order - b.order)
        .map((unit) => {
          const modules = curriculumState.moduleStore
            .filter((m) => m.unitId === unit.id)
            .sort((a, b) => a.order - b.order)
            .map((mod) => {
              const assignments = curriculumState.assignmentStore
                .filter((a) => a.moduleId === mod.id || a.lessonId === mod.id)
                .map((a) => ({
                  id: a.id,
                  title: a.title,
                  dueDate: a.dueDate,
                  points: a.points,
                  pointsPossible: a.pointsPossible,
                  assignmentType: a.assignmentType,
                  standards: a.standards,
                  rubric: a.rubric,
                  bloomsLevel: (a as any).bloomsLevel,
                  dokLevel: (a as any).dokLevel,
                }));
              const assessments = curriculumState.assessmentStore
                .filter((a) => a.moduleId === mod.id)
                .map((a) => ({
                  id: a.id,
                  title: a.title,
                  dueDate: a.dueDate,
                  totalPoints: a.totalPoints,
                  assessmentType: a.assessmentType,
                  standards: a.standards,
                  bloomsLevel: (a as any).bloomsLevel,
                  dokLevel: (a as any).dokLevel,
                }));
              return {
                id: mod.id,
                title: mod.title,
                standards: mod.standards,
                assignments,
                assessments,
              };
            });
          return {
            id: unit.id,
            title: unit.title,
            modules,
            standards: unit.standards,
          };
        });
      return {
        id: course.id,
        title: course.title,
        subject: course.subject,
        framework: course.framework,
        frameworkFields: course.frameworkFields,
        units,
      };
    });

    localStorage.setItem(
      "edunite_curriculum",
      JSON.stringify({ courses: nestedCourses }),
    );
    scheduleCurriculumBackendSync();
    document.dispatchEvent(new CustomEvent("edunite:data-changed"));
    window.dispatchEvent(
      new StorageEvent("storage", {
        key: "edunite_curriculum",
        newValue: localStorage.getItem("edunite_curriculum"),
        storageArea: localStorage,
      }),
    );
  } catch {
    /* ignore quota errors */
  }
}

// ─── Backend sync layer ───────────────────────────────────────────────────────
// Syncs curriculum data to the IC backend so it survives browser clears.
// Uses the generic saveUserData / getUserData KV store (no new Motoko model needed).

let _backendSyncTimer: ReturnType<typeof setTimeout> | null = null;
let _actorRef: {
  saveUserData: (key: string, value: string) => Promise<void>;
  getUserData: (key: string) => Promise<string | null>;
} | null = null;

export function registerCurriculumActor(actor: {
  saveUserData: (key: string, value: string) => Promise<void>;
  getUserData: (key: string) => Promise<string | null>;
}) {
  _actorRef = actor;
}

/** Serialises in-memory curriculum and saves to backend (debounced, 2s). */
export function scheduleCurriculumBackendSync(): void {
  if (_backendSyncTimer) clearTimeout(_backendSyncTimer);
  _backendSyncTimer = setTimeout(() => {
    syncCurriculumToBackend().catch(() => {
      /* silent */
    });
  }, 2000);
}

export async function syncCurriculumToBackend(): Promise<void> {
  if (!_actorRef) return;
  try {
    const raw = localStorage.getItem("edunite_curriculum");
    if (raw) {
      await _actorRef.saveUserData("edunite_curriculum", raw);
    }
  } catch {
    /* silent — backend unavailable */
  }
}

/** Loads curriculum from backend and restores to localStorage + in-memory state. */
export async function loadCurriculumFromBackend(actor: {
  saveUserData: (key: string, value: string) => Promise<void>;
  getUserData: (key: string) => Promise<string | null>;
}): Promise<boolean> {
  try {
    const raw = await actor.getUserData("edunite_curriculum");
    if (raw && raw.trim() !== "" && raw !== "null") {
      const existing = localStorage.getItem("edunite_curriculum");
      // Only restore if backend has data and localStorage is empty or different
      if (!existing || existing === "{}") {
        localStorage.setItem("edunite_curriculum", raw);
        return true;
      }
    }
  } catch {
    /* silent */
  }
  return false;
}
