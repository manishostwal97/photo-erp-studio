import type { CurriculumFramework } from "../lib/curriculumTypes";

export interface TemplateAssignment {
  title: string;
  type: "assignment" | "assessment";
}

export interface TemplateModule {
  title: string;
  assignments: TemplateAssignment[];
}

export interface TemplateUnit {
  title: string;
  duration: number; // weeks
  modules: TemplateModule[];
}

export interface CurriculumTemplate {
  id: string;
  name: string;
  subject: "ela" | "science" | "social-studies" | "math" | "blank";
  framework: CurriculumFramework | null;
  description: string;
  units: TemplateUnit[];
}

export const CURRICULUM_TEMPLATES: CurriculumTemplate[] = [
  {
    id: "ela-ubd",
    name: "English Language Arts",
    subject: "ela",
    framework: "ubd",
    description:
      "Full-year ELA course covering analysis, writing, grammar, and presentation.",
    units: [
      {
        title: "Literary Analysis",
        duration: 4,
        modules: [
          {
            title: "Close Reading Strategies",
            assignments: [
              { title: "Annotation Practice", type: "assignment" },
              { title: "Close Reading Quiz", type: "assessment" },
            ],
          },
          {
            title: "Thematic Interpretation",
            assignments: [
              { title: "Theme Journal", type: "assignment" },
              { title: "Literary Analysis Essay", type: "assessment" },
            ],
          },
          {
            title: "Comparative Analysis",
            assignments: [
              { title: "Text Comparison Chart", type: "assignment" },
              { title: "Comparative Essay", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Narrative Writing",
        duration: 3,
        modules: [
          {
            title: "Story Structure & Craft",
            assignments: [
              { title: "Story Outline", type: "assignment" },
              { title: "Craft Analysis Response", type: "assessment" },
            ],
          },
          {
            title: "Drafting & Revision",
            assignments: [
              { title: "First Draft", type: "assignment" },
              { title: "Peer Review", type: "assignment" },
              { title: "Final Narrative", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Research Paper",
        duration: 5,
        modules: [
          {
            title: "Research & Source Evaluation",
            assignments: [
              { title: "Source Annotation", type: "assignment" },
              { title: "Credibility Quiz", type: "assessment" },
            ],
          },
          {
            title: "Thesis & Outline",
            assignments: [
              { title: "Thesis Statement Draft", type: "assignment" },
              { title: "Outline Submission", type: "assignment" },
            ],
          },
          {
            title: "Drafting & MLA Formatting",
            assignments: [
              { title: "Research Paper Draft", type: "assignment" },
              { title: "Final Research Paper", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Grammar & Mechanics",
        duration: 2,
        modules: [
          {
            title: "Sentence Structure",
            assignments: [
              { title: "Sentence Variety Exercises", type: "assignment" },
              { title: "Grammar Quiz", type: "assessment" },
            ],
          },
          {
            title: "Punctuation & Style",
            assignments: [
              { title: "Style Revision Activity", type: "assignment" },
              { title: "Editing Assessment", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Speech & Presentation",
        duration: 3,
        modules: [
          {
            title: "Oral Communication Techniques",
            assignments: [
              { title: "Speech Outline", type: "assignment" },
              { title: "Peer Feedback Activity", type: "assignment" },
            ],
          },
          {
            title: "Formal Presentation",
            assignments: [
              { title: "Presentation Slides", type: "assignment" },
              { title: "Formal Speech Assessment", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Exam Prep",
        duration: 2,
        modules: [
          {
            title: "Review & Synthesis",
            assignments: [
              { title: "Study Guide", type: "assignment" },
              { title: "Practice Exam", type: "assessment" },
            ],
          },
          {
            title: "Final Examination",
            assignments: [{ title: "Final Exam", type: "assessment" }],
          },
        ],
      },
    ],
  },
  {
    id: "science-5e",
    name: "Science (5E Model)",
    subject: "science",
    framework: "5e",
    description:
      "Inquiry-based science course using the Engage–Explore–Explain–Elaborate–Evaluate cycle.",
    units: [
      {
        title: "Forces & Motion",
        duration: 4,
        modules: [
          {
            title: "Engage",
            assignments: [
              { title: "Force & Motion Phenomenon", type: "assignment" },
            ],
          },
          {
            title: "Explore",
            assignments: [
              { title: "Lab: Ramp Experiment", type: "assignment" },
            ],
          },
          {
            title: "Explain",
            assignments: [{ title: "Newton's Laws Notes", type: "assignment" }],
          },
          {
            title: "Elaborate",
            assignments: [
              { title: "Real-World Application", type: "assignment" },
            ],
          },
          {
            title: "Evaluate",
            assignments: [
              { title: "Forces & Motion Test", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Energy Transfer",
        duration: 4,
        modules: [
          {
            title: "Engage",
            assignments: [
              { title: "Energy Observation Activity", type: "assignment" },
            ],
          },
          {
            title: "Explore",
            assignments: [{ title: "Lab: Heat Transfer", type: "assignment" }],
          },
          {
            title: "Explain",
            assignments: [
              { title: "Energy Forms Graphic Organizer", type: "assignment" },
            ],
          },
          {
            title: "Elaborate",
            assignments: [
              { title: "Engineering Design Challenge", type: "assignment" },
            ],
          },
          {
            title: "Evaluate",
            assignments: [
              { title: "Energy Transfer Assessment", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Ecosystems",
        duration: 4,
        modules: [
          {
            title: "Engage",
            assignments: [
              { title: "Ecosystem Observation", type: "assignment" },
            ],
          },
          {
            title: "Explore",
            assignments: [{ title: "Food Web Activity", type: "assignment" }],
          },
          {
            title: "Explain",
            assignments: [
              { title: "Ecosystem Relationships Notes", type: "assignment" },
            ],
          },
          {
            title: "Elaborate",
            assignments: [
              { title: "Human Impact Research", type: "assignment" },
            ],
          },
          {
            title: "Evaluate",
            assignments: [{ title: "Ecosystem Quiz", type: "assessment" }],
          },
        ],
      },
      {
        title: "Genetics",
        duration: 5,
        modules: [
          {
            title: "Engage",
            assignments: [{ title: "Trait Observation", type: "assignment" }],
          },
          {
            title: "Explore",
            assignments: [{ title: "Punnett Square Lab", type: "assignment" }],
          },
          {
            title: "Explain",
            assignments: [
              { title: "DNA & Heredity Notes", type: "assignment" },
            ],
          },
          {
            title: "Elaborate",
            assignments: [
              { title: "Genetic Disorder Research", type: "assignment" },
            ],
          },
          {
            title: "Evaluate",
            assignments: [{ title: "Genetics Assessment", type: "assessment" }],
          },
        ],
      },
      {
        title: "Scientific Inquiry",
        duration: 3,
        modules: [
          {
            title: "Engage",
            assignments: [
              { title: "Question Formulation", type: "assignment" },
            ],
          },
          {
            title: "Explore",
            assignments: [
              { title: "Student-Led Experiment", type: "assignment" },
            ],
          },
          {
            title: "Explain",
            assignments: [{ title: "Lab Report Draft", type: "assignment" }],
          },
          {
            title: "Elaborate",
            assignments: [{ title: "Peer Critique", type: "assignment" }],
          },
          {
            title: "Evaluate",
            assignments: [{ title: "Final Lab Report", type: "assessment" }],
          },
        ],
      },
    ],
  },
  {
    id: "social-studies-backwards",
    name: "Social Studies",
    subject: "social-studies",
    framework: "backwards",
    description:
      "U.S. history course designed backwards from essential questions and transfer goals.",
    units: [
      {
        title: "Foundations of Democracy",
        duration: 4,
        modules: [
          {
            title: "Constitutional Foundations",
            assignments: [
              { title: "Primary Source Analysis", type: "assignment" },
              { title: "Constitution Quiz", type: "assessment" },
            ],
          },
          {
            title: "Rights & Civic Participation",
            assignments: [
              { title: "Bill of Rights Poster", type: "assignment" },
              { title: "Civic Participation Essay", type: "assessment" },
            ],
          },
          {
            title: "Branches of Government",
            assignments: [
              { title: "Government Structure Diagram", type: "assignment" },
              { title: "Checks & Balances Assessment", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Industrial Era",
        duration: 4,
        modules: [
          {
            title: "Industrial Revolution",
            assignments: [
              { title: "Timeline Activity", type: "assignment" },
              { title: "Industrial Impact DBQ", type: "assessment" },
            ],
          },
          {
            title: "Immigration & Urbanization",
            assignments: [
              { title: "Immigration Stories Research", type: "assignment" },
              { title: "Urban Growth Analysis", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "World Wars",
        duration: 5,
        modules: [
          {
            title: "Causes & Alliances",
            assignments: [
              { title: "Alliance Mapping Activity", type: "assignment" },
              { title: "Causation Quiz", type: "assessment" },
            ],
          },
          {
            title: "Major Battles & Turning Points",
            assignments: [
              { title: "Battle Analysis", type: "assignment" },
              { title: "Turning Points Essay", type: "assessment" },
            ],
          },
          {
            title: "Home Front & Legacy",
            assignments: [
              { title: "Home Front Research", type: "assignment" },
              { title: "Legacy of WWII Assessment", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Modern America",
        duration: 4,
        modules: [
          {
            title: "Civil Rights Movement",
            assignments: [
              { title: "Civil Rights Leaders Profile", type: "assignment" },
              { title: "Movement Analysis Essay", type: "assessment" },
            ],
          },
          {
            title: "Cold War & Contemporary Issues",
            assignments: [
              { title: "Cold War Timeline", type: "assignment" },
              { title: "Contemporary Issues Debate", type: "assessment" },
            ],
          },
        ],
      },
    ],
  },
  {
    id: "math-simple",
    name: "Mathematics",
    subject: "math",
    framework: "ims",
    description:
      "Comprehensive math course with EdUnite's streamlined planning structure.",
    units: [
      {
        title: "Number Sense & Operations",
        duration: 4,
        modules: [
          {
            title: "Integers & Rational Numbers",
            assignments: [
              { title: "Number Line Activity", type: "assignment" },
              { title: "Operations Quiz", type: "assessment" },
            ],
          },
          {
            title: "Real-World Problem Solving",
            assignments: [
              { title: "Word Problem Set", type: "assignment" },
              { title: "Unit Test", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Algebraic Thinking",
        duration: 5,
        modules: [
          {
            title: "Expressions & Equations",
            assignments: [
              { title: "Equation Practice", type: "assignment" },
              { title: "Equations Quiz", type: "assessment" },
            ],
          },
          {
            title: "Functions & Graphing",
            assignments: [
              { title: "Graphing Activity", type: "assignment" },
              { title: "Functions Assessment", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Geometry & Measurement",
        duration: 4,
        modules: [
          {
            title: "Shapes & Properties",
            assignments: [
              { title: "Shape Classification", type: "assignment" },
              { title: "Geometry Quiz", type: "assessment" },
            ],
          },
          {
            title: "Area, Volume & Proof",
            assignments: [
              { title: "Measurement Problems", type: "assignment" },
              { title: "Geometry Unit Test", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Statistics & Probability",
        duration: 3,
        modules: [
          {
            title: "Data Analysis",
            assignments: [
              { title: "Data Set Analysis", type: "assignment" },
              { title: "Statistics Quiz", type: "assessment" },
            ],
          },
          {
            title: "Probability & Predictions",
            assignments: [
              { title: "Probability Simulation", type: "assignment" },
              { title: "Probability Test", type: "assessment" },
            ],
          },
        ],
      },
      {
        title: "Exam Prep",
        duration: 2,
        modules: [
          {
            title: "Review & Practice",
            assignments: [
              { title: "Mixed Review Set", type: "assignment" },
              { title: "Mock Exam", type: "assessment" },
            ],
          },
          {
            title: "Final Exam",
            assignments: [{ title: "Final Examination", type: "assessment" }],
          },
        ],
      },
      {
        title: "Extension Challenges",
        duration: 2,
        modules: [
          {
            title: "Advanced Problem Solving",
            assignments: [
              { title: "Challenge Problem Set", type: "assignment" },
              { title: "Extension Project", type: "assessment" },
            ],
          },
          {
            title: "Math Competitions Prep",
            assignments: [
              { title: "Competition Practice Problems", type: "assignment" },
            ],
          },
        ],
      },
    ],
  },
  {
    id: "blank",
    name: "Blank Course",
    subject: "blank",
    framework: null,
    description:
      "Start from scratch with an empty course. Add your own units and modules.",
    units: [],
  },
];
