import AppLayout from "@/components/layout/AppLayout";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  computeInvoiceBalance as computeBalanceHelper,
  computeInvoiceTotalPaid,
  deduplicatePaymentHistory,
} from "@/hooks/useQueries";
import {
  calculatePaymentSchedule,
  formatCurrency,
  formatDate,
  generateWhatsAppLink,
  getDeliveryStageLabel,
  getDeliveryStageProgress,
  getInitials,
  getMinimumAdvance,
  getPaymentStatus,
  getStatusColor,
  interpolateTemplate,
} from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import { useStudioStore } from "@/stores/useStudioStore";
import type { Invoice, PaymentHistoryEntry, TeamAssignment } from "@/types";
import { useNavigate, useParams } from "@tanstack/react-router";
import {
  ArrowLeft,
  Building2,
  CalendarClock,
  CheckCircle2,
  Clock,
  Download,
  MessageCircle,
  Pencil,
  Plus,
  Trash2,
  UserPlus,
  Users,
  XCircle,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { generateInvoicePDF } from "../lib/pdfGenerator";
const sortByDateTime = (
  a: {
    date?: string;
    dateRangeStart?: string;
    startDate?: string;
    time?: string;
    startTime?: string;
  },
  b: {
    date?: string;
    dateRangeStart?: string;
    startDate?: string;
    time?: string;
    startTime?: string;
  },
) => {
  const dateA = new Date(
    a.date || a.dateRangeStart || a.startDate || "",
  ).getTime();
  const dateB = new Date(
    b.date || b.dateRangeStart || b.startDate || "",
  ).getTime();
  if (dateA !== dateB) return dateA - dateB;
  const timeA = (a.time || a.startTime || "").toString();
  const timeB = (b.time || b.startTime || "").toString();
  return timeA.localeCompare(timeB);
};

/* A4 print styles */
if (
  typeof document !== "undefined" &&
  !document.getElementById("invoice-print-style")
) {
  const style = document.createElement("style");
  style.id = "invoice-print-style";
  style.textContent = `
    @media print {
      * { -webkit-print-color-adjust: exact !important; color-adjust: exact !important; }
      body > * { display: none !important; }
      #invoice-print-area { display: block !important; }
      #invoice-print-area {
        position: fixed; top: 0; left: 0;
        width: 210mm; min-height: 297mm;
        padding: 12mm 15mm;
        background: #fff !important; color: #000 !important;
        font-family: Arial, sans-serif;
      }
      @page { size: A4; margin: 0; }
    }
    @media screen { #invoice-print-area { display: none; } }
  `;
  document.head.appendChild(style);
}

export default function InvoiceDetailPage() {
  const { invoiceId } = useParams({ strict: false }) as { invoiceId: string };
  const navigate = useNavigate();
  const {
    invoices,
    updateInvoice,
    deleteInvoice,
    addPaymentToInvoice,
    editPaymentInInvoice,
    deletePaymentInInvoice,
  } = useERPStore();
  const studioProfile = useStudioStore((s) => s.studioProfile);

  const invoice = invoices.find((i) => i.id === invoiceId) ?? null;

  const teamMembers = useERPStore((s) => s.teamMembers);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [editingPayment, setEditingPayment] =
    useState<PaymentHistoryEntry | null>(null);
  const [deletingPaymentId, setDeletingPaymentId] = useState<string | null>(
    null,
  );
  const [showTeamReminderDialog, setShowTeamReminderDialog] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isPdfGenerating, setIsPdfGenerating] = useState(false);
  const [editingAssignment, setEditingAssignment] =
    useState<TeamAssignment | null>(null);
  const [deletingAssignmentId, setDeletingAssignmentId] = useState<
    string | null
  >(null);

  const {
    updateTeamAssignment,
    deleteTeamAssignment,
    recordPaymentByAssignmentId,
  } = useERPStore();
  const [payingAssignment, setPayingAssignment] = useState<any | null>(null);
  const [payRemainingAmount, setPayRemainingAmount] = useState<string>("");

  if (!invoice) {
    return (
      <AppLayout>
        <div className="max-w-4xl mx-auto text-center py-20">
          <h3 className="text-xl font-display font-bold text-foreground">
            Invoice not found
          </h3>
          <Button
            className="mt-4"
            onClick={() => navigate({ to: "/invoices" })}
          >
            Back to Invoices
          </Button>
        </div>
      </AppLayout>
    );
  }

  const payStatus = getPaymentStatus(invoice);
  const dealAmount = Number(invoice.dealAmount) || 0;
  const discount = Number(invoice.discount) || 0;
  const subtotal = dealAmount - discount;
  const gstPct =
    invoice.gstEnabled &&
    (invoice.gstPercent ?? studioProfile?.gstPercent ?? 0) > 0
      ? (invoice.gstPercent ?? studioProfile?.gstPercent ?? 0)
      : 0;
  const extraChargesTotal = (invoice.packageExtraCharges ?? []).reduce(
    (sum, c) => sum + (Number(c.extraTotal) || 0),
    0,
  );
  const gstAmount = (subtotal + extraChargesTotal) * (gstPct / 100);
  const grandTotal = subtotal + extraChargesTotal + gstAmount;
  const totalPaid = computeInvoiceTotalPaid(invoice);
  const pendingBalance = computeBalanceHelper(invoice);

  const schedule = calculatePaymentSchedule(
    invoice.totalAmount || grandTotal,
    invoice.eventStartDate,
    invoice.eventEndDate,
  );

  // Build vars map used for all template interpolation
  const templateVars: Record<string, string> = {
    clientName: invoice.clientName ?? "—",
    eventName: invoice.eventType ?? "—",
    programName:
      invoice.programs?.find((p) => p.enabled)?.name ??
      invoice.eventType ??
      "—",
    eventDate: invoice.eventStartDate
      ? formatDate(invoice.eventStartDate)
      : "—",
    eventTime: invoice.programs?.find((p) => p.enabled)?.startTime ?? "—",
    venue: invoice.eventVenueName ?? invoice.eventVenueAddress ?? "—",
    invoiceNumber: invoice.invoiceNumber ?? "—",
    paidAmount: formatCurrency(totalPaid),
    balance: formatCurrency(pendingBalance),
    assignedTeam:
      invoice.teamAssignments?.map((a) => a.teamMemberName).join(", ") ?? "—",
  };

  const advanceTemplate =
    localStorage.getItem("wa_advance") ??
    "Hello {clientName},\n\nThank you for booking with us! 📸\n\nThis is a reminder that your advance payment for Invoice #{invoiceNumber} is due.\n\nEvent: {eventName}\nEvent Date: {eventDate}\nVenue: {venue}\nAmount Paid: {paidAmount}\nBalance Remaining: {balance}\n\nKindly make the payment at your earliest convenience. Thank you!";
  const whatsappMsg = interpolateTemplate(advanceTemplate, templateVars);

  async function handleDownloadPdf() {
    if (!invoice) return;
    setIsPdfGenerating(true);
    try {
      const blob = await generateInvoicePDF(invoice, studioProfile);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Invoice-${invoice.invoiceNumber || "download"}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success("Invoice PDF downloaded!");
    } catch (err) {
      console.error("PDF error:", err);
      toast.error("Failed to generate PDF. Please try again.");
    } finally {
      setIsPdfGenerating(false);
    }
  }

  async function handleWhatsApp() {
    if (!invoice) return;
    try {
      const blob = await generateInvoicePDF(invoice, studioProfile);
      const file = new File(
        [blob],
        `Invoice-${invoice.invoiceNumber || "download"}.pdf`,
        { type: "application/pdf" },
      );
      if (
        typeof navigator !== "undefined" &&
        navigator.share &&
        navigator.canShare?.({ files: [file] })
      ) {
        await navigator.share({
          title: `Invoice ${invoice.invoiceNumber}`,
          text: whatsappMsg,
          files: [file],
        });
        return;
      }
    } catch (_) {
      // Web Share API not available or cancelled — fall back
    }
    // Fallback: download PDF + open WhatsApp with text
    try {
      const blob = await generateInvoicePDF(invoice, studioProfile);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Invoice-${invoice.invoiceNumber || "download"}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (_) {
      // ignore download error
    }
    const link = generateWhatsAppLink(
      invoice?.clientWhatsapp || "",
      whatsappMsg,
    );
    window.open(link, "_blank");
    toast.success(
      "PDF downloaded. Open WhatsApp to share it with your client.",
      { duration: 6000 },
    );
  }

  function handleAddPayment(entry: PaymentHistoryEntry) {
    if (!invoice) return;
    addPaymentToInvoice(invoice.id, entry);
    setShowPaymentModal(false);
    toast.success("Payment recorded. Balance updated.");
  }

  function handleEditPayment(updated: PaymentHistoryEntry) {
    if (!invoice) return;
    setIsSaving(true);
    try {
      editPaymentInInvoice(invoice.id, updated.id, updated);
      setEditingPayment(null);
      toast.success("Payment updated");
    } finally {
      setIsSaving(false);
    }
  }

  function handleDeletePayment(paymentId: string) {
    if (!invoice) return;
    deletePaymentInInvoice(invoice.id, paymentId);
    setDeletingPaymentId(null);
    toast.success("Payment removed");
  }

  function handleSendTeamReminder(memberId: string, memberName: string) {
    const rawTemplate =
      localStorage.getItem("wa_teamReminder") ??
      "Hello {teamMemberName},\nYou are assigned for:\nClient: {clientName}\nProgram: {programName}\nDate: {eventDate}\nTime: {eventTime}\nLocation: {venue}\nRole: {assignedTeam}\n\nPlease confirm your availability. Thank you!";

    const assignments = (invoice?.teamAssignments ?? []).filter(
      (a) => a.teamMemberId === memberId,
    );
    const assignment = assignments[0];
    const member = teamMembers.find((m) => m.id === memberId);

    if (!member?.phone) {
      toast.error(
        `No phone number for ${memberName}. Add it in Team Management.`,
      );
      return;
    }

    const vars: Record<string, string> = {
      teamMemberName: memberName ?? "—",
      clientName: invoice?.clientName ?? "—",
      eventName: invoice?.eventType ?? "—",
      programName: assignment?.program ?? invoice?.eventType ?? "—",
      eventDate: assignment?.date
        ? formatDate(assignment.date)
        : formatDate(invoice?.eventStartDate ?? ""),
      eventTime:
        assignment?.startTime && assignment?.endTime
          ? `${assignment.startTime} – ${assignment.endTime}`
          : (assignment?.startTime ?? "—"),
      venue:
        assignment?.location ??
        invoice?.eventVenueName ??
        invoice?.eventVenueAddress ??
        "—",
      assignedTeam: member?.role ?? "Photographer",
      invoiceNumber: invoice?.invoiceNumber ?? "—",
      balance: formatCurrency(
        Math.max(0, (invoice?.totalAmount ?? 0) - (invoice?.advancePaid ?? 0)),
      ),
    };

    const msg = interpolateTemplate(rawTemplate, vars);
    const phone = member.phone.replace(/[^0-9]/g, "");
    const link = `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
    window.open(link, "_blank");
  }

  function handleCancelBooking() {
    if (!invoice) return;
    updateInvoice(invoice.id, { status: "cancelled" as Invoice["status"] });
    toast.success("Booking cancelled");
  }

  function handleDeleteInvoice() {
    if (!invoice) return;
    deleteInvoice(invoice.id);
    toast.success("Invoice deleted");
    navigate({ to: "/invoices" });
  }

  return (
    <AppLayout>
      <div
        data-ocid="invoice_detail.page"
        className="max-w-4xl mx-auto space-y-6 pb-20 lg:pb-6"
      >
        {/* Page header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="gap-1"
              data-ocid="invoice_detail.back_button"
              onClick={() => navigate({ to: "/invoices" })}
            >
              <ArrowLeft className="w-4 h-4" /> Back
            </Button>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xl font-mono font-bold text-foreground">
                  {invoice.invoiceNumber}
                </h2>
                <Badge
                  variant="outline"
                  className={`text-xs border capitalize ${getStatusColor(payStatus)}`}
                >
                  {payStatus}
                </Badge>
                {(invoice.status as string) === "cancelled" && (
                  <Badge
                    variant="outline"
                    className="text-xs border bg-muted text-muted-foreground"
                  >
                    Cancelled
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground mt-0.5">
                {invoice.eventType} \u2022 {invoice.clientName}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-1.5"
              data-ocid="invoice_detail.add_payment_button"
              onClick={() => setShowPaymentModal(true)}
            >
              <Plus className="w-4 h-4" /> Add Payment
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-1.5"
              data-ocid="invoice_detail.edit_button"
              onClick={() => navigate({ to: `/invoices/${invoice.id}/edit` })}
            >
              <Pencil className="w-4 h-4" /> Edit
            </Button>
            {(invoice.status as string) !== "cancelled" && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="gap-1.5 text-yellow-600 border-yellow-300"
                data-ocid="invoice_detail.cancel_button"
                onClick={handleCancelBooking}
              >
                <XCircle className="w-4 h-4" /> Cancel Booking
              </Button>
            )}
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-1.5 text-destructive border-destructive/30"
              data-ocid="invoice_detail.delete_button"
              onClick={() => setShowDeleteDialog(true)}
            >
              <Trash2 className="w-4 h-4" /> Delete
            </Button>
          </div>
        </div>

        {/* Printable invoice card */}
        <div
          id="print-invoice"
          className="bg-card border border-border rounded-xl overflow-hidden print:border-0 print:rounded-none print:shadow-none"
        >
          {/* Studio header */}
          <div className="bg-primary px-6 py-5 print:bg-transparent print:border-b-2 print:border-primary">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                {studioProfile?.logo ? (
                  <img
                    src={studioProfile.logo}
                    alt="Studio Logo"
                    className="w-14 h-14 rounded-xl object-cover bg-white/20"
                  />
                ) : (
                  <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center">
                    <Building2 className="w-7 h-7 text-white" />
                  </div>
                )}
                <div>
                  <h1 className="text-xl font-display font-bold text-white">
                    {studioProfile?.name ?? "Photography Studio"}
                  </h1>
                  <p className="text-white/70 text-sm">
                    {studioProfile?.address}
                  </p>
                  <p className="text-white/70 text-sm">
                    {studioProfile?.phone}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-mono font-bold text-2xl text-white">
                  {invoice.invoiceNumber}
                </p>
                {studioProfile?.gstNumber && (
                  <p className="text-white/70 text-xs mt-1">
                    GST: {studioProfile.gstNumber}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="p-6 space-y-6">
            {/* Client & Event info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  Client Details
                </h4>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                    {getInitials(invoice.clientName)}
                  </div>
                  <p className="font-semibold text-foreground text-lg">
                    {invoice.clientName}
                  </p>
                </div>
                <p className="text-sm text-muted-foreground">
                  {invoice.clientWhatsapp || invoice.clientPhone}
                </p>
                {invoice.clientAddress && (
                  <p className="text-sm text-muted-foreground mt-1">
                    {invoice.clientAddress}
                  </p>
                )}
                {invoice.clientCity && (
                  <p className="text-sm text-muted-foreground">
                    {invoice.clientCity}
                  </p>
                )}
              </div>
              <div>
                <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  Event Details
                </h4>
                <Badge className="mb-2">{invoice.eventType}</Badge>
                {invoice.packageName && (
                  <p className="text-sm text-foreground mb-1">
                    <span className="text-muted-foreground">Package:</span>{" "}
                    {invoice.packageName}
                  </p>
                )}
                {invoice.eventStartDate && (
                  <p className="text-sm text-foreground">
                    <span className="text-muted-foreground">From:</span>{" "}
                    {formatDate(invoice.eventStartDate)}
                  </p>
                )}
                {invoice.eventEndDate &&
                  invoice.eventEndDate !== invoice.eventStartDate && (
                    <p className="text-sm text-foreground">
                      <span className="text-muted-foreground">To:</span>{" "}
                      {formatDate(invoice.eventEndDate)}
                    </p>
                  )}
                {invoice.eventVenueName && (
                  <p className="text-sm text-foreground mt-1">
                    <span className="text-muted-foreground">Venue:</span>{" "}
                    {invoice.eventVenueName}
                  </p>
                )}
                {invoice.eventVenueAddress && (
                  <p className="text-sm text-muted-foreground">
                    {invoice.eventVenueAddress}
                  </p>
                )}
              </div>
            </div>

            {/* Wedding programs */}
            {invoice.programs && invoice.programs.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                  Programs
                </h4>
                <div className="border border-border rounded-lg overflow-hidden">
                  <div className="overflow-x-auto w-full">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/40">
                        <tr>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground">
                            Program
                          </th>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground">
                            Date
                          </th>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground">
                            Time
                          </th>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground hidden sm:table-cell">
                            Notes
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {[...invoice.programs]
                          .sort(sortByDateTime)
                          .filter((p) => p.enabled)
                          .map((prog) => (
                            <tr key={prog.id}>
                              <td className="px-3 py-2 font-medium">
                                {prog.name}
                              </td>
                              <td className="px-3 py-2 text-muted-foreground">
                                {prog.date ? formatDate(prog.date) : "\u2014"}
                              </td>
                              <td className="px-3 py-2 text-muted-foreground">
                                {prog.startTime || "\u2014"}
                              </td>
                              <td className="px-3 py-2 text-muted-foreground hidden sm:table-cell">
                                {prog.notes || "\u2014"}
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* Services */}
            {invoice.services && invoice.services.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                  Services
                </h4>
                <div className="border border-border rounded-lg overflow-hidden">
                  <div className="overflow-x-auto w-full">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/40">
                        <tr>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground">
                            Service
                          </th>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground hidden sm:table-cell">
                            Category
                          </th>
                          <th className="text-right px-3 py-2 font-semibold text-muted-foreground">
                            Qty
                          </th>
                          <th className="text-right px-3 py-2 font-semibold text-muted-foreground">
                            Rate
                          </th>
                          <th className="text-right px-3 py-2 font-semibold text-muted-foreground">
                            Total
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {invoice.services.map((svc, i) => (
                          // biome-ignore lint/suspicious/noArrayIndexKey: order-stable
                          <tr key={i}>
                            <td className="px-3 py-2 font-medium">
                              {svc.name}
                            </td>
                            <td className="px-3 py-2 text-muted-foreground capitalize hidden sm:table-cell">
                              {svc.category}
                            </td>
                            <td className="px-3 py-2 text-right text-muted-foreground">
                              {svc.quantity}
                            </td>
                            <td className="px-3 py-2 text-right text-muted-foreground">
                              {formatCurrency(svc.unitPrice)}
                            </td>
                            <td className="px-3 py-2 text-right font-semibold">
                              {formatCurrency(svc.total)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* Package extra charges */}
            {(invoice.packageExtraCharges ?? []).length > 0 && (
              <div>
                <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                  Package Extra Charges
                </h4>
                <div className="border border-amber-200 rounded-lg overflow-hidden bg-amber-50/50">
                  <div className="overflow-x-auto w-full">
                    <table className="w-full text-sm">
                      <thead className="bg-amber-100/50">
                        <tr>
                          <th className="text-left px-3 py-2 font-semibold text-amber-700">
                            Service
                          </th>
                          <th className="text-center px-3 py-2 font-semibold text-amber-700">
                            Included
                          </th>
                          <th className="text-center px-3 py-2 font-semibold text-amber-700">
                            Actual
                          </th>
                          <th className="text-right px-3 py-2 font-semibold text-amber-700">
                            Extra Total
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-amber-100">
                        {invoice.packageExtraCharges!.map((c, i) => (
                          // biome-ignore lint/suspicious/noArrayIndexKey: order-stable
                          <tr key={i}>
                            <td className="px-3 py-2 font-medium">
                              {c.ruleName}
                            </td>
                            <td className="px-3 py-2 text-center text-muted-foreground">
                              {Number(c.includedQuantity)}
                            </td>
                            <td className="px-3 py-2 text-center text-muted-foreground">
                              {Number(c.actualQuantity)}
                            </td>
                            <td className="px-3 py-2 text-right font-semibold text-amber-700">
                              +{formatCurrency(Number(c.extraTotal))}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* Team Assignments */}
            {(invoice.teamAssignments ?? []).length > 0 && (
              <div>
                <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Users className="w-3.5 h-3.5" /> Team Assignments
                </h4>
                <div className="border border-border rounded-lg overflow-hidden">
                  <div className="overflow-x-auto w-full">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/40">
                        <tr>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground">
                            Member
                          </th>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground hidden sm:table-cell">
                            Program
                          </th>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground hidden sm:table-cell">
                            Date
                          </th>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground">
                            Day Type
                          </th>
                          <th className="text-right px-3 py-2 font-semibold text-muted-foreground hidden md:table-cell">
                            Rate
                          </th>
                          <th className="px-3 py-2 text-right print:hidden">
                            Paid / Due
                          </th>
                          <th className="px-3 py-2 w-20 print:hidden" />
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {(invoice.teamAssignments ?? [])
                          .sort(sortByDateTime)
                          .map((a, idx) => {
                            const isHalf = a.dayType === "half";
                            const hasRange = a.dateRangeStart && a.dateRangeEnd;
                            const dateDisplay = hasRange
                              ? `${formatDate(a.dateRangeStart!)} – ${formatDate(a.dateRangeEnd!)}`
                              : a.date
                                ? formatDate(a.date)
                                : "—";
                            return (
                              <tr
                                key={a.id ?? idx}
                                className="hover:bg-muted/30 transition-colors"
                                data-ocid={`invoice_detail.team_assignment_row.${idx + 1}`}
                              >
                                <td className="px-3 py-2">
                                  <p className="font-medium text-sm">
                                    {a.teamMemberName}
                                  </p>
                                  {a.role && (
                                    <p className="text-xs text-muted-foreground">
                                      {a.role}
                                    </p>
                                  )}
                                </td>
                                <td className="px-3 py-2 text-muted-foreground hidden sm:table-cell">
                                  {a.program || "—"}
                                </td>
                                <td className="px-3 py-2 hidden sm:table-cell">
                                  <span className="text-xs text-muted-foreground">
                                    {dateDisplay}
                                  </span>
                                </td>
                                <td className="px-3 py-2">
                                  <Badge
                                    variant="outline"
                                    className={`text-[10px] ${
                                      isHalf
                                        ? "border-amber-300 text-amber-600"
                                        : "border-green-300 text-green-600"
                                    }`}
                                  >
                                    {isHalf ? "Half Day" : "Full Day"}
                                  </Badge>
                                </td>
                                <td className="px-3 py-2 text-right hidden md:table-cell">
                                  <span className="text-xs font-medium">
                                    {(a.rateUsed ?? 0) > 0
                                      ? formatCurrency(
                                          isHalf
                                            ? (a.rateUsed ?? 0) * 0.5
                                            : (a.rateUsed ?? 0),
                                        )
                                      : "—"}
                                  </span>
                                  {isHalf && (a.rateUsed ?? 0) > 0 && (
                                    <p className="text-[10px] text-amber-600">
                                      ×50%
                                    </p>
                                  )}
                                </td>
                                <td className="px-3 py-2 text-right text-sm print:hidden">
                                  <div className="space-y-1">
                                    <span className="text-green-600">
                                      Paid: ₹
                                      {(
                                        a.paymentReceived || 0
                                      ).toLocaleString()}
                                    </span>
                                    <span className="text-red-500 block">
                                      Due: ₹
                                      {(a.paymentPending || 0).toLocaleString()}
                                    </span>
                                    {(a.paymentPending || 0) > 0 && (
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setPayingAssignment(a);
                                          setPayRemainingAmount(
                                            String(a.paymentPending || ""),
                                          );
                                        }}
                                        className="mt-1 px-2 py-0.5 text-xs bg-blue-500 hover:bg-blue-600 text-white rounded"
                                      >
                                        Pay Due
                                      </button>
                                    )}
                                  </div>
                                </td>
                                <td className="px-3 py-2 print:hidden">
                                  <div className="flex items-center gap-1 justify-end">
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="icon"
                                      className="h-7 w-7"
                                      aria-label="Edit assignment"
                                      data-ocid={`invoice_detail.edit_assignment_button.${idx + 1}`}
                                      onClick={() =>
                                        setEditingAssignment({ ...a })
                                      }
                                    >
                                      <Pencil className="w-3 h-3" />
                                    </Button>
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="icon"
                                      className="h-7 w-7 text-destructive"
                                      aria-label="Delete assignment"
                                      data-ocid={`invoice_detail.delete_assignment_button.${idx + 1}`}
                                      onClick={() =>
                                        setDeletingAssignmentId(a.id ?? null)
                                      }
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </Button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* Payment summary */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                  Payment Summary
                </h4>
                <div className="space-y-2">
                  <PayRow
                    label="Deal Amount"
                    value={formatCurrency(invoice.dealAmount)}
                  />
                  {(invoice.discount ?? 0) > 0 && (
                    <PayRow
                      label="Discount"
                      value={`-${formatCurrency(invoice.discount ?? 0)}`}
                      className="text-green-600"
                    />
                  )}
                  {extraChargesTotal > 0 && (
                    <PayRow
                      label="Package Extra Charges"
                      value={`+${formatCurrency(extraChargesTotal)}`}
                      className="text-amber-600"
                    />
                  )}
                  <PayRow
                    label="Subtotal"
                    value={formatCurrency(subtotal + extraChargesTotal)}
                  />
                  {gstPct > 0 && (
                    <PayRow
                      label={`GST (${gstPct}%)`}
                      value={formatCurrency(gstAmount)}
                    />
                  )}
                  <div className="border-t border-border pt-2">
                    <PayRow
                      label="Grand Total"
                      value={formatCurrency(grandTotal)}
                      className="font-bold text-foreground text-base"
                    />
                  </div>
                  <PayRow
                    label="Minimum Advance Required"
                    value={formatCurrency(getMinimumAdvance(grandTotal))}
                    className="text-amber-600 text-xs"
                  />
                  <PayRow
                    label="Amount Paid"
                    value={formatCurrency(totalPaid)}
                    className="text-green-600"
                  />
                  <div className="border-t border-border pt-2">
                    <PayRow
                      label="Balance Due"
                      value={formatCurrency(pendingBalance)}
                      className={
                        pendingBalance > 0
                          ? "font-bold text-destructive text-base"
                          : "font-bold text-green-600 text-base"
                      }
                    />
                  </div>
                </div>
              </div>

              {/* UPI / QR */}
              {studioProfile?.upiId && (
                <div>
                  <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                    Pay via UPI
                  </h4>
                  <div className="bg-muted/30 rounded-lg p-4 text-center space-y-2">
                    <div className="w-20 h-20 bg-muted rounded-lg mx-auto flex items-center justify-center">
                      <span className="text-3xl">&#x1F4F1;</span>
                    </div>
                    <p className="font-mono text-sm font-bold text-foreground">
                      {studioProfile.upiId}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Scan or pay to this UPI ID
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Payment Schedule — always shown */}
            <div>
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                <CalendarClock className="w-3.5 h-3.5" /> Payment Schedule
              </h4>
              {schedule ? (
                <div className="border border-border rounded-lg overflow-hidden">
                  <div className="overflow-x-auto w-full">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/40">
                        <tr>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground">
                            Installment
                          </th>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground">
                            Due Date
                          </th>
                          <th className="text-right px-3 py-2 font-semibold text-muted-foreground">
                            Amount
                          </th>
                          <th className="text-center px-3 py-2 font-semibold text-muted-foreground">
                            Status
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {(
                          [
                            {
                              title: "1st – Advance",
                              amount: schedule.advance,
                              dueDate: schedule.advanceDue,
                            },
                            {
                              title: "2nd Installment",
                              amount: schedule.secondInstallment,
                              dueDate: schedule.secondDue,
                            },
                            {
                              title: "3rd Installment",
                              amount: schedule.thirdInstallment,
                              dueDate: schedule.thirdDue,
                            },
                          ] as Array<{
                            title: string;
                            amount: number;
                            dueDate: string;
                          }>
                        ).map((inst, i) => {
                          const isOverdue =
                            !!inst.dueDate &&
                            new Date(inst.dueDate) < new Date();
                          const statusLabel = isOverdue ? "overdue" : "pending";
                          return (
                            <tr
                              key={inst.title}
                              data-ocid={`invoice_detail.installment.${i + 1}`}
                            >
                              <td className="px-3 py-2 font-medium">
                                {inst.title}
                              </td>
                              <td className="px-3 py-2 text-muted-foreground">
                                {inst.dueDate
                                  ? formatDate(inst.dueDate)
                                  : "\u2014"}
                              </td>
                              <td className="px-3 py-2 text-right font-semibold">
                                {formatCurrency(inst.amount)}
                              </td>
                              <td className="px-3 py-2 text-center">
                                <Badge
                                  variant="outline"
                                  className={`text-[10px] capitalize ${getStatusColor(statusLabel)}`}
                                >
                                  {statusLabel}
                                </Badge>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="border border-dashed border-border rounded-lg p-4 text-center">
                  <p className="text-sm text-muted-foreground">
                    No installment schedule. Set deal amount and event dates to
                    auto-generate.
                  </p>
                </div>
              )}
            </div>

            {/* Payment history with edit/delete */}
            {invoice.paymentHistory && invoice.paymentHistory.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                  Payment History
                </h4>
                <div className="border border-border rounded-lg overflow-hidden">
                  <div className="overflow-x-auto w-full">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/40">
                        <tr>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground">
                            Date
                          </th>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground">
                            Method
                          </th>
                          <th className="text-right px-3 py-2 font-semibold text-muted-foreground">
                            Amount
                          </th>
                          <th className="text-left px-3 py-2 font-semibold text-muted-foreground hidden sm:table-cell">
                            Notes
                          </th>
                          <th className="px-3 py-2 w-20 print:hidden" />
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {deduplicatePaymentHistory(
                          invoice.paymentHistory ?? [],
                        ).map((pay, idx) => (
                          <tr
                            key={pay.id}
                            data-ocid={`invoice_detail.payment_row.${idx + 1}`}
                          >
                            <td className="px-3 py-2 text-muted-foreground">
                              {formatDate(pay.date)}
                            </td>
                            <td className="px-3 py-2">
                              <Badge
                                variant="secondary"
                                className="text-[10px] px-1.5 h-5 capitalize"
                              >
                                {pay.mode}
                              </Badge>
                            </td>
                            <td className="px-3 py-2 text-right font-semibold text-green-600">
                              {formatCurrency(pay.amount)}
                            </td>
                            <td className="px-3 py-2 text-muted-foreground hidden sm:table-cell">
                              {pay.notes || "\u2014"}
                            </td>
                            <td className="px-3 py-2 print:hidden">
                              <div className="flex items-center gap-1 justify-end">
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7"
                                  data-ocid={`invoice_detail.edit_payment_button.${idx + 1}`}
                                  onClick={() => setEditingPayment({ ...pay })}
                                >
                                  <Pencil className="w-3 h-3" />
                                </Button>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 text-destructive"
                                  data-ocid={`invoice_detail.delete_payment_button.${idx + 1}`}
                                  onClick={() => setDeletingPaymentId(pay.id)}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* Signature */}
            <div className="flex items-end justify-between pt-4 border-t border-border">
              <div className="text-xs text-muted-foreground space-y-1 max-w-sm">
                {invoice.termsAndConditions && (
                  <>
                    <p className="font-semibold text-foreground text-[11px] uppercase tracking-wider mb-1">
                      Terms & Conditions
                    </p>
                    <p className="whitespace-pre-line">
                      {invoice.termsAndConditions}
                    </p>
                  </>
                )}
              </div>
              <div className="text-center">
                {studioProfile?.signature ? (
                  <img
                    src={studioProfile.signature}
                    alt="Signature"
                    className="h-12 w-24 object-contain mb-1"
                  />
                ) : (
                  <div className="h-12 w-24 border-b-2 border-foreground mb-1" />
                )}
                <p className="text-xs text-muted-foreground">
                  Authorized Signature
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap gap-3">
          <Button
            type="button"
            variant="outline"
            className="gap-2"
            data-ocid="invoice_detail.download_pdf_button"
            onClick={handleDownloadPdf}
            disabled={isPdfGenerating}
          >
            <Download className="w-4 h-4" />
            {isPdfGenerating ? "Generating…" : "Download PDF"}
          </Button>
          <Button
            type="button"
            variant="outline"
            className="gap-2 text-green-700 border-green-300 hover:bg-green-50"
            data-ocid="invoice_detail.whatsapp_button"
            onClick={handleWhatsApp}
          >
            <MessageCircle className="w-4 h-4" /> Share on WhatsApp
          </Button>
          <Button
            type="button"
            variant="outline"
            className="gap-2 text-blue-700 border-blue-300 hover:bg-blue-50"
            data-ocid="invoice_detail.team_reminder_button"
            onClick={() => {
              if (!invoice?.teamAssignments?.length) {
                toast.warning("No team members assigned to this invoice.");
              } else {
                setShowTeamReminderDialog(true);
              }
            }}
          >
            <MessageCircle className="w-4 h-4" /> Send Team Reminders
          </Button>
          <Button
            type="button"
            className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            data-ocid="invoice_detail.assign_team_button"
            onClick={() => {
              window.location.href = `/team?invoiceId=${invoice.id}&clientName=${encodeURIComponent(invoice.clientName ?? "")}&newAssignment=true`;
            }}
          >
            <UserPlus className="w-4 h-4" /> Assign Team Member
          </Button>
        </div>
      </div>

      {/* Hidden printable invoice area — A4 format */}
      <div id="invoice-print-area">
        <div
          style={{
            fontFamily: "Arial, sans-serif",
            maxWidth: "800px",
            margin: "0 auto",
            padding: "24px",
          }}
        >
          <div
            style={{
              background: "#dc2626",
              color: "#fff",
              padding: "20px 24px",
              marginBottom: "24px",
              borderRadius: "8px",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
              }}
            >
              <div>
                <h1 style={{ margin: 0, fontSize: "20px" }}>
                  {studioProfile?.name ?? "Photography Studio"}
                </h1>
                <p
                  style={{ margin: "4px 0 0", opacity: 0.8, fontSize: "13px" }}
                >
                  {studioProfile?.address}
                </p>
                <p
                  style={{ margin: "2px 0 0", opacity: 0.8, fontSize: "13px" }}
                >
                  {studioProfile?.phone}
                </p>
              </div>
              <div style={{ textAlign: "right" }}>
                <p style={{ margin: 0, fontSize: "22px", fontWeight: 700 }}>
                  {invoice.invoiceNumber}
                </p>
                {studioProfile?.gstNumber && (
                  <p
                    style={{
                      margin: "4px 0 0",
                      opacity: 0.8,
                      fontSize: "12px",
                    }}
                  >
                    GST: {studioProfile.gstNumber}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "24px",
              marginBottom: "24px",
            }}
          >
            <div>
              <p
                style={{
                  fontSize: "10px",
                  textTransform: "uppercase",
                  letterSpacing: "0.08em",
                  color: "#666",
                  marginBottom: "8px",
                }}
              >
                Client
              </p>
              <p style={{ fontSize: "16px", fontWeight: 600, margin: 0 }}>
                {invoice.clientName}
              </p>
              <p style={{ fontSize: "13px", color: "#666", margin: "2px 0" }}>
                {invoice.clientWhatsapp || invoice.clientPhone}
              </p>
              {invoice.clientAddress && (
                <p style={{ fontSize: "13px", color: "#666", margin: "2px 0" }}>
                  {invoice.clientAddress}
                </p>
              )}
            </div>
            <div>
              <p
                style={{
                  fontSize: "10px",
                  textTransform: "uppercase",
                  letterSpacing: "0.08em",
                  color: "#666",
                  marginBottom: "8px",
                }}
              >
                Event
              </p>
              <p style={{ fontSize: "14px", fontWeight: 600, margin: 0 }}>
                {invoice.eventType}
              </p>
              {invoice.packageName && (
                <p style={{ fontSize: "12px", color: "#666", margin: "2px 0" }}>
                  Package: {invoice.packageName}
                </p>
              )}
              {invoice.eventStartDate && (
                <p style={{ fontSize: "13px", color: "#666", margin: "2px 0" }}>
                  {formatDate(invoice.eventStartDate)}
                </p>
              )}
              {invoice.eventVenueName && (
                <p style={{ fontSize: "13px", color: "#666", margin: "2px 0" }}>
                  Venue: {invoice.eventVenueName}
                </p>
              )}
            </div>
          </div>

          {/* Services table */}
          {invoice.services && invoice.services.length > 0 && (
            <table
              style={{
                width: "100%",
                borderCollapse: "collapse",
                marginBottom: "24px",
                fontSize: "13px",
              }}
            >
              <thead>
                <tr style={{ background: "#f5f5f5" }}>
                  {["Service", "Qty", "Rate", "Total"].map((h) => (
                    <th
                      key={h}
                      style={{
                        padding: "8px 12px",
                        textAlign: "left",
                        fontSize: "11px",
                        textTransform: "uppercase",
                        color: "#666",
                      }}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {invoice.services.map((svc, i) => (
                  // biome-ignore lint/suspicious/noArrayIndexKey: order-stable
                  <tr key={i} style={{ borderBottom: "1px solid #eee" }}>
                    <td style={{ padding: "8px 12px" }}>{svc.name}</td>
                    <td style={{ padding: "8px 12px" }}>{svc.quantity}</td>
                    <td style={{ padding: "8px 12px" }}>
                      {formatCurrency(svc.unitPrice)}
                    </td>
                    <td
                      style={{
                        padding: "8px 12px",
                        fontWeight: 600,
                        textAlign: "right",
                      }}
                    >
                      {formatCurrency(svc.total)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* Payment schedule */}
          {schedule && (
            <div style={{ marginBottom: "24px" }}>
              <p
                style={{
                  fontSize: "11px",
                  textTransform: "uppercase",
                  letterSpacing: "0.08em",
                  color: "#666",
                  marginBottom: "8px",
                }}
              >
                Payment Schedule
              </p>
              <table
                style={{
                  width: "100%",
                  borderCollapse: "collapse",
                  fontSize: "13px",
                }}
              >
                <thead>
                  <tr style={{ background: "#f5f5f5" }}>
                    {["Installment", "Due Date", "Amount"].map((h) => (
                      <th
                        key={h}
                        style={{
                          padding: "6px 12px",
                          textAlign: "left",
                          fontSize: "11px",
                          color: "#666",
                        }}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    {
                      title: "1st – Advance",
                      amount: schedule.advance,
                      dueDate: schedule.advanceDue,
                    },
                    {
                      title: "2nd Installment",
                      amount: schedule.secondInstallment,
                      dueDate: schedule.secondDue,
                    },
                    {
                      title: "3rd Installment",
                      amount: schedule.thirdInstallment,
                      dueDate: schedule.thirdDue,
                    },
                  ].map((inst, i) => (
                    // biome-ignore lint/suspicious/noArrayIndexKey: order-stable
                    <tr key={i} style={{ borderBottom: "1px solid #eee" }}>
                      <td style={{ padding: "6px 12px" }}>{inst.title}</td>
                      <td style={{ padding: "6px 12px", color: "#666" }}>
                        {inst.dueDate ? formatDate(inst.dueDate) : "\u2014"}
                      </td>
                      <td style={{ padding: "6px 12px", fontWeight: 600 }}>
                        {formatCurrency(inst.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Totals */}
          <div
            style={{
              marginLeft: "auto",
              width: "260px",
              fontSize: "13px",
              marginBottom: "24px",
            }}
          >
            {[
              { label: "Deal Amount", val: formatCurrency(invoice.dealAmount) },
              ...(invoice.discount
                ? [
                    {
                      label: "Discount",
                      val: `-${formatCurrency(invoice.discount)}`,
                    },
                  ]
                : []),
              ...(extraChargesTotal > 0
                ? [
                    {
                      label: "Extra Charges",
                      val: `+${formatCurrency(extraChargesTotal)}`,
                      color: "#d97706",
                    },
                  ]
                : []),
              {
                label: "Subtotal",
                val: formatCurrency(subtotal + extraChargesTotal),
              },
              ...(gstPct > 0
                ? [
                    {
                      label: `GST (${gstPct}%)`,
                      val: formatCurrency(gstAmount),
                    },
                  ]
                : []),
              {
                label: "Grand Total",
                val: formatCurrency(grandTotal),
                bold: true,
              },
              { label: "Paid", val: formatCurrency(totalPaid), color: "green" },
              {
                label: "Balance Due",
                val: formatCurrency(pendingBalance),
                bold: true,
                color: pendingBalance > 0 ? "red" : "green",
              },
            ].map((row) => (
              <div
                key={row.label}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  padding: "4px 0",
                  borderBottom: "1px solid #eee",
                  fontWeight: "bold" in row && row.bold ? 700 : 400,
                  color: "color" in row && row.color ? row.color : "inherit",
                }}
              >
                <span style={{ color: "#666" }}>{row.label}</span>
                <span>{row.val}</span>
              </div>
            ))}
          </div>

          {/* UPI */}
          {studioProfile?.upiId && (
            <div
              style={{
                background: "#fef2f2",
                border: "1px solid #fca5a5",
                borderRadius: "8px",
                padding: "16px",
                textAlign: "center",
                marginBottom: "24px",
              }}
            >
              <p style={{ margin: 0, fontSize: "12px", color: "#666" }}>
                Pay via UPI
              </p>
              <p
                style={{
                  margin: "4px 0 0",
                  fontFamily: "monospace",
                  fontWeight: 700,
                  fontSize: "16px",
                }}
              >
                {studioProfile.upiId}
              </p>
            </div>
          )}

          {/* Terms */}
          {invoice.termsAndConditions && (
            <div
              style={{
                borderTop: "1px solid #eee",
                paddingTop: "16px",
                fontSize: "11px",
                color: "#666",
              }}
            >
              <p
                style={{
                  fontWeight: 600,
                  textTransform: "uppercase",
                  letterSpacing: "0.06em",
                  marginBottom: "6px",
                }}
              >
                Terms & Conditions
              </p>
              <p style={{ whiteSpace: "pre-line" }}>
                {invoice.termsAndConditions}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Edit Assignment Modal */}
      {editingAssignment && (
        <EditAssignmentModal
          assignment={editingAssignment}
          invoice={invoice}
          onClose={() => setEditingAssignment(null)}
          onSave={(updates) => {
            if (!editingAssignment.id) return;
            updateTeamAssignment(editingAssignment.id, updates);
            setEditingAssignment(null);
            toast.success("Assignment updated");
          }}
        />
      )}

      {/* Delete Assignment confirmation */}
      <AlertDialog
        open={!!deletingAssignmentId}
        onOpenChange={(o) => !o && setDeletingAssignmentId(null)}
      >
        <AlertDialogContent
          data-ocid="invoice_detail.delete_assignment_dialog"
          className="max-w-[95vw] sm:max-w-lg max-h-[85dvh] overflow-y-auto"
        >
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Assignment?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the team assignment and related work history
              entries. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-ocid="invoice_detail.delete_assignment_cancel_button">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              data-ocid="invoice_detail.delete_assignment_confirm_button"
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (deletingAssignmentId) {
                  deleteTeamAssignment(deletingAssignmentId);
                  toast.success("Assignment removed");
                }
                setDeletingAssignmentId(null);
              }}
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Add Payment Modal */}
      <AddPaymentModal
        open={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        onSave={handleAddPayment}
      />

      {/* Edit Payment Modal */}
      {editingPayment && (
        <EditPaymentModal
          payment={editingPayment}
          onClose={() => setEditingPayment(null)}
          onSave={handleEditPayment}
          isSaving={isSaving}
        />
      )}

      {/* Delete Payment confirmation */}
      <AlertDialog
        open={!!deletingPaymentId}
        onOpenChange={(o) => !o && setDeletingPaymentId(null)}
      >
        <AlertDialogContent
          data-ocid="invoice_detail.delete_payment_dialog"
          className="max-w-[95vw] sm:max-w-lg max-h-[85dvh] overflow-y-auto"
        >
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Payment?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove this payment entry and update the balance.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-ocid="invoice_detail.delete_payment_cancel_button">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              data-ocid="invoice_detail.delete_payment_confirm_button"
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() =>
                deletingPaymentId && handleDeletePayment(deletingPaymentId)
              }
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Team Reminder Dialog */}
      <Dialog
        open={showTeamReminderDialog}
        onOpenChange={setShowTeamReminderDialog}
      >
        <DialogContent
          data-ocid="invoice_detail.team_reminder_dialog"
          className="max-w-[95vw] sm:max-w-md max-h-[85dvh] overflow-y-auto"
        >
          <DialogHeader>
            <DialogTitle>Send Team Reminders</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-sm text-muted-foreground">
              Send a WhatsApp reminder to each assigned team member.
            </p>
            {(invoice?.teamAssignments ?? []).map((assignment, idx) => {
              const member = teamMembers.find(
                (m) => m.id === assignment.teamMemberId,
              );
              return (
                <div
                  key={assignment.teamMemberId}
                  className="flex items-center justify-between p-3 rounded-lg border border-border bg-background"
                  data-ocid={`invoice_detail.team_reminder_row.${idx + 1}`}
                >
                  <div className="min-w-0">
                    <p className="font-medium text-sm truncate">
                      {assignment.teamMemberName}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {assignment.program ?? invoice?.eventType}
                      {assignment.date
                        ? ` · ${formatDate(assignment.date)}`
                        : ""}
                    </p>
                    {!member?.phone && (
                      <p className="text-xs text-destructive mt-0.5">
                        No phone number
                      </p>
                    )}
                  </div>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="gap-1.5 text-green-700 border-green-300 hover:bg-green-50 shrink-0 ml-3"
                    data-ocid={`invoice_detail.send_team_reminder_button.${idx + 1}`}
                    disabled={!member?.phone}
                    onClick={() =>
                      handleSendTeamReminder(
                        assignment.teamMemberId,
                        assignment.teamMemberName,
                      )
                    }
                  >
                    <MessageCircle className="w-3.5 h-3.5" /> Send
                  </Button>
                </div>
              );
            })}
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              data-ocid="invoice_detail.team_reminder_close_button"
              onClick={() => setShowTeamReminderDialog(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent
          data-ocid="invoice_detail.delete_dialog"
          className="max-w-[95vw] sm:max-w-lg max-h-[85dvh] overflow-y-auto"
        >
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Invoice?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. All payment history will also be
              deleted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-ocid="invoice_detail.delete_cancel_button">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              data-ocid="invoice_detail.delete_confirm_button"
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDeleteInvoice}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {payingAssignment && (
        <Dialog
          open={!!payingAssignment}
          onOpenChange={(o) => !o && setPayingAssignment(null)}
        >
          <DialogContent className="max-w-[95vw] sm:max-w-sm max-h-[85dvh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Record Payment</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <p className="text-sm text-muted-foreground">
                Team Member:{" "}
                <span className="font-medium text-foreground">
                  {payingAssignment.teamMemberName ?? "—"}
                </span>
              </p>
              <p className="text-sm text-muted-foreground">
                Pending:{" "}
                <span className="font-medium text-red-500">
                  ₹{(payingAssignment.paymentPending || 0).toLocaleString()}
                </span>
              </p>
              <div className="space-y-1.5">
                <Label htmlFor="payDueAmount">Amount (₹)</Label>
                <Input
                  id="payDueAmount"
                  type="number"
                  min="0"
                  value={payRemainingAmount}
                  onChange={(e) => setPayRemainingAmount(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setPayingAssignment(null)}
              >
                Cancel
              </Button>
              <Button
                type="button"
                onClick={() => {
                  recordPaymentByAssignmentId(
                    payingAssignment.id,
                    Number.parseFloat(payRemainingAmount) || 0,
                  );
                  setPayingAssignment(null);
                }}
              >
                Confirm Payment
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </AppLayout>
  );
}

function PayRow({
  label,
  value,
  className = "",
}: { label: string; value: string; className?: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className={`whitespace-nowrap ${className || "text-foreground"}`}>
        {value}
      </span>
    </div>
  );
}

interface AddPaymentModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (entry: PaymentHistoryEntry) => void;
}

function AddPaymentModal({ open, onClose, onSave }: AddPaymentModalProps) {
  const today = new Date().toISOString().split("T")[0];
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(today);
  const [mode, setMode] = useState<string>("cash");
  const [notes, setNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  function handleSubmit() {
    const amtNum = Number(amount);
    if (!amtNum || amtNum <= 0) {
      toast.error("Enter a valid amount");
      return;
    }
    if (isSubmitting) return;
    setIsSubmitting(true);
    try {
      const entry: PaymentHistoryEntry = {
        id: crypto.randomUUID(),
        amount: amtNum,
        date,
        mode: mode as PaymentHistoryEntry["mode"],
        notes,
        createdAt: new Date().toISOString(),
      };
      onSave(entry);
      setAmount("");
      setDate(today);
      setMode("cash");
      setNotes("");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent
        data-ocid="invoice_detail.payment_dialog"
        className="max-w-[95vw] sm:max-w-md max-h-[85dvh] overflow-y-auto"
      >
        <DialogHeader>
          <DialogTitle>Record Payment</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label htmlFor="payAmount">Amount (\u20b9) *</Label>
            <Input
              id="payAmount"
              type="number"
              min="1"
              data-ocid="invoice_detail.payment_amount_input"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g. 10000"
              autoFocus
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="payDate">Date</Label>
              <Input
                id="payDate"
                type="date"
                data-ocid="invoice_detail.payment_date_input"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Method</Label>
              <Select value={mode} onValueChange={setMode}>
                <SelectTrigger data-ocid="invoice_detail.payment_method_select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="upi">UPI</SelectItem>
                  <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                  <SelectItem value="cheque">Cheque</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="payNotes">Notes</Label>
            <Textarea
              id="payNotes"
              data-ocid="invoice_detail.payment_notes_textarea"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Transaction ID, reference, etc."
            />
          </div>
        </div>
        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            data-ocid="invoice_detail.payment_cancel_button"
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button
            type="button"
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
            data-ocid="invoice_detail.payment_submit_button"
            disabled={isSubmitting}
            onClick={handleSubmit}
          >
            {isSubmitting ? "Saving\u2026" : "Record Payment"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

interface EditPaymentModalProps {
  payment: PaymentHistoryEntry;
  onClose: () => void;
  onSave: (updated: PaymentHistoryEntry) => void;
  isSaving: boolean;
}

// ─── EditAssignmentModal ────────────────────────────────────────────────────

interface EditAssignmentModalProps {
  assignment: TeamAssignment;
  onClose: () => void;
  onSave: (updates: Partial<TeamAssignment>) => void;
  invoice?: Invoice;
}

function EditAssignmentModal({
  assignment,
  onClose,
  onSave,
  invoice,
}: EditAssignmentModalProps) {
  const [date, setDate] = useState(assignment.date ?? "");
  const [dateRangeStart, setDateRangeStart] = useState(
    assignment.dateRangeStart ?? "",
  );
  const [dateRangeEnd, setDateRangeEnd] = useState(
    assignment.dateRangeEnd ?? "",
  );
  const [dayType, setDayType] = useState<"full" | "half">(
    assignment.dayType ?? "full",
  );
  const [startTime, setStartTime] = useState(assignment.startTime ?? "");
  const [endTime, setEndTime] = useState(assignment.endTime ?? "");
  const [location, setLocation] = useState(assignment.location ?? "");
  const [notes, setNotes] = useState(assignment.notes ?? "");

  function handleSave() {
    const updates: Partial<TeamAssignment> = {
      dayType,
      startTime: startTime || undefined,
      endTime: endTime || undefined,
      location: location || undefined,
      notes: notes || undefined,
      updatedAt: Date.now(),
    };
    // Prefer range if both range fields are filled, otherwise single date
    if (dateRangeStart && dateRangeEnd) {
      updates.dateRangeStart = dateRangeStart;
      updates.dateRangeEnd = dateRangeEnd;
      updates.date = dateRangeStart; // keep date in sync with range start
    } else {
      updates.date = date || undefined;
      updates.dateRangeStart = undefined;
      updates.dateRangeEnd = undefined;
    }
    onSave(updates);
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent
        data-ocid="invoice_detail.edit_assignment_dialog"
        className="max-w-[95vw] sm:max-w-lg max-h-[85dvh] overflow-y-auto"
      >
        <DialogHeader>
          <DialogTitle>
            Edit Assignment —{" "}
            <span className="font-normal text-muted-foreground">
              {assignment.teamMemberName}
            </span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Single date */}
          <div className="space-y-1.5">
            <Label htmlFor="assignDate">Single Date</Label>
            <Input
              id="assignDate"
              type="date"
              data-ocid="invoice_detail.edit_assignment_date_input"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          {/* Date range */}
          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="rangeStart">Range Start (optional)</Label>
                <Input
                  id="rangeStart"
                  type="date"
                  data-ocid="invoice_detail.edit_assignment_range_start_input"
                  value={dateRangeStart}
                  onChange={(e) => setDateRangeStart(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="rangeEnd">Range End (optional)</Label>
                <Input
                  id="rangeEnd"
                  type="date"
                  data-ocid="invoice_detail.edit_assignment_range_end_input"
                  value={dateRangeEnd}
                  onChange={(e) => setDateRangeEnd(e.target.value)}
                />
              </div>
            </div>
            {invoice && (
              <div className="flex items-center gap-2 rounded-md border border-dashed border-border bg-muted/40 px-3 py-2 text-sm">
                <span className="text-muted-foreground">
                  Event:{" "}
                  <span className="font-medium text-foreground">
                    {invoice.eventStartDate}
                  </span>
                  {invoice.eventEndDate &&
                    invoice.eventEndDate !== invoice.eventStartDate && (
                      <>
                        {" → "}
                        <span className="font-medium text-foreground">
                          {invoice.eventEndDate}
                        </span>
                      </>
                    )}
                </span>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  data-ocid="invoice_detail.edit_assignment_sync_dates_button"
                  className="ml-auto h-7 px-2 text-xs"
                  onClick={() => {
                    setDateRangeStart(invoice.eventStartDate);
                    setDateRangeEnd(
                      invoice.eventEndDate ?? invoice.eventStartDate,
                    );
                    setDate(invoice.eventStartDate);
                  }}
                >
                  Sync Dates
                </Button>
              </div>
            )}
          </div>

          {/* Day type */}
          <div className="space-y-1.5">
            <Label>Day Type</Label>
            <RadioGroup
              data-ocid="invoice_detail.edit_assignment_day_type"
              value={dayType}
              onValueChange={(v) => setDayType(v as "full" | "half")}
              className="flex gap-6"
            >
              <div className="flex items-center gap-2">
                <RadioGroupItem
                  value="full"
                  id="dayFull"
                  data-ocid="invoice_detail.edit_assignment_day_full"
                />
                <Label htmlFor="dayFull" className="cursor-pointer font-normal">
                  Full Day
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <RadioGroupItem
                  value="half"
                  id="dayHalf"
                  data-ocid="invoice_detail.edit_assignment_day_half"
                />
                <Label htmlFor="dayHalf" className="cursor-pointer font-normal">
                  Half Day
                  <span className="ml-1 text-xs text-amber-600">
                    (50% rate)
                  </span>
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Times */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="startTime">Start Time</Label>
              <Input
                id="startTime"
                type="time"
                data-ocid="invoice_detail.edit_assignment_start_time_input"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="endTime">End Time</Label>
              <Input
                id="endTime"
                type="time"
                data-ocid="invoice_detail.edit_assignment_end_time_input"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
              />
            </div>
          </div>

          {/* Location */}
          <div className="space-y-1.5">
            <Label htmlFor="assignLocation">Location</Label>
            <Input
              id="assignLocation"
              type="text"
              data-ocid="invoice_detail.edit_assignment_location_input"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Venue / location details"
            />
          </div>

          {/* Notes */}
          <div className="space-y-1.5">
            <Label htmlFor="assignNotes">Notes</Label>
            <Textarea
              id="assignNotes"
              data-ocid="invoice_detail.edit_assignment_notes_textarea"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Any additional instructions or notes"
            />
          </div>
        </div>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            data-ocid="invoice_detail.edit_assignment_cancel_button"
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button
            type="button"
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
            data-ocid="invoice_detail.edit_assignment_save_button"
            onClick={handleSave}
          >
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── EditPaymentModal ─────────────────────────────────────────────────────────

function EditPaymentModal({
  payment,
  onClose,
  onSave,
  isSaving,
}: EditPaymentModalProps) {
  const [amount, setAmount] = useState(String(payment.amount));
  const [date, setDate] = useState(payment.date);
  const [mode, setMode] = useState<string>(payment.mode);
  const [notes, setNotes] = useState(payment.notes ?? "");

  function handleSave() {
    const amtNum = Number(amount);
    if (!amtNum || amtNum <= 0) {
      toast.error("Enter a valid amount");
      return;
    }
    onSave({
      ...payment,
      amount: amtNum,
      date,
      mode: mode as PaymentHistoryEntry["mode"],
      notes,
    });
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent
        data-ocid="invoice_detail.edit_payment_dialog"
        className="max-w-[95vw] sm:max-w-md max-h-[85dvh] overflow-y-auto"
      >
        <DialogHeader>
          <DialogTitle>Edit Payment</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label>Amount (\u20b9) *</Label>
            <Input
              type="number"
              min="1"
              data-ocid="invoice_detail.edit_payment_amount_input"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Date</Label>
              <Input
                type="date"
                data-ocid="invoice_detail.edit_payment_date_input"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Method</Label>
              <Select value={mode} onValueChange={setMode}>
                <SelectTrigger data-ocid="invoice_detail.edit_payment_method_select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="upi">UPI</SelectItem>
                  <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                  <SelectItem value="cheque">Cheque</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Notes</Label>
            <Input
              data-ocid="invoice_detail.edit_payment_notes_input"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Reference / transaction ID"
            />
          </div>
        </div>
        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            data-ocid="invoice_detail.edit_payment_cancel_button"
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button
            type="button"
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
            data-ocid="invoice_detail.edit_payment_save_button"
            disabled={isSaving}
            onClick={handleSave}
          >
            {isSaving ? "Saving\u2026" : "Save Changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
