import AppLayout from "@/components/layout/AppLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  calculatePaymentSchedule,
  formatCurrency,
  getMinimumAdvance,
  getNextInvoiceNumber,
  safeNumber,
} from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import { useStudioStore } from "@/stores/useStudioStore";
import type {
  Invoice,
  InvoiceService,
  TeamMember,
  WeddingProgram,
} from "@/types";
import { EventType } from "@/types";
import { useNavigate } from "@tanstack/react-router";
import {
  BookmarkPlus,
  ChevronLeft,
  Package2,
  Plus,
  Trash2,
  UserPlus,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

const EVENT_TYPES = Object.values(EventType);

const WEDDING_PROGRAM_NAMES = [
  "Engagement",
  "Mata Ji Pujan",
  "Ganesh Pujan",
  "Haldi",
  "Mamera",
  "Mehndi",
  "Sangeet",
  "Fere",
  "Reception",
  "Barat",
];

const DEFAULT_TERMS = `1. 50% advance required to confirm booking.
2. Balance due on day of event.
3. Cancellation within 7 days forfeits advance.
4. Final edited photos/videos delivered within 30-45 days.
5. Raw footage not shared.`;

type DayType = "full" | "half";

interface TeamAssignmentRow {
  teamMemberId: string;
  teamMemberName: string;
  programName: string;
  date: string;
  startTime: string;
  endTime: string;
  location: string;
  dayType: DayType;
}

interface WeddingProgramState {
  name: string;
  enabled: boolean;
  date: string;
  startTime: string;
  endTime: string;
  location: string;
  notes: string;
}

function initWeddingPrograms(): WeddingProgramState[] {
  return WEDDING_PROGRAM_NAMES.map((name) => ({
    name,
    enabled: false,
    date: "",
    startTime: "",
    endTime: "",
    location: "",
    notes: "",
  }));
}

interface ServiceRow {
  serviceId: string;
  name: string;
  category: string;
  unitPrice: number;
  quantity: number;
  total: number;
  enabled: boolean;
}

interface CustomProgram {
  _k: number;
  name: string;
  date: string;
  startTime: string;
  endTime: string;
  location: string;
  notes: string;
  _savePrompt?: boolean;
}

interface InstallmentEntry {
  date: string;
  amount: number;
  label: string;
  isPaid: boolean;
}

function computeInstallmentSchedule(
  grandTotal: number,
  advancePaid: number,
  eventStartDate: string,
  eventEndDate: string,
): InstallmentEntry[] {
  if (!eventStartDate || grandTotal <= 0) return [];
  const advance = Math.max(grandTotal * 0.5, 20000);
  const remaining = grandTotal - advance;
  const half = Math.ceil(remaining / 2);
  const secondDue = eventStartDate;
  const endDate = new Date(eventEndDate || eventStartDate);
  endDate.setMonth(endDate.getMonth() + 1);
  const thirdDue = endDate.toISOString().split("T")[0];
  return [
    {
      label: "Advance Payment (1st Installment)",
      date: new Date().toISOString().split("T")[0],
      amount: advance,
      isPaid: advancePaid >= advance,
    },
    { label: "2nd Installment", date: secondDue, amount: half, isPaid: false },
    {
      label: "3rd Installment (Final)",
      date: thirdDue,
      amount: remaining - half,
      isPaid: false,
    },
  ];
}

export default function CreateInvoicePage() {
  const navigate = useNavigate();
  const studioProfile = useStudioStore((s) => s.studioProfile);
  const {
    invoices,
    clients,
    services: allServices,
    packages,
    teamMembers,
    addInvoice,
    addTeamMember,
    upsertClientByName,
    addCustomProgramTemplate,
  } = useERPStore();

  const [clientSearch, setClientSearch] = useState("");
  const [selectedClientId, setSelectedClientId] = useState("");
  const [invoiceNumber, setInvoiceNumber] = useState("");
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [clientWhatsapp, setClientWhatsapp] = useState("");
  const [eventStartDate, setEventStartDate] = useState("");
  const [eventEndDate, setEventEndDate] = useState("");
  const [clientCity, setClientCity] = useState("");
  const [clientAddress, setClientAddress] = useState("");
  const [eventVenueName, setEventVenueName] = useState("");
  const [eventVenueAddress, setEventVenueAddress] = useState("");
  const [eventType, setEventType] = useState<string>("");
  const [customEventName, setCustomEventName] = useState("");
  const [customEventDate, setCustomEventDate] = useState("");
  const [customEventTime, setCustomEventTime] = useState("");
  const [customEventNotes, setCustomEventNotes] = useState("");
  const [weddingPrograms, setWeddingPrograms] =
    useState<WeddingProgramState[]>(initWeddingPrograms);
  const [customPrograms, setCustomPrograms] = useState<CustomProgram[]>([]);
  const [serviceRows, setServiceRows] = useState<ServiceRow[]>([]);
  const [customServices, setCustomServices] = useState<
    Array<InvoiceService & { _k: number }>
  >([]);
  const [selectedTeam, setSelectedTeam] = useState<string[]>([]);
  const [teamAssignmentRows, setTeamAssignmentRows] = useState<
    TeamAssignmentRow[]
  >([]);
  const [dealAmount, setDealAmount] = useState(0);
  const [dealAmountAutoCalc, setDealAmountAutoCalc] = useState(false);
  const [discount, setDiscount] = useState(0);
  const [advancePaid, setAdvancePaid] = useState(0);
  const [paymentNotes, setPaymentNotes] = useState("");
  const [terms, setTerms] = useState(DEFAULT_TERMS);
  const [selectedPackageId, setSelectedPackageId] = useState("");
  const [gstEnabled, setGstEnabled] = useState(
    studioProfile?.gstEnabled ?? false,
  );
  const gstPct =
    studioProfile?.gstPercent && studioProfile.gstPercent > 0
      ? studioProfile.gstPercent
      : 18;

  // Quick create team member modal
  const [showAddTeamModal, setShowAddTeamModal] = useState(false);
  const [newMemberName, setNewMemberName] = useState("");
  const [newMemberMobile, setNewMemberMobile] = useState("");
  const [newMemberRole, setNewMemberRole] = useState("Photographer");

  const [installments, setInstallments] = useState<InstallmentEntry[]>([]);
  const keyRef = useRef(0);

  // Generate invoice number
  useEffect(() => {
    setInvoiceNumber(getNextInvoiceNumber(invoices));
  }, [invoices]);

  // Build service rows from store
  useEffect(() => {
    if (allServices.length > 0) {
      setServiceRows(
        allServices.map((s) => ({
          serviceId: s.id,
          name: s.name,
          category: s.category,
          unitPrice: s.price,
          quantity: 1,
          total: s.price,
          enabled: false,
        })),
      );
    }
  }, [allServices]);

  // Auto-fill from selected client
  function handleClientSelect(id: string) {
    setSelectedClientId(id);
    const client = clients.find((c) => c.id === id);
    if (client) {
      setClientName(client.name);
      setClientPhone(client.phone);
      setClientWhatsapp(client.whatsapp ?? client.phone);
      setClientCity(client.city ?? "");
      setClientAddress(client.address ?? "");
      setEventVenueName(client.eventVenueName ?? "");
      setEventVenueAddress(client.eventVenueAddress ?? "");
    }
  }

  // Package selection — pre-populate deal amount
  function handlePackageSelect(pkgId: string) {
    const realId = pkgId === "no-package" ? "" : pkgId;
    setSelectedPackageId(realId);
    // Don't auto-set deal amount here; let the auto-calc effect handle it
  }

  // Service calculations
  const enabledServices: InvoiceService[] = useMemo(() => {
    const fromCatalog = serviceRows
      .filter((r) => r.enabled)
      .map(
        (r): InvoiceService => ({
          serviceId: r.serviceId,
          name: r.name,
          category: r.category,
          unitPrice: r.unitPrice,
          quantity: r.quantity,
          total: r.quantity * r.unitPrice,
        }),
      );
    return [
      ...fromCatalog,
      ...customServices.map(({ _k: _, ...rest }) => rest),
    ];
  }, [serviceRows, customServices]);

  const servicesTotal = enabledServices.reduce(
    (s, r) => s + safeNumber(r.total),
    0,
  );
  const extraChargesTotal = selectedPackageId
    ? (() => {
        const pkg = packages.find((p) => p.id === selectedPackageId);
        if (!pkg?.extraChargeRules) return 0;
        let extra = 0;
        for (const rule of pkg.extraChargeRules) {
          const svc = enabledServices.find((s) => s.name === rule.serviceName);
          if (svc && svc.quantity > rule.includedLimit) {
            extra +=
              (svc.quantity - rule.includedLimit) *
              safeNumber(rule.extraChargePerUnit);
          }
        }
        return extra;
      })()
    : 0;
  const subtotal =
    safeNumber(dealAmount) -
    safeNumber(discount) +
    safeNumber(extraChargesTotal);
  const gstAmount = gstEnabled ? subtotal * (safeNumber(gstPct) / 100) : 0;
  const grandTotal = safeNumber(subtotal) + safeNumber(gstAmount);
  const balance = safeNumber(grandTotal) - safeNumber(advancePaid);
  const minAdvance = getMinimumAdvance(grandTotal);

  // Auto-calculate deal amount from services + package + extra charges
  // biome-ignore lint/correctness/useExhaustiveDependencies: dealAmountAutoCalc is a flag; packages.find is stable
  useEffect(() => {
    const pkgBase = selectedPackageId
      ? (packages.find((p) => p.id === selectedPackageId)?.basePrice ?? 0)
      : 0;
    const autoTotal = servicesTotal + pkgBase + extraChargesTotal;
    if (autoTotal > 0) {
      setDealAmount(autoTotal);
      setDealAmountAutoCalc(true);
    } else if (dealAmountAutoCalc) {
      // Only clear if previously auto-set
      setDealAmountAutoCalc(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [servicesTotal, selectedPackageId, extraChargesTotal]);

  // Auto-generate installment schedule
  useEffect(() => {
    if (dealAmount > 0 && eventStartDate) {
      setInstallments(
        computeInstallmentSchedule(
          grandTotal,
          advancePaid,
          eventStartDate,
          eventEndDate,
        ),
      );
    } else {
      setInstallments([]);
    }
  }, [grandTotal, advancePaid, eventStartDate, eventEndDate, dealAmount]);

  function updateWeddingProgram(
    index: number,
    field: keyof WeddingProgramState,
    value: string | boolean,
  ) {
    setWeddingPrograms((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  }

  function addCustomProgram() {
    setCustomPrograms((prev) => [
      ...prev,
      {
        _k: ++keyRef.current,
        name: "",
        date: "",
        startTime: "",
        endTime: "",
        location: "",
        notes: "",
      },
    ]);
  }

  function updateCustomProgram(
    i: number,
    field: keyof Omit<CustomProgram, "_k" | "_savePrompt">,
    value: string,
  ) {
    setCustomPrograms((prev) => {
      const updated = [...prev];
      updated[i] = { ...updated[i], [field]: value };
      if (field === "name" && value.trim().length > 2) {
        updated[i]._savePrompt = true;
      }
      return updated;
    });
  }

  function removeCustomProgram(i: number) {
    setCustomPrograms((prev) => prev.filter((_, idx) => idx !== i));
  }

  function updateServiceRow(
    i: number,
    field: keyof ServiceRow,
    value: number | string | boolean,
  ) {
    setServiceRows((prev) => {
      const updated = [...prev];
      const row = { ...updated[i], [field]: value };
      row.total = row.quantity * row.unitPrice;
      updated[i] = row;
      return updated;
    });
  }

  function addCustomService() {
    setCustomServices((prev) => [
      ...prev,
      {
        serviceId: "",
        name: "",
        category: "",
        unitPrice: 0,
        quantity: 1,
        total: 0,
        _k: ++keyRef.current,
      },
    ]);
  }

  function updateCustomService(
    i: number,
    field: keyof InvoiceService,
    value: number | string,
  ) {
    setCustomServices((prev) => {
      const updated = [...prev];
      const row = { ...updated[i], [field]: value };
      row.total = Number(row.quantity) * Number(row.unitPrice);
      return [
        updated.slice(0, i),
        row,
        ...updated.slice(i + 1),
      ].flat() as typeof prev;
    });
  }

  function removeCustomService(i: number) {
    setCustomServices((prev) => prev.filter((_, idx) => idx !== i));
  }

  function toggleTeam(id: string) {
    setSelectedTeam((prev) => {
      const next = prev.includes(id)
        ? prev.filter((x) => x !== id)
        : [...prev, id];
      // Add a default assignment row when adding; remove when unchecking
      if (!prev.includes(id)) {
        const member = teamMembers.find((m) => m.id === id);
        setTeamAssignmentRows((rows) => [
          ...rows,
          {
            teamMemberId: id,
            teamMemberName: member?.name ?? id,
            programName: "",
            date: "",
            startTime: "",
            endTime: "",
            location: "",
            dayType: "full",
          },
        ]);
      } else {
        setTeamAssignmentRows((rows) =>
          rows.filter((r) => r.teamMemberId !== id),
        );
      }
      return next;
    });
  }

  function updateTeamAssignmentRow(
    memberId: string,
    field: keyof Omit<TeamAssignmentRow, "teamMemberId" | "teamMemberName">,
    value: string,
  ) {
    setTeamAssignmentRows((rows) =>
      rows.map((r) =>
        r.teamMemberId === memberId ? { ...r, [field]: value } : r,
      ),
    );
  }

  function handleAddTeamMember() {
    if (!newMemberName.trim()) {
      toast.error("Name is required");
      return;
    }
    const member: TeamMember = {
      id: `tm-${Date.now()}`,
      name: newMemberName.trim(),
      role: newMemberRole,
      phone: newMemberMobile.trim(),
      perDayRateWithCamera: 0,
      perDayRateWithoutCamera: 0,
      joinedAt: new Date().toISOString(),
    };
    addTeamMember(member);
    setSelectedTeam((prev) => [...prev, member.id]);
    setShowAddTeamModal(false);
    setNewMemberName("");
    setNewMemberMobile("");
    setNewMemberRole("Photographer");
    toast.success(`${member.name} added to team!`);
  }

  const selectedPackage = selectedPackageId
    ? packages.find((p) => p.id === selectedPackageId)
    : undefined;

  function handleSubmit() {
    if (!clientName.trim()) {
      toast.error("Client name is required");
      return;
    }
    if (!eventType) {
      toast.error("Event type is required");
      return;
    }
    if (!clientPhone.trim() && !clientWhatsapp.trim()) {
      toast.error("Phone number is required");
      return;
    }
    if (grandTotal < 0 || !Number.isFinite(grandTotal)) {
      toast.error(
        "Grand total cannot be negative or invalid. Check deal amount and discount.",
      );
      return;
    }
    for (const inst of installments) {
      if (!Number.isFinite(inst.amount) || inst.amount < 0) {
        toast.error(
          "One or more installment amounts are invalid. Check payment schedule.",
        );
        return;
      }
    }

    const now = new Date().toISOString();

    // Build WeddingPrograms
    const programs: WeddingProgram[] =
      eventType === EventType.WEDDING
        ? weddingPrograms
            .filter((p) => p.enabled)
            .map((p) => ({
              id: `prog-${Date.now()}-${Math.random()}`,
              name: p.name,
              enabled: true,
              date: p.date || undefined,
              startTime: p.startTime || undefined,
              endTime: p.endTime || undefined,
              location: p.location || undefined,
              notes: p.notes || undefined,
            }))
        : [];

    // Add custom programs as WeddingPrograms
    const allPrograms: WeddingProgram[] = [
      ...programs,
      ...customPrograms.map((p) => ({
        id: `cprog-${Date.now()}-${Math.random()}`,
        name: p.name,
        enabled: true,
        date: p.date || undefined,
        startTime: p.startTime || undefined,
        endTime: p.endTime || undefined,
        location: p.location || undefined,
        notes: p.notes || undefined,
      })),
    ];

    // Auto-create client if not selected
    const phone = clientPhone.trim() || clientWhatsapp.trim();
    const client = upsertClientByName(clientName.trim(), phone, {
      whatsapp: clientWhatsapp.trim() || undefined,
      address: clientAddress || undefined,
      city: clientCity || undefined,
      eventVenueName: eventVenueName || undefined,
      eventVenueAddress: eventVenueAddress || undefined,
    });

    const teamAssignments = selectedTeam.map((tmId) => {
      const tm = teamMembers.find((m) => m.id === tmId);
      const assignRow = teamAssignmentRows.find((r) => r.teamMemberId === tmId);
      return {
        teamMemberId: tmId,
        teamMemberName: tm?.name ?? tmId,
        programName: assignRow?.programName || undefined,
        date: assignRow?.date || undefined,
        startTime: assignRow?.startTime || undefined,
        endTime: assignRow?.endTime || undefined,
        location: assignRow?.location || undefined,
        dayType: assignRow?.dayType || "full",
      };
    });

    const invoice: Invoice = {
      id: `inv-${Date.now()}`,
      invoiceNumber: invoiceNumber || getNextInvoiceNumber(invoices),
      clientId: selectedClientId || client.id,
      clientName: clientName.trim(),
      clientPhone: phone,
      clientWhatsapp: clientWhatsapp.trim() || undefined,
      clientAddress: clientAddress || undefined,
      clientCity: clientCity || undefined,
      eventVenueName: eventVenueName || undefined,
      eventVenueAddress: eventVenueAddress || undefined,
      eventType:
        eventType === EventType.CUSTOM_EVENT && customEventName
          ? customEventName.trim()
          : eventType,
      customEventName:
        eventType === EventType.CUSTOM_EVENT ? customEventName : undefined,
      eventStartDate,
      eventEndDate: eventEndDate || undefined,
      programs: allPrograms.length > 0 ? allPrograms : undefined,
      services: enabledServices,
      packageId: selectedPackageId || undefined,
      packageName: selectedPackage?.name,
      packageBasePrice: selectedPackage?.basePrice,
      dealAmount,
      subtotal,
      gstEnabled,
      gstPercent: gstEnabled ? gstPct : undefined,
      gstAmount: gstEnabled ? gstAmount : undefined,
      discount: discount > 0 ? discount : undefined,
      totalAmount: grandTotal,
      advancePaid,
      pendingAmount: balance,
      status: balance <= 0 ? "paid" : advancePaid > 0 ? "partial" : "pending",
      paymentHistory: [],
      teamAssignments: teamAssignments.length > 0 ? teamAssignments : undefined,
      notes: paymentNotes || undefined,
      termsAndConditions: terms || undefined,
      createdAt: now,
      updatedAt: now,
    };

    addInvoice(invoice);
    toast.success("Invoice created successfully!");
    navigate({ to: `/invoices/${invoice.id}` });
  }

  const filteredClients = clients.filter((c) =>
    c.name.toLowerCase().includes(clientSearch.toLowerCase()),
  );

  const sectionNum = (base: number) =>
    eventType === EventType.WEDDING ? base : base - 1;

  return (
    <AppLayout>
      <div
        data-ocid="create_invoice.page"
        className="max-w-4xl mx-auto space-y-6 pb-12"
      >
        {/* Page header */}
        <div className="flex items-center gap-3">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="gap-1"
            data-ocid="create_invoice.back_button"
            onClick={() => navigate({ to: "/invoices" })}
          >
            <ChevronLeft className="w-4 h-4" /> Back
          </Button>
          <div>
            <h2 className="text-2xl font-display font-bold text-foreground">
              Create Invoice
            </h2>
          </div>
        </div>

        {/* SECTION 1: Client Info */}
        <FormSection title="Client Information" number={1}>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>Select Existing Client (optional)</Label>
              <div className="relative">
                <Input
                  data-ocid="create_invoice.client_search_input"
                  placeholder="Search clients…"
                  value={clientSearch}
                  onChange={(e) => setClientSearch(e.target.value)}
                />
              </div>
              {clientSearch && filteredClients.length > 0 && (
                <div className="border border-border rounded-lg bg-card shadow-lg max-h-48 overflow-y-auto">
                  {filteredClients.map((c) => (
                    <button
                      type="button"
                      key={c.id}
                      className="w-full text-left px-4 py-2.5 hover:bg-muted/50 flex items-center gap-3 transition-colors"
                      onClick={() => {
                        handleClientSelect(c.id);
                        setClientSearch("");
                      }}
                    >
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold">
                        {c.name.slice(0, 1).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{c.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {c.phone}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="clientName">Client Name *</Label>
                <Input
                  id="clientName"
                  data-ocid="create_invoice.client_name_input"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="Full name"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="invoiceNum">Invoice Number</Label>
                <Input
                  id="invoiceNum"
                  data-ocid="create_invoice.invoice_number_input"
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  placeholder="Auto-generated (YYMMXX)"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="clientPhone">Phone Number *</Label>
                <Input
                  id="clientPhone"
                  data-ocid="create_invoice.client_phone_input"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="whatsapp">WhatsApp Number</Label>
                <Input
                  id="whatsapp"
                  data-ocid="create_invoice.whatsapp_input"
                  value={clientWhatsapp}
                  onChange={(e) => setClientWhatsapp(e.target.value)}
                  placeholder="+91 98765 43210 (if different)"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="startDate">Event Start Date</Label>
                <Input
                  id="startDate"
                  type="date"
                  data-ocid="create_invoice.start_date_input"
                  value={eventStartDate}
                  onChange={(e) => setEventStartDate(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="endDate">Event End Date</Label>
                <Input
                  id="endDate"
                  type="date"
                  data-ocid="create_invoice.end_date_input"
                  value={eventEndDate}
                  onChange={(e) => setEventEndDate(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  data-ocid="create_invoice.city_input"
                  value={clientCity}
                  onChange={(e) => setClientCity(e.target.value)}
                  placeholder="e.g. Mumbai"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="address">Client Address</Label>
              <Textarea
                id="address"
                data-ocid="create_invoice.address_input"
                value={clientAddress}
                onChange={(e) => setClientAddress(e.target.value)}
                placeholder="Street, locality, pincode"
                rows={2}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="venueName">Event Venue Name</Label>
                <Input
                  id="venueName"
                  data-ocid="create_invoice.venue_name_input"
                  value={eventVenueName}
                  onChange={(e) => setEventVenueName(e.target.value)}
                  placeholder="e.g. Grand Palace Banquet"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="venueAddress">Event Venue Address</Label>
                <Input
                  id="venueAddress"
                  data-ocid="create_invoice.venue_address_input"
                  value={eventVenueAddress}
                  onChange={(e) => setEventVenueAddress(e.target.value)}
                  placeholder="Venue street / locality"
                />
              </div>
            </div>
          </div>
        </FormSection>

        {/* SECTION 2: Package Selection */}
        <FormSection title="Package" number={2}>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Select Package (optional)</Label>
              <Select
                value={selectedPackageId}
                onValueChange={handlePackageSelect}
              >
                <SelectTrigger data-ocid="create_invoice.package_select">
                  <SelectValue placeholder="No package — custom pricing" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="no-package">
                    No package — custom pricing
                  </SelectItem>
                  {packages.map((pkg) => (
                    <SelectItem key={pkg.id} value={pkg.id}>
                      {pkg.name} — {formatCurrency(pkg.basePrice)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedPackage && (
              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 space-y-3">
                <div className="flex items-start gap-3">
                  <Package2 className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-foreground">
                      {selectedPackage.name}
                    </p>
                    <p className="text-sm font-bold text-primary mt-1">
                      {formatCurrency(selectedPackage.basePrice)}
                    </p>
                  </div>
                  <button
                    type="button"
                    className="text-muted-foreground hover:text-foreground"
                    onClick={() => handlePackageSelect("no-package")}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                {selectedPackage.services.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                      Included Services
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedPackage.services.map((svc) => (
                        <Badge
                          key={svc.id}
                          variant="secondary"
                          className="text-xs"
                        >
                          {svc.name}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                {extraChargesTotal > 0 && (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-2 text-sm text-amber-700">
                    Package extra charges: +{formatCurrency(extraChargesTotal)}
                  </div>
                )}
              </div>
            )}
          </div>
        </FormSection>

        {/* SECTION 3: Event Type */}
        <FormSection title="Event Type" number={3}>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Event Type *</Label>
              <Select value={eventType} onValueChange={setEventType}>
                <SelectTrigger data-ocid="create_invoice.event_type_select">
                  <SelectValue placeholder="Select event type…" />
                </SelectTrigger>
                <SelectContent>
                  {EVENT_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>
                      {t}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {eventType === EventType.CUSTOM_EVENT && (
              <div className="bg-muted/30 rounded-lg p-4 space-y-3 border border-border">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Custom Event Details
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Event Name *</Label>
                    <Input
                      data-ocid="create_invoice.custom_event_name_input"
                      value={customEventName}
                      onChange={(e) => setCustomEventName(e.target.value)}
                      placeholder="e.g. Naming Ceremony"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Date</Label>
                    <Input
                      type="date"
                      data-ocid="create_invoice.custom_event_date_input"
                      value={customEventDate}
                      onChange={(e) => setCustomEventDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Time</Label>
                    <Input
                      type="time"
                      data-ocid="create_invoice.custom_event_time_input"
                      value={customEventTime}
                      onChange={(e) => setCustomEventTime(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Notes</Label>
                    <Input
                      data-ocid="create_invoice.custom_event_notes_input"
                      value={customEventNotes}
                      onChange={(e) => setCustomEventNotes(e.target.value)}
                      placeholder="Additional details…"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </FormSection>

        {/* SECTION 4: Wedding Workflow */}
        {eventType === EventType.WEDDING && (
          <FormSection title="Wedding Programs" number={4}>
            <div className="space-y-2">
              {weddingPrograms.map((prog, i) => (
                <div
                  key={prog.name}
                  className={`border rounded-lg overflow-hidden transition-colors ${
                    prog.enabled
                      ? "border-primary/30 bg-primary/5"
                      : "border-border bg-background"
                  }`}
                >
                  <label
                    htmlFor={`wedding-prog-${prog.name}`}
                    className="flex items-center gap-3 px-4 py-3 cursor-pointer"
                  >
                    <Checkbox
                      id={`wedding-prog-${prog.name}`}
                      checked={prog.enabled}
                      onCheckedChange={(v) =>
                        updateWeddingProgram(i, "enabled", !!v)
                      }
                      data-ocid={`create_invoice.wedding_${prog.name.toLowerCase().replace(/ /g, "_")}_checkbox`}
                    />
                    <span className="font-medium text-sm flex-1">
                      {prog.name}
                    </span>
                    {prog.enabled && prog.date && (
                      <Badge
                        variant="secondary"
                        className="text-[10px] h-5 shrink-0"
                      >
                        {prog.date}
                      </Badge>
                    )}
                  </label>
                  {prog.enabled && (
                    <div className="px-4 pb-4 grid grid-cols-1 sm:grid-cols-2 gap-3 border-t border-border/50 pt-3">
                      <div className="space-y-1.5">
                        <Label className="text-xs">Date</Label>
                        <Input
                          type="date"
                          value={prog.date}
                          onChange={(e) =>
                            updateWeddingProgram(i, "date", e.target.value)
                          }
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">Start Time</Label>
                        <Input
                          type="time"
                          value={prog.startTime}
                          onChange={(e) =>
                            updateWeddingProgram(i, "startTime", e.target.value)
                          }
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">End Time</Label>
                        <Input
                          type="time"
                          value={prog.endTime}
                          onChange={(e) =>
                            updateWeddingProgram(i, "endTime", e.target.value)
                          }
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">Location</Label>
                        <Input
                          value={prog.location}
                          onChange={(e) =>
                            updateWeddingProgram(i, "location", e.target.value)
                          }
                          placeholder="Venue / location"
                        />
                      </div>
                      <div className="sm:col-span-2 space-y-1.5">
                        <Label className="text-xs">Notes</Label>
                        <Textarea
                          value={prog.notes}
                          onChange={(e) =>
                            updateWeddingProgram(i, "notes", e.target.value)
                          }
                          rows={2}
                          placeholder="Additional details…"
                        />
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </FormSection>
        )}

        {/* SECTION 5: Custom Programs */}
        <FormSection
          title="Custom Programs"
          number={eventType === EventType.WEDDING ? 5 : 4}
        >
          <div className="space-y-3">
            {customPrograms.map((prog, i) => (
              <div
                key={prog._k}
                className="border border-border rounded-lg p-4 space-y-3 bg-background"
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium text-sm">Program {i + 1}</span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-destructive"
                    onClick={() => removeCustomProgram(i)}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs">Program Name</Label>
                    <Input
                      value={prog.name}
                      onChange={(e) =>
                        updateCustomProgram(i, "name", e.target.value)
                      }
                      placeholder="e.g. Cocktail Party"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Date</Label>
                    <Input
                      type="date"
                      value={prog.date}
                      onChange={(e) =>
                        updateCustomProgram(i, "date", e.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Start Time</Label>
                    <Input
                      type="time"
                      value={prog.startTime}
                      onChange={(e) =>
                        updateCustomProgram(i, "startTime", e.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Notes</Label>
                    <Input
                      value={prog.notes}
                      onChange={(e) =>
                        updateCustomProgram(i, "notes", e.target.value)
                      }
                      placeholder="Details…"
                    />
                  </div>
                </div>
                {prog._savePrompt && prog.name.trim() && (
                  <div className="flex items-center gap-2 p-2 rounded-lg bg-primary/5 border border-primary/20">
                    <BookmarkPlus className="w-3.5 h-3.5 text-primary shrink-0" />
                    <span className="text-xs text-muted-foreground flex-1">
                      Save &ldquo;{prog.name}&rdquo; to wedding templates?
                    </span>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-6 text-xs px-2 border-primary/30 text-primary"
                      data-ocid={`create_invoice.save_template_button.${i + 1}`}
                      onClick={() => {
                        addCustomProgramTemplate({
                          id: `tpl-${Date.now()}`,
                          name: prog.name,
                          isDefault: false,
                        });
                        toast.success(
                          `"${prog.name}" saved to wedding templates`,
                        );
                        setCustomPrograms((prev) => {
                          const updated = [...prev];
                          updated[i] = { ...updated[i], _savePrompt: false };
                          return updated;
                        });
                      }}
                    >
                      Save
                    </Button>
                    <button
                      type="button"
                      className="text-xs text-muted-foreground hover:text-foreground"
                      onClick={() =>
                        setCustomPrograms((prev) => {
                          const updated = [...prev];
                          updated[i] = { ...updated[i], _savePrompt: false };
                          return updated;
                        })
                      }
                    >
                      Dismiss
                    </button>
                  </div>
                )}
              </div>
            ))}
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-2"
              data-ocid="create_invoice.add_program_button"
              onClick={addCustomProgram}
            >
              <Plus className="w-4 h-4" /> Add Program
            </Button>
          </div>
        </FormSection>

        {/* SECTION 6: Services */}
        <FormSection title="Services" number={sectionNum(7)}>
          <div className="space-y-3">
            {serviceRows.map((row, i) => (
              <div
                key={row.serviceId}
                className={`border rounded-lg p-4 transition-colors ${
                  row.enabled
                    ? "border-primary/30 bg-primary/5"
                    : "border-border bg-background"
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <Checkbox
                      checked={row.enabled}
                      onCheckedChange={(v) =>
                        updateServiceRow(i, "enabled", !!v)
                      }
                      data-ocid={`create_invoice.service_${row.name.toLowerCase().replace(/ /g, "_")}_checkbox`}
                    />
                    <div>
                      <p className="font-medium text-sm">{row.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">
                        {row.category}
                      </p>
                    </div>
                  </div>
                  {row.enabled && (
                    <span className="font-bold text-primary">
                      {formatCurrency(row.total)}
                    </span>
                  )}
                </div>
                {row.enabled && (
                  <div className="grid grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <Label className="text-xs">Qty</Label>
                      <Input
                        type="number"
                        min="1"
                        value={row.quantity}
                        onChange={(e) =>
                          updateServiceRow(
                            i,
                            "quantity",
                            Number(e.target.value),
                          )
                        }
                        className="h-8 text-sm"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Price (₹)</Label>
                      <Input
                        type="number"
                        min="0"
                        value={row.unitPrice}
                        onChange={(e) =>
                          updateServiceRow(
                            i,
                            "unitPrice",
                            Number(e.target.value),
                          )
                        }
                        className="h-8 text-sm"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Total</Label>
                      <Input
                        value={formatCurrency(row.total)}
                        readOnly
                        className="h-8 text-sm bg-muted"
                      />
                    </div>
                  </div>
                )}
              </div>
            ))}
            {customServices.map((svc, i) => (
              <div
                key={svc._k}
                className="border border-dashed border-border rounded-lg p-4 space-y-3 bg-background"
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-muted-foreground">
                    Custom Service
                  </span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-destructive"
                    onClick={() => removeCustomService(i)}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="sm:col-span-2 space-y-1">
                    <Label className="text-xs">Service Name</Label>
                    <Input
                      value={svc.name}
                      onChange={(e) =>
                        updateCustomService(i, "name", e.target.value)
                      }
                      placeholder="Service description"
                      className="h-8 text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Qty</Label>
                    <Input
                      type="number"
                      min="1"
                      value={svc.quantity}
                      onChange={(e) =>
                        updateCustomService(
                          i,
                          "quantity",
                          Number(e.target.value),
                        )
                      }
                      className="h-8 text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Price (₹)</Label>
                    <Input
                      type="number"
                      min="0"
                      value={svc.unitPrice}
                      onChange={(e) =>
                        updateCustomService(
                          i,
                          "unitPrice",
                          Number(e.target.value),
                        )
                      }
                      className="h-8 text-sm"
                    />
                  </div>
                </div>
              </div>
            ))}
            <div className="flex items-center justify-between pt-2 border-t border-border">
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="gap-2"
                data-ocid="create_invoice.add_custom_service_button"
                onClick={addCustomService}
              >
                <Plus className="w-4 h-4" /> Add Custom Service
              </Button>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Services Total</p>
                <p className="font-bold text-foreground">
                  {formatCurrency(servicesTotal)}
                </p>
              </div>
            </div>
          </div>
        </FormSection>

        {/* SECTION 7: Team */}
        <FormSection title="Team Assignment" number={sectionNum(8)}>
          <div className="space-y-4">
            {teamMembers.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                No team members found. Add a member below.
              </p>
            ) : (
              <div className="space-y-3">
                {teamMembers.map((member) => {
                  const isSelected = selectedTeam.includes(member.id);
                  const assignRow = teamAssignmentRows.find(
                    (r) => r.teamMemberId === member.id,
                  );
                  return (
                    <div
                      key={member.id}
                      className={`border rounded-lg overflow-hidden transition-colors ${
                        isSelected
                          ? "border-primary/40 bg-primary/5"
                          : "border-border bg-background"
                      }`}
                    >
                      <label className="flex items-center gap-3 p-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleTeam(member.id)}
                          className="accent-primary"
                          data-ocid={`create_invoice.team_${member.id}_checkbox`}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">
                            {member.name}
                          </p>
                          <span className="text-xs text-muted-foreground">
                            {member.role}
                          </span>
                        </div>
                        {isSelected && assignRow && (
                          <span
                            className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                              assignRow.dayType === "half"
                                ? "bg-amber-100 text-amber-700"
                                : "bg-green-100 text-green-700"
                            }`}
                          >
                            {assignRow.dayType === "half"
                              ? "Half Day"
                              : "Full Day"}
                          </span>
                        )}
                      </label>
                      {isSelected && assignRow && (
                        <div className="px-4 pb-4 pt-1 border-t border-border/50 grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="space-y-1.5">
                            <Label className="text-xs">Program / Event</Label>
                            {weddingPrograms.filter((p) => p.enabled).length >
                            0 ? (
                              <Select
                                value={assignRow.programName}
                                onValueChange={(v) =>
                                  updateTeamAssignmentRow(
                                    member.id,
                                    "programName",
                                    v,
                                  )
                                }
                              >
                                <SelectTrigger className="h-8 text-sm">
                                  <SelectValue placeholder="Select program" />
                                </SelectTrigger>
                                <SelectContent>
                                  {weddingPrograms
                                    .filter((p) => p.enabled)
                                    .map((p) => (
                                      <SelectItem key={p.name} value={p.name}>
                                        {p.name}
                                      </SelectItem>
                                    ))}
                                </SelectContent>
                              </Select>
                            ) : (
                              <Input
                                value={assignRow.programName}
                                onChange={(e) =>
                                  updateTeamAssignmentRow(
                                    member.id,
                                    "programName",
                                    e.target.value,
                                  )
                                }
                                placeholder="e.g. Haldi, Barat"
                                className="h-8 text-sm"
                              />
                            )}
                          </div>
                          <div className="space-y-1.5">
                            <Label className="text-xs">Day Type</Label>
                            <Select
                              value={assignRow.dayType || "full"}
                              onValueChange={(v) =>
                                updateTeamAssignmentRow(member.id, "dayType", v)
                              }
                            >
                              <SelectTrigger
                                className="h-8 text-sm"
                                data-ocid={`create_invoice.team_day_type_${member.id}`}
                              >
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="full">
                                  Full Day (100%)
                                </SelectItem>
                                <SelectItem value="half">
                                  Half Day (50% rate)
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-1.5">
                            <Label className="text-xs">Date</Label>
                            <Input
                              type="date"
                              value={assignRow.date}
                              onChange={(e) =>
                                updateTeamAssignmentRow(
                                  member.id,
                                  "date",
                                  e.target.value,
                                )
                              }
                              className="h-8 text-sm"
                            />
                          </div>
                          <div className="space-y-1.5">
                            <Label className="text-xs">Location</Label>
                            <Input
                              value={assignRow.location}
                              onChange={(e) =>
                                updateTeamAssignmentRow(
                                  member.id,
                                  "location",
                                  e.target.value,
                                )
                              }
                              placeholder="Venue / location"
                              className="h-8 text-sm"
                            />
                          </div>
                          <div className="space-y-1.5">
                            <Label className="text-xs">Start Time</Label>
                            <Input
                              type="time"
                              value={assignRow.startTime}
                              onChange={(e) =>
                                updateTeamAssignmentRow(
                                  member.id,
                                  "startTime",
                                  e.target.value,
                                )
                              }
                              className="h-8 text-sm"
                            />
                          </div>
                          <div className="space-y-1.5">
                            <Label className="text-xs">End Time</Label>
                            <Input
                              type="time"
                              value={assignRow.endTime}
                              onChange={(e) =>
                                updateTeamAssignmentRow(
                                  member.id,
                                  "endTime",
                                  e.target.value,
                                )
                              }
                              className="h-8 text-sm"
                            />
                          </div>
                          {assignRow.dayType === "half" && (
                            <div className="sm:col-span-2 flex items-center gap-2 p-2 rounded-lg bg-amber-50 border border-amber-200">
                              <span className="text-xs text-amber-700">
                                ⚠️ Half day — payment will be calculated at{" "}
                                <strong>50% of the daily rate</strong>
                              </span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-2 text-primary border-primary/30"
              data-ocid="create_invoice.add_team_member_button"
              onClick={() => setShowAddTeamModal(true)}
            >
              <UserPlus className="w-4 h-4" /> Add New Member
            </Button>
          </div>
        </FormSection>

        {/* SECTION 8: Payment */}
        <FormSection title="Payment Summary" number={sectionNum(9)}>
          <div className="space-y-4">
            {/* GST toggle */}
            {studioProfile?.gstEnabled && (
              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <div>
                  <p className="font-medium text-sm">Apply GST ({gstPct}%)</p>
                  <p className="text-xs text-muted-foreground">
                    GST from studio profile settings
                  </p>
                </div>
                <Checkbox
                  checked={gstEnabled}
                  onCheckedChange={(v) => setGstEnabled(!!v)}
                  data-ocid="create_invoice.gst_toggle"
                />
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label htmlFor="dealAmount">Total Deal Amount (₹) *</Label>
                  {dealAmountAutoCalc && (
                    <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-primary/10 text-primary">
                      Auto-calculated
                    </span>
                  )}
                </div>
                <Input
                  id="dealAmount"
                  type="number"
                  min="0"
                  data-ocid="create_invoice.deal_amount_input"
                  value={dealAmount || ""}
                  onChange={(e) => {
                    setDealAmountAutoCalc(false);
                    setDealAmount(safeNumber(e.target.value));
                  }}
                  placeholder="Auto-calculated from services"
                  className={
                    dealAmountAutoCalc ? "bg-primary/5 font-semibold" : ""
                  }
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="discount">Discount (₹)</Label>
                <Input
                  id="discount"
                  type="number"
                  min="0"
                  data-ocid="create_invoice.discount_input"
                  value={discount || ""}
                  onChange={(e) => setDiscount(safeNumber(e.target.value))}
                  placeholder="0"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="advance">Advance Received (₹)</Label>
                <Input
                  id="advance"
                  type="number"
                  min="0"
                  data-ocid="create_invoice.advance_input"
                  value={advancePaid || ""}
                  onChange={(e) => setAdvancePaid(safeNumber(e.target.value))}
                  placeholder="0"
                />
                {grandTotal > 0 && (
                  <p className="text-xs flex items-center gap-1 mt-1 px-2 py-1 rounded-md bg-amber-50 border border-amber-200 text-amber-700 font-medium">
                    <span>⚠️</span>
                    Min. advance required:{" "}
                    <strong className="text-amber-800">
                      {formatCurrency(minAdvance)}
                    </strong>
                    {advancePaid > 0 && advancePaid < minAdvance && (
                      <span className="ml-1 text-red-600">
                        (short by {formatCurrency(minAdvance - advancePaid)})
                      </span>
                    )}
                  </p>
                )}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="payNotes">Payment Notes</Label>
                <Input
                  id="payNotes"
                  data-ocid="create_invoice.payment_notes_input"
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  placeholder="UPI, cash, etc."
                />
              </div>
            </div>

            {/* Calculated summary */}
            <div className="bg-muted/40 rounded-lg p-4 space-y-2">
              <SummaryRow
                label="Deal Amount"
                value={formatCurrency(dealAmount)}
              />
              {discount > 0 && (
                <SummaryRow
                  label="Discount"
                  value={`-${formatCurrency(discount)}`}
                  className="text-green-600"
                />
              )}
              {extraChargesTotal > 0 && (
                <SummaryRow
                  label="Package Extra Charges"
                  value={`+${formatCurrency(extraChargesTotal)}`}
                  className="text-amber-600"
                />
              )}
              <SummaryRow label="Subtotal" value={formatCurrency(subtotal)} />
              {gstEnabled && gstPct > 0 && (
                <SummaryRow
                  label={`GST (${gstPct}%)`}
                  value={formatCurrency(gstAmount)}
                />
              )}
              <div className="border-t border-border pt-2">
                <SummaryRow
                  label="Grand Total"
                  value={formatCurrency(grandTotal)}
                  className="font-bold text-foreground text-base"
                />
              </div>
              <SummaryRow
                label="Advance Paid"
                value={formatCurrency(advancePaid)}
                className="text-green-600"
              />
              <SummaryRow
                label="Balance Due"
                value={formatCurrency(balance)}
                className={
                  balance > 0
                    ? "font-bold text-destructive text-base"
                    : "font-bold text-green-600 text-base"
                }
              />
            </div>

            {/* Auto-generated installment schedule */}
            {installments.length > 0 && (
              <div className="border border-border rounded-lg overflow-hidden">
                <div className="bg-muted/40 px-4 py-2 border-b border-border">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Payment Schedule (Auto-Generated)
                  </p>
                </div>
                <div className="divide-y divide-border">
                  {installments.map((inst, i) => (
                    <div
                      key={`${inst.date}-${i}`}
                      className="flex items-center justify-between px-4 py-3"
                      data-ocid={`create_invoice.installment.${i + 1}`}
                    >
                      <div>
                        <p className="font-medium text-sm">{inst.label}</p>
                        <p className="text-xs text-muted-foreground">
                          Due: {inst.date}
                        </p>
                      </div>
                      <div className="text-right flex items-center gap-2">
                        <span className="font-bold text-foreground">
                          {formatCurrency(inst.amount)}
                        </span>
                        {inst.isPaid ? (
                          <Badge
                            variant="outline"
                            className="text-[10px] border-green-300 text-green-600"
                          >
                            Paid
                          </Badge>
                        ) : (
                          <Badge
                            variant="outline"
                            className="text-[10px] border-yellow-300 text-yellow-600"
                          >
                            Pending
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </FormSection>

        {/* SECTION 9: Terms */}
        <FormSection title="Terms & Conditions" number={sectionNum(10)}>
          <div className="space-y-1.5">
            <Label htmlFor="terms">Terms & Conditions</Label>
            <Textarea
              id="terms"
              data-ocid="create_invoice.terms_textarea"
              value={terms}
              onChange={(e) => setTerms(e.target.value)}
              rows={6}
            />
          </div>
        </FormSection>

        {/* Submit */}
        <Button
          type="button"
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-12 text-base font-semibold"
          data-ocid="create_invoice.submit_button"
          onClick={handleSubmit}
        >
          Create Invoice
        </Button>
      </div>

      {/* Quick create team member modal */}
      <Dialog open={showAddTeamModal} onOpenChange={setShowAddTeamModal}>
        <DialogContent
          data-ocid="create_invoice.add_team_dialog"
          className="w-[95vw] max-w-sm max-h-[90vh] overflow-y-auto"
        >
          <DialogHeader>
            <DialogTitle>Add Team Member</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1.5">
              <Label>Full Name *</Label>
              <Input
                data-ocid="create_invoice.new_member_name_input"
                value={newMemberName}
                onChange={(e) => setNewMemberName(e.target.value)}
                placeholder="e.g. Mohit Sharma"
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label>Mobile</Label>
              <Input
                data-ocid="create_invoice.new_member_mobile_input"
                value={newMemberMobile}
                onChange={(e) => setNewMemberMobile(e.target.value)}
                placeholder="+91 98765 43210"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Role</Label>
              <Select value={newMemberRole} onValueChange={setNewMemberRole}>
                <SelectTrigger data-ocid="create_invoice.new_member_role_select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[
                    "Photographer",
                    "Videographer",
                    "Drone Pilot",
                    "Editor",
                    "Assistant",
                    "Album Designer",
                  ].map((r) => (
                    <SelectItem key={r} value={r}>
                      {r}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              data-ocid="create_invoice.add_team_cancel_button"
              onClick={() => setShowAddTeamModal(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
              data-ocid="create_invoice.add_team_confirm_button"
              onClick={handleAddTeamMember}
            >
              Add & Assign
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}

function FormSection({
  title,
  number,
  children,
}: { title: string; number: number; children: React.ReactNode }) {
  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="bg-muted/30 border-b border-border px-5 py-3 flex items-center gap-3">
        <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center shrink-0">
          {number}
        </div>
        <h3 className="font-display font-semibold text-foreground">{title}</h3>
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

function SummaryRow({
  label,
  value,
  className = "",
}: { label: string; value: string; className?: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className={className || "text-foreground"}>{value}</span>
    </div>
  );
}
