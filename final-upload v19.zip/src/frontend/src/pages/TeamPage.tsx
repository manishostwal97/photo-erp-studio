import AppLayout from "@/components/layout/AppLayout";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { formatCurrency, getInitials } from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type {
  AssignmentDateEntry,
  Invoice,
  TeamAssignment,
  TeamMember,
} from "@/types";
import { useNavigate } from "@tanstack/react-router";
import {
  CalendarDays,
  Camera,
  Clock,
  Loader2,
  MapPin,
  Pencil,
  Phone,
  Plus,
  Search,
  Trash2,
  Users,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { toast } from "sonner";
const sortByDateTime = (
  a: {
    date?: string;
    dateRangeStart?: string;
    startDate?: string;
    time?: string;
    startTime?: string;
  },
  b: {
    date?: string;
    dateRangeStart?: string;
    startDate?: string;
    time?: string;
    startTime?: string;
  },
) => {
  const dateA = new Date(
    a.date || a.dateRangeStart || a.startDate || "",
  ).getTime();
  const dateB = new Date(
    b.date || b.dateRangeStart || b.startDate || "",
  ).getTime();
  if (dateA !== dateB) return dateA - dateB;
  const timeA = (a.time || a.startTime || "").toString();
  const timeB = (b.time || b.startTime || "").toString();
  return timeA.localeCompare(timeB);
};

// ---- Types ----

interface MemberFormValues {
  name: string;
  phone: string;
  email: string;
  role: string;
  perDayRateWithCamera: number;
  perDayRateWithoutCamera: number;
  cameraName: string;
  equipmentDetails: string;
  notes: string;
  skills: string;
}

interface AssignmentFormValues {
  memberId: string;
  memberName: string;
  dateMode: "single" | "range";
  date: string;
  dateRangeStart: string;
  dateRangeEnd: string;
  program: string;
  startTime: string;
  endTime: string;
  clientName: string;
  location: string;
  notes: string;
  dayType: "full" | "half";
  invoiceId: string;
  syncWithInvoice: boolean;
}

const PHOTOGRAPHY_PROGRAMS = [
  "Mehendi",
  "Haldi",
  "Barat",
  "Wedding Ceremony",
  "Reception",
  "Sagai / Engagement",
  "Ring Ceremony",
  "Pre-Wedding Shoot",
  "Candid Photography",
  "Traditional Video",
  "Drone Shoot",
  "Baby Shower",
  "Birthday Party",
  "Corporate Event",
  "Maternity Shoot",
  "Other / Custom",
];

// ---- Skills Tag Input ----

function SkillsInput({
  value,
  onChange,
}: {
  value: string[];
  onChange: (v: string[]) => void;
}) {
  const [input, setInput] = useState("");

  function addSkill() {
    const trimmed = input.trim();
    if (trimmed && !value.includes(trimmed)) onChange([...value, trimmed]);
    setInput("");
  }

  return (
    <div className="space-y-2">
      <div className="flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              addSkill();
            }
          }}
          placeholder="Type skill and press Enter"
          className="h-9"
        />
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={addSkill}
          className="h-9 px-3"
        >
          Add
        </Button>
      </div>
      {value.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {value.map((skill) => (
            <span
              key={skill}
              className="inline-flex items-center gap-1 px-2 py-0.5 bg-primary/10 text-primary text-xs rounded-full font-medium"
            >
              {skill}
              <button
                type="button"
                onClick={() => onChange(value.filter((s) => s !== skill))}
                className="hover:text-primary/60 transition-colors"
                aria-label={`Remove ${skill}`}
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

// ---- Role Badge ----

function RoleBadge({ role }: { role: string }) {
  return (
    <Badge variant="secondary" className="text-[11px]">
      {role}
    </Badge>
  );
}

// ---- Member Form Modal ----

interface MemberModalProps {
  open: boolean;
  onClose: () => void;
  member?: TeamMember | null;
}

function MemberModal({ open, onClose, member }: MemberModalProps) {
  const { addTeamMember, updateTeamMember } = useERPStore();
  const isEdit = !!member;
  const [skills, setSkills] = useState<string[]>(member?.skills ?? []);
  const [photo, setPhoto] = useState<string>(member?.photo ?? "");
  const [photoLoading, setPhotoLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<MemberFormValues>({
    defaultValues: {
      name: member?.name ?? "",
      phone: member?.phone ?? "",
      email: member?.email ?? "",
      role: member?.role ?? "",
      perDayRateWithCamera: member?.perDayRateWithCamera ?? 0,
      perDayRateWithoutCamera: member?.perDayRateWithoutCamera ?? 0,
      cameraName: member?.cameraName ?? "",
      equipmentDetails: member?.equipmentDetails ?? "",
      notes: member?.notes ?? "",
      skills: "",
    },
  });

  async function onSubmit(data: MemberFormValues) {
    setSubmitting(true);
    try {
      if (isEdit && member) {
        updateTeamMember(member.id, {
          name: data.name,
          phone: data.phone,
          email: data.email,
          role: data.role,
          perDayRateWithCamera: Number(data.perDayRateWithCamera),
          perDayRateWithoutCamera: Number(data.perDayRateWithoutCamera),
          cameraName: data.cameraName,
          equipmentDetails: data.equipmentDetails,
          notes: data.notes,
          skills,
          photo,
        });
        toast.success("Member updated");
      } else {
        const newMember: TeamMember = {
          id: `member-${Date.now()}`,
          name: data.name,
          phone: data.phone,
          email: data.email,
          role: data.role,
          perDayRateWithCamera: Number(data.perDayRateWithCamera),
          perDayRateWithoutCamera: Number(data.perDayRateWithoutCamera),
          cameraName: data.cameraName,
          equipmentDetails: data.equipmentDetails,
          notes: data.notes,
          skills,
          photo,
          joinedAt: new Date().toISOString(),
          assignments: [],
          workHistory: [],
        };
        addTeamMember(newMember);
        toast.success("Member added");
      }
      handleClose();
    } finally {
      setSubmitting(false);
    }
  }

  async function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoLoading(true);
    const reader = new FileReader();
    reader.onload = () => {
      setPhoto(reader.result as string);
      setPhotoLoading(false);
    };
    reader.readAsDataURL(file);
  }

  function handleClose() {
    reset();
    setSkills(member?.skills ?? []);
    setPhoto(member?.photo ?? "");
    onClose();
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent className="w-[95vw] max-w-lg max-h-[90vh] p-0 flex flex-col sm:w-full">
        <DialogHeader className="px-6 pt-6 pb-2 shrink-0">
          <DialogTitle className="font-display">
            {isEdit ? "Edit Team Member" : "Add Team Member"}
          </DialogTitle>
        </DialogHeader>

        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex flex-col flex-1 min-h-0"
        >
          <div className="flex-1 overflow-y-auto px-6 space-y-4 pt-2">
            {/* Photo */}
            <div className="flex flex-col items-center gap-3">
              <button
                type="button"
                className="relative w-20 h-20 rounded-full overflow-hidden bg-muted border-2 border-border cursor-pointer group"
                onClick={() => fileRef.current?.click()}
                aria-label="Upload photo"
              >
                {photo ? (
                  <img
                    src={photo}
                    alt={member?.name ?? "Photo"}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                    {photoLoading ? (
                      <Loader2 className="w-6 h-6 animate-spin" />
                    ) : (
                      <Camera className="w-8 h-8" />
                    )}
                  </div>
                )}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Camera className="w-5 h-5 text-white" />
                </div>
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handlePhotoChange}
                data-ocid="team.photo_upload"
              />
              <p className="text-xs text-muted-foreground">
                Click to upload photo
              </p>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="tm-name">Name *</Label>
              <Input
                id="tm-name"
                {...register("name", { required: "Name is required" })}
                placeholder="Full name"
                data-ocid="team.name_input"
              />
              {errors.name && (
                <p
                  className="text-xs text-destructive"
                  data-ocid="team.name.field_error"
                >
                  {errors.name.message}
                </p>
              )}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="tm-phone">Mobile *</Label>
              <Input
                id="tm-phone"
                {...register("phone", { required: "Mobile is required" })}
                placeholder="+91 98765 43210"
                data-ocid="team.mobile_input"
              />
              {errors.phone && (
                <p
                  className="text-xs text-destructive"
                  data-ocid="team.mobile.field_error"
                >
                  {errors.phone.message}
                </p>
              )}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="tm-email">Email</Label>
              <Input
                id="tm-email"
                type="email"
                {...register("email")}
                placeholder="member@studio.com"
                data-ocid="team.email_input"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="tm-role">Role</Label>
              <Input
                id="tm-role"
                {...register("role")}
                placeholder="Photographer, Videographer, Editor…"
                data-ocid="team.role_input"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="tm-rate-camera">
                  Per Day Rate With Camera ₹
                </Label>
                <Input
                  id="tm-rate-camera"
                  type="number"
                  min={0}
                  {...register("perDayRateWithCamera", { valueAsNumber: true })}
                  placeholder="2500"
                  data-ocid="team.day_rate_camera_input"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="tm-rate-no-camera">
                  Per Day Rate Without Camera ₹
                </Label>
                <Input
                  id="tm-rate-no-camera"
                  type="number"
                  min={0}
                  {...register("perDayRateWithoutCamera", {
                    valueAsNumber: true,
                  })}
                  placeholder="1500"
                  data-ocid="team.day_rate_no_camera_input"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="tm-camera-name">Camera Name</Label>
              <Input
                id="tm-camera-name"
                {...register("cameraName")}
                placeholder="e.g. Sony A7IV, Canon R6"
                data-ocid="team.camera_name_input"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="tm-equip-details">Equipment Details</Label>
              <Textarea
                id="tm-equip-details"
                {...register("equipmentDetails")}
                placeholder="Lenses, accessories, other gear…"
                rows={2}
                data-ocid="team.equipment_details_textarea"
              />
            </div>

            <div className="space-y-1.5">
              <Label>Skills</Label>
              <SkillsInput value={skills} onChange={setSkills} />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="tm-notes">Notes</Label>
              <Textarea
                id="tm-notes"
                {...register("notes")}
                placeholder="Additional notes about this team member…"
                rows={3}
                data-ocid="team.notes_textarea"
              />
            </div>
          </div>
          <div className="flex gap-3 px-6 py-4 border-t shrink-0">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={handleClose}
              data-ocid="team.cancel_button"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
              disabled={submitting}
              data-ocid="team.submit_button"
            >
              {submitting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {isEdit ? "Update Member" : "Add Member"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ---- Assignment Form Modal ----

interface AssignmentModalProps {
  open: boolean;
  onClose: () => void;
  members: TeamMember[];
  invoices: Invoice[];
  editAssignment?: (TeamAssignment & { id: string }) | null;
}

function AssignmentModal({
  open,
  onClose,
  members,
  invoices,
  editAssignment,
}: AssignmentModalProps) {
  const { addTeamAssignment, updateTeamAssignment } = useERPStore();
  const isEdit = !!editAssignment;

  // ── Multi-date entries state ──
  const [dateEntries, setDateEntries] = useState<AssignmentDateEntry[]>([
    {
      date: new Date().toISOString().split("T")[0],
      program: "",
      dayType: "full",
      source: "custom",
    },
  ]);
  const [_assignMode, _setAssignMode] = useState<"multi" | "legacy">(
    editAssignment?.dateEntries?.length ? "multi" : "multi",
  );
  const [conflictWarning, setConflictWarning] = useState<string>("");
  const [syncedInvoiceId, setSyncedInvoiceId] = useState("");
  const lastSyncedInvoiceRef = useRef<string>("");

  const {
    register,
    handleSubmit,
    control,
    reset,
    watch,
    setValue,
    formState: { errors },
  } = useForm<AssignmentFormValues>({
    defaultValues: {
      memberId: editAssignment?.teamMemberId ?? "",
      memberName: editAssignment?.teamMemberName ?? "",
      dateMode: editAssignment?.dateRangeStart ? "range" : "single",
      date:
        editAssignment?.date ??
        editAssignment?.dateRangeStart ??
        new Date().toISOString().split("T")[0],
      dateRangeStart:
        editAssignment?.dateRangeStart ??
        new Date().toISOString().split("T")[0],
      dateRangeEnd:
        editAssignment?.dateRangeEnd ?? new Date().toISOString().split("T")[0],
      program: editAssignment?.program ?? "",
      startTime: editAssignment?.startTime ?? "09:00",
      endTime: editAssignment?.endTime ?? "17:00",
      clientName: editAssignment?.clientName ?? "",
      location: editAssignment?.location ?? "",
      notes: editAssignment?.notes ?? "",
      dayType: editAssignment?.dayType ?? "full",
      invoiceId: editAssignment?.invoiceId ?? "",
      syncWithInvoice: false,
    },
  });

  // Initialize entries when modal opens
  useEffect(() => {
    if (open) {
      const entries: AssignmentDateEntry[] =
        editAssignment?.dateEntries?.map((e) => ({
          ...e,
          source: editAssignment.invoiceId ? "invoice" : (e.source ?? "custom"),
        })) ??
        (editAssignment?.date
          ? [
              {
                date: editAssignment.date,
                program: editAssignment.program ?? "",
                dayType: editAssignment.dayType ?? "full",
                source: editAssignment.invoiceId ? "invoice" : "custom",
              },
            ]
          : editAssignment?.dateRangeStart
            ? [
                {
                  date: editAssignment.dateRangeStart,
                  program: editAssignment.program ?? "",
                  dayType: editAssignment.dayType ?? "full",
                  source: editAssignment.invoiceId ? "invoice" : "custom",
                },
              ]
            : [
                {
                  date: new Date().toISOString().split("T")[0],
                  program: "",
                  dayType: "full",
                  source: "custom",
                },
              ]);
      setDateEntries(entries);
      if (editAssignment?.invoiceId) {
        setSyncedInvoiceId(editAssignment.invoiceId);
        lastSyncedInvoiceRef.current = editAssignment.invoiceId;
      } else {
        setSyncedInvoiceId("");
        lastSyncedInvoiceRef.current = "";
      }
      // Pre-fill clientName from assignment or linked invoice
      if (editAssignment?.clientName) {
        setValue("clientName", editAssignment.clientName);
      } else if (editAssignment?.invoiceId) {
        const linkedInvoice = invoices.find(
          (i) => i.id === editAssignment.invoiceId,
        );
        if (linkedInvoice?.clientName) {
          setValue("clientName", linkedInvoice.clientName);
        }
      }
    }
  }, [open, editAssignment, invoices, setValue]);

  const selectedMemberId = watch("memberId");
  const _dateMode = watch("dateMode");
  const _syncWithInvoice = watch("syncWithInvoice");
  const _selectedInvoiceId = watch("invoiceId");
  const _dayType = watch("dayType");

  // ── Date entry helpers ──

  function updateEntry(idx: number, patch: Partial<AssignmentDateEntry>) {
    setDateEntries((prev) =>
      prev.map((e, i) => (i === idx ? { ...e, ...patch } : e)),
    );
  }

  function addEntry() {
    const lastDate =
      dateEntries[dateEntries.length - 1]?.date ??
      new Date().toISOString().split("T")[0];
    // Suggest next calendar day
    const next = new Date(lastDate);
    next.setDate(next.getDate() + 1);
    setDateEntries((prev) => [
      ...prev,
      {
        date: next.toISOString().split("T")[0],
        program: "",
        dayType: "full",
        source: "custom",
      },
    ]);
  }

  function removeEntry(idx: number) {
    if (dateEntries.length === 1) return; // keep at least one
    setDateEntries((prev) => prev.filter((_, i) => i !== idx));
  }

  // Auto-fill dates, programs, times, location from invoice in exact order
  function handleInvoiceSync(invoiceId: string) {
    if (invoiceId === lastSyncedInvoiceRef.current) return;
    const inv = invoices.find((i) => i.id === invoiceId);
    if (!inv) return;

    if (inv.programs && inv.programs.length > 0) {
      const entries: AssignmentDateEntry[] = [...inv.programs]
        .sort(sortByDateTime)
        .filter((p) => p.enabled)
        .map((p) => ({
          date: p.date || inv.eventStartDate,
          program: p.name,
          dayType: "full" as const,
          startTime: p.startTime,
          endTime: p.endTime,
          location: p.location,
          source: "invoice" as const,
        }));
      if (entries.length > 0) {
        setDateEntries(entries);
        setSyncedInvoiceId(invoiceId);
        lastSyncedInvoiceRef.current = invoiceId;
        // Set top-level fields from first program
        if (entries[0].startTime) setValue("startTime", entries[0].startTime);
        if (entries[0].endTime) setValue("endTime", entries[0].endTime);
        if (entries[0].location) setValue("location", entries[0].location);
        else if (inv.eventVenueName) setValue("location", inv.eventVenueName);
        if (inv.clientName) setValue("clientName", inv.clientName);
        return;
      }
    }

    // Fallback: single entry from event start
    setDateEntries([
      {
        date: inv.eventStartDate,
        program: "",
        dayType: "full",
        source: "invoice",
      },
    ]);
    setSyncedInvoiceId(invoiceId);
    lastSyncedInvoiceRef.current = invoiceId;
    if (inv.eventVenueName) setValue("location", inv.eventVenueName);
    if (inv.clientName) setValue("clientName", inv.clientName);
  }

  function onSubmit(data: AssignmentFormValues) {
    const selectedMember = members.find((m) => m.id === data.memberId);
    const baseRate =
      selectedMember?.perDayRateWithCamera ||
      selectedMember?.perDayRateWithoutCamera ||
      0;

    // Check for scheduling conflicts with the same member in other invoices
    let computedWarning = "";
    if (selectedMember) {
      const newStart = dateEntries[0]?.date ?? data.dateRangeStart ?? data.date;
      const newEnd =
        dateEntries[dateEntries.length - 1]?.date ??
        data.dateRangeEnd ??
        data.date;

      if (newStart) {
        const conflictingAssignment = (selectedMember.assignments ?? []).find(
          (a) => {
            // Skip the assignment being edited
            if (editAssignment && a.id === editAssignment.id) return false;
            const aStart =
              a.dateRangeStart ?? a.dateEntries?.[0]?.date ?? a.date ?? "";
            const aEnd =
              a.dateRangeEnd ??
              (a.dateEntries?.length
                ? a.dateEntries[a.dateEntries.length - 1].date
                : undefined) ??
              a.date ??
              "";
            if (!aStart || !aEnd) return false;
            // Overlap: startA <= endB && endA >= startB
            return aStart <= (newEnd ?? newStart) && aEnd >= newStart;
          },
        );
        if (conflictingAssignment) {
          const conflictDate =
            conflictingAssignment.dateRangeStart ??
            conflictingAssignment.date ??
            "";
          const conflictProgram =
            conflictingAssignment.program ??
            conflictingAssignment.dateEntries?.[0]?.program ??
            "event";
          computedWarning = `Warning: ${selectedMember.name} is already assigned to ${conflictProgram}${
            conflictDate
              ? ` on ${new Date(conflictDate).toLocaleDateString("en-IN", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                })}`
              : ""
          } (overlapping dates). Saving anyway.`;
        }
      }
    }
    setConflictWarning(computedWarning);

    // Use multi-date entries
    const validEntries = dateEntries.filter((e) => e.date && e.program);
    const primaryEntry = validEntries[0];
    const rateUsed =
      primaryEntry?.dayType === "half" ? baseRate * 0.5 : baseRate;

    const assignmentData: TeamAssignment & { id: string } = {
      id:
        editAssignment?.id ??
        `assign-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      teamMemberId: data.memberId,
      teamMemberName: data.memberName,
      program: primaryEntry?.program ?? data.program,
      date: primaryEntry?.date ?? data.date,
      dateRangeStart:
        validEntries.length > 1 ? validEntries[0].date : undefined,
      dateRangeEnd:
        validEntries.length > 1
          ? validEntries[validEntries.length - 1].date
          : undefined,
      dateEntries: validEntries.length > 0 ? validEntries : undefined,
      startTime: data.startTime,
      endTime: data.endTime,
      location: data.location,
      notes: data.notes,
      dayType: primaryEntry?.dayType ?? data.dayType,
      rateUsed,
      invoiceId: data.invoiceId || undefined,
      createdAt: editAssignment?.createdAt ?? Date.now(),
      updatedAt: Date.now(),
    };

    if (isEdit && editAssignment?.id) {
      updateTeamAssignment(editAssignment.id, assignmentData);
      toast.success("Assignment updated");
    } else {
      addTeamAssignment(assignmentData);
      toast.success("Assignment created");
    }
    reset();
    setDateEntries([
      {
        date: new Date().toISOString().split("T")[0],
        program: "",
        dayType: "full",
      },
    ]);
    onClose();
  }

  function handleClose() {
    reset();
    setDateEntries([
      {
        date: new Date().toISOString().split("T")[0],
        program: "",
        dayType: "full",
        source: "custom",
      },
    ]);
    setSyncedInvoiceId("");
    lastSyncedInvoiceRef.current = "";
    onClose();
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent className="w-[95vw] max-w-lg max-h-[90vh] p-0 flex flex-col sm:w-full">
        <DialogHeader className="px-6 pt-6 pb-2 shrink-0">
          <DialogTitle className="font-display">
            {isEdit ? "Edit Assignment" : "New Team Assignment"}
          </DialogTitle>
        </DialogHeader>

        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex flex-col flex-1 min-h-0"
        >
          <div className="flex-1 overflow-y-auto px-6 space-y-4 pt-2">
            {/* Team Member */}
            <div className="space-y-1.5">
              <Label>Team Member *</Label>
              <Controller
                name="memberId"
                control={control}
                rules={{ required: "Select a member" }}
                render={({ field }) => (
                  <Select
                    value={field.value}
                    onValueChange={(val) => {
                      field.onChange(val);
                      const m = members.find((x) => x.id === val);
                      if (m) setValue("memberName", m.name);
                    }}
                  >
                    <SelectTrigger data-ocid="team_assign.member_select">
                      <SelectValue placeholder="Select team member" />
                    </SelectTrigger>
                    <SelectContent>
                      {members.map((m) => (
                        <SelectItem key={m.id} value={m.id}>
                          {m.name}
                          {m.role ? ` — ${m.role}` : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
              {errors.memberId && (
                <p
                  className="text-xs text-destructive"
                  data-ocid="team_assign.member.field_error"
                >
                  {errors.memberId.message}
                </p>
              )}
            </div>

            {/* Link to Invoice */}
            <div className="space-y-1.5">
              <Label>Link to Invoice (optional)</Label>
              <Controller
                name="invoiceId"
                control={control}
                render={({ field }) => (
                  <Select
                    value={field.value || "none"}
                    onValueChange={(val) => {
                      const v = val === "none" ? "" : val;
                      field.onChange(v);
                      if (v) {
                        handleInvoiceSync(v);
                      } else {
                        setSyncedInvoiceId("");
                        lastSyncedInvoiceRef.current = "";
                      }
                    }}
                  >
                    <SelectTrigger data-ocid="team_assign.invoice_select">
                      <SelectValue placeholder="Select invoice (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {invoices.map((inv) => (
                        <SelectItem key={inv.id} value={inv.id}>
                          {inv.invoiceNumber} — {inv.clientName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
            </div>

            {/* Linked invoice info */}
            {syncedInvoiceId && (
              <div className="rounded-lg border border-primary/20 bg-primary/5 px-3 py-2 space-y-0.5">
                <p className="text-xs font-medium text-foreground">
                  Client:{" "}
                  {invoices.find((i) => i.id === syncedInvoiceId)?.clientName}
                </p>
                {invoices.find((i) => i.id === syncedInvoiceId)
                  ?.eventVenueName && (
                  <p className="text-[11px] text-muted-foreground">
                    Location:{" "}
                    {
                      invoices.find((i) => i.id === syncedInvoiceId)
                        ?.eventVenueName
                    }
                  </p>
                )}
              </div>
            )}

            {/* ── Multi-date Entry Table ── */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-semibold">
                  Work Dates &amp; Programs
                  <span className="ml-1.5 text-[11px] text-muted-foreground font-normal">
                    (add one row per day)
                  </span>
                </Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addEntry}
                  className="h-7 px-2 text-xs gap-1"
                  data-ocid="team_assign.add_date_row_button"
                >
                  <Plus className="w-3 h-3" />
                  {dateEntries.some((e) => e.source === "invoice")
                    ? "Add Custom Program"
                    : "Add Date"}
                </Button>
              </div>

              <div className="rounded-xl border border-border overflow-x-auto">
                {/* Header */}
                <div className="grid grid-cols-[1fr_1.4fr_auto_auto_auto] gap-0 bg-muted/50 px-3 py-1.5 border-b border-border">
                  <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">
                    Date
                  </span>
                  <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">
                    Program
                  </span>
                  <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">
                    Day
                  </span>
                  <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">
                    Cam
                  </span>
                  <span className="w-7" />
                </div>

                {/* Rows */}
                <div className="divide-y divide-border">
                  {dateEntries.map((entry, idx) => (
                    <div
                      key={`${entry.date}-${entry.program}-${idx}`}
                      className="grid grid-cols-[1fr_1.4fr_auto_auto_auto] gap-2 items-center px-3 py-2"
                      data-ocid={`team_assign.date_row.${idx + 1}`}
                    >
                      {/* Date */}
                      <Input
                        type="date"
                        value={entry.date}
                        onChange={(e) =>
                          updateEntry(idx, { date: e.target.value })
                        }
                        className="h-8 text-xs px-2 border-0 shadow-none bg-transparent focus:bg-background focus:border focus:border-input rounded"
                        data-ocid={`team_assign.date_entry.${idx + 1}`}
                      />

                      {/* Program */}
                      {entry.source === "invoice" ? (
                        <div className="h-8 flex items-center text-xs font-medium text-foreground px-2">
                          {entry.program}
                          {entry.startTime && entry.endTime && (
                            <span className="ml-1.5 text-[10px] text-muted-foreground">
                              ({entry.startTime}–{entry.endTime})
                            </span>
                          )}
                        </div>
                      ) : (
                        <Select
                          value={entry.program || "__none"}
                          onValueChange={(val) =>
                            updateEntry(idx, {
                              program: val === "__none" ? "" : val,
                            })
                          }
                        >
                          <SelectTrigger
                            className="h-8 text-xs border-0 shadow-none bg-transparent focus:bg-background focus:border focus:border-input"
                            data-ocid={`team_assign.program_entry.${idx + 1}`}
                          >
                            <SelectValue placeholder="Program" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="__none">Select…</SelectItem>
                            {PHOTOGRAPHY_PROGRAMS.map((p) => (
                              <SelectItem key={p} value={p}>
                                {p}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}

                      {/* Day Type Toggle */}
                      <button
                        type="button"
                        onClick={() =>
                          updateEntry(idx, {
                            dayType: entry.dayType === "full" ? "half" : "full",
                          })
                        }
                        className={`h-8 px-2.5 text-[11px] font-semibold rounded-lg border transition-colors whitespace-nowrap ${
                          entry.dayType === "full"
                            ? "bg-green-50 border-green-300 text-green-700 hover:bg-green-100"
                            : "bg-amber-50 border-amber-300 text-amber-700 hover:bg-amber-100"
                        }`}
                        data-ocid={`team_assign.day_type_toggle.${idx + 1}`}
                        title={
                          entry.dayType === "full"
                            ? "Full Day — click for Half Day"
                            : "Half Day — click for Full Day"
                        }
                      >
                        {entry.dayType === "full" ? "Full" : "Half"}
                      </button>

                      {/* Camera Toggle */}
                      <button
                        type="button"
                        onClick={() =>
                          updateEntry(idx, { withCamera: !entry.withCamera })
                        }
                        title={entry.withCamera ? "With Camera" : "No Camera"}
                        className={`p-1.5 rounded text-xs border transition-colors ${
                          entry.withCamera
                            ? "bg-blue-50 text-blue-700 border-blue-300 hover:bg-blue-100"
                            : "bg-muted text-muted-foreground border-border hover:bg-muted/80"
                        }`}
                        data-ocid={`team_assign.camera_toggle.${idx + 1}`}
                        aria-label={
                          entry.withCamera ? "With Camera" : "No Camera"
                        }
                      >
                        📷
                      </button>

                      {/* Remove Row */}
                      <button
                        type="button"
                        onClick={() => removeEntry(idx)}
                        className="w-7 h-7 flex items-center justify-center rounded text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors disabled:opacity-30"
                        disabled={dateEntries.length === 1}
                        aria-label="Remove date row"
                        data-ocid={`team_assign.remove_date_row.${idx + 1}`}
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Summary row */}
                {dateEntries.length > 1 && (
                  <div className="px-3 py-2 bg-muted/30 border-t border-border flex items-center gap-2 flex-wrap">
                    <span className="text-[11px] text-muted-foreground">
                      {dateEntries.length} dates:
                    </span>
                    {dateEntries.map((e, _i) => (
                      <span
                        key={`summary-${e.date}-${e.program}`}
                        className="inline-flex items-center gap-1 px-2 py-0.5 bg-primary/8 text-primary text-[10px] rounded-full border border-primary/20"
                      >
                        {new Date(e.date).toLocaleDateString("en-IN", {
                          day: "numeric",
                          month: "short",
                        })}
                        {e.program && <> → {e.program}</>}
                        <span
                          className={`font-medium ${
                            e.dayType === "half"
                              ? "text-amber-600"
                              : "text-green-600"
                          }`}
                        >
                          {e.dayType === "half" ? " ½" : " ●"}
                        </span>
                        {e.withCamera && (
                          <span className="ml-1 text-xs">📷</span>
                        )}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Time */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="assign-start">Start Time</Label>
                <Input
                  id="assign-start"
                  type="time"
                  {...register("startTime")}
                  data-ocid="team_assign.start_time_input"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="assign-end">End Time</Label>
                <Input
                  id="assign-end"
                  type="time"
                  {...register("endTime")}
                  data-ocid="team_assign.end_time_input"
                />
              </div>
            </div>

            {/* Location */}
            <div className="space-y-1.5">
              <Label htmlFor="assign-location">Location</Label>
              <Input
                id="assign-location"
                {...register("location")}
                placeholder="Venue / City"
                data-ocid="team_assign.location_input"
              />
            </div>

            {/* Notes */}
            <div className="space-y-1.5">
              <Label htmlFor="assign-notes">Notes</Label>
              <Textarea
                id="assign-notes"
                {...register("notes")}
                placeholder="Additional notes…"
                rows={2}
                data-ocid="team_assign.notes_textarea"
              />
            </div>

            {conflictWarning && (
              <p
                className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-md px-3 py-2"
                data-ocid="team_assign.conflict_warning"
              >
                {conflictWarning}
              </p>
            )}
          </div>
          <div className="flex gap-3 px-6 py-4 border-t shrink-0">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={handleClose}
              data-ocid="team_assign.cancel_button"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
              disabled={
                !selectedMemberId || dateEntries.every((e) => !e.program)
              }
              data-ocid="team_assign.submit_button"
            >
              {isEdit ? "Update Assignment" : "Save Assignment"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ---- Member Card ----

function MemberCard({
  member,
  onEdit,
  onDelete,
}: { member: TeamMember; onEdit: () => void; onDelete: () => void }) {
  const navigate = useNavigate();
  const initials = getInitials(member.name);
  const visibleSkills = (member.skills ?? []).slice(0, 3);
  const extraSkills = (member.skills ?? []).length - 3;

  return (
    <Card className="group hover:shadow-md transition-shadow duration-200 border-border">
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <Avatar className="w-14 h-14 border-2 border-border">
              {member.photo && (
                <AvatarFallback className="bg-primary/10 text-primary text-lg font-bold">
                  {initials}
                </AvatarFallback>
              )}
              {member.photo ? (
                <img
                  src={member.photo}
                  alt={member.name}
                  className="w-full h-full object-cover rounded-full"
                />
              ) : null}
              <AvatarFallback className="bg-primary/10 text-primary text-lg font-bold">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <p className="font-semibold text-foreground truncate">
                {member.name}
              </p>
              <div className="flex flex-wrap gap-1 mt-1">
                {member.role && <RoleBadge role={member.role} />}
              </div>
            </div>
          </div>
          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={(e) => {
                e.stopPropagation();
                onEdit();
              }}
              data-ocid="team.edit_button"
            >
              <Pencil className="w-3.5 h-3.5" />
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-7 w-7 text-destructive hover:text-destructive"
              onClick={(e) => {
                e.stopPropagation();
                onDelete();
              }}
              data-ocid="team.delete_button"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>

        {(member.skills ?? []).length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {visibleSkills.map((skill) => (
              <span
                key={skill}
                className="px-2 py-0.5 bg-primary/10 text-primary text-[11px] rounded-full font-medium"
              >
                {skill}
              </span>
            ))}
            {extraSkills > 0 && (
              <span className="px-2 py-0.5 bg-muted text-muted-foreground text-[11px] rounded-full">
                +{extraSkills} more
              </span>
            )}
          </div>
        )}

        {member.cameraName && (
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
            <Camera className="w-3 h-3 flex-shrink-0" />
            <span className="truncate">{member.cameraName}</span>
          </div>
        )}

        {(member.perDayRateWithCamera > 0 ||
          member.perDayRateWithoutCamera > 0) && (
          <div className="flex gap-3 text-xs mb-3 flex-wrap">
            {member.perDayRateWithCamera > 0 && (
              <span className="bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">
                📷 {formatCurrency(member.perDayRateWithCamera)}/day
              </span>
            )}
            {member.perDayRateWithoutCamera > 0 && (
              <span className="bg-muted text-muted-foreground px-2 py-0.5 rounded-full font-medium">
                {formatCurrency(member.perDayRateWithoutCamera)}/day
              </span>
            )}
          </div>
        )}

        <div className="flex items-center justify-between text-sm border-t border-border pt-3 mt-3">
          <a
            href={`tel:${member.phone}`}
            className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors"
            data-ocid="team.phone_link"
          >
            <Phone className="w-3.5 h-3.5" />
            <span className="font-mono text-[12px]">{member.phone}</span>
          </a>
        </div>

        <Button
          type="button"
          variant="outline"
          className="w-full mt-3 h-8 text-xs hover:bg-primary hover:text-primary-foreground hover:border-primary transition-colors"
          onClick={() => navigate({ to: `/team/${member.id}` })}
          data-ocid="team.view_profile_button"
        >
          View Profile
        </Button>
      </CardContent>
    </Card>
  );
}

// ---- Assignment Row ----

function AssignmentRow({
  assignment,
  index,
  onDelete,
  onEdit,
}: {
  assignment: TeamAssignment & { id: string };
  index: number;
  onDelete: () => void;
  onEdit: () => void;
}) {
  const hasMultipleDates =
    assignment.dateEntries && assignment.dateEntries.length > 1;

  // Build a human-readable date summary that covers all assignment variants:
  //  • multi-date entries → list first 2 dates + count
  //  • date range         → "1 Jan – 3 Jan 2025"
  //  • single date        → "1 Jan 2025"
  const displayDate = hasMultipleDates
    ? (() => {
        const entries = assignment.dateEntries!;
        const first = new Date(entries[0].date).toLocaleDateString("en-IN", {
          day: "numeric",
          month: "short",
        });
        const last = new Date(
          entries[entries.length - 1].date,
        ).toLocaleDateString("en-IN", {
          day: "numeric",
          month: "short",
          year: "numeric",
        });
        return entries.length === 1
          ? first
          : `${first} – ${last} (${entries.length} days)`;
      })()
    : assignment.dateRangeStart && assignment.dateRangeEnd
      ? `${new Date(assignment.dateRangeStart).toLocaleDateString("en-IN", { day: "numeric", month: "short" })} – ${new Date(assignment.dateRangeEnd).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}`
      : assignment.date
        ? new Date(assignment.date).toLocaleDateString("en-IN", {
            day: "numeric",
            month: "short",
            year: "numeric",
          })
        : "";

  const dateForCalendar = hasMultipleDates
    ? assignment.dateEntries![0].date
    : (assignment.dateRangeStart ?? assignment.date);
  const primaryDayType =
    assignment.dateEntries?.[0]?.dayType ?? assignment.dayType;
  const isHalf = primaryDayType === "half";

  return (
    <div
      className="group flex items-start gap-3 p-3 rounded-xl border border-border hover:bg-muted/30 transition-colors"
      data-ocid={`team.assignment.item.${index}`}
    >
      <div className="flex-shrink-0 w-12 text-center">
        <div className="text-[10px] font-bold text-primary uppercase">
          {dateForCalendar
            ? new Date(dateForCalendar).toLocaleString("en-IN", {
                month: "short",
              })
            : ""}
        </div>
        <div className="text-base font-bold text-foreground leading-none">
          {dateForCalendar ? new Date(dateForCalendar).getDate() : ""}
        </div>
      </div>
      <div className="w-px bg-primary/20 self-stretch flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <div className="flex flex-wrap items-center gap-1.5 mb-0.5">
          <span className="font-semibold text-sm text-foreground truncate">
            {assignment.teamMemberName}
          </span>
          {!hasMultipleDates && assignment.program && (
            <Badge variant="secondary" className="text-[10px]">
              {assignment.program}
            </Badge>
          )}
          {!hasMultipleDates && (
            <Badge
              variant="outline"
              className={`text-[10px] ${
                isHalf
                  ? "border-amber-300 text-amber-600"
                  : "border-green-300 text-green-600"
              }`}
            >
              {isHalf ? "Half" : "Full"}
            </Badge>
          )}
          {hasMultipleDates && (
            <Badge variant="secondary" className="text-[10px]">
              {assignment.dateEntries!.length} days
            </Badge>
          )}
        </div>
        <p className="text-[11px] text-muted-foreground mb-1">{displayDate}</p>

        {/* Multi-date entry chips */}
        {hasMultipleDates && (
          <div className="flex flex-wrap gap-1 mb-1">
            {assignment.dateEntries!.map((e, i) => (
              <span
                key={`${e.date || ""}-${e.program || ""}-${i}`}
                className={`inline-flex items-center gap-1 px-1.5 py-0.5 text-[10px] rounded-full border ${
                  e.dayType === "half"
                    ? "bg-amber-50 border-amber-200 text-amber-700"
                    : "bg-green-50 border-green-200 text-green-700"
                }`}
              >
                {new Date(e.date).toLocaleDateString("en-IN", {
                  day: "numeric",
                  month: "short",
                })}
                {e.program && <> → {e.program}</>}
                <span className="font-semibold">
                  {e.dayType === "half" ? " ½" : ""}
                </span>
              </span>
            ))}
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          {(assignment.startTime || assignment.endTime) && (
            <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
              <Clock className="w-3 h-3" />
              {assignment.startTime}
              {assignment.endTime ? ` – ${assignment.endTime}` : ""}
            </span>
          )}
          {assignment.location && (
            <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
              <MapPin className="w-3 h-3" />
              {assignment.location}
            </span>
          )}
        </div>
      </div>
      <div className="flex gap-1 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={onEdit}
          data-ocid={`team.assignment.edit_button.${index}`}
          aria-label="Edit assignment"
        >
          <Pencil className="w-3.5 h-3.5" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="h-7 w-7 text-destructive hover:text-destructive"
          onClick={onDelete}
          data-ocid={`team.assignment.delete_button.${index}`}
          aria-label="Delete assignment"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
}

// ---- Assignments Section ----

type StoredAssignment = TeamAssignment & { id: string };

function AssignmentsSection({ members }: { members: TeamMember[] }) {
  const { deleteTeamAssignment, invoices } = useERPStore();
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] =
    useState<StoredAssignment | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [dateFilter, setDateFilter] = useState("");

  // Flatten all assignments from all members
  const allAssignments: StoredAssignment[] = members.flatMap((m) =>
    (m.assignments ?? []).map((a) => ({
      ...a,
      id: a.id ?? `${m.id}-${a.date}-${a.program}`,
      teamMemberId: m.id,
      teamMemberName: m.name,
    })),
  );

  const sorted = [...allAssignments].sort((a, b) => {
    const aDate = a.dateRangeStart ?? a.date ?? "";
    const bDate = b.dateRangeStart ?? b.date ?? "";
    return new Date(bDate).getTime() - new Date(aDate).getTime();
  });

  const filtered = dateFilter
    ? sorted.filter(
        (a) =>
          a.date === dateFilter ||
          a.dateRangeStart === dateFilter ||
          (a.dateRangeStart &&
            a.dateRangeEnd &&
            dateFilter >= a.dateRangeStart &&
            dateFilter <= a.dateRangeEnd),
      )
    : sorted;

  const today = new Date().toISOString().split("T")[0];
  const upcoming = sorted
    .filter((a) => {
      const d = a.dateRangeStart ?? a.date ?? "";
      return d >= today;
    })
    .slice(0, 8);

  function handleDeleteAssignment(assignId: string) {
    deleteTeamAssignment(assignId);
    toast.success("Assignment removed");
    setDeleteTarget(null);
  }

  return (
    <div className="space-y-5">
      {upcoming.length > 0 && (
        <Card className="border-border" data-ocid="team.upcoming_schedule">
          <CardHeader className="pb-2">
            <CardTitle className="font-display text-sm flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-primary" />
              Upcoming Schedule
              <Badge variant="secondary" className="ml-1">
                {upcoming.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {upcoming.map((a, i) => {
                const d = a.dateRangeStart ?? a.date ?? "";
                return (
                  <div
                    key={`${a.id}-${i}`}
                    className="group flex items-center gap-3 py-2 border-b border-border last:border-0"
                    data-ocid={`team.upcoming.item.${i + 1}`}
                  >
                    <div className="flex-shrink-0 text-center w-10">
                      <p className="text-[10px] font-bold text-primary uppercase">
                        {new Date(d).toLocaleString("en-IN", {
                          month: "short",
                        })}
                      </p>
                      <p className="text-base font-bold text-foreground leading-none">
                        {new Date(d).getDate()}
                      </p>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-medium text-sm text-foreground truncate">
                          {a.teamMemberName}
                        </span>
                        <span className="text-muted-foreground text-xs">→</span>
                        <span className="text-xs text-primary font-medium truncate">
                          {a.program}
                        </span>
                        {a.dayType === "half" && (
                          <Badge
                            variant="outline"
                            className="text-[10px] border-amber-300 text-amber-600 ml-1"
                          >
                            Half
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground truncate">
                        {a.startTime ? `${a.startTime}` : ""}
                        {a.endTime ? ` – ${a.endTime}` : ""}
                      </p>
                    </div>
                    {a.location && (
                      <span className="hidden sm:flex items-center gap-1 text-[11px] text-muted-foreground flex-shrink-0">
                        <MapPin className="w-3 h-3" />
                        {a.location}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <h3 className="font-semibold text-foreground">All Assignments</h3>
          <Badge variant="secondary">{allAssignments.length}</Badge>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="h-8 w-40 text-sm"
            data-ocid="team.assignment.date_filter"
          />
          {dateFilter && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setDateFilter("")}
              aria-label="Clear date filter"
            >
              <X className="w-3.5 h-3.5" />
            </Button>
          )}
          <Button
            type="button"
            size="sm"
            className="bg-primary text-primary-foreground hover:bg-primary/90 gap-1.5"
            onClick={() => {
              setEditingAssignment(null);
              setAssignModalOpen(true);
            }}
            data-ocid="team.add_assignment_button"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Assignment
          </Button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div
          className="flex flex-col items-center justify-center h-40 text-center space-y-3 bg-card rounded-xl border border-border"
          data-ocid="team.assignments.empty_state"
        >
          <CalendarDays className="w-10 h-10 text-muted-foreground" />
          <div>
            <p className="font-semibold text-foreground">
              {dateFilter
                ? "No assignments on this date"
                : "No assignments yet"}
            </p>
            <p className="text-sm text-muted-foreground mt-0.5">
              {dateFilter
                ? "Try a different date or clear the filter"
                : "Create the first assignment to track team schedules"}
            </p>
          </div>
          {!dateFilter && (
            <Button
              type="button"
              size="sm"
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={() => {
                setEditingAssignment(null);
                setAssignModalOpen(true);
              }}
              data-ocid="team.assignments.empty_add_button"
            >
              <Plus className="w-3.5 h-3.5 mr-1" />
              Add First Assignment
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-2 group">
          {filtered.map((a, i) => (
            <AssignmentRow
              key={`${a.id}-${i}`}
              assignment={a}
              index={i + 1}
              onDelete={() => setDeleteTarget(a.id)}
              onEdit={() => {
                setEditingAssignment(a);
                setAssignModalOpen(true);
              }}
            />
          ))}
        </div>
      )}

      <AssignmentModal
        open={assignModalOpen}
        onClose={() => {
          setAssignModalOpen(false);
          setEditingAssignment(null);
        }}
        members={members}
        invoices={invoices}
        editAssignment={editingAssignment}
      />

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
      >
        <AlertDialogContent
          className="max-w-[95vw] sm:max-w-lg max-h-[90vh] overflow-y-auto"
          data-ocid="team.assignment.delete_dialog"
        >
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display">
              Remove Assignment?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove this assignment?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-ocid="team.assignment.delete_cancel_button">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() =>
                deleteTarget && handleDeleteAssignment(deleteTarget)
              }
              data-ocid="team.assignment.delete_confirm_button"
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ---- Main Page ----

export default function TeamPage() {
  const { teamMembers, deleteTeamMember } = useERPStore();

  const [search, setSearch] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editMember, setEditMember] = useState<TeamMember | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<TeamMember | null>(null);

  const filtered = teamMembers.filter(
    (m) =>
      !search ||
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      (m.role ?? "").toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <AppLayout>
      <div className="space-y-6" data-ocid="team.page">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-display font-bold text-foreground">
              Team
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              {teamMembers.length} member{teamMembers.length !== 1 ? "s" : ""}
            </p>
          </div>
          <Button
            type="button"
            className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2"
            onClick={() => {
              setEditMember(null);
              setModalOpen(true);
            }}
            data-ocid="team.add_button"
          >
            <Plus className="w-4 h-4" />
            Add Member
          </Button>
        </div>

        <Tabs defaultValue="members" data-ocid="team.main_tabs">
          <TabsList className="w-full flex-wrap h-auto">
            <TabsTrigger value="members" data-ocid="team.members_tab">
              <Users className="w-3.5 h-3.5 mr-1.5" />
              Members
            </TabsTrigger>
            <TabsTrigger value="assignments" data-ocid="team.assignments_tab">
              <CalendarDays className="w-3.5 h-3.5 mr-1.5" />
              Assignments
            </TabsTrigger>
          </TabsList>

          <TabsContent value="members" className="mt-5 space-y-5">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1 max-w-xs">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or role…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                  data-ocid="team.search_input"
                />
              </div>
            </div>

            {filtered.length === 0 ? (
              <div
                className="flex flex-col items-center justify-center h-64 text-center space-y-4 bg-card rounded-xl border border-border"
                data-ocid="team.empty_state"
              >
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <Users className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">
                    {search ? "No matching members" : "No team members yet"}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {search
                      ? "Try adjusting your search"
                      : "Add your first team member to get started"}
                  </p>
                </div>
                {!search && (
                  <Button
                    type="button"
                    className="bg-primary text-primary-foreground hover:bg-primary/90"
                    onClick={() => {
                      setEditMember(null);
                      setModalOpen(true);
                    }}
                    data-ocid="team.empty_add_button"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add First Member
                  </Button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                {filtered.map((m, i) => (
                  <div key={m.id} data-ocid={`team.item.${i + 1}`}>
                    <MemberCard
                      member={m}
                      onEdit={() => {
                        setEditMember(m);
                        setModalOpen(true);
                      }}
                      onDelete={() => setDeleteTarget(m)}
                    />
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="assignments" className="mt-5">
            <AssignmentsSection members={teamMembers} />
          </TabsContent>
        </Tabs>
      </div>

      <MemberModal
        open={modalOpen}
        onClose={() => {
          setModalOpen(false);
          setEditMember(null);
        }}
        member={editMember}
      />

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
      >
        <AlertDialogContent
          className="max-w-[95vw] sm:max-w-lg max-h-[90vh] overflow-y-auto"
          data-ocid="team.delete_dialog"
        >
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display">
              Remove Member?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Remove{" "}
              <span className="font-semibold text-foreground">
                {deleteTarget?.name}
              </span>{" "}
              from your team? This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-ocid="team.delete_cancel_button">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (deleteTarget) {
                  try {
                    deleteTeamMember(deleteTarget.id);
                    toast.success("Team member removed");
                    setDeleteTarget(null);
                  } catch (err) {
                    toast.error(
                      err instanceof Error ? err.message : "Delete failed",
                    );
                    setDeleteTarget(null);
                  }
                }
              }}
              data-ocid="team.delete_confirm_button"
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
