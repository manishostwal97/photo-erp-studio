import AppLayout from "@/components/layout/AppLayout";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  cn,
  formatDateShort,
  getDeliveryStageLabel,
  getDeliveryStageProgress,
  getInitials,
} from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { DeliveryStageEntry } from "@/types";
import { CheckCircle2, Clock, Save, Search, Truck } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

const STAGES = [
  "RAW_BACKUP",
  "SELECTION_PENDING",
  "EDITING",
  "ALBUM_DESIGNING",
  "PRINTING",
  "READY",
  "DELIVERED",
] as const;

type StageKey = (typeof STAGES)[number];

const STAGE_COLORS: Record<StageKey, string> = {
  RAW_BACKUP: "bg-slate-400",
  SELECTION_PENDING: "bg-amber-400",
  EDITING: "bg-orange-400",
  ALBUM_DESIGNING: "bg-blue-400",
  PRINTING: "bg-violet-400",
  READY: "bg-emerald-400",
  DELIVERED: "bg-green-500",
};

const STAGE_BADGE_COLORS: Record<StageKey, string> = {
  RAW_BACKUP: "bg-slate-100 text-slate-700 border-slate-200",
  SELECTION_PENDING: "bg-amber-100 text-amber-700 border-amber-200",
  EDITING: "bg-orange-100 text-orange-700 border-orange-200",
  ALBUM_DESIGNING: "bg-blue-100 text-blue-700 border-blue-200",
  PRINTING: "bg-violet-100 text-violet-700 border-violet-200",
  READY: "bg-emerald-100 text-emerald-700 border-emerald-200",
  DELIVERED: "bg-green-100 text-green-700 border-green-200",
};

function StageStat({ stage, count }: { stage: StageKey; count: number }) {
  return (
    <div
      className={`rounded-xl border p-2 sm:p-3 text-center ${STAGE_BADGE_COLORS[stage]}`}
    >
      <div className="text-base sm:text-xl font-bold">{count}</div>
      <div className="text-[9px] sm:text-[10px] font-medium leading-tight mt-0.5">
        {getDeliveryStageLabel(stage)}
      </div>
    </div>
  );
}

function ProgressBar({ stage }: { stage: string }) {
  const currentIdx = STAGES.indexOf(stage as StageKey);
  const pct = getDeliveryStageProgress(stage);

  return (
    <div className="space-y-1.5">
      <div className="flex gap-0.5">
        {STAGES.map((s, i) => (
          <div
            key={s}
            className={cn(
              "flex-1 h-2 rounded-full transition-all duration-300",
              i < currentIdx
                ? "bg-primary"
                : i === currentIdx
                  ? "bg-primary animate-pulse"
                  : "bg-muted",
            )}
            title={getDeliveryStageLabel(s)}
          />
        ))}
      </div>
      <div className="flex justify-between items-center">
        <span className="text-[10px] text-muted-foreground">
          {getDeliveryStageLabel(STAGES[0])}
        </span>
        <span className="text-xs font-semibold text-primary">
          {pct}% Complete
        </span>
        <span className="text-[10px] text-muted-foreground">
          {getDeliveryStageLabel(STAGES[STAGES.length - 1])}
        </span>
      </div>
    </div>
  );
}

function DeliveryHistoryTimeline({
  history,
}: {
  history: DeliveryStageEntry[];
}) {
  if (!history || history.length === 0) return null;

  const sorted = [...history].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime(),
  );

  return (
    <div className="mt-3 pt-3 border-t border-border">
      <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide mb-2.5 flex items-center gap-1.5">
        <Clock className="w-3 h-3" />
        History
      </p>
      <div className="space-y-2">
        {sorted.map((entry, i) => {
          const date = new Date(entry.timestamp);
          const formatted = Number.isNaN(date.getTime())
            ? "—"
            : date.toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
                year: "numeric",
              });
          return (
            <div
              key={`${entry.stage}-${i}`}
              className="flex items-start gap-2.5 text-xs"
            >
              <div className="w-4 h-4 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle2 className="w-2.5 h-2.5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-foreground">
                    {getDeliveryStageLabel(entry.stage)}
                  </span>
                  <span className="text-muted-foreground">{formatted}</span>
                  {entry.updatedBy && (
                    <span className="text-muted-foreground text-[10px]">
                      by {entry.updatedBy}
                    </span>
                  )}
                </div>
                {entry.notes && (
                  <p className="text-muted-foreground mt-0.5 italic">
                    {entry.notes}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

interface DeliveryCardState {
  stage: string;
  dueDate: string;
  editorName: string;
  notes: string;
  dirty: boolean;
  saving: boolean;
}

interface DeliveryCardProps {
  trackerId: string;
  clientName: string;
  eventName: string;
  invoiceId: string;
  invoiceNumber: string;
  eventStartDate?: string;
  currentStage: string;
  stageHistory: DeliveryStageEntry[];
  assignedEditor?: string;
  dueDate?: string;
  index: number;
}

function DeliveryCard({
  trackerId,
  clientName,
  eventName,
  invoiceNumber,
  eventStartDate,
  currentStage,
  stageHistory,
  assignedEditor,
  dueDate: initialDueDate,
  index,
}: DeliveryCardProps) {
  const { updateDeliveryTracker } = useERPStore();

  const [state, setState] = useState<DeliveryCardState>({
    stage: currentStage || "RAW_BACKUP",
    dueDate: initialDueDate || "",
    editorName: assignedEditor || "",
    notes: "",
    dirty: false,
    saving: false,
  });

  async function handleStageChange(newStage: string) {
    setState((s) => ({ ...s, stage: newStage, dirty: true }));
    try {
      const newEntry: DeliveryStageEntry = {
        stage: newStage,
        timestamp: new Date().toISOString(),
        notes: state.notes || undefined,
        updatedBy: "Admin",
      };
      updateDeliveryTracker(trackerId, {
        currentStage: newStage,
        stageHistory: [...stageHistory, newEntry],
      });
      setState((s) => ({ ...s, stage: newStage, dirty: false }));
      toast.success(`Stage updated: ${getDeliveryStageLabel(newStage)}`);
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : "Failed to update stage",
      );
    }
  }

  async function handleSave() {
    setState((s) => ({ ...s, saving: true }));
    try {
      updateDeliveryTracker(trackerId, {
        currentStage: state.stage,
        assignedEditor: state.editorName || undefined,
        dueDate: state.dueDate || undefined,
      });
      setState((s) => ({ ...s, dirty: false, saving: false }));
      toast.success(`Delivery updated for ${clientName}`);
    } catch (err) {
      setState((s) => ({ ...s, saving: false }));
      toast.error(
        err instanceof Error ? err.message : "Failed to save delivery",
      );
    }
  }

  const stageBadgeClass =
    STAGE_BADGE_COLORS[state.stage as StageKey] ??
    "bg-muted text-muted-foreground border-border";

  return (
    <div
      className="bg-card border border-border rounded-2xl shadow-card p-5 space-y-4 hover:border-primary/30 transition-colors"
      data-ocid={`delivery.card.${index}`}
    >
      {/* Top row */}
      <div className="flex items-start gap-3 flex-wrap">
        <Avatar className="w-11 h-11 flex-shrink-0">
          <AvatarFallback className="bg-primary/10 text-primary text-sm font-bold">
            {getInitials(clientName)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-semibold text-sm text-foreground">
              {clientName}
            </h3>
            <span className="text-xs text-muted-foreground font-mono">
              #{invoiceNumber}
            </span>
          </div>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <Badge
              variant="outline"
              className="text-[10px] h-4 px-1.5 border-primary/30 text-primary"
            >
              {eventName}
            </Badge>
            {eventStartDate && (
              <span className="text-[10px] text-muted-foreground">
                {formatDateShort(eventStartDate)}
              </span>
            )}
          </div>
        </div>
        <Badge
          variant="outline"
          className={`text-xs h-6 px-2 font-medium ${stageBadgeClass}`}
        >
          {getDeliveryStageLabel(state.stage)}
        </Badge>
      </div>

      {/* Progress bar */}
      <ProgressBar stage={state.stage} />

      {/* Stage selector */}
      <div className="flex items-center gap-2">
        <span className="text-xs text-muted-foreground font-medium flex-shrink-0">
          Update Stage:
        </span>
        <Select value={state.stage} onValueChange={handleStageChange}>
          <SelectTrigger
            className="h-8 text-xs flex-1"
            data-ocid={`delivery.stage_select.${index}`}
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {STAGES.map((s) => (
              <SelectItem key={s} value={s} className="text-xs">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full flex-shrink-0 ${STAGE_COLORS[s]}`}
                  />
                  {getDeliveryStageLabel(s)}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Details grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 sm:gap-3">
        <div className="space-y-1">
          <label
            htmlFor={`due-date-${index}`}
            className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide"
          >
            Due Date
          </label>
          <Input
            id={`due-date-${index}`}
            type="date"
            className="h-8 text-xs"
            value={state.dueDate}
            onChange={(e) =>
              setState((s) => ({ ...s, dueDate: e.target.value, dirty: true }))
            }
            data-ocid={`delivery.due_date.${index}`}
          />
        </div>
        <div className="space-y-1">
          <label
            htmlFor={`editor-${index}`}
            className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide"
          >
            Assigned Editor
          </label>
          <Input
            id={`editor-${index}`}
            type="text"
            placeholder="Editor name"
            className="h-8 text-xs"
            value={state.editorName}
            onChange={(e) =>
              setState((s) => ({
                ...s,
                editorName: e.target.value,
                dirty: true,
              }))
            }
            data-ocid={`delivery.editor.${index}`}
          />
        </div>
        <div className="space-y-1">
          <label
            htmlFor={`notes-${index}`}
            className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide"
          >
            Notes
          </label>
          <Input
            id={`notes-${index}`}
            type="text"
            placeholder="Short note..."
            className="h-8 text-xs"
            value={state.notes}
            onChange={(e) =>
              setState((s) => ({ ...s, notes: e.target.value, dirty: true }))
            }
            data-ocid={`delivery.notes.${index}`}
          />
        </div>
      </div>

      {/* Save button */}
      {state.dirty && (
        <div className="flex justify-end">
          <Button
            type="button"
            size="sm"
            className="h-8 text-xs gap-1.5"
            onClick={handleSave}
            disabled={state.saving}
            data-ocid={`delivery.save.${index}`}
          >
            <Save className="w-3 h-3" />
            {state.saving ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      )}

      {/* Delivery History Timeline */}
      <DeliveryHistoryTimeline history={stageHistory} />
    </div>
  );
}

export default function DeliveryPage() {
  const { invoices, deliveryTrackers, addDeliveryTracker } = useERPStore();
  const [stageFilter, setStageFilter] = useState<string>("ALL");
  const [search, setSearch] = useState("");

  // Ensure every invoice has a tracker — auto-create if missing
  useEffect(() => {
    for (const inv of invoices) {
      const exists = deliveryTrackers.some((t) => t.invoiceId === inv.id);
      if (!exists) {
        addDeliveryTracker({
          id: `dt-${inv.id}`,
          invoiceId: inv.id,
          clientName: inv.clientName,
          eventName: inv.eventType,
          currentStage: "RAW_BACKUP",
          stageHistory: [],
          createdAt: new Date().toISOString(),
        });
      }
    }
  }, [invoices, deliveryTrackers, addDeliveryTracker]);

  // Build display list: trackers merged with invoice data
  const trackerList = useMemo(() => {
    return deliveryTrackers.map((t) => {
      const inv = invoices.find((i) => i.id === t.invoiceId);
      return {
        ...t,
        invoiceNumber: inv?.invoiceNumber ?? "",
        eventStartDate: inv?.eventStartDate,
      };
    });
  }, [deliveryTrackers, invoices]);

  const stageCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const s of STAGES) counts[s] = 0;
    for (const t of deliveryTrackers) {
      const s = t.currentStage || "RAW_BACKUP";
      if (s in counts) counts[s]++;
    }
    return counts;
  }, [deliveryTrackers]);

  const filtered = useMemo(() => {
    return trackerList.filter((t) => {
      const stage = t.currentStage || "RAW_BACKUP";
      if (stageFilter !== "ALL" && stage !== stageFilter) return false;
      if (search && !t.clientName.toLowerCase().includes(search.toLowerCase()))
        return false;
      return true;
    });
  }, [trackerList, stageFilter, search]);

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-bold text-foreground">
              Delivery Tracker
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              Track post-production workflow for every booking
            </p>
          </div>
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search client..."
              className="pl-8 h-9 text-sm w-full sm:w-52"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              data-ocid="delivery.search_input"
            />
          </div>
        </div>

        {/* Stage stats */}
        <div
          className="grid grid-cols-4 sm:grid-cols-7 gap-1.5 overflow-x-auto"
          data-ocid="delivery.stats.section"
        >
          {STAGES.map((s) => (
            <StageStat key={s} stage={s} count={stageCounts[s] ?? 0} />
          ))}
        </div>

        {/* Stage filter tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
          {(["ALL", ...STAGES] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setStageFilter(s)}
              className={cn(
                "flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border",
                stageFilter === s
                  ? "bg-primary text-white border-primary shadow-sm"
                  : "bg-card text-muted-foreground border-border hover:border-primary/30 hover:text-foreground",
              )}
              data-ocid={`delivery.filter.${s.toLowerCase()}`}
            >
              {s === "ALL" ? "All" : getDeliveryStageLabel(s)}
              {s !== "ALL" && (stageCounts[s] ?? 0) > 0 && (
                <span
                  className={`ml-1.5 px-1 rounded text-[10px] ${
                    stageFilter === s ? "bg-white/20" : "bg-muted"
                  }`}
                >
                  {stageCounts[s]}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Cards / States */}
        {filtered.length === 0 ? (
          <div
            className="bg-card border border-border rounded-2xl p-12 text-center"
            data-ocid="delivery.empty_state"
          >
            <div className="w-14 h-14 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
              <Truck className="w-7 h-7 text-muted-foreground/50" />
            </div>
            <h3 className="font-semibold text-foreground">
              No deliveries found
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              {stageFilter !== "ALL" || search
                ? "Try adjusting your filters"
                : "Create invoices to start tracking deliveries"}
            </p>
          </div>
        ) : (
          <div className="space-y-4" data-ocid="delivery.list">
            {filtered.map((t, i) => (
              <DeliveryCard
                key={t.id}
                trackerId={t.id}
                clientName={t.clientName}
                eventName={t.eventName}
                invoiceId={t.invoiceId}
                invoiceNumber={t.invoiceNumber}
                eventStartDate={t.eventStartDate}
                currentStage={t.currentStage}
                stageHistory={t.stageHistory}
                assignedEditor={t.assignedEditor}
                dueDate={t.dueDate}
                index={i + 1}
              />
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
