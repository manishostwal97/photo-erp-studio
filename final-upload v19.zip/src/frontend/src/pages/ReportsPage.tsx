import AppLayout from "@/components/layout/AppLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  computeInvoiceBalance,
  formatCurrency,
  formatDate,
  generateWhatsAppLink,
  getInvoiceBalance,
  getPaymentStatus,
} from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { TeamMember } from "@/types";
import {
  ArrowUpRight,
  Download,
  MessageCircle,
  Printer,
  TrendingDown,
  TrendingUp,
  Wallet,
} from "lucide-react";
import { useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";

const MONTHS = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

function getMemberTotalEarned(m: TeamMember): number {
  return (m.workHistory ?? []).reduce((sum, wh) => sum + (wh.rateUsed ?? 0), 0);
}

function getMemberTotalPaid(m: TeamMember): number {
  return (m.workHistory ?? []).reduce(
    (sum, wh) => sum + (wh.paymentReceived ?? 0),
    0,
  );
}

const PIE_COLORS = [
  "#DC2626",
  "#2563EB",
  "#16A34A",
  "#D97706",
  "#7C3AED",
  "#DB2777",
  "#0891B2",
  "#65A30D",
  "#9CA3AF",
];

function StatCard({
  title,
  value,
  icon: Icon,
  trend,
  trendLabel,
  colorClass,
  onClick,
}: {
  title: string;
  value: string;
  icon: React.ElementType;
  trend?: "up" | "down" | "neutral";
  trendLabel?: string;
  colorClass?: string;
  onClick?: () => void;
}) {
  return (
    <Card
      className={`shadow-card border-border ${onClick ? "cursor-pointer hover:shadow-md transition-shadow" : ""}`}
      onClick={onClick}
    >
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="space-y-1 min-w-0 flex-1">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              {title}
            </p>
            <p
              className={`text-2xl font-display font-bold truncate whitespace-nowrap ${colorClass ?? "text-foreground"}`}
            >
              {value}
            </p>
            {trendLabel && (
              <div className="flex items-center gap-1">
                {trend === "up" && (
                  <TrendingUp className="w-3 h-3 text-green-600" />
                )}
                {trend === "down" && (
                  <TrendingDown className="w-3 h-3 text-red-600" />
                )}
                <span className="text-xs text-muted-foreground">
                  {trendLabel}
                </span>
              </div>
            )}
          </div>
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 ml-3">
            <Icon className="w-5 h-5 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ReportsPage() {
  const { invoices, expenses, teamMembers } = useERPStore();
  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState(String(currentYear));
  const [activePanel, setActivePanel] = useState<
    "revenue" | "pending" | "profit" | "expenses" | "team" | null
  >(null);

  const isLoading = false;

  // ── Derived metrics ──
  const year = Number(selectedYear);

  const yearInvoices = invoices.filter((inv) => {
    const d = new Date(inv.eventStartDate || "");
    return !Number.isNaN(d.getTime()) && d.getFullYear() === year;
  });

  const yearExpenses = expenses.filter((exp) => {
    const d = new Date(exp.date);
    return !Number.isNaN(d.getTime()) && d.getFullYear() === year;
  });

  // Monthly revenue: sum all payment records by the payment date (or event date fallback)
  const monthlyRevenue = Array(12).fill(0) as number[];
  for (const inv of invoices) {
    for (const p of inv.paymentHistory) {
      const d = new Date(p.date);
      if (!Number.isNaN(d.getTime()) && d.getFullYear() === year) {
        monthlyRevenue[d.getMonth()] += p.amount;
      }
    }
  }

  const monthlyExpenses = Array(12).fill(0) as number[];
  for (const exp of yearExpenses) {
    const d = new Date(exp.date);
    if (!Number.isNaN(d.getTime())) {
      monthlyExpenses[d.getMonth()] += exp.amount;
    }
  }

  const chartData = MONTHS.map((month, i) => ({
    month,
    revenue: monthlyRevenue[i],
    expenses: monthlyExpenses[i],
  }));

  // Round to 2 decimal places to prevent floating-point display artefacts
  // (e.g. ₹29999.999999999996 instead of ₹30000)
  const totalRevenue =
    Math.round(monthlyRevenue.reduce((a, b) => a + b, 0) * 100) / 100;
  const totalExpenses =
    Math.round(monthlyExpenses.reduce((a, b) => a + b, 0) * 100) / 100;
  const netProfit = Math.round((totalRevenue - totalExpenses) * 100) / 100;

  const pendingPayments = invoices
    .filter((inv) => computeInvoiceBalance(inv) > 0)
    .reduce((sum, inv) => sum + computeInvoiceBalance(inv), 0);

  // Event type distribution
  const eventTypeCounts: Record<string, number> = {};
  for (const inv of yearInvoices) {
    const t = inv.eventType || "Unknown";
    eventTypeCounts[t] = (eventTypeCounts[t] ?? 0) + 1;
  }
  const sorted = Object.entries(eventTypeCounts).sort((a, b) => b[1] - a[1]);
  const top8 = sorted.slice(0, 8);
  const othersCount = sorted.slice(8).reduce((s, [, c]) => s + c, 0);
  const pieData = [
    ...top8.map(([name, value]) => ({ name, value })),
    ...(othersCount > 0 ? [{ name: "Others", value: othersCount }] : []),
  ];
  const totalEvents = pieData.reduce((s, d) => s + d.value, 0);

  // Top clients
  const clientMap: Record<
    string,
    { name: string; events: number; revenue: number; pending: number }
  > = {};
  for (const inv of invoices) {
    const cKey = inv.clientId ?? inv.id;
    if (!clientMap[cKey]) {
      clientMap[cKey] = {
        name: inv.clientName,
        events: 0,
        revenue: 0,
        pending: 0,
      };
    }
    const entry = clientMap[cKey];
    entry.events += 1;
    entry.revenue += inv.paymentHistory.reduce((s, p) => s + p.amount, 0);
    entry.pending += Math.max(0, computeInvoiceBalance(inv));
  }
  const topClients = Object.values(clientMap)
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5);

  // Top services
  const serviceMap: Record<
    string,
    { name: string; count: number; revenue: number }
  > = {};
  for (const inv of invoices) {
    for (const svc of inv.services) {
      const svcName =
        (svc as { name?: string; serviceName?: string }).name ??
        (svc as { serviceName?: string }).serviceName ??
        "Unknown";
      if (!serviceMap[svcName]) {
        serviceMap[svcName] = {
          name: svcName,
          count: 0,
          revenue: 0,
        };
      }
      serviceMap[svcName].count += 1;
      serviceMap[svcName].revenue += svc.total;
    }
  }
  const topServices = Object.values(serviceMap)
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 8);

  // Payment status summary counts
  const paymentStatusSummary = invoices.reduce(
    (acc, inv) => {
      try {
        const status = getPaymentStatus(inv);
        if (status === "paid") acc.paid += 1;
        else if (status === "partial") acc.partial += 1;
        else if (status === "overdue") acc.overdue += 1;
        else acc.pending += 1;
      } catch {
        acc.pending += 1;
      }
      return acc;
    },
    { paid: 0, partial: 0, pending: 0, overdue: 0 },
  );

  // Pending payments list
  const pendingInvoices = invoices
    .filter((inv) => computeInvoiceBalance(inv) > 0)
    .sort((a, b) => computeInvoiceBalance(b) - computeInvoiceBalance(a));

  // Monthly expense breakdown by category
  const expByCatMonth: Record<string, Record<string, number>> = {};
  for (const exp of yearExpenses) {
    const d = new Date(exp.date);
    if (Number.isNaN(d.getTime())) continue;
    const m = MONTHS[d.getMonth()];
    if (!expByCatMonth[m]) expByCatMonth[m] = {};
    expByCatMonth[m][exp.category] =
      (expByCatMonth[m][exp.category] ?? 0) + exp.amount;
  }
  const expenseMonths = MONTHS.filter((m) => expByCatMonth[m]);
  const expenseCategories = Array.from(
    new Set(yearExpenses.map((e) => e.category)),
  ).sort();

  // Year options
  const yearOptions = Array.from({ length: 5 }, (_, i) =>
    String(currentYear - i),
  );

  // ── CSV Export ──
  const handleExportCSV = () => {
    // Combined CSV: expenses + payments for the selected year
    const expenseRows = yearExpenses.map((exp) => [
      exp.date,
      exp.category,
      exp.vendor + (exp.notes ? ` — ${exp.notes}` : ""),
      exp.amount,
      "Expense",
    ]);

    const paymentRows: (string | number)[][] = [];
    for (const inv of yearInvoices) {
      for (const p of inv.paymentHistory) {
        const d = new Date(p.date);
        if (!Number.isNaN(d.getTime()) && d.getFullYear() === year) {
          paymentRows.push([
            p.date,
            "Payment",
            `${inv.clientName} — ${inv.invoiceNumber}`,
            p.amount,
            "Revenue",
          ]);
        }
      }
    }

    const header = ["Date", "Category", "Description", "Amount", "Type"];
    const allRows = [...expenseRows, ...paymentRows].sort((a, b) =>
      String(a[0]).localeCompare(String(b[0])),
    );

    const csv = [header, ...allRows]
      .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `studio-report-${selectedYear}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success(`CSV exported — ${allRows.length} records`);
  };

  return (
    <AppLayout>
      <div
        id="reports-page"
        className="space-y-6 pb-20 lg:pb-6"
        data-ocid="reports.page"
      >
        {/* ── Header ── */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl font-bold text-foreground">
              Reports & Analytics
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Business performance overview
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Select
              value={selectedYear}
              onValueChange={setSelectedYear}
              data-ocid="reports.year.select"
            >
              <SelectTrigger className="w-28" data-ocid="reports.year.select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {yearOptions.map((y) => (
                  <SelectItem key={y} value={y}>
                    {y}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              type="button"
              variant="outline"
              className="gap-2"
              onClick={handleExportCSV}
              data-ocid="reports.export_csv.button"
            >
              <Download className="w-4 h-4" />
              Export CSV
            </Button>
            <Button
              type="button"
              variant="outline"
              className="gap-2"
              onClick={() => window.print()}
              data-ocid="reports.print.button"
            >
              <Printer className="w-4 h-4" />
              Print
            </Button>
          </div>
        </div>

        {/* ── Revenue Overview Cards ── */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              // biome-ignore lint/suspicious/noArrayIndexKey: static loading skeleton
              <Skeleton key={i} className="h-28 rounded-xl" />
            ))}
          </div>
        ) : (
          <div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
            data-ocid="reports.stats.section"
          >
            <StatCard
              title="Total Revenue"
              value={formatCurrency(totalRevenue)}
              icon={TrendingUp}
              colorClass="text-foreground"
              onClick={() => setActivePanel("revenue")}
            />
            <StatCard
              title={`Total Expenses (${selectedYear})`}
              value={formatCurrency(totalExpenses)}
              icon={TrendingDown}
              colorClass="text-red-600"
              trendLabel={`${yearExpenses.length} expense records`}
              onClick={() => setActivePanel("expenses")}
            />
            <StatCard
              title="Net Profit"
              value={formatCurrency(netProfit)}
              icon={ArrowUpRight}
              colorClass={netProfit >= 0 ? "text-green-600" : "text-red-600"}
              onClick={() => setActivePanel("profit")}
            />
            <StatCard
              title="Pending Payments"
              value={formatCurrency(pendingPayments)}
              icon={Wallet}
              colorClass="text-amber-600"
              onClick={() => setActivePanel("pending")}
            />
          </div>
        )}

        {/* ── Payment Status Summary ── */}
        <div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
          data-ocid="reports.payment_status.section"
        >
          {[
            {
              label: "Paid",
              count: paymentStatusSummary.paid,
              colorClass: "text-green-600",
              bg: "bg-green-50 border-green-200",
            },
            {
              label: "Partial",
              count: paymentStatusSummary.partial,
              colorClass: "text-amber-600",
              bg: "bg-amber-50 border-amber-200",
            },
            {
              label: "Pending",
              count: paymentStatusSummary.pending,
              colorClass: "text-blue-600",
              bg: "bg-blue-50 border-blue-200",
            },
            {
              label: "Overdue",
              count: paymentStatusSummary.overdue,
              colorClass: "text-red-600",
              bg: "bg-red-50 border-red-200",
            },
          ].map(({ label, count, colorClass, bg }) => (
            <Card
              key={label}
              className={`border shadow-sm ${bg}`}
              data-ocid={`reports.status_${label.toLowerCase()}.card`}
            >
              <CardContent className="p-4">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">
                  {label}
                </p>
                <p className={`text-3xl font-display font-bold ${colorClass}`}>
                  {count}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  invoice{count !== 1 ? "s" : ""}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* ── Monthly Revenue Chart ── */}
        <Card className="shadow-card">
          <CardHeader className="pb-2">
            <CardTitle className="font-display text-base font-semibold">
              Monthly Revenue vs Expenses — {selectedYear}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-64 w-full rounded-lg" />
            ) : (
              <div className="overflow-x-auto">
                <ResponsiveContainer width="100%" height={280} minWidth={320}>
                  <BarChart
                    data={chartData}
                    margin={{ top: 4, right: 8, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      className="stroke-border"
                    />
                    <XAxis
                      dataKey="month"
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      tickFormatter={(v: number) =>
                        `₹${v >= 1000 ? `${Math.round(v / 1000)}k` : v}`
                      }
                      tick={{ fontSize: 11 }}
                      tickLine={false}
                      axisLine={false}
                      width={52}
                    />
                    <Tooltip
                      formatter={(value: number, name: string) => [
                        formatCurrency(value),
                        name.charAt(0).toUpperCase() + name.slice(1),
                      ]}
                      contentStyle={{
                        borderRadius: "8px",
                        border: "1px solid #e5e7eb",
                        fontSize: 12,
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <Bar
                      dataKey="revenue"
                      name="Revenue"
                      fill="#DC2626"
                      radius={[3, 3, 0, 0]}
                    />
                    <Bar
                      dataKey="expenses"
                      name="Expenses"
                      fill="#9CA3AF"
                      radius={[3, 3, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* ── Event Distribution + Top Services ── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Pie chart */}
          <Card className="shadow-card">
            <CardHeader className="pb-2">
              <CardTitle className="font-display text-base font-semibold">
                Event Type Distribution — {selectedYear}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-56 w-full rounded-lg" />
              ) : pieData.length === 0 ? (
                <div className="h-56 flex items-center justify-center">
                  <p className="text-sm text-muted-foreground">
                    No events for {selectedYear}
                  </p>
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  <div className="overflow-x-auto">
                    <ResponsiveContainer
                      width="100%"
                      height={220}
                      minWidth={320}
                    >
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={55}
                          outerRadius={95}
                          paddingAngle={2}
                          dataKey="value"
                        >
                          {pieData.map((entry, index) => (
                            <Cell
                              key={entry.name}
                              fill={PIE_COLORS[index % PIE_COLORS.length]}
                            />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(value: number, name: string) => [
                            `${value} events (${totalEvents > 0 ? Math.round((value / totalEvents) * 100) : 0}%)`,
                            name,
                          ]}
                          contentStyle={{ borderRadius: "8px", fontSize: 12 }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    {pieData.map((entry, index) => (
                      <div
                        key={entry.name}
                        className="flex items-center gap-1.5 min-w-0"
                      >
                        <span
                          className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                          style={{
                            background: PIE_COLORS[index % PIE_COLORS.length],
                          }}
                        />
                        <span className="text-xs text-muted-foreground truncate">
                          {entry.name}
                        </span>
                        <span className="text-xs font-semibold text-foreground ml-auto">
                          {entry.value}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Top services */}
          <Card className="shadow-card">
            <CardHeader className="pb-2">
              <CardTitle className="font-display text-base font-semibold">
                Top Services by Revenue
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 6 }).map((_, i) => (
                    // biome-ignore lint/suspicious/noArrayIndexKey: static loading skeleton
                    <Skeleton key={i} className="h-8 rounded" />
                  ))}
                </div>
              ) : topServices.length === 0 ? (
                <p className="text-sm text-muted-foreground py-8 text-center">
                  No services data yet
                </p>
              ) : (
                <div className="space-y-2">
                  {topServices.map((svc, idx) => (
                    <div
                      key={svc.name}
                      className="flex items-center gap-3 py-1.5 border-b border-border last:border-0"
                    >
                      <span className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center flex-shrink-0">
                        {idx + 1}
                      </span>
                      <span className="flex-1 text-sm font-medium text-foreground truncate min-w-0">
                        {svc.name}
                      </span>
                      <Badge variant="secondary" className="text-xs">
                        {svc.count}×
                      </Badge>
                      <span className="text-sm font-semibold text-foreground w-24 text-right whitespace-nowrap">
                        {formatCurrency(svc.revenue)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ── Top 5 Clients ── */}
        <Card className="shadow-card">
          <CardHeader className="pb-2">
            <CardTitle className="font-display text-base font-semibold">
              Top 5 Clients by Revenue
            </CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            {isLoading ? (
              <Skeleton className="h-40 w-full rounded-lg" />
            ) : topClients.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">
                No client data yet
              </p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10">#</TableHead>
                    <TableHead>Client Name</TableHead>
                    <TableHead className="text-right">Events</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                    <TableHead className="text-right">Pending</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topClients.map((client, idx) => (
                    <TableRow
                      key={client.name}
                      data-ocid={`reports.top_clients.item.${idx + 1}`}
                    >
                      <TableCell>
                        <span className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center">
                          {idx + 1}
                        </span>
                      </TableCell>
                      <TableCell className="font-medium">
                        {client.name}
                      </TableCell>
                      <TableCell className="text-right">
                        {client.events}
                      </TableCell>
                      <TableCell className="text-right font-semibold whitespace-nowrap">
                        {formatCurrency(client.revenue)}
                      </TableCell>
                      <TableCell className="text-right">
                        {client.pending > 0 ? (
                          <span className="text-amber-600 font-medium whitespace-nowrap">
                            {formatCurrency(client.pending)}
                          </span>
                        ) : (
                          <span className="text-green-600 text-xs">
                            Cleared
                          </span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* ── Pending Payments ── */}
        <Card className="shadow-card">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="font-display text-base font-semibold">
                Pending Payments
              </CardTitle>
              <Badge variant="destructive" className="text-xs">
                {pendingInvoices.length} outstanding
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            {isLoading ? (
              <Skeleton className="h-40 w-full rounded-lg" />
            ) : pendingInvoices.length === 0 ? (
              <div
                className="py-10 text-center"
                data-ocid="reports.pending_payments.empty_state"
              >
                <p className="text-2xl mb-2">🎉</p>
                <p className="text-sm font-medium text-foreground">
                  All payments cleared!
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  No outstanding balances
                </p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Client</TableHead>
                    <TableHead>Invoice#</TableHead>
                    <TableHead>Event</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead className="text-right">Paid</TableHead>
                    <TableHead className="text-right">Balance Due</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingInvoices.map((inv, idx) => {
                    const paid = inv.paymentHistory.reduce(
                      (s, p) => s + p.amount,
                      0,
                    );
                    const balance = computeInvoiceBalance(inv);
                    const status = getPaymentStatus(inv);
                    const waMsg = `Hello ${inv.clientName}, this is a reminder that your balance of ${formatCurrency(balance)} for invoice ${inv.invoiceNumber} (${inv.eventType}) is pending. Please make the payment at your earliest convenience. Thank you!`;
                    return (
                      <TableRow
                        key={inv.id}
                        data-ocid={`reports.pending.item.${idx + 1}`}
                      >
                        <TableCell className="font-medium">
                          {inv.clientName}
                        </TableCell>
                        <TableCell className="text-muted-foreground font-mono text-xs">
                          {inv.invoiceNumber}
                        </TableCell>
                        <TableCell>
                          <span className="text-xs">{inv.eventType}</span>
                          <span className="block text-xs text-muted-foreground">
                            {formatDate(inv.eventStartDate)}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          {formatCurrency(
                            (inv.totalAmount ?? 0) - (inv.discount ?? 0),
                          )}
                        </TableCell>
                        <TableCell className="text-right text-green-600">
                          {formatCurrency(paid)}
                        </TableCell>
                        <TableCell className="text-right">
                          <span
                            className={`font-semibold ${
                              status === "overdue"
                                ? "text-red-600"
                                : "text-amber-600"
                            }`}
                          >
                            {formatCurrency(balance)}
                          </span>
                        </TableCell>
                        <TableCell>
                          {inv.clientWhatsapp ? (
                            <Button
                              type="button"
                              size="sm"
                              variant="outline"
                              className="h-7 gap-1 text-xs"
                              onClick={() =>
                                window.open(
                                  generateWhatsAppLink(
                                    inv.clientWhatsapp ?? "",
                                    waMsg,
                                  ),
                                  "_blank",
                                )
                              }
                              data-ocid={`reports.pending.whatsapp.${idx + 1}`}
                            >
                              <MessageCircle className="w-3 h-3" />
                              Remind
                            </Button>
                          ) : (
                            <span className="text-xs text-muted-foreground">
                              No WhatsApp
                            </span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* ── Team Earnings Card ── */}
        <StatCard
          title="Team Earnings"
          value={formatCurrency(
            (teamMembers ?? []).reduce(
              (s, m) => s + getMemberTotalEarned(m),
              0,
            ),
          )}
          icon={Wallet}
          colorClass="text-blue-600"
          trendLabel={`${(teamMembers ?? []).length} members`}
          onClick={() => setActivePanel("team")}
        />

        {/* ── Monthly Expense Breakdown ── */}
        <Card className="shadow-card">
          <CardHeader className="pb-2">
            <CardTitle className="font-display text-base font-semibold">
              Monthly Expense Breakdown — {selectedYear}
            </CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            {isLoading ? (
              <Skeleton className="h-40 w-full rounded-lg" />
            ) : expenseMonths.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">
                No expenses recorded for {selectedYear}
              </p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Month</TableHead>
                    {expenseCategories.map((cat) => (
                      <TableHead key={cat} className="text-right capitalize">
                        {cat}
                      </TableHead>
                    ))}
                    <TableHead className="text-right font-semibold">
                      Total
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {expenseMonths.map((month) => {
                    const cats = expByCatMonth[month] ?? {};
                    const total = Object.values(cats).reduce(
                      (s, v) => s + v,
                      0,
                    );
                    return (
                      <TableRow key={month}>
                        <TableCell className="font-medium">{month}</TableCell>
                        {expenseCategories.map((cat) => (
                          <TableCell key={cat} className="text-right text-sm">
                            {cats[cat] ? formatCurrency(cats[cat]) : "—"}
                          </TableCell>
                        ))}
                        <TableCell className="text-right font-semibold">
                          {formatCurrency(total)}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      <Sheet
        open={activePanel !== null}
        onOpenChange={() => setActivePanel(null)}
      >
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="font-display text-lg">
              {activePanel === "revenue" && "Revenue Breakdown"}
              {activePanel === "pending" && "Pending Payments"}
              {activePanel === "profit" && "Profit Analytics"}
              {activePanel === "expenses" && "Expense Breakdown"}
              {activePanel === "team" && "Team Earnings"}
            </SheetTitle>
          </SheetHeader>
          <div className="mt-6 space-y-4">
            {activePanel === "revenue" && (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Monthly invoiced amount vs paid amount for {selectedYear}
                </p>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Month</TableHead>
                        <TableHead className="text-right">Invoiced</TableHead>
                        <TableHead className="text-right">Paid</TableHead>
                        <TableHead className="text-right">Remaining</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {MONTHS.map((month, i) => {
                        const invoiced = yearInvoices
                          .filter((inv) => {
                            const d = new Date(inv.eventStartDate || "");
                            return (
                              !Number.isNaN(d.getTime()) &&
                              d.getMonth() === i &&
                              d.getFullYear() === year
                            );
                          })
                          .reduce(
                            (s, inv) =>
                              s +
                              ((inv.totalAmount ?? 0) - (inv.discount ?? 0)),
                            0,
                          );
                        const paid = monthlyRevenue[i];
                        return (
                          <TableRow key={month}>
                            <TableCell className="font-medium">
                              {month}
                            </TableCell>
                            <TableCell className="text-right">
                              {formatCurrency(invoiced)}
                            </TableCell>
                            <TableCell className="text-right text-green-600">
                              {formatCurrency(paid)}
                            </TableCell>
                            <TableCell className="text-right">
                              {formatCurrency(invoiced - paid)}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {activePanel === "pending" && (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Clients with outstanding balances
                </p>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Client</TableHead>
                        <TableHead className="text-right">Balance</TableHead>
                        <TableHead className="text-right">Invoices</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {Object.values(
                        pendingInvoices.reduce<
                          Record<
                            string,
                            { name: string; balance: number; count: number }
                          >
                        >((acc, inv) => {
                          const key = inv.clientId ?? inv.id;
                          if (!acc[key]) {
                            acc[key] = {
                              name: inv.clientName,
                              balance: 0,
                              count: 0,
                            };
                          }
                          acc[key].balance += computeInvoiceBalance(inv);
                          acc[key].count += 1;
                          return acc;
                        }, {}),
                      )
                        .sort((a, b) => b.balance - a.balance)
                        .map((c) => (
                          <TableRow key={c.name}>
                            <TableCell className="font-medium">
                              {c.name}
                            </TableCell>
                            <TableCell className="text-right text-amber-600 font-semibold">
                              {formatCurrency(c.balance)}
                            </TableCell>
                            <TableCell className="text-right">
                              {c.count}
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {activePanel === "profit" && (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Monthly profit = revenue − expenses for {selectedYear}
                </p>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Month</TableHead>
                        <TableHead className="text-right">Revenue</TableHead>
                        <TableHead className="text-right">Expenses</TableHead>
                        <TableHead className="text-right">Profit</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {chartData.map((row) => {
                        const profit = row.revenue - row.expenses;
                        return (
                          <TableRow key={row.month}>
                            <TableCell className="font-medium">
                              {row.month}
                            </TableCell>
                            <TableCell className="text-right text-green-600">
                              {formatCurrency(row.revenue)}
                            </TableCell>
                            <TableCell className="text-right text-red-600">
                              {formatCurrency(row.expenses)}
                            </TableCell>
                            <TableCell
                              className={`text-right font-semibold ${profit >= 0 ? "text-green-600" : "text-red-600"}`}
                            >
                              {formatCurrency(profit)}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {activePanel === "expenses" && (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Expenses aggregated by category for {selectedYear}
                </p>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Category</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                        <TableHead className="text-right">% of Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {expenseCategories.map((cat) => {
                        const catTotal = yearExpenses
                          .filter((e) => e.category === cat)
                          .reduce((s, e) => s + e.amount, 0);
                        const pct =
                          totalExpenses > 0
                            ? Math.round((catTotal / totalExpenses) * 100)
                            : 0;
                        return (
                          <TableRow key={cat}>
                            <TableCell className="font-medium capitalize">
                              {cat}
                            </TableCell>
                            <TableCell className="text-right">
                              {formatCurrency(catTotal)}
                            </TableCell>
                            <TableCell className="text-right">{pct}%</TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {activePanel === "team" && (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Team member earnings summary
                </p>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Member</TableHead>
                        <TableHead className="text-right">Earned</TableHead>
                        <TableHead className="text-right">Paid</TableHead>
                        <TableHead className="text-right">Due</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(teamMembers ?? [])
                        .sort(
                          (a, b) =>
                            getMemberTotalEarned(b) - getMemberTotalEarned(a),
                        )
                        .map((m) => (
                          <TableRow key={m.id}>
                            <TableCell className="font-medium">
                              {m.name}
                            </TableCell>
                            <TableCell className="text-right">
                              {formatCurrency(getMemberTotalEarned(m))}
                            </TableCell>
                            <TableCell className="text-right text-green-600">
                              {formatCurrency(getMemberTotalPaid(m))}
                            </TableCell>
                            <TableCell className="text-right text-amber-600 font-semibold">
                              {formatCurrency(
                                getMemberTotalEarned(m) - getMemberTotalPaid(m),
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </AppLayout>
  );
}
