import InvoiceTemplateEngine from "@/components/InvoiceTemplateEngine";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useAppStore, useERPStore } from "@/stores/useAppStore";
import { useStudioStore } from "@/stores/useStudioStore";
import { StudioProfile } from "@/types";
import {
  AlertTriangle,
  Camera,
  Check,
  Download,
  FileJson,
  Loader2,
  MessageCircle,
  Moon,
  PenLine,
  Receipt,
  Settings2,
  Sun,
  Upload,
} from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";

// ── WhatsApp template defaults ──
const DEFAULT_ADVANCE_TEMPLATE =
  "Hello {clientName},\n\nThank you for booking with us! 📸\n\nThis is a reminder that your advance payment for Invoice #{invoiceNumber} is due.\n\nEvent: {eventName}\nEvent Date: {eventDate}\nVenue: {venue}\nBalance Remaining: {balance}\n\nKindly make the payment at your earliest convenience. Thank you!";

const DEFAULT_BALANCE_TEMPLATE =
  "Hello {clientName},\n\nYour event memories are ready! ✨\n\nThis is a friendly reminder that the remaining balance of {balance} for Invoice #{invoiceNumber} is pending.\n\nEvent: {eventName}\nEvent Date: {eventDate}\nAssigned Team: {assignedTeam}\n\nPlease clear the dues so we can proceed with delivery. Thank you!";

const DEFAULT_DELIVERY_TEMPLATE =
  "Hello {clientName},\n\nGreat news! 🎉 Your {eventName} photos/videos are ready for delivery!\n\nInvoice: #{invoiceNumber}\nPlease contact us to arrange delivery of your cherished memories. Thank you for choosing us!";

const DEFAULT_EVENT_REMINDER_TEMPLATE =
  "Hello {clientName},\nReminder for your upcoming event:\nEvent: {eventName}\nProgram: {programName}\nDate: {eventDate}\nVenue: {venue}\nInvoice: {invoiceNumber}\nPending Amount: {balance}\nPlease ensure payment is cleared before the event. Thank you!";

const DEFAULT_TEAM_REMINDER_TEMPLATE =
  "Hello {teamMemberName},\nYou are assigned for:\nClient: {clientName}\nProgram: {programName}\nDate: {eventDate}\nTime: {eventTime}\nLocation: {venue}\nRole: {assignedTeam}\n\nPlease confirm your availability. Thank you!";

const WA_SAMPLE = {
  clientName: "Rahul Sharma",
  eventName: "Wedding",
  programName: "Haldi",
  eventDate: "18 Apr 2026",
  eventTime: "10:00 AM",
  venue: "Hotel Sunrise, Mandsaur",
  invoiceNumber: "260501",
  balance: "₹15,000",
  assignedTeam: "Mohit, Rahul",
  teamMemberName: "Mohit",
};

function renderTemplate(template: string, sample: typeof WA_SAMPLE) {
  return template.replace(/\{\{?(\w+)\}?\}/g, (_m: string, key: string) =>
    key in sample ? sample[key as keyof typeof sample] : `{${key}}`,
  );
}

// ── Studio Profile Tab ──
interface StudioFormData {
  studioName: string;
  ownerName: string;
  mobile: string;
  email: string;
  address: string;
  upiId: string;
  gstNumber: string;
  logoUrl: string;
  signatureUrl: string;
  gstPercentage: number;
  invoicePrefix: string;
  invoiceStartNumber: number;
}

function StudioProfileTab() {
  const updateStudioProfile = useStudioStore((s) => s.updateStudioProfile);
  const studioProfile = useStudioStore((s) => s.studioProfile);

  const logoInputRef = useRef<HTMLInputElement>(null);
  const signInputRef = useRef<HTMLInputElement>(null);
  const [saving, setSaving] = useState(false);
  const [logoPreview, setLogoPreview] = useState("");
  const [signPreview, setSignPreview] = useState("");

  const [form, setForm] = useState<StudioFormData>({
    studioName: studioProfile?.name ?? "",
    ownerName: studioProfile?.ownerName ?? "",
    mobile: studioProfile?.phone ?? "",
    email: studioProfile?.email ?? "",
    address: studioProfile?.address ?? "",
    upiId: studioProfile?.upiId ?? "",
    gstNumber: studioProfile?.gstNumber ?? "",
    logoUrl: studioProfile?.logo ?? "",
    signatureUrl: studioProfile?.signature ?? "",
    gstPercentage: studioProfile?.gstPercent ?? 18,
    invoicePrefix: "INV",
    invoiceStartNumber: 1001,
  });

  const setField = (k: keyof StudioFormData, v: string | number) =>
    setForm((prev) => ({ ...prev, [k]: v }));

  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    field: "logoUrl" | "signatureUrl",
    setPreview: (s: string) => void,
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPreview(URL.createObjectURL(file));
    const reader = new FileReader();
    reader.onload = (ev) => setField(field, ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    if (!form.studioName.trim()) {
      toast.error("Studio name is required");
      return;
    }
    if (!form.ownerName.trim()) {
      toast.error("Owner name is required");
      return;
    }
    setSaving(true);
    try {
      updateStudioProfile({
        name: form.studioName.trim(),
        ownerName: form.ownerName.trim(),
        phone: form.mobile.trim(),
        email: form.email.trim(),
        address: form.address.trim(),
        upiId: form.upiId.trim(),
        gstNumber: form.gstNumber.trim(),
        gstEnabled: !!form.gstNumber.trim(),
        gstPercent: Number(form.gstPercentage),
        logo: form.logoUrl,
        signature: form.signatureUrl,
      });
      toast.success("Studio profile updated!");
    } catch {
      toast.error("Save failed. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 pb-20 lg:pb-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label htmlFor="s-studio-name">
            Studio Name <span className="text-primary">*</span>
          </Label>
          <Input
            id="s-studio-name"
            value={form.studioName}
            onChange={(e) => setField("studioName", e.target.value)}
            placeholder="Aura Photography Studio"
            data-ocid="settings.studio_name.input"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="s-owner-name">
            Owner Name <span className="text-primary">*</span>
          </Label>
          <Input
            id="s-owner-name"
            value={form.ownerName}
            onChange={(e) => setField("ownerName", e.target.value)}
            placeholder="Sarah Johnson"
            data-ocid="settings.owner_name.input"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="s-mobile">Mobile Number</Label>
          <Input
            id="s-mobile"
            value={form.mobile}
            onChange={(e) => setField("mobile", e.target.value)}
            placeholder="+91 98765 43210"
            data-ocid="settings.mobile.input"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="s-email">Email Address</Label>
          <Input
            id="s-email"
            type="email"
            value={form.email}
            onChange={(e) => setField("email", e.target.value)}
            placeholder="studio@example.com"
            data-ocid="settings.email.input"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="s-upi">UPI ID</Label>
          <Input
            id="s-upi"
            value={form.upiId}
            onChange={(e) => setField("upiId", e.target.value)}
            placeholder="studio@upi"
            data-ocid="settings.upi_id.input"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="s-gst">GST Number</Label>
          <Input
            id="s-gst"
            value={form.gstNumber}
            onChange={(e) => setField("gstNumber", e.target.value)}
            placeholder="22AAAAA0000A1Z5"
            data-ocid="settings.gst_number.input"
          />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="s-address">Studio Address</Label>
        <Textarea
          id="s-address"
          value={form.address}
          onChange={(e) => setField("address", e.target.value)}
          placeholder="123 Studio Lane, Mumbai, Maharashtra"
          rows={3}
          data-ocid="settings.address.input"
        />
      </div>

      {/* Logo & Signature */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div className="space-y-3">
          <Label>Studio Logo</Label>
          <div className="flex items-center gap-4">
            <div
              className="w-20 h-20 rounded-xl border-2 border-dashed border-border flex items-center justify-center overflow-hidden flex-shrink-0"
              style={{
                background:
                  logoPreview || form.logoUrl ? "transparent" : "#fef2f2",
              }}
            >
              {logoPreview || form.logoUrl ? (
                <img
                  src={logoPreview || form.logoUrl}
                  alt="Logo"
                  className="w-full h-full object-cover rounded-xl"
                />
              ) : (
                <Camera className="w-7 h-7 text-primary/40" />
              )}
            </div>
            <div className="space-y-1.5 flex-1">
              <input
                ref={logoInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) =>
                  handleImageUpload(e, "logoUrl", setLogoPreview)
                }
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="w-full gap-2"
                onClick={() => logoInputRef.current?.click()}
                data-ocid="settings.logo.upload_button"
              >
                <Upload className="w-4 h-4" />
                Upload Logo
              </Button>
              <p className="text-xs text-muted-foreground">
                PNG/JPG, 200×200px recommended
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <Label>Signature</Label>
          <div
            className="w-full h-20 rounded-xl border-2 border-dashed border-border flex items-center justify-center overflow-hidden"
            style={{
              background:
                signPreview || form.signatureUrl ? "transparent" : "#f9fafb",
            }}
          >
            {signPreview || form.signatureUrl ? (
              <img
                src={signPreview || form.signatureUrl}
                alt="Signature"
                className="h-full object-contain"
              />
            ) : (
              <div className="flex flex-col items-center gap-1">
                <PenLine className="w-5 h-5 text-muted-foreground/40" />
                <p className="text-xs text-muted-foreground">
                  No signature uploaded
                </p>
              </div>
            )}
          </div>
          <input
            ref={signInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) =>
              handleImageUpload(e, "signatureUrl", setSignPreview)
            }
          />
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="w-full gap-2"
            onClick={() => signInputRef.current?.click()}
            data-ocid="settings.signature.upload_button"
          >
            <PenLine className="w-4 h-4" />
            Upload Signature
          </Button>
        </div>
      </div>

      <Button
        type="button"
        className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
        onClick={handleSave}
        disabled={saving}
        data-ocid="settings.studio.save_button"
      >
        {saving ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <Check className="w-4 h-4" />
        )}
        {saving ? "Saving..." : "Save Studio Details"}
      </Button>
    </div>
  );
}

// ── Invoice Settings Tab ──
function InvoiceSettingsTab() {
  const updateStudioProfile = useStudioStore((s) => s.updateStudioProfile);
  const studioProfile = useStudioStore((s) => s.studioProfile);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    invoicePrefix: "INV",
    invoiceStartNumber: 1001,
    gstPercentage: studioProfile?.gstPercent ?? 18,
    gstEnabledDefault:
      studioProfile?.gstEnabled ??
      localStorage.getItem("gstEnabledDefault") === "true",
    terms:
      localStorage.getItem("defaultTerms") ??
      "1. 50% advance required to confirm booking.\n2. Balance due before/on delivery.\n3. Raw files are not provided.\n4. Cancellation charges apply.",
  });

  const setField = (k: keyof typeof form, v: string | number | boolean) =>
    setForm((prev) => ({ ...prev, [k]: v }));

  const handleSave = () => {
    setSaving(true);
    try {
      updateStudioProfile({
        gstEnabled: form.gstEnabledDefault,
        gstPercent: Number(form.gstPercentage),
      });
      localStorage.setItem("defaultTerms", form.terms);
      localStorage.setItem("gstEnabledDefault", String(form.gstEnabledDefault));
      toast.success("Invoice settings saved!");
    } catch {
      toast.error("Save failed.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* GST Toggle */}
      <div className="flex items-center justify-between p-4 rounded-xl border border-border bg-muted/30">
        <div>
          <p className="font-medium text-sm text-foreground">GST on Invoices</p>
          <p className="text-xs text-muted-foreground mt-0.5">
            Enable GST by default for all new invoices
          </p>
        </div>
        <Switch
          checked={form.gstEnabledDefault}
          onCheckedChange={(v) => setField("gstEnabledDefault", v)}
          data-ocid="settings.gst_enabled.toggle"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        <div className="space-y-1.5">
          <Label htmlFor="inv-prefix">Invoice Prefix</Label>
          <Input
            id="inv-prefix"
            value={form.invoicePrefix}
            onChange={(e) => setField("invoicePrefix", e.target.value)}
            placeholder="INV"
            data-ocid="settings.invoice_prefix.input"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="inv-start">Starting Number</Label>
          <Input
            id="inv-start"
            type="number"
            min={1}
            value={form.invoiceStartNumber}
            onChange={(e) =>
              setField("invoiceStartNumber", Number(e.target.value))
            }
            data-ocid="settings.invoice_start.input"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="inv-gst">
            GST Percentage (%){" "}
            {!form.gstEnabledDefault && (
              <span className="text-xs text-muted-foreground font-normal">
                (GST disabled)
              </span>
            )}
          </Label>
          <Input
            id="inv-gst"
            type="number"
            min={0}
            max={28}
            value={form.gstPercentage}
            disabled={!form.gstEnabledDefault}
            onChange={(e) => setField("gstPercentage", Number(e.target.value))}
            data-ocid="settings.gst_percentage.input"
          />
        </div>
      </div>

      <div
        className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs"
        style={{
          background: "#fef2f2",
          border: "1px solid #fecaca",
          color: "#374151",
        }}
      >
        <Receipt
          className="w-4 h-4 flex-shrink-0"
          style={{ color: "#DC2626" }}
        />
        Preview: Invoice will be numbered{" "}
        <strong>
          {form.invoicePrefix}-
          {String(form.invoiceStartNumber).padStart(4, "0")}
        </strong>
        {form.gstEnabledDefault && (
          <span className="ml-2 text-green-700">
            · GST {form.gstPercentage}% enabled
          </span>
        )}
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="inv-terms">Default Terms & Conditions</Label>
        <Textarea
          id="inv-terms"
          value={form.terms}
          onChange={(e) => setField("terms", e.target.value)}
          rows={6}
          placeholder="Enter default terms that appear on every new invoice..."
          className="font-mono text-xs"
          data-ocid="settings.default_terms.textarea"
        />
        <p className="text-xs text-muted-foreground">
          These terms are pre-filled when creating new invoices.
        </p>
      </div>

      {/* Invoice Template Engine */}
      <div className="space-y-1.5">
        <p className="text-sm font-semibold text-foreground">
          Invoice Design Template
        </p>
        <p className="text-xs text-muted-foreground">
          Choose the visual style used when generating PDFs.
        </p>
        <InvoiceTemplateEngine />
      </div>

      <Button
        type="button"
        className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
        onClick={handleSave}
        disabled={saving}
        data-ocid="settings.invoice.save_button"
      >
        {saving ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <Check className="w-4 h-4" />
        )}
        {saving ? "Saving..." : "Save Invoice Settings"}
      </Button>
    </div>
  );
}

// ── WhatsApp Templates Tab ──
function WhatsAppTemplatesTab() {
  const [saved, setSaved] = useState(false);
  const [previewTab, setPreviewTab] = useState<
    "advance" | "balance" | "delivery" | "eventReminder" | "teamReminder"
  >("advance");

  const [templates, setTemplates] = useState({
    advance: localStorage.getItem("wa_advance") ?? DEFAULT_ADVANCE_TEMPLATE,
    balance: localStorage.getItem("wa_balance") ?? DEFAULT_BALANCE_TEMPLATE,
    delivery: localStorage.getItem("wa_delivery") ?? DEFAULT_DELIVERY_TEMPLATE,
    eventReminder:
      localStorage.getItem("wa_eventReminder") ??
      DEFAULT_EVENT_REMINDER_TEMPLATE,
    teamReminder:
      localStorage.getItem("wa_teamReminder") ?? DEFAULT_TEAM_REMINDER_TEMPLATE,
  });

  const setTpl = (k: keyof typeof templates, v: string) =>
    setTemplates((prev) => ({ ...prev, [k]: v }));

  const handleSave = () => {
    localStorage.setItem("wa_advance", templates.advance);
    localStorage.setItem("wa_balance", templates.balance);
    localStorage.setItem("wa_delivery", templates.delivery);
    localStorage.setItem("wa_eventReminder", templates.eventReminder);
    localStorage.setItem("wa_teamReminder", templates.teamReminder);
    setSaved(true);
    toast.success("WhatsApp templates saved!");
    setTimeout(() => setSaved(false), 2000);
  };

  const handleTestSend = (key: keyof typeof templates) => {
    const rendered = renderTemplate(templates[key], WA_SAMPLE);
    const encodedText = encodeURIComponent(rendered);
    window.open(`https://wa.me/?text=${encodedText}`, "_blank");
  };

  const varBadge = (v: string) => (
    <code
      key={v}
      className="text-xs px-1.5 py-0.5 rounded font-mono"
      style={{
        background: "#fef2f2",
        color: "#DC2626",
        border: "1px solid #fecaca",
      }}
    >
      {`{{${v}}}`}
    </code>
  );

  const TEMPLATE_DEFS = [
    { key: "advance" as const, label: "Advance Payment Reminder" },
    { key: "balance" as const, label: "Balance Payment Reminder" },
    { key: "delivery" as const, label: "Delivery Ready Notification" },
    { key: "eventReminder" as const, label: "Event Reminder (Client)" },
    { key: "teamReminder" as const, label: "Team Member Reminder" },
  ];

  return (
    <div className="space-y-6">
      {/* Variable reference */}
      <div
        className="p-3 rounded-xl text-sm space-y-2"
        style={{ background: "#f9fafb", border: "1px solid #e5e7eb" }}
      >
        <p className="text-xs text-muted-foreground font-semibold">
          Client / Invoice variables:
        </p>
        <div className="flex flex-wrap gap-1.5">
          {varBadge("clientName")}
          {varBadge("eventName")}
          {varBadge("programName")}
          {varBadge("eventDate")}
          {varBadge("eventTime")}
          {varBadge("venue")}
          {varBadge("invoiceNumber")}
          {varBadge("balance")}
          {varBadge("assignedTeam")}
        </div>
        <p className="text-xs text-muted-foreground font-semibold mt-1">
          Team reminder only:
        </p>
        <div className="flex flex-wrap gap-1.5">
          {varBadge("teamMemberName")}
        </div>
      </div>

      {/* Template editors */}
      <div className="grid grid-cols-1 gap-6">
        {TEMPLATE_DEFS.map(({ key, label }) => (
          <div key={key} className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-primary" />
                {label}
              </Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-7 text-xs gap-1.5 text-green-700 border-green-300 hover:bg-green-50"
                onClick={() => handleTestSend(key)}
                data-ocid={`settings.wa_test.${key}.button`}
              >
                <MessageCircle className="w-3 h-3" />
                Test Send
              </Button>
            </div>
            <Textarea
              value={templates[key]}
              onChange={(e) => setTpl(key, e.target.value)}
              rows={5}
              className="text-sm font-mono"
              data-ocid={`settings.wa_${key}.textarea`}
            />
          </div>
        ))}
      </div>

      {/* Preview */}
      <Card className="border-border bg-muted/30">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">
            Preview with Sample Data
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {(
              [
                "advance",
                "balance",
                "delivery",
                "eventReminder",
                "teamReminder",
              ] as const
            ).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setPreviewTab(t)}
                className={`text-xs px-3 py-1 rounded-full font-medium transition-colors ${
                  previewTab === t
                    ? "bg-primary text-primary-foreground"
                    : "bg-background text-muted-foreground hover:bg-muted"
                }`}
                data-ocid={`settings.wa_preview.${t}.tab`}
              >
                {t === "eventReminder"
                  ? "Event"
                  : t === "teamReminder"
                    ? "Team"
                    : t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </div>
          <div
            className="p-4 rounded-xl text-sm whitespace-pre-wrap leading-relaxed"
            style={{
              background: "#dcfce7",
              color: "#166534",
              fontFamily: "sans-serif",
            }}
          >
            {renderTemplate(templates[previewTab], WA_SAMPLE)}
          </div>
        </CardContent>
      </Card>

      <Button
        type="button"
        className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
        onClick={handleSave}
        data-ocid="settings.wa.save_button"
      >
        {saved ? (
          <Check className="w-4 h-4" />
        ) : (
          <MessageCircle className="w-4 h-4" />
        )}
        {saved ? "Saved!" : "Save Templates"}
      </Button>
    </div>
  );
}

// ── Appearance Tab ──
function AppearanceTab() {
  const theme = useAppStore((s) => s.theme);
  const toggleTheme = useAppStore((s) => s.toggleTheme);
  const isDark = theme === "dark";

  return (
    <div className="space-y-6">
      <Card className="border-border">
        <CardContent className="p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                {isDark ? (
                  <Moon className="w-5 h-5 text-primary" />
                ) : (
                  <Sun className="w-5 h-5 text-primary" />
                )}
              </div>
              <div>
                <p className="font-medium text-sm text-foreground">
                  {isDark ? "Dark Mode" : "Light Mode"}
                </p>
                <p className="text-xs text-muted-foreground">
                  Toggle app appearance
                </p>
              </div>
            </div>
            <Switch
              checked={isDark}
              onCheckedChange={toggleTheme}
              data-ocid="settings.theme.toggle"
            />
          </div>
        </CardContent>
      </Card>

      {/* Theme Preview */}
      <div className="space-y-2">
        <p className="text-sm font-medium text-foreground">Theme Preview</p>
        <div
          className="rounded-xl p-5 border border-border"
          style={{ background: isDark ? "#1a1a1a" : "#ffffff" }}
        >
          <div className="flex items-center gap-3 mb-4">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ background: "#DC2626" }}
            >
              <Camera className="w-4 h-4 text-white" />
            </div>
            <span
              className="font-semibold text-sm"
              style={{ color: isDark ? "#f9fafb" : "#111827" }}
            >
              Photography Invoice Studio
            </span>
          </div>
          <div className="flex gap-2 flex-wrap">
            {["Dashboard", "Invoices", "Clients", "Reports"].map((item) => (
              <span
                key={item}
                className="text-xs px-3 py-1.5 rounded-full"
                style={{
                  background:
                    item === "Dashboard"
                      ? "#DC2626"
                      : isDark
                        ? "#2a2a2a"
                        : "#f3f4f6",
                  color:
                    item === "Dashboard"
                      ? "white"
                      : isDark
                        ? "#d1d5db"
                        : "#374151",
                }}
              >
                {item}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Backup & Restore Tab ──
function BackupRestoreTab() {
  const {
    invoices,
    clients,
    services,
    packages,
    teamMembers,
    expenses,
    deliveryTrackers,
  } = useERPStore();
  const studioProfile = useStudioStore((s) => s.studioProfile);
  const [exporting, setExporting] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importSummary, setImportSummary] = useState<{
    clients: number;
    invoices: number;
    team: number;
    services: number;
    expenses: number;
  } | null>(null);
  const [importData, setImportData] = useState<Record<string, unknown> | null>(
    null,
  );
  const [restoring, setRestoring] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const lastBackup = localStorage.getItem("lastBackupDate");

  const handleExport = () => {
    setExporting(true);
    try {
      const backup = {
        exportedAt: new Date().toISOString(),
        version: "2.0",
        studioProfile,
        clients,
        invoices,
        team: teamMembers,
        services,
        packages,
        expenses,
        deliveryTrackers,
      };
      const blob = new Blob([JSON.stringify(backup, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      const date = new Date().toISOString().split("T")[0];
      a.href = url;
      a.download = `photography-studio-backup-${date}.json`;
      a.click();
      URL.revokeObjectURL(url);
      const now = new Date().toLocaleString("en-IN");
      localStorage.setItem("lastBackupDate", now);
      toast.success("Backup downloaded!");
    } catch {
      toast.error("Export failed.");
    } finally {
      setExporting(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportFile(file);
    setImportSummary(null);
    setImportData(null);
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target?.result as string) as Record<
          string,
          unknown
        >;
        setImportData(data);
        setImportSummary({
          clients: Array.isArray(data.clients) ? data.clients.length : 0,
          invoices: Array.isArray(data.invoices) ? data.invoices.length : 0,
          team: Array.isArray(data.team) ? data.team.length : 0,
          services: Array.isArray(data.services) ? data.services.length : 0,
          expenses: Array.isArray(data.expenses) ? data.expenses.length : 0,
        });
      } catch {
        toast.error("Invalid backup file");
      }
    };
    reader.readAsText(file);
  };

  const handleRestore = () => {
    if (!importData) {
      toast.error("No data to restore");
      return;
    }
    setRestoring(true);
    try {
      const store = useERPStore.getState();
      if (Array.isArray(importData.clients)) {
        for (const c of importData.clients as import("@/types").Client[]) {
          try {
            store.addClient(c);
          } catch {
            /* skip */
          }
        }
      }
      if (Array.isArray(importData.invoices)) {
        for (const inv of importData.invoices as import("@/types").Invoice[]) {
          try {
            store.addInvoice(inv);
          } catch {
            /* skip */
          }
        }
      }
      if (Array.isArray(importData.expenses)) {
        for (const exp of importData.expenses as import("@/types").Expense[]) {
          try {
            store.addExpense(exp);
          } catch {
            /* skip */
          }
        }
      }
      toast.success("Restore complete!");
      setImportFile(null);
      setImportSummary(null);
      setImportData(null);
    } catch {
      toast.error("Restore failed.");
    } finally {
      setRestoring(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Export */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
              <Download className="w-5 h-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-sm font-semibold">
                Export All Data
              </CardTitle>
              <CardDescription className="text-xs">
                Download a complete JSON backup of your studio data
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0 space-y-3">
          {lastBackup && (
            <p className="text-xs text-muted-foreground">
              Last backup:{" "}
              <span className="font-medium text-foreground">{lastBackup}</span>
            </p>
          )}
          <Button
            type="button"
            className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={handleExport}
            disabled={exporting}
            data-ocid="settings.export_data.button"
          >
            {exporting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Download className="w-4 h-4" />
            )}
            {exporting ? "Exporting..." : "Export All Data"}
          </Button>
        </CardContent>
      </Card>

      {/* Import */}
      <Card className="border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-100 flex items-center justify-center">
              <FileJson className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <CardTitle className="text-sm font-semibold">
                Import Data
              </CardTitle>
              <CardDescription className="text-xs">
                Restore from a previous backup file
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0 space-y-4">
          {/* Warning */}
          <div
            className="flex items-start gap-2 p-3 rounded-xl text-xs"
            style={{
              background: "#fef3c7",
              border: "1px solid #fde68a",
              color: "#92400e",
            }}
          >
            <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5 text-amber-600" />
            <span>
              <strong>Warning:</strong> Importing will add data on top of
              existing records. This cannot be undone. Make sure you have a
              current backup before proceeding.
            </span>
          </div>

          <div className="space-y-2">
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleFileSelect}
              disabled={restoring}
            />
            <Button
              type="button"
              variant="outline"
              className="gap-2"
              onClick={() => fileInputRef.current?.click()}
              data-ocid="settings.import.upload_button"
            >
              <Upload className="w-4 h-4" />
              {importFile ? importFile.name : "Select Backup File (.json)"}
            </Button>
          </div>

          {/* Summary */}
          {importSummary && (
            <div
              className="p-4 rounded-xl space-y-2 text-sm"
              style={{ background: "#f0fdf4", border: "1px solid #bbf7d0" }}
              data-ocid="settings.import.summary"
            >
              <p className="font-semibold text-green-800">Backup Summary:</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {(
                  [
                    ["Clients", importSummary.clients],
                    ["Invoices", importSummary.invoices],
                    ["Team", importSummary.team],
                    ["Services", importSummary.services],
                    ["Expenses", importSummary.expenses],
                  ] as [string, number][]
                ).map(([label, count]) => (
                  <div key={label} className="text-center">
                    <p className="text-xl font-bold text-green-700">{count}</p>
                    <p className="text-xs text-green-600">{label}</p>
                  </div>
                ))}
              </div>
              <Button
                type="button"
                className="w-full gap-2 mt-2"
                style={{ background: "#16a34a", color: "white" }}
                onClick={handleRestore}
                disabled={restoring}
                data-ocid="settings.restore.confirm_button"
              >
                {restoring ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Check className="w-4 h-4" />
                )}
                {restoring ? "Restoring..." : "Restore Data"}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ── Main Settings Page ──
export default function SettingsPage() {
  const studioProfile = useStudioStore((s) => s.studioProfile);

  const TABS = [
    { value: "profile", label: "Studio Profile", icon: Camera },
    { value: "invoice", label: "Invoice Settings", icon: Receipt },
    { value: "whatsapp", label: "WhatsApp Templates", icon: MessageCircle },
    { value: "appearance", label: "Appearance", icon: Settings2 },
    { value: "backup", label: "Backup & Restore", icon: FileJson },
  ];

  return (
    <AppLayout>
      <div
        id="settings-page"
        className="space-y-6 pb-8 max-w-4xl"
        data-ocid="settings.page"
      >
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">
            Settings
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Manage your studio preferences and configuration
          </p>
        </div>

        {!studioProfile ? (
          <div className="space-y-3">
            <Skeleton className="h-10 w-full rounded-lg" />
            <Skeleton className="h-64 w-full rounded-xl" />
          </div>
        ) : (
          <Tabs defaultValue="profile" data-ocid="settings.tabs">
            <TabsList className="flex flex-wrap h-auto gap-1 p-1 bg-muted w-full justify-start">
              {TABS.map((tab) => {
                const Icon = tab.icon;
                return (
                  <TabsTrigger
                    key={tab.value}
                    value={tab.value}
                    className="gap-1.5 text-xs sm:text-sm"
                    data-ocid={`settings.${tab.value}.tab`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{tab.label}</span>
                    <span className="sm:hidden">{tab.label.split(" ")[0]}</span>
                  </TabsTrigger>
                );
              })}
            </TabsList>

            <TabsContent value="profile" className="mt-6">
              <Card className="shadow-card">
                <CardHeader className="pb-4">
                  <CardTitle className="font-display text-base">
                    Studio Profile
                  </CardTitle>
                  <CardDescription>
                    Update your studio information and branding
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <StudioProfileTab />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="invoice" className="mt-6">
              <Card className="shadow-card">
                <CardHeader className="pb-4">
                  <CardTitle className="font-display text-base">
                    Invoice Settings
                  </CardTitle>
                  <CardDescription>
                    Configure numbering, GST, and default terms
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <InvoiceSettingsTab />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="whatsapp" className="mt-6">
              <Card className="shadow-card">
                <CardHeader className="pb-4">
                  <CardTitle className="font-display text-base">
                    WhatsApp Templates
                  </CardTitle>
                  <CardDescription>
                    Customize automated reminder messages sent to clients
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <WhatsAppTemplatesTab />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="appearance" className="mt-6">
              <Card className="shadow-card">
                <CardHeader className="pb-4">
                  <CardTitle className="font-display text-base">
                    Appearance
                  </CardTitle>
                  <CardDescription>
                    Customize the look and feel of your app
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <AppearanceTab />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="backup" className="mt-6">
              <BackupRestoreTab />
            </TabsContent>
          </Tabs>
        )}
      </div>
    </AppLayout>
  );
}
