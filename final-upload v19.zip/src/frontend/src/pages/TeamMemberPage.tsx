import AppLayout from "@/components/layout/AppLayout";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  formatCurrency,
  formatDate,
  getInitials,
  getPaymentStatus,
  getStatusColor,
} from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { PaymentLedgerEntry, PaymentMode } from "@/types";
import type { Invoice, TeamAssignment, WorkHistoryEntry } from "@/types";
import { useNavigate, useParams } from "@tanstack/react-router";
import {
  AlertCircle,
  ArrowLeft,
  CalendarDays,
  Camera,
  ClipboardList,
  Clock,
  IndianRupee,
  Mail,
  MapPin,
  Pencil,
  Phone,
  Plus,
  Trash2,
  TrendingUp,
  Wallet,
} from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

// ---- Rate Card ----

function RateCard({
  label,
  amount,
  sub,
}: { label: string; amount: number; sub?: string }) {
  return (
    <div className="flex flex-col gap-1 p-4 rounded-xl border border-border bg-card">
      <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
        {label}
      </p>
      <div className="flex items-center gap-1">
        <IndianRupee className="w-4 h-4 text-primary" />
        <span className="text-xl font-display font-bold text-foreground">
          {amount.toLocaleString("en-IN")}
        </span>
      </div>
      {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
    </div>
  );
}

// ---- Add Payment Dialog ----

function AddPaymentDialog({
  open,
  onClose,
  onConfirm,
  clients,
  initialData,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: (data: {
    clientId: string;
    amount: number;
    mode: PaymentMode;
    note: string;
    date: string;
  }) => void;
  clients: { id: string; name: string }[];
  initialData?: {
    clientId: string;
    amount: number;
    mode: PaymentMode;
    note: string;
    date: string;
  };
}) {
  const [clientId, setClientId] = useState("");
  const [amount, setAmount] = useState("");
  const [mode, setMode] = useState<PaymentMode>("cash");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);

  useEffect(() => {
    if (initialData) {
      setClientId(initialData.clientId);
      setAmount(String(initialData.amount));
      setMode(initialData.mode);
      setNote(initialData.note || "");
      setDate(initialData.date);
    } else {
      setClientId("");
      setAmount("");
      setMode("cash");
      setNote("");
      setDate(new Date().toISOString().split("T")[0]);
    }
  }, [initialData]);

  function handleConfirm() {
    const val = Number(amount);
    if (!val || val <= 0) {
      toast.error("Enter a valid payment amount");
      return;
    }
    if (!clientId) {
      toast.error("Select a client");
      return;
    }
    onConfirm({
      clientId,
      amount: val,
      mode,
      note,
      date,
    });
    setAmount("");
    setNote("");
    setClientId("");
    setMode("cash");
    setDate(new Date().toISOString().split("T")[0]);
    onClose();
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent
        className="w-[95vw] max-w-md max-h-[90vh] overflow-y-auto"
        data-ocid="team_member.add_payment_dialog"
      >
        <DialogHeader>
          <DialogTitle>Record Payment</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label>Client</Label>
            <Select value={clientId} onValueChange={setClientId}>
              <SelectTrigger data-ocid="team_member.payment_client_select">
                <SelectValue placeholder="Select client" />
              </SelectTrigger>
              <SelectContent>
                {clients.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Amount (₹)</Label>
            <Input
              type="number"
              min="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter payment amount"
              data-ocid="team_member.payment_amount_input"
              autoFocus
            />
          </div>
          <div className="space-y-1.5">
            <Label>Payment Mode</Label>
            <Select
              value={mode}
              onValueChange={(v) => setMode(v as PaymentMode)}
            >
              <SelectTrigger data-ocid="team_member.payment_mode_select">
                <SelectValue placeholder="Select mode" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cash">Cash</SelectItem>
                <SelectItem value="upi">UPI / Online</SelectItem>
                <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                <SelectItem value="cheque">Cheque</SelectItem>
                <SelectItem value="card">Card</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Date</Label>
            <Input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              data-ocid="team_member.payment_date_input"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Note</Label>
            <Input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Optional note"
              data-ocid="team_member.payment_note_input"
            />
          </div>
        </div>
        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            data-ocid="team_member.payment_cancel_button"
          >
            Cancel
          </Button>
          <Button
            type="button"
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
            onClick={handleConfirm}
            data-ocid="team_member.payment_confirm_button"
          >
            Record Payment
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---- Edit History Entry Dialog ----

function EditHistoryDialog({
  open,
  onClose,
  entry,
  onSave,
}: {
  open: boolean;
  onClose: () => void;
  entry: WorkHistoryEntry;
  onSave: (assignmentId: string, updates: Partial<TeamAssignment>) => void;
}) {
  const [date, setDate] = useState(entry.date ?? "");
  const [dayType, setDayType] = useState<"full" | "half">(
    entry.dayType ?? "full",
  );
  const [startTime, setStartTime] = useState(entry.startTime ?? "");
  const [endTime, setEndTime] = useState(entry.endTime ?? "");
  const [notes, setNotes] = useState("");

  // Reset form fields whenever the entry prop changes (e.g. opening for a different row)
  useEffect(() => {
    setDate(entry.date ?? "");
    setDayType(entry.dayType ?? "full");
    setStartTime(entry.startTime ?? "");
    setEndTime(entry.endTime ?? "");
    setNotes("");
  }, [entry]);

  function handleSave() {
    if (!entry.assignmentId) {
      toast.error("This entry has no assignment ID and cannot be edited.");
      return;
    }
    onSave(entry.assignmentId, {
      date,
      dayType,
      startTime: startTime || undefined,
      endTime: endTime || undefined,
      notes: notes || undefined,
    });
    onClose();
    toast.success("Assignment updated");
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent
        className="w-[95vw] max-w-sm max-h-[90vh] overflow-y-auto"
        data-ocid="team_member.edit_history_dialog"
      >
        <DialogHeader>
          <DialogTitle>Edit Work Entry</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label htmlFor="edit-date">Date</Label>
            <Input
              id="edit-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              data-ocid="team_member.edit_history.date_input"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Day Type</Label>
            <RadioGroup
              value={dayType}
              onValueChange={(v) => setDayType(v as "full" | "half")}
              className="flex gap-4"
            >
              <div className="flex items-center gap-2">
                <RadioGroupItem
                  value="full"
                  id="edit-full"
                  data-ocid="team_member.edit_history.full_day_radio"
                />
                <Label
                  htmlFor="edit-full"
                  className="font-normal cursor-pointer"
                >
                  Full Day
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <RadioGroupItem
                  value="half"
                  id="edit-half"
                  data-ocid="team_member.edit_history.half_day_radio"
                />
                <Label
                  htmlFor="edit-half"
                  className="font-normal cursor-pointer"
                >
                  Half Day (50%)
                </Label>
              </div>
            </RadioGroup>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="edit-start">Start Time</Label>
              <Input
                id="edit-start"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                data-ocid="team_member.edit_history.start_time_input"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="edit-end">End Time</Label>
              <Input
                id="edit-end"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                data-ocid="team_member.edit_history.end_time_input"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="edit-notes">Notes</Label>
            <Input
              id="edit-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Optional notes"
              data-ocid="team_member.edit_history.notes_input"
            />
          </div>
        </div>
        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            data-ocid="team_member.edit_history.cancel_button"
          >
            Cancel
          </Button>
          <Button
            type="button"
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
            onClick={handleSave}
            data-ocid="team_member.edit_history.save_button"
          >
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---- Work History Table ----

/** Apply half-day multiplier to a work history entry's base rate */
function getEffectiveRate(h: WorkHistoryEntry): number {
  const rate = h.rateUsed ?? 0;
  return h.dayType === "half" ? rate * 0.5 : rate;
}

function WorkHistoryTable({
  history,
  onEditEntry,
  onDeleteEntry,
}: {
  history: WorkHistoryEntry[];
  onEditEntry: (entry: WorkHistoryEntry) => void;
  onDeleteEntry: (entry: WorkHistoryEntry, index: number) => void;
}) {
  if (history.length === 0) {
    return (
      <div
        className="flex flex-col items-center justify-center py-10 text-center"
        data-ocid="team_member.work_history.empty_state"
      >
        <CalendarDays className="w-10 h-10 text-muted-foreground mb-3" />
        <p className="text-sm text-muted-foreground">
          No work history recorded yet
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border">
            <th className="text-left py-2.5 pr-2 font-medium text-muted-foreground text-xs uppercase tracking-wide">
              Client / Event
            </th>
            <th className="text-left py-2.5 pr-2 font-medium text-muted-foreground text-xs uppercase tracking-wide">
              Program
            </th>
            <th className="text-left py-2.5 pr-2 font-medium text-muted-foreground text-xs uppercase tracking-wide hidden sm:table-cell">
              Date
            </th>
            <th className="text-left py-2.5 pr-2 font-medium text-muted-foreground text-xs uppercase tracking-wide hidden md:table-cell">
              Day Type
            </th>
            <th className="text-left py-2.5 pr-2 font-medium text-muted-foreground text-xs uppercase tracking-wide hidden lg:table-cell">
              Role
            </th>
            <th className="text-right py-2.5 pr-2 font-medium text-muted-foreground text-xs uppercase tracking-wide">
              Base Rate
            </th>
            <th className="text-right py-2.5 pr-2 font-medium text-muted-foreground text-xs uppercase tracking-wide hidden md:table-cell">
              Earned
            </th>
            <th className="text-right py-2.5 pr-2 font-medium text-muted-foreground text-xs uppercase tracking-wide hidden md:table-cell">
              Paid
            </th>
            <th className="text-right py-2.5 pr-2 font-medium text-muted-foreground text-xs uppercase tracking-wide hidden md:table-cell">
              Pending
            </th>
            <th className="text-center py-2.5 font-medium text-muted-foreground text-xs uppercase tracking-wide">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {history.map((h, i) => {
            const earned = getEffectiveRate(h);
            const paid = h.paymentReceived ?? 0;
            const pending = Math.max(0, earned - paid);
            const isHalf = h.dayType === "half";
            return (
              <tr
                key={`${h.invoiceId}-${h.program ?? ""}-${i}`}
                className="hover:bg-muted/40 transition-colors"
                data-ocid={`team_member.work_history.item.${i + 1}`}
              >
                <td className="py-3 pr-2">
                  <p className="font-medium text-xs text-foreground truncate max-w-[100px]">
                    {h.clientName || "—"}
                  </p>
                  <p className="text-[11px] text-muted-foreground truncate max-w-[100px]">
                    {h.eventName || "—"}
                  </p>
                </td>
                <td className="py-3 pr-2">
                  <Badge variant="secondary" className="text-[11px]">
                    {h.program || "—"}
                  </Badge>
                </td>
                <td className="py-3 pr-2 hidden sm:table-cell">
                  <span className="text-xs text-muted-foreground">
                    {h.date
                      ? new Date(h.date).toLocaleDateString("en-IN", {
                          day: "numeric",
                          month: "short",
                          year: "numeric",
                        })
                      : "—"}
                  </span>
                </td>
                <td className="py-3 pr-2 hidden md:table-cell">
                  <Badge
                    variant="outline"
                    className={`text-[10px] ${
                      isHalf
                        ? "border-amber-300 text-amber-600"
                        : "border-green-300 text-green-600"
                    }`}
                  >
                    {isHalf ? "Half Day (50%)" : "Full Day"}
                  </Badge>
                </td>
                <td className="py-3 pr-2 hidden lg:table-cell text-xs text-muted-foreground">
                  {h.role || "—"}
                </td>
                <td className="py-3 pr-2 text-right">
                  <span className="text-xs text-muted-foreground">
                    {(h.rateUsed ?? 0) > 0
                      ? formatCurrency(h.rateUsed ?? 0)
                      : "—"}
                  </span>
                  {isHalf && (h.rateUsed ?? 0) > 0 && (
                    <p className="text-[10px] text-amber-600">×50%</p>
                  )}
                </td>
                <td className="py-3 pr-2 text-right hidden md:table-cell">
                  <span className="text-xs font-semibold text-foreground">
                    {earned > 0 ? formatCurrency(earned) : "—"}
                  </span>
                </td>
                <td className="py-3 pr-2 text-right hidden md:table-cell">
                  <span className="text-xs font-semibold text-green-600">
                    {paid > 0 ? formatCurrency(paid) : "₹0"}
                  </span>
                </td>
                <td className="py-3 pr-2 text-right hidden md:table-cell">
                  <span
                    className={`text-xs font-semibold ${pending > 0 ? "text-destructive" : "text-green-600"}`}
                  >
                    {pending > 0 ? formatCurrency(pending) : "Cleared"}
                  </span>
                </td>
                <td className="py-3">
                  <div className="flex items-center justify-center gap-0.5">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-muted-foreground hover:text-foreground"
                      onClick={() => onEditEntry(h)}
                      aria-label="Edit entry"
                      data-ocid={`team_member.edit_history_button.${i + 1}`}
                    >
                      <Pencil className="w-3 h-3" />
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-destructive/60 hover:text-destructive"
                      onClick={() => onDeleteEntry(h, i)}
                      aria-label="Delete entry"
                      data-ocid={`team_member.delete_history_button.${i + 1}`}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ---- Main Page ----

export default function TeamMemberPage() {
  const navigate = useNavigate();
  const params = useParams({ strict: false }) as { memberId?: string };
  const memberId = params.memberId ?? "";

  const {
    teamMembers,
    invoices,
    clients,
    addClientPayment,
    editClientPayment,
    deleteClientPayment,
    getClientPaymentHistory,
    updateTeamAssignment,
    deleteTeamAssignment,
  } = useERPStore();
  const member = teamMembers.find((m) => m.id === memberId);

  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [editingPayment, setEditingPayment] =
    useState<PaymentLedgerEntry | null>(null);
  const [editingEntry, setEditingEntry] = useState<WorkHistoryEntry | null>(
    null,
  );
  const [deletingEntry, setDeletingEntry] = useState<{
    entry: WorkHistoryEntry;
    index: number;
  } | null>(null);

  const assignedInvoices: Invoice[] = invoices.filter((inv) =>
    (inv.teamAssignments ?? []).some((a) => a.teamMemberId === memberId),
  );

  // Build rich work history — reconcile member.workHistory with live invoice data.
  // For each assignment on every assigned invoice, emit one WorkHistoryEntry per
  // effective date. We prefer existing workHistory entries (which carry payment data)
  // and fall back to deriving them directly from the invoice assignments so that
  // earnings/paid/pending are never zero due to a stale or missing sync.
  const workHistory: WorkHistoryEntry[] = (() => {
    // Index existing history entries by assignmentId + date for fast lookup
    const existingByKey = new Map<string, WorkHistoryEntry>();
    for (const h of member?.workHistory ?? []) {
      const key = `${h.assignmentId ?? `${h.invoiceId}__${h.program ?? ""}`}__${h.date ?? ""}`;
      existingByKey.set(key, h);
    }

    const result: WorkHistoryEntry[] = [];

    for (const inv of assignedInvoices) {
      const myAssignments = (inv.teamAssignments ?? []).filter(
        (a) => a.teamMemberId === memberId,
      );
      for (const a of myAssignments) {
        // Determine effective dates for this assignment
        const effectiveDates: string[] = [];
        if (a.dateRangeStart && a.dateRangeEnd) {
          const cur = new Date(a.dateRangeStart);
          const end = new Date(a.dateRangeEnd);
          while (cur <= end) {
            effectiveDates.push(cur.toISOString().split("T")[0]);
            cur.setDate(cur.getDate() + 1);
          }
        } else if (a.date) {
          effectiveDates.push(a.date);
        } else {
          // No date info — still emit one entry so payment info is visible
          effectiveDates.push("");
        }

        for (const d of effectiveDates) {
          const keyBase = a.id
            ? `${a.id}__${d}`
            : `${inv.id}__${a.program ?? ""}__${d}`;
          const key = keyBase;
          const existing = existingByKey.get(key);

          if (existing) {
            // Use existing (has up-to-date payment data), but ensure client/event names are set
            result.push({
              ...existing,
              clientName: existing.clientName || inv.clientName,
              eventName:
                existing.eventName || inv.customEventName || inv.eventType,
              rateUsed:
                (existing.rateUsed ?? 0) > 0
                  ? existing.rateUsed
                  : (a.rateUsed ?? 0),
            });
          } else {
            // Derive from live assignment data
            const baseRate = a.rateUsed ?? 0;
            const effectiveRate =
              a.dayType === "half" ? baseRate * 0.5 : baseRate;
            const paid = a.paymentReceived ?? 0;
            result.push({
              invoiceId: inv.id,
              clientName: inv.clientName,
              eventName: inv.customEventName ?? inv.eventType,
              program: a.program ?? "",
              date: d,
              startTime: a.startTime ?? "",
              endTime: a.endTime ?? "",
              location: a.location ?? "",
              role: a.role ?? "",
              dayType: a.dayType ?? "full",
              rateUsed: baseRate,
              paymentReceived: paid,
              paymentPending: Math.max(0, effectiveRate - paid),
              recordedAt: a.createdAt
                ? new Date(a.createdAt).toISOString()
                : new Date().toISOString(),
              assignmentId: a.id,
            });
          }
        }
      }
    }

    // Also include member.workHistory entries that are NOT linked to any invoice assignment
    // (e.g. manually created entries without an invoiceId)
    for (const h of member?.workHistory ?? []) {
      const linkedInvoice = assignedInvoices.find(
        (inv) => inv.id === h.invoiceId,
      );
      if (!linkedInvoice) {
        // Standalone history entry — include as-is
        result.push(h);
      }
    }

    // Sort by date descending (most recent first)
    return result.sort(
      (a, b) =>
        new Date(b.date ?? "").getTime() - new Date(a.date ?? "").getTime(),
    );
  })();

  const now = new Date();
  // Count work history entries this month (by actual worked date)
  const thisMonthEvents = workHistory.filter((h) => {
    if (!h.date) return false;
    const d = new Date(h.date);
    return (
      d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth()
    );
  });

  // Upcoming: distinct invoices with future event start dates
  const upcoming = assignedInvoices
    .filter(
      (inv) => inv.eventStartDate && new Date(inv.eventStartDate) >= new Date(),
    )
    .sort(
      (a, b) =>
        new Date(a.eventStartDate).getTime() -
        new Date(b.eventStartDate).getTime(),
    );

  // Earnings calculations — apply half-day 50% multiplier to rateUsed
  function effectiveRate(h: WorkHistoryEntry): number {
    const rate = h.rateUsed ?? 0;
    return h.dayType === "half" ? rate * 0.5 : rate;
  }

  const totalEarnings = workHistory.reduce((s, h) => s + effectiveRate(h), 0);
  const totalPaid = workHistory.reduce(
    (s, h) => s + (h.paymentReceived ?? 0),
    0,
  );
  const totalPending = workHistory.reduce(
    (s, h) => s + Math.max(0, effectiveRate(h) - (h.paymentReceived ?? 0)),
    0,
  );

  function handleAddPayment(data: {
    clientId: string;
    amount: number;
    mode: PaymentMode;
    note: string;
    date: string;
  }) {
    addClientPayment(data.clientId, {
      date: data.date,
      amount: data.amount,
      mode: data.mode,
      note: data.note,
      linkedClientId: data.clientId,
      linkedInvoiceId: undefined,
    });
    toast.success(`Payment of ${formatCurrency(data.amount)} recorded`);
    setPaymentDialogOpen(false);
    setEditingPayment(null);
  }

  function handleEditPayment(data: {
    clientId: string;
    amount: number;
    mode: PaymentMode;
    note: string;
    date: string;
  }) {
    if (!editingPayment) return;
    editClientPayment(data.clientId, editingPayment.id, {
      date: data.date,
      amount: data.amount,
      mode: data.mode,
      note: data.note,
    });
    toast.success("Payment updated");
    setPaymentDialogOpen(false);
    setEditingPayment(null);
  }

  function handleDeletePayment(entry: PaymentLedgerEntry) {
    if (confirm("Are you sure you want to delete this payment?")) {
      deleteClientPayment(entry.linkedClientId, entry.id);
      toast.success("Payment deleted");
    }
  }

  function handleEditEntry(entry: WorkHistoryEntry) {
    setEditingEntry(entry);
  }

  function handleSaveEditEntry(
    assignmentId: string,
    updates: Partial<TeamAssignment>,
  ) {
    updateTeamAssignment(assignmentId, updates);
    setEditingEntry(null);
  }

  function handleDeleteEntry(entry: WorkHistoryEntry, _index: number) {
    setDeletingEntry({ entry, index: _index });
  }

  function confirmDeleteEntry() {
    if (!deletingEntry) return;
    const { entry } = deletingEntry;
    if (entry.assignmentId) {
      deleteTeamAssignment(entry.assignmentId);
      toast.success("Work entry deleted");
    } else {
      toast.error(
        "This entry has no assignment ID and cannot be deleted from here.",
      );
    }
    setDeletingEntry(null);
  }

  if (!memberId || !member) {
    return (
      <AppLayout>
        <div
          className="flex flex-col items-center justify-center h-64 text-center space-y-4"
          data-ocid="team_member.error_state"
        >
          <AlertCircle className="w-12 h-12 text-destructive" />
          <p className="font-semibold text-foreground">Team member not found</p>
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate({ to: "/team" })}
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Team
          </Button>
        </div>
      </AppLayout>
    );
  }

  const initials = getInitials(member.name);
  const totalWorkDays = workHistory.length;
  const totalAssignmentsCount =
    new Set(
      workHistory
        .map((w) => w.assignmentId)
        .filter((id): id is string => Boolean(id)),
    ).size || totalWorkDays;

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-6" data-ocid="team_member.page">
        {/* Back + Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-4 min-w-0">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => navigate({ to: "/team" })}
              data-ocid="team_member.back_button"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <Avatar className="w-20 h-20 border-2 border-border">
              {member.photo && (
                <AvatarImage src={member.photo} alt={member.name} />
              )}
              <AvatarFallback className="bg-primary/10 text-primary text-2xl font-bold">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-xl font-display font-bold text-foreground">
                {member.name}
              </h1>
              <div className="flex flex-wrap items-center gap-2 mt-1">
                {member.role && (
                  <Badge variant="secondary">{member.role}</Badge>
                )}
              </div>
              {member.phone && (
                <a
                  href={`tel:${member.phone}`}
                  className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors mt-1.5"
                  data-ocid="team_member.phone_link"
                >
                  <Phone className="w-3.5 h-3.5" />
                  {member.phone}
                </a>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              type="button"
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
              onClick={() => setPaymentDialogOpen(true)}
              data-ocid="team_member.add_payment_button"
            >
              <Plus className="w-4 h-4 mr-2" /> Add Payment
            </Button>
            <Button
              type="button"
              variant="outline"
              className="hover:bg-primary hover:text-primary-foreground hover:border-primary transition-colors"
              onClick={() =>
                navigate({
                  to: "/team",
                  search: { edit: memberId } as Record<string, string>,
                })
              }
              data-ocid="team_member.edit_button"
            >
              <Pencil className="w-4 h-4 mr-2" /> Edit Profile
            </Button>
          </div>
        </div>

        {/* Rate Cards */}
        <div
          className="grid grid-cols-2 gap-4"
          data-ocid="team_member.rates_section"
        >
          <RateCard
            label="Day Rate (with camera)"
            amount={member.perDayRateWithCamera}
            sub="per full day"
          />
          <RateCard
            label="Day Rate (without camera)"
            amount={member.perDayRateWithoutCamera}
            sub="per full day"
          />
        </div>

        {/* Earnings Summary */}
        <div
          className="grid grid-cols-2 sm:grid-cols-4 gap-4"
          data-ocid="team_member.earnings_section"
        >
          <div className="bg-card border border-border rounded-xl p-4">
            <p className="text-xs text-muted-foreground font-medium">
              Total Assignments
            </p>
            <p className="text-2xl font-display font-bold text-foreground mt-1">
              {totalAssignmentsCount}{" "}
              <span className="text-xs font-normal text-muted-foreground">
                ({totalWorkDays} days)
              </span>
            </p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4">
            <p className="text-xs text-muted-foreground font-medium">
              This Month
            </p>
            <p className="text-2xl font-display font-bold text-foreground mt-1">
              {thisMonthEvents.length}
            </p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              work days
            </p>
          </div>
          <div className="bg-card border border-primary/20 rounded-xl p-4">
            <p className="text-xs text-muted-foreground font-medium flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> Total Earnings
            </p>
            <p className="text-lg font-display font-bold text-primary mt-1">
              {formatCurrency(totalEarnings)}
            </p>
            <p className="text-[11px] text-green-600 mt-0.5">
              Paid: {formatCurrency(totalPaid)}
            </p>
          </div>
          <div
            className={`bg-card border rounded-xl p-4 ${totalPending > 0 ? "border-destructive/30" : "border-border"}`}
          >
            <p className="text-xs text-muted-foreground font-medium flex items-center gap-1">
              <Wallet className="w-3 h-3" /> Pending
            </p>
            <p
              className={`text-lg font-display font-bold mt-1 ${totalPending > 0 ? "text-destructive" : "text-green-600"}`}
            >
              {totalPending > 0 ? formatCurrency(totalPending) : "Cleared"}
            </p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              {upcoming.length} upcoming
            </p>
          </div>
          <div className="bg-blue-50 border border-blue-100 rounded-xl p-4">
            <p className="text-xs text-muted-foreground font-medium">
              Camera Days
            </p>
            <p className="text-2xl font-display font-bold text-blue-600 mt-1">
              {workHistory.filter((w) => w.withCamera === true).length}
            </p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              with camera
            </p>
          </div>
          <div className="bg-muted/30 border border-border rounded-xl p-4">
            <p className="text-xs text-muted-foreground font-medium">
              No Camera
            </p>
            <p className="text-2xl font-display font-bold text-muted-foreground mt-1">
              {workHistory.filter((w) => !w.withCamera).length}
            </p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              without camera
            </p>
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid md:grid-cols-2 gap-5">
          {/* Info Card */}
          <Card className="border-border" data-ocid="team_member.info_card">
            <CardHeader className="pb-3">
              <CardTitle className="font-display text-base">
                Member Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {member.phone && (
                <div className="flex items-center gap-3 text-sm">
                  <Phone className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <a
                    href={`tel:${member.phone}`}
                    className="hover:text-primary transition-colors"
                  >
                    {member.phone}
                  </a>
                </div>
              )}
              {member.email && (
                <div className="flex items-center gap-3 text-sm">
                  <Mail className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <a
                    href={`mailto:${member.email}`}
                    className="hover:text-primary transition-colors truncate"
                  >
                    {member.email}
                  </a>
                </div>
              )}
              {(member.skills ?? []).length > 0 && (
                <div className="pt-2">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-2">
                    Skills
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {(member.skills ?? []).map((skill) => (
                      <span
                        key={skill}
                        className="px-2.5 py-1 bg-primary/10 text-primary text-xs rounded-full font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {member.notes && (
                <div className="pt-2 border-t border-border">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">
                    Notes
                  </p>
                  <p className="text-sm text-foreground leading-relaxed">
                    {member.notes}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Equipment Card */}
          <Card
            className="border-border"
            data-ocid="team_member.equipment_card"
          >
            <CardHeader className="pb-3">
              <CardTitle className="font-display text-base">
                Equipment
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {member.cameraName && (
                <div className="p-3 rounded-lg bg-primary/5 border border-primary/20 space-y-1">
                  <div className="flex items-center gap-2">
                    <Camera className="w-4 h-4 text-primary" />
                    <span className="text-sm font-semibold text-foreground">
                      {member.cameraName}
                    </span>
                  </div>
                  {member.equipmentDetails && (
                    <p className="text-xs text-muted-foreground pl-6">
                      {member.equipmentDetails}
                    </p>
                  )}
                </div>
              )}
              {!member.cameraName && !member.equipmentDetails && (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Camera className="w-10 h-10 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">
                    No equipment details added
                  </p>
                </div>
              )}
              {member.equipmentDetails && !member.cameraName && (
                <p className="text-sm text-foreground">
                  {member.equipmentDetails}
                </p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Work History */}
        <Card
          className="border-border"
          data-ocid="team_member.work_history_card"
        >
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <CardTitle className="font-display text-base flex items-center gap-2">
                <CalendarDays className="w-4 h-4" />
                Work History
                <Badge variant="secondary" className="ml-1">
                  {workHistory.length} entr
                  {workHistory.length !== 1 ? "ies" : "y"}
                </Badge>
              </CardTitle>
              {totalEarnings > 0 && (
                <div className="flex items-center gap-3 text-xs">
                  <span className="text-muted-foreground">
                    Total:{" "}
                    <strong className="text-foreground">
                      {formatCurrency(totalEarnings)}
                    </strong>
                  </span>
                  <span className="text-green-600">
                    Paid: <strong>{formatCurrency(totalPaid)}</strong>
                  </span>
                  {totalPending > 0 && (
                    <span className="text-destructive">
                      Due: <strong>{formatCurrency(totalPending)}</strong>
                    </span>
                  )}
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <WorkHistoryTable
              history={workHistory}
              onEditEntry={handleEditEntry}
              onDeleteEntry={handleDeleteEntry}
            />
          </CardContent>
        </Card>

        {/* Assigned Events */}
        <Card className="border-border" data-ocid="team_member.events_card">
          <CardHeader className="pb-3">
            <CardTitle className="font-display text-base flex items-center gap-2">
              <ClipboardList className="w-4 h-4" />
              Invoice Events
              <Badge variant="secondary" className="ml-1">
                {assignedInvoices.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {assignedInvoices.length === 0 ? (
              <div
                className="flex flex-col items-center justify-center py-10 text-center"
                data-ocid="team_member.events.empty_state"
              >
                <ClipboardList className="w-10 h-10 text-muted-foreground mb-3" />
                <p className="text-sm text-muted-foreground">
                  No invoices assigned to this member
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-2.5 pr-3 font-medium text-muted-foreground text-xs uppercase tracking-wide">
                        Invoice
                      </th>
                      <th className="text-left py-2.5 pr-3 font-medium text-muted-foreground text-xs uppercase tracking-wide">
                        Client
                      </th>
                      <th className="text-left py-2.5 pr-3 font-medium text-muted-foreground text-xs uppercase tracking-wide hidden sm:table-cell">
                        Event
                      </th>
                      <th className="text-left py-2.5 pr-3 font-medium text-muted-foreground text-xs uppercase tracking-wide hidden md:table-cell">
                        Date
                      </th>
                      <th className="text-left py-2.5 font-medium text-muted-foreground text-xs uppercase tracking-wide">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {assignedInvoices.map((inv, i) => {
                      const status = getPaymentStatus(inv);
                      return (
                        <tr
                          key={inv.id}
                          className="hover:bg-muted/40 cursor-pointer transition-colors"
                          onClick={() =>
                            navigate({ to: `/invoices/${inv.id}` })
                          }
                          onKeyDown={(e) =>
                            e.key === "Enter" &&
                            navigate({ to: `/invoices/${inv.id}` })
                          }
                          data-ocid={`team_member.events.item.${i + 1}`}
                        >
                          <td className="py-3 pr-3 font-mono text-xs text-primary">
                            {inv.invoiceNumber}
                          </td>
                          <td className="py-3 pr-3 font-medium truncate max-w-[120px]">
                            {inv.clientName}
                          </td>
                          <td className="py-3 pr-3 text-muted-foreground hidden sm:table-cell">
                            {inv.eventType}
                          </td>
                          <td className="py-3 pr-3 text-muted-foreground hidden md:table-cell">
                            {formatDate(inv.eventStartDate)}
                          </td>
                          <td className="py-3">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium border ${getStatusColor(status)}`}
                            >
                              {status.charAt(0).toUpperCase() + status.slice(1)}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Upcoming Schedule */}
        <Card className="border-border" data-ocid="team_member.schedule_card">
          <CardHeader className="pb-3">
            <CardTitle className="font-display text-base flex items-center gap-2">
              <CalendarDays className="w-4 h-4" />
              Upcoming Schedule
              <Badge variant="secondary" className="ml-1">
                {upcoming.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {upcoming.length === 0 ? (
              <div
                className="flex flex-col items-center justify-center py-10 text-center"
                data-ocid="team_member.schedule.empty_state"
              >
                <CalendarDays className="w-10 h-10 text-muted-foreground mb-3" />
                <p className="text-sm text-muted-foreground">
                  No upcoming events scheduled
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {upcoming.map((inv, i) => (
                  <div
                    key={inv.id}
                    className="flex items-start gap-4 p-3 rounded-xl border border-border hover:bg-muted/30 cursor-pointer transition-colors"
                    onClick={() => navigate({ to: `/invoices/${inv.id}` })}
                    onKeyDown={(e) =>
                      e.key === "Enter" &&
                      navigate({ to: `/invoices/${inv.id}` })
                    }
                    data-ocid={`team_member.schedule.item.${i + 1}`}
                  >
                    <div className="flex-shrink-0 w-12 text-center">
                      <div className="text-xs font-bold text-primary uppercase">
                        {new Date(inv.eventStartDate).toLocaleString("en-IN", {
                          month: "short",
                        })}
                      </div>
                      <div className="text-lg font-bold text-foreground leading-none">
                        {new Date(inv.eventStartDate).getDate()}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(inv.eventStartDate).getFullYear()}
                      </div>
                    </div>
                    <div className="w-px bg-primary/30 self-stretch flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-foreground truncate">
                        {inv.clientName}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {inv.eventType}
                      </p>
                      {inv.clientCity && (
                        <p className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                          <MapPin className="w-3 h-3" />
                          {inv.clientCity}
                        </p>
                      )}
                    </div>
                    <span className="text-xs font-mono text-primary flex-shrink-0">
                      {inv.invoiceNumber}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Payment History */}
        <Card
          className="border-border"
          data-ocid="team_member.payment_history_card"
        >
          <CardHeader className="pb-3">
            <CardTitle className="font-display text-base flex items-center gap-2">
              <Wallet className="w-4 h-4" />
              Payment History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const workedWithClientIds = Array.from(
                new Set(
                  workHistory
                    .map((h) => {
                      const inv = invoices.find((i) => i.id === h.invoiceId);
                      return inv?.clientId;
                    })
                    .filter(Boolean) as string[],
                ),
              );
              const allPayments: (PaymentLedgerEntry & {
                clientName: string;
              })[] = [];
              for (const clientId of workedWithClientIds) {
                const history = getClientPaymentHistory(clientId);
                const client = clients.find((c) => c.id === clientId);
                for (const entry of history) {
                  allPayments.push({
                    ...entry,
                    clientName: client?.name || "Unknown",
                  });
                }
              }
              allPayments.sort(
                (a, b) =>
                  new Date(b.date).getTime() - new Date(a.date).getTime(),
              );
              if (allPayments.length === 0) {
                return (
                  <div
                    className="flex flex-col items-center justify-center py-10 text-center"
                    data-ocid="team_member.payment_history.empty_state"
                  >
                    <Wallet className="w-10 h-10 text-muted-foreground mb-3" />
                    <p className="text-sm text-muted-foreground">
                      No payment history
                    </p>
                  </div>
                );
              }
              return (
                <div className="space-y-3">
                  {allPayments.map((p, i) => (
                    <div
                      key={p.id}
                      className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-xl border border-border hover:bg-muted/30 transition-colors"
                      data-ocid={`team_member.payment_history.item.${i + 1}`}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-sm text-foreground">
                            {formatCurrency(p.amount)}
                          </span>
                          <Badge variant="secondary" className="text-[11px]">
                            {p.mode}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {p.clientName} • {formatDate(p.date)}
                        </p>
                        {p.note && (
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {p.note}
                          </p>
                        )}
                        <p className="text-[11px] text-muted-foreground mt-0.5">
                          Balance: {formatCurrency(p.balanceAfterPayment)}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-muted-foreground hover:text-foreground"
                          onClick={() => {
                            setEditingPayment(p);
                            setPaymentDialogOpen(true);
                          }}
                          aria-label="Edit payment"
                          data-ocid={`team_member.payment_history.edit_button.${i + 1}`}
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive/60 hover:text-destructive"
                          onClick={() => handleDeletePayment(p)}
                          aria-label="Delete payment"
                          data-ocid={`team_member.payment_history.delete_button.${i + 1}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}
          </CardContent>
        </Card>
      </div>

      {/* Payment Dialog */}
      <AddPaymentDialog
        open={paymentDialogOpen}
        onClose={() => {
          setPaymentDialogOpen(false);
          setEditingPayment(null);
        }}
        onConfirm={editingPayment ? handleEditPayment : handleAddPayment}
        clients={clients.map((c) => ({ id: c.id, name: c.name }))}
        initialData={
          editingPayment
            ? {
                clientId: editingPayment.linkedClientId,
                amount: editingPayment.amount,
                mode: editingPayment.mode,
                note: editingPayment.note || "",
                date: editingPayment.date,
              }
            : undefined
        }
      />

      {/* Edit History Entry Dialog */}
      {editingEntry && (
        <EditHistoryDialog
          open={!!editingEntry}
          onClose={() => setEditingEntry(null)}
          entry={editingEntry}
          onSave={handleSaveEditEntry}
        />
      )}

      {/* Delete Entry Confirmation */}
      <AlertDialog
        open={!!deletingEntry}
        onOpenChange={(o) => !o && setDeletingEntry(null)}
      >
        <AlertDialogContent data-ocid="team_member.delete_history_dialog">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Work Entry?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the assignment and all related work history
              entries for {deletingEntry?.entry.clientName} —{" "}
              {deletingEntry?.entry.program || deletingEntry?.entry.eventName}.
              This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-ocid="team_member.delete_history_cancel_button">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              data-ocid="team_member.delete_history_confirm_button"
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={confirmDeleteEntry}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
