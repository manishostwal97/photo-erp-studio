import AppLayout from "@/components/layout/AppLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { formatCurrency } from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { Package, Service } from "@/types";
import {
  AlertTriangle,
  BoxIcon,
  Camera,
  Edit2,
  Layers,
  Package as PackageIcon,
  Plus,
  Trash2,
  X,
} from "lucide-react";
import { useState } from "react";
import { Controller, useFieldArray, useForm } from "react-hook-form";
import { toast } from "sonner";

// ─── Constants ──────────────────────────────────────────────────────────────

const CATEGORIES = [
  { value: "Cinematic", label: "Cinematic" },
  { value: "Traditional", label: "Traditional" },
  { value: "Drone", label: "Drone" },
  { value: "Album", label: "Album" },
  { value: "Editing", label: "Editing" },
  { value: "Custom", label: "Custom" },
] as const;

const CATEGORY_COLORS: Record<string, string> = {
  Cinematic: "bg-violet-100 text-violet-700 border-violet-200",
  Traditional: "bg-amber-100 text-amber-700 border-amber-200",
  Drone: "bg-purple-100 text-purple-700 border-purple-200",
  Album: "bg-yellow-100 text-yellow-700 border-yellow-200",
  Editing: "bg-cyan-100 text-cyan-700 border-cyan-200",
  Custom: "bg-muted text-muted-foreground border-border",
};

// ─── Service Form ────────────────────────────────────────────────────────────

interface ServiceFormValues {
  name: string;
  description: string;
  category: string;
  price: number;
  isCustom: boolean;
}

function defaultServiceValues(): ServiceFormValues {
  return {
    name: "",
    description: "",
    category: "Custom",
    price: 0,
    isCustom: false,
  };
}

interface ServiceModalProps {
  open: boolean;
  onClose: () => void;
  editing?: Service;
  onSaved: () => void;
}

function ServiceModal({ open, onClose, editing, onSaved }: ServiceModalProps) {
  const { addService, updateService } = useERPStore();
  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<ServiceFormValues>({
    defaultValues: editing
      ? {
          name: editing.name,
          description: editing.description ?? "",
          category: editing.category,
          price: editing.price,
          isCustom: editing.isCustom ?? false,
        }
      : defaultServiceValues(),
  });

  function onSubmit(data: ServiceFormValues) {
    if (editing) {
      updateService(editing.id, {
        name: data.name,
        description: data.description,
        category: data.category as Service["category"],
        price: Number(data.price),
        isCustom: data.isCustom,
      });
      toast.success("Service updated successfully");
    } else {
      addService({
        id: `svc-${Date.now()}`,
        name: data.name,
        description: data.description,
        category: data.category as Service["category"],
        price: Number(data.price),
        isCustom: data.isCustom,
      });
      toast.success("Service created successfully");
    }
    onSaved();
    onClose();
    reset(defaultServiceValues());
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) {
          onClose();
          reset(defaultServiceValues());
        }
      }}
    >
      <DialogContent
        className="w-[95vw] max-w-md max-h-[90vh] overflow-y-auto sm:w-full"
        data-ocid="services.dialog"
      >
        <DialogHeader>
          <DialogTitle className="font-display">
            {editing ? "Edit Service" : "Add New Service"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="svc-name">Service Name *</Label>
            <Input
              id="svc-name"
              placeholder="e.g. Wedding Photography"
              data-ocid="services.name.input"
              {...register("name", { required: "Name is required" })}
            />
            {errors.name && (
              <p
                className="text-xs text-destructive"
                data-ocid="services.name.field_error"
              >
                {errors.name.message}
              </p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="svc-desc">Description</Label>
            <Textarea
              id="svc-desc"
              placeholder="Brief description…"
              rows={2}
              data-ocid="services.description.textarea"
              {...register("description")}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Category *</Label>
            <Controller
              name="category"
              control={control}
              render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger data-ocid="services.category.select">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => (
                      <SelectItem key={c.value} value={c.value}>
                        {c.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="svc-price">Price (₹) *</Label>
            <Input
              id="svc-price"
              type="number"
              min={0}
              placeholder="0"
              data-ocid="services.base_price.input"
              {...register("price", {
                required: "Price is required",
                valueAsNumber: true,
                min: { value: 0, message: "Price must be ≥ 0" },
              })}
            />
            {errors.price && (
              <p
                className="text-xs text-destructive"
                data-ocid="services.price.field_error"
              >
                {errors.price.message}
              </p>
            )}
          </div>
          <Controller
            name="isCustom"
            control={control}
            render={({ field }) => (
              <div className="flex items-center gap-2">
                <Checkbox
                  id="svc-custom"
                  checked={field.value}
                  onCheckedChange={field.onChange}
                  data-ocid="services.is_custom.checkbox"
                />
                <Label htmlFor="svc-custom" className="cursor-pointer">
                  Custom service (created by studio)
                </Label>
              </div>
            )}
          />
          <DialogFooter className="gap-2 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              data-ocid="services.cancel_button"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-primary text-primary-foreground"
              data-ocid="services.submit_button"
            >
              {isSubmitting
                ? "Saving…"
                : editing
                  ? "Update Service"
                  : "Add Service"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Delete Confirm ───────────────────────────────────────────────────────────

function DeleteConfirm({
  open,
  itemName,
  itemType = "Service",
  onConfirm,
  onCancel,
  isDeleting,
}: {
  open: boolean;
  itemName: string;
  itemType?: string;
  onConfirm: () => void;
  onCancel: () => void;
  isDeleting: boolean;
}) {
  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) onCancel();
      }}
    >
      <DialogContent
        className="w-[95vw] max-w-sm sm:w-full"
        data-ocid="services.delete.dialog"
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display">
            <AlertTriangle className="w-5 h-5 text-destructive" />
            Delete {itemType}
          </DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">
          Are you sure you want to delete{" "}
          <span className="font-semibold text-foreground">{itemName}</span>?
          This action cannot be undone.
        </p>
        <DialogFooter className="gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            data-ocid="services.delete.cancel_button"
          >
            Cancel
          </Button>
          <Button
            type="button"
            variant="destructive"
            disabled={isDeleting}
            onClick={onConfirm}
            data-ocid="services.delete.confirm_button"
          >
            {isDeleting ? "Deleting…" : "Delete"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Package Service Row ──────────────────────────────────────────────────────

interface PackageServiceRow {
  serviceId: string;
  serviceName: string;
  category: string;
  price: number;
  includedQuantity: number;
  extraChargePerUnit: number;
  isLimited: boolean;
  unit: string;
}

interface PackageFormValues {
  name: string;
  description: string;
  basePrice: number;
  totalDays: number;
  serviceRows: PackageServiceRow[];
}

function defaultPackageValues(): PackageFormValues {
  return {
    name: "",
    description: "",
    basePrice: 0,
    totalDays: 1,
    serviceRows: [],
  };
}

function packageToFormValues(pkg: Package): PackageFormValues {
  return {
    name: pkg.name,
    description: "",
    basePrice: pkg.basePrice,
    totalDays: pkg.totalDays ?? 1,
    serviceRows: (pkg.services ?? []).map((s) => ({
      serviceId: s.id,
      serviceName: s.name,
      category: s.category,
      price: s.price,
      includedQuantity: 0,
      extraChargePerUnit: 0,
      isLimited: false,
      unit: "unit",
    })),
  };
}

interface PackageModalProps {
  open: boolean;
  onClose: () => void;
  editing?: Package;
  onSaved: () => void;
  availableServices: Service[];
}

function PackageModal({
  open,
  onClose,
  editing,
  onSaved,
  availableServices,
}: PackageModalProps) {
  const { addPackage, updatePackage } = useERPStore();
  const {
    register,
    handleSubmit,
    control,
    reset,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<PackageFormValues>({
    defaultValues: editing
      ? packageToFormValues(editing)
      : defaultPackageValues(),
  });
  const { fields, append, remove } = useFieldArray({
    control,
    name: "serviceRows",
  });
  const watchedRows = watch("serviceRows");

  function onSubmit(data: PackageFormValues) {
    const services: Service[] = data.serviceRows.map((r) => ({
      id: r.serviceId || `svc-${Date.now()}-${r.serviceName}`,
      name: r.serviceName,
      category: r.category as Service["category"],
      price: Number(r.price),
    }));
    const extraChargeRules = data.serviceRows
      .filter((r) => r.isLimited && r.extraChargePerUnit > 0)
      .map((r) => ({
        serviceName: r.serviceName,
        includedLimit: Number(r.includedQuantity),
        unit: r.unit || "unit",
        extraChargePerUnit: Number(r.extraChargePerUnit),
      }));
    const includedLimits: Record<string, number> = {};
    for (const r of data.serviceRows.filter((r) => r.isLimited)) {
      includedLimits[r.serviceName] = Number(r.includedQuantity);
    }

    if (editing) {
      updatePackage(editing.id, {
        name: data.name,
        basePrice: Number(data.basePrice),
        totalDays: Number(data.totalDays),
        services,
        extraChargeRules,
        includedLimits,
      });
      toast.success("Package updated successfully");
    } else {
      addPackage({
        id: `pkg-${Date.now()}`,
        name: data.name,
        basePrice: Number(data.basePrice),
        totalDays: Number(data.totalDays),
        services,
        extraChargeRules,
        includedLimits,
        isActive: true,
        createdAt: new Date().toISOString(),
      });
      toast.success("Package created successfully");
    }
    onSaved();
    onClose();
    reset(defaultPackageValues());
  }

  function addServiceRow() {
    append({
      serviceId: "",
      serviceName: "",
      category: "Custom",
      price: 0,
      includedQuantity: 0,
      extraChargePerUnit: 0,
      isLimited: false,
      unit: "unit",
    });
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) {
          onClose();
          reset(defaultPackageValues());
        }
      }}
    >
      <DialogContent
        className="w-[95vw] max-w-2xl max-h-[90vh] overflow-y-auto sm:w-full"
        data-ocid="packages.dialog"
      >
        <DialogHeader>
          <DialogTitle className="font-display">
            {editing ? "Edit Package" : "Add New Package"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
          <div className="space-y-1.5">
            <Label htmlFor="pkg-name">Package Name *</Label>
            <Input
              id="pkg-name"
              placeholder="e.g. Silver Wedding Package"
              data-ocid="packages.name.input"
              {...register("name", { required: "Package name is required" })}
            />
            {errors.name && (
              <p
                className="text-xs text-destructive"
                data-ocid="packages.name.field_error"
              >
                {errors.name.message}
              </p>
            )}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="pkg-price">Base Price (₹) *</Label>
              <Input
                id="pkg-price"
                type="number"
                min={0}
                step={1000}
                placeholder="40000"
                data-ocid="packages.base_price.input"
                {...register("basePrice", {
                  required: "Price is required",
                  valueAsNumber: true,
                  min: { value: 0, message: "Price must be ≥ 0" },
                })}
              />
              {errors.basePrice && (
                <p className="text-xs text-destructive">
                  {errors.basePrice.message}
                </p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pkg-days">Total Days</Label>
              <Input
                id="pkg-days"
                type="number"
                min={1}
                placeholder="1"
                data-ocid="packages.total_days.input"
                {...register("totalDays", { valueAsNumber: true, min: 1 })}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pkg-desc">Description</Label>
            <Textarea
              id="pkg-desc"
              placeholder="Describe what this package covers…"
              rows={2}
              data-ocid="packages.description.textarea"
              {...register("description")}
            />
          </div>

          {/* Services */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-semibold">Included Services</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="gap-1.5 h-8 text-xs"
                onClick={addServiceRow}
                data-ocid="packages.add_service_button"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Service
              </Button>
            </div>
            {fields.length === 0 && (
              <div className="rounded-xl border-2 border-dashed border-border bg-muted/30 py-6 text-center">
                <p className="text-sm text-muted-foreground">
                  No services added yet. Click{" "}
                  <span className="font-medium text-foreground">
                    Add Service
                  </span>{" "}
                  to include services.
                </p>
              </div>
            )}
            {fields.map((field, idx) => (
              <div
                key={field.id}
                className="rounded-xl border border-border bg-muted/20 p-3 space-y-3"
                data-ocid={`packages.service_row.${idx + 1}`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    Service {idx + 1}
                  </span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-muted-foreground hover:text-destructive"
                    onClick={() => remove(idx)}
                    data-ocid={`packages.remove_service_button.${idx + 1}`}
                  >
                    <X className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs">Service Name *</Label>
                    <Controller
                      name={`serviceRows.${idx}.serviceName`}
                      control={control}
                      rules={{ required: "Required" }}
                      render={({ field: f }) => (
                        <Select
                          value={f.value}
                          onValueChange={(val) => {
                            f.onChange(val);
                            const svc = availableServices.find(
                              (s) => s.name === val,
                            );
                            if (svc) {
                              // also set serviceId and price via setValue is not available here;
                              // just set name, user can adjust price manually
                            }
                          }}
                        >
                          <SelectTrigger
                            className="h-8 text-sm"
                            data-ocid={`packages.service_name.${idx + 1}`}
                          >
                            <SelectValue placeholder="Select service" />
                          </SelectTrigger>
                          <SelectContent>
                            {availableServices.map((s) => (
                              <SelectItem key={s.id} value={s.name}>
                                {s.name}
                              </SelectItem>
                            ))}
                            <SelectItem value="_custom_">
                              + Custom Service
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Price (₹)</Label>
                    <Input
                      type="number"
                      min={0}
                      className="h-8 text-sm"
                      placeholder="0"
                      data-ocid={`packages.service_price.${idx + 1}`}
                      {...register(`serviceRows.${idx}.price`, {
                        valueAsNumber: true,
                        min: 0,
                      })}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                  <div className="space-y-1">
                    <Label className="text-xs">Included Qty</Label>
                    <Input
                      type="number"
                      min={0}
                      className="h-8 text-sm"
                      placeholder="0"
                      disabled={!watchedRows[idx]?.isLimited}
                      data-ocid={`packages.service_qty.${idx + 1}`}
                      {...register(`serviceRows.${idx}.includedQuantity`, {
                        valueAsNumber: true,
                        min: 0,
                      })}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Extra Charge (₹/unit)</Label>
                    <Input
                      type="number"
                      min={0}
                      className="h-8 text-sm"
                      placeholder="0"
                      disabled={!watchedRows[idx]?.isLimited}
                      data-ocid={`packages.service_extra_rate.${idx + 1}`}
                      {...register(`serviceRows.${idx}.extraChargePerUnit`, {
                        valueAsNumber: true,
                        min: 0,
                      })}
                    />
                  </div>
                  <Controller
                    name={`serviceRows.${idx}.isLimited`}
                    control={control}
                    render={({ field: f }) => (
                      <div className="flex items-center gap-1.5 pb-1">
                        <Checkbox
                          id={`pkg-svc-limited-${idx}`}
                          checked={f.value}
                          onCheckedChange={f.onChange}
                          data-ocid={`packages.service_limited.${idx + 1}`}
                        />
                        <Label
                          htmlFor={`pkg-svc-limited-${idx}`}
                          className="text-xs cursor-pointer"
                        >
                          Has limit
                        </Label>
                      </div>
                    )}
                  />
                </div>
              </div>
            ))}
          </div>

          <DialogFooter className="gap-2 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              data-ocid="packages.cancel_button"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-primary text-primary-foreground"
              data-ocid="packages.submit_button"
            >
              {isSubmitting
                ? "Saving…"
                : editing
                  ? "Update Package"
                  : "Create Package"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Package Card ─────────────────────────────────────────────────────────────

function PackageCard({
  pkg,
  idx,
  onEdit,
  onDelete,
}: {
  pkg: Package;
  idx: number;
  onEdit: (pkg: Package) => void;
  onDelete: (pkg: Package) => void;
}) {
  return (
    <div
      className="rounded-2xl border border-border bg-card shadow-sm p-5 space-y-4 hover:shadow-md transition-shadow"
      data-ocid={`packages.item.${idx}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
            <BoxIcon className="w-5 h-5 text-primary" />
          </div>
          <div className="min-w-0">
            <h3 className="font-display font-semibold text-foreground text-base leading-snug">
              {pkg.name}
            </h3>
          </div>
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:text-primary"
            onClick={() => onEdit(pkg)}
            data-ocid={`packages.edit_button.${idx}`}
          >
            <Edit2 className="w-4 h-4" />
            <span className="sr-only">Edit</span>
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:text-destructive"
            onClick={() => onDelete(pkg)}
            data-ocid={`packages.delete_button.${idx}`}
          >
            <Trash2 className="w-4 h-4" />
            <span className="sr-only">Delete</span>
          </Button>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-xl font-bold font-display text-primary">
          {formatCurrency(pkg.basePrice)}
        </span>
        <Badge
          variant="outline"
          className="text-xs bg-primary/5 text-primary border-primary/20"
        >
          {(pkg.services ?? []).length} service
          {(pkg.services ?? []).length !== 1 ? "s" : ""} included
        </Badge>
        {pkg.totalDays && pkg.totalDays > 1 && (
          <Badge variant="outline" className="text-xs">
            {pkg.totalDays} days
          </Badge>
        )}
      </div>
      {(pkg.services ?? []).length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {(pkg.services ?? []).map((s) => (
            <span
              key={s.id}
              className="inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full bg-primary/8 text-primary border border-primary/20"
            >
              {s.name}
            </span>
          ))}
        </div>
      )}
      {(pkg.extraChargeRules ?? []).length > 0 && (
        <div className="pt-1 border-t border-border">
          <p className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide mb-1">
            Extra Charges
          </p>
          <div className="flex flex-wrap gap-1.5">
            {(pkg.extraChargeRules ?? []).map((r, i) => (
              <span
                key={r.serviceName || String(i)}
                className="text-[11px] px-2 py-0.5 rounded bg-muted text-muted-foreground"
              >
                {r.serviceName}: ₹{r.extraChargePerUnit}/{r.unit}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

type ActiveTab = "services" | "packages";

export default function ServicesPage() {
  const { services, packages, deleteService, deletePackage } = useERPStore();
  const [activeTab, setActiveTab] = useState<ActiveTab>("services");

  // Service state
  const [addOpen, setAddOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | undefined>();
  const [deleteTarget, setDeleteTarget] = useState<Service | undefined>();
  const [isDeleting, setIsDeleting] = useState(false);

  // Package state
  const [pkgAddOpen, setPkgAddOpen] = useState(false);
  const [editingPackage, setEditingPackage] = useState<Package | undefined>();
  const [pkgDeleteTarget, setPkgDeleteTarget] = useState<Package | undefined>();
  const [isPkgDeleting, setIsPkgDeleting] = useState(false);

  const svcList = services ?? [];
  const pkgList = packages ?? [];

  function handleDeleteService() {
    if (!deleteTarget) return;
    setIsDeleting(true);
    deleteService(deleteTarget.id);
    toast.success("Service deleted");
    setDeleteTarget(undefined);
    setIsDeleting(false);
  }

  function handleDeletePackage() {
    if (!pkgDeleteTarget) return;
    setIsPkgDeleting(true);
    deletePackage(pkgDeleteTarget.id);
    toast.success("Package deleted");
    setPkgDeleteTarget(undefined);
    setIsPkgDeleting(false);
  }

  return (
    <AppLayout>
      <div className="space-y-6" data-ocid="services.page">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-display font-bold text-foreground">
              {activeTab === "services" ? (
                <>
                  Services
                  {svcList.length > 0 && (
                    <span className="ml-2 text-base font-normal text-muted-foreground">
                      ({svcList.length})
                    </span>
                  )}
                </>
              ) : (
                <>
                  Packages
                  {pkgList.length > 0 && (
                    <span className="ml-2 text-base font-normal text-muted-foreground">
                      ({pkgList.length})
                    </span>
                  )}
                </>
              )}
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              {activeTab === "services"
                ? "Manage your photography studio service catalog"
                : "Create bundles with included limits and auto extra charges"}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {activeTab === "services" && (
              <Button
                type="button"
                className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => setAddOpen(true)}
                data-ocid="services.add_button"
              >
                <Plus className="w-4 h-4" />
                Add Service
              </Button>
            )}
            {activeTab === "packages" && (
              <Button
                type="button"
                className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => setPkgAddOpen(true)}
                data-ocid="packages.add_button"
              >
                <Plus className="w-4 h-4" />
                Add Package
              </Button>
            )}
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex gap-1 p-1 rounded-xl bg-muted/40 border border-border w-fit">
          <button
            type="button"
            onClick={() => setActiveTab("services")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === "services"
                ? "bg-card text-foreground shadow-sm border border-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
            data-ocid="services.tab"
          >
            <PackageIcon className="w-4 h-4" />
            Services
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("packages")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === "packages"
                ? "bg-card text-foreground shadow-sm border border-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
            data-ocid="packages.tab"
          >
            <Layers className="w-4 h-4" />
            Packages
          </button>
        </div>

        {/* ═══ SERVICES TAB ═══════════════════════════════════════════════════ */}
        {activeTab === "services" &&
          (svcList.length === 0 ? (
            <div
              className="flex flex-col items-center justify-center py-20 text-center rounded-2xl border-2 border-dashed border-border bg-muted/30"
              data-ocid="services.empty_state"
            >
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Camera className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-display font-semibold text-foreground mb-2">
                No services yet
              </h3>
              <p className="text-sm text-muted-foreground max-w-xs mb-6">
                Add custom services to build your photography catalog.
              </p>
              <Button
                type="button"
                className="bg-primary text-primary-foreground"
                onClick={() => setAddOpen(true)}
                data-ocid="services.empty.add_button"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Service
              </Button>
            </div>
          ) : (
            <div className="rounded-2xl border border-border bg-card overflow-hidden shadow-sm">
              {/* Desktop table */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/40">
                      <th className="text-left font-semibold text-muted-foreground px-5 py-3">
                        Name
                      </th>
                      <th className="text-left font-semibold text-muted-foreground px-4 py-3">
                        Category
                      </th>
                      <th className="text-right font-semibold text-muted-foreground px-4 py-3">
                        Price
                      </th>
                      <th className="text-right font-semibold text-muted-foreground px-5 py-3">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {svcList.map((svc, idx) => (
                      <tr
                        key={svc.id}
                        className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors"
                        data-ocid={`services.item.${idx + 1}`}
                      >
                        <td className="px-5 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                              <PackageIcon className="w-4 h-4 text-primary" />
                            </div>
                            <div>
                              <p className="font-semibold text-foreground">
                                {svc.name}
                              </p>
                              {svc.description && (
                                <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
                                  {svc.description}
                                </p>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <Badge
                            variant="outline"
                            className={`text-xs font-medium ${CATEGORY_COLORS[svc.category] ?? CATEGORY_COLORS.Custom}`}
                          >
                            {svc.category}
                          </Badge>
                        </td>
                        <td className="px-4 py-4 text-right font-semibold text-foreground">
                          {formatCurrency(svc.price)}
                        </td>
                        <td className="px-5 py-4">
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground hover:text-primary"
                              onClick={() => setEditingService(svc)}
                              data-ocid={`services.edit_button.${idx + 1}`}
                            >
                              <Edit2 className="w-4 h-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground hover:text-destructive"
                              onClick={() => setDeleteTarget(svc)}
                              data-ocid={`services.delete_button.${idx + 1}`}
                            >
                              <Trash2 className="w-4 h-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {/* Mobile card list */}
              <div className="md:hidden divide-y divide-border">
                {svcList.map((svc, idx) => (
                  <div
                    key={svc.id}
                    className="p-4 space-y-3"
                    data-ocid={`services.item.${idx + 1}`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
                          <PackageIcon className="w-4 h-4 text-primary" />
                        </div>
                        <div>
                          <p className="font-semibold text-foreground">
                            {svc.name}
                          </p>
                          {svc.description && (
                            <p className="text-xs text-muted-foreground line-clamp-1">
                              {svc.description}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-primary"
                          onClick={() => setEditingService(svc)}
                          data-ocid={`services.mobile.edit_button.${idx + 1}`}
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          onClick={() => setDeleteTarget(svc)}
                          data-ocid={`services.mobile.delete_button.${idx + 1}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 items-center">
                      <Badge
                        variant="outline"
                        className={`text-xs ${CATEGORY_COLORS[svc.category] ?? CATEGORY_COLORS.Custom}`}
                      >
                        {svc.category}
                      </Badge>
                      <span className="text-sm font-semibold text-foreground ml-auto">
                        {formatCurrency(svc.price)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}

        {/* ═══ PACKAGES TAB ════════════════════════════════════════════════════ */}
        {activeTab === "packages" &&
          (pkgList.length === 0 ? (
            <div
              className="flex flex-col items-center justify-center py-20 text-center rounded-2xl border-2 border-dashed border-border bg-muted/30"
              data-ocid="packages.empty_state"
            >
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Layers className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-display font-semibold text-foreground mb-2">
                No packages yet
              </h3>
              <p className="text-sm text-muted-foreground max-w-xs mb-6">
                Create packages to bundle services with included limits. Extra
                charges are auto-calculated when clients exceed limits.
              </p>
              <Button
                type="button"
                className="bg-primary text-primary-foreground"
                onClick={() => setPkgAddOpen(true)}
                data-ocid="packages.empty.add_button"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Package
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {pkgList.map((pkg, idx) => (
                <PackageCard
                  key={pkg.id}
                  pkg={pkg}
                  idx={idx + 1}
                  onEdit={(p) => setEditingPackage(p)}
                  onDelete={(p) => setPkgDeleteTarget(p)}
                />
              ))}
            </div>
          ))}
      </div>

      {/* Service Modals */}
      <ServiceModal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onSaved={() => {}}
      />
      {editingService && (
        <ServiceModal
          open={!!editingService}
          onClose={() => setEditingService(undefined)}
          editing={editingService}
          onSaved={() => {}}
        />
      )}
      <DeleteConfirm
        open={!!deleteTarget}
        itemName={deleteTarget?.name ?? ""}
        itemType="Service"
        onConfirm={handleDeleteService}
        onCancel={() => setDeleteTarget(undefined)}
        isDeleting={isDeleting}
      />

      {/* Package Modals */}
      <PackageModal
        open={pkgAddOpen}
        onClose={() => setPkgAddOpen(false)}
        onSaved={() => {}}
        availableServices={svcList}
      />
      {editingPackage && (
        <PackageModal
          open={!!editingPackage}
          onClose={() => setEditingPackage(undefined)}
          editing={editingPackage}
          onSaved={() => {}}
          availableServices={svcList}
        />
      )}
      <DeleteConfirm
        open={!!pkgDeleteTarget}
        itemName={pkgDeleteTarget?.name ?? ""}
        itemType="Package"
        onConfirm={handleDeletePackage}
        onCancel={() => setPkgDeleteTarget(undefined)}
        isDeleting={isPkgDeleting}
      />
    </AppLayout>
  );
}
