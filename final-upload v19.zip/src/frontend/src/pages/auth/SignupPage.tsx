import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { type UserRole, useAuthStore } from "@/stores/authStore";
import { useNavigate } from "@tanstack/react-router";
import { Camera, Eye, EyeOff } from "lucide-react";
import { useState } from "react";
import { Controller, useForm } from "react-hook-form";

interface SignupFormValues {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  role: UserRole;
  terms: boolean;
}

export default function SignupPage() {
  const navigate = useNavigate();
  const { signUpWithEmail } = useAuth();
  const error = useAuthStore((s) => s.error);
  const setError = useAuthStore((s) => s.setError);

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    watch,
    control,
    formState: { errors },
  } = useForm<SignupFormValues>({
    defaultValues: { role: "staff", terms: false },
  });

  const passwordValue = watch("password");

  const onSubmit = async (data: SignupFormValues) => {
    setError(null);
    setIsSubmitting(true);
    const ok = await signUpWithEmail(
      data.email,
      data.password,
      data.name,
      data.role,
    );
    setIsSubmitting(false);
    if (ok) navigate({ to: "/dashboard" });
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center bg-background px-4 py-10"
      data-ocid="signup.page"
    >
      <div className="w-full max-w-md">
        {/* Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4">
            <Camera className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-display font-bold text-foreground">
            Create Account
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Join PhotoStudio ERP
          </p>
        </div>

        <Card className="shadow-lg border-border">
          <CardContent className="px-6 py-6 space-y-4">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              {/* Full Name */}
              <div className="space-y-1.5">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  placeholder="Jane Smith"
                  data-ocid="signup.name_input"
                  {...register("name", { required: "Full name is required." })}
                />
                {errors.name && (
                  <p
                    className="text-xs text-destructive"
                    data-ocid="signup.name_field_error"
                  >
                    {errors.name.message}
                  </p>
                )}
              </div>

              {/* Email */}
              <div className="space-y-1.5">
                <Label htmlFor="signup-email">Email address</Label>
                <Input
                  id="signup-email"
                  type="email"
                  placeholder="you@studio.com"
                  data-ocid="signup.email_input"
                  {...register("email", {
                    required: "Email is required.",
                    pattern: {
                      value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                      message: "Enter a valid email.",
                    },
                  })}
                />
                {errors.email && (
                  <p
                    className="text-xs text-destructive"
                    data-ocid="signup.email_field_error"
                  >
                    {errors.email.message}
                  </p>
                )}
              </div>

              {/* Password */}
              <div className="space-y-1.5">
                <Label htmlFor="signup-password">Password</Label>
                <div className="relative">
                  <Input
                    id="signup-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    className="pr-10"
                    data-ocid="signup.password_input"
                    {...register("password", {
                      required: "Password is required.",
                      minLength: { value: 6, message: "Minimum 6 characters." },
                    })}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    onClick={() => setShowPassword((v) => !v)}
                    aria-label={
                      showPassword ? "Hide password" : "Show password"
                    }
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
                {errors.password && (
                  <p
                    className="text-xs text-destructive"
                    data-ocid="signup.password_field_error"
                  >
                    {errors.password.message}
                  </p>
                )}
              </div>

              {/* Confirm Password */}
              <div className="space-y-1.5">
                <Label htmlFor="confirm-password">Confirm Password</Label>
                <div className="relative">
                  <Input
                    id="confirm-password"
                    type={showConfirm ? "text" : "password"}
                    placeholder="••••••••"
                    className="pr-10"
                    data-ocid="signup.confirm_password_input"
                    {...register("confirmPassword", {
                      required: "Please confirm your password.",
                      validate: (v) =>
                        v === passwordValue || "Passwords do not match.",
                    })}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    onClick={() => setShowConfirm((v) => !v)}
                    aria-label={
                      showConfirm
                        ? "Hide confirm password"
                        : "Show confirm password"
                    }
                  >
                    {showConfirm ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
                {errors.confirmPassword && (
                  <p
                    className="text-xs text-destructive"
                    data-ocid="signup.confirm_field_error"
                  >
                    {errors.confirmPassword.message}
                  </p>
                )}
              </div>

              {/* Role */}
              <div className="space-y-1.5">
                <Label htmlFor="role-select">Role</Label>
                <Controller
                  control={control}
                  name="role"
                  rules={{ required: "Please select a role." }}
                  render={({ field }) => (
                    <Select
                      value={field.value}
                      onValueChange={(v) => field.onChange(v as UserRole)}
                    >
                      <SelectTrigger
                        id="role-select"
                        data-ocid="signup.role_select"
                      >
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="team_member">Team Member</SelectItem>
                        <SelectItem value="staff">Staff</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                />
                {errors.role && (
                  <p className="text-xs text-destructive">
                    {errors.role.message}
                  </p>
                )}
              </div>

              {/* Terms */}
              <div className="flex items-start gap-2.5">
                <Controller
                  control={control}
                  name="terms"
                  rules={{ required: "You must accept the terms." }}
                  render={({ field }) => (
                    <Checkbox
                      id="terms"
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      className="mt-0.5"
                      data-ocid="signup.terms_checkbox"
                    />
                  )}
                />
                <Label
                  htmlFor="terms"
                  className="text-sm text-muted-foreground leading-relaxed cursor-pointer"
                >
                  I agree to the terms and conditions
                </Label>
              </div>
              {errors.terms && (
                <p className="text-xs text-destructive">
                  {errors.terms.message}
                </p>
              )}

              {/* Server error */}
              {error && (
                <div
                  className="rounded-lg bg-destructive/10 border border-destructive/20 px-4 py-3 text-sm text-destructive"
                  data-ocid="signup.error_state"
                >
                  {error}
                </div>
              )}

              <Button
                type="submit"
                className="w-full"
                disabled={isSubmitting}
                data-ocid="signup.submit_button"
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 rounded-full border-2 border-primary-foreground border-t-transparent animate-spin" />
                    Creating account…
                  </span>
                ) : (
                  "Create Account"
                )}
              </Button>
            </form>

            <p className="text-center text-sm text-muted-foreground">
              Already have an account?{" "}
              <button
                type="button"
                onClick={() => navigate({ to: "/login" })}
                className="text-primary font-medium hover:underline"
                data-ocid="signup.login_link"
              >
                Sign In
              </button>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
