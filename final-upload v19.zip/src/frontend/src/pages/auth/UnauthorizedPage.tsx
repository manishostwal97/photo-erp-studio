import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "@tanstack/react-router";
import { ShieldOff } from "lucide-react";

export default function UnauthorizedPage() {
  const navigate = useNavigate();
  const { logout } = useAuth();

  const handleLogout = async () => {
    await logout();
    navigate({ to: "/login" });
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center bg-background px-4"
      data-ocid="unauthorized.page"
    >
      <div className="text-center max-w-sm">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-destructive/10 mb-6">
          <ShieldOff className="w-10 h-10 text-destructive" />
        </div>
        <h1 className="text-3xl font-display font-bold text-foreground mb-3">
          Access Denied
        </h1>
        <p className="text-muted-foreground mb-8">
          You don't have permission to view this page. Contact your
          administrator if you believe this is a mistake.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button
            type="button"
            onClick={() => navigate({ to: "/dashboard" })}
            data-ocid="unauthorized.dashboard_button"
          >
            Go to Dashboard
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={handleLogout}
            data-ocid="unauthorized.signout_button"
          >
            Sign Out
          </Button>
        </div>
      </div>
    </div>
  );
}
