import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useStudioStore } from "@/stores/useStudioStore";
import { useNavigate } from "@tanstack/react-router";
import {
  Building2,
  Camera,
  CheckCircle,
  CreditCard,
  ImagePlus,
  Loader2,
  MapPin,
  PenLine,
  Phone,
  Upload,
} from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";

const STEPS = [
  { id: 1, label: "Studio", icon: Building2 },
  { id: 2, label: "Contact", icon: Phone },
  { id: 3, label: "Finance", icon: CreditCard },
  { id: 4, label: "Branding", icon: ImagePlus },
];

interface FormData {
  studioName: string;
  ownerName: string;
  mobile: string;
  email: string;
  address: string;
  city: string;
  upiId: string;
  gstNumber: string;
  gstPercentage: number;
  invoicePrefix: string;
  invoiceStartNumber: number;
  logoUrl: string;
  signatureUrl: string;
}

const INITIAL: FormData = {
  studioName: "",
  ownerName: "",
  mobile: "",
  email: "",
  address: "",
  city: "",
  upiId: "",
  gstNumber: "",
  gstPercentage: 18,
  invoicePrefix: "INV",
  invoiceStartNumber: 1001,
  logoUrl: "",
  signatureUrl: "",
};

export default function SetupPage() {
  const navigate = useNavigate();
  const updateStudioProfile = useStudioStore((s) => s.updateStudioProfile);
  const studioProfile = useStudioStore((s) => s.studioProfile);
  const isUpdating = studioProfile !== null;

  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);
  const [logoUploading, setLogoUploading] = useState(false);
  const [signUploading, setSignUploading] = useState(false);
  const [logoPreview, setLogoPreview] = useState<string>("");
  const [signPreview, setSignPreview] = useState<string>("");
  const logoInputRef = useRef<HTMLInputElement>(null);
  const signInputRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState<FormData>(
    studioProfile
      ? {
          studioName: studioProfile.name,
          ownerName: studioProfile.ownerName,
          mobile: studioProfile.phone,
          email: studioProfile.email ?? "",
          address: studioProfile.address ?? "",
          city: studioProfile.city ?? "",
          upiId: studioProfile.upiId ?? "",
          gstNumber: studioProfile.gstNumber ?? "",
          gstPercentage: studioProfile.gstPercent ?? 18,
          invoicePrefix: "INV",
          invoiceStartNumber: 1001,
          logoUrl: studioProfile.logo ?? "",
          signatureUrl: studioProfile.signature ?? "",
        }
      : INITIAL,
  );

  const setField = (name: keyof FormData, value: string | number) =>
    setForm((prev) => ({ ...prev, [name]: value }));

  // ── File upload helpers ──

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLogoUploading(true);
    try {
      const previewUrl = URL.createObjectURL(file);
      setLogoPreview(previewUrl);
      const reader = new FileReader();
      reader.onload = (ev) => {
        const dataUrl = ev.target?.result as string;
        setField("logoUrl", dataUrl);
        toast.success("Logo uploaded!");
        setLogoUploading(false);
      };
      reader.onerror = () => {
        toast.error("Logo upload failed");
        setLogoUploading(false);
      };
      reader.readAsDataURL(file);
    } catch {
      toast.error("Logo upload failed");
      setLogoUploading(false);
    }
  };

  const handleSignatureUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSignUploading(true);
    try {
      const previewUrl = URL.createObjectURL(file);
      setSignPreview(previewUrl);
      const reader = new FileReader();
      reader.onload = (ev) => {
        const dataUrl = ev.target?.result as string;
        setField("signatureUrl", dataUrl);
        toast.success("Signature uploaded!");
        setSignUploading(false);
      };
      reader.onerror = () => {
        toast.error("Signature upload failed");
        setSignUploading(false);
      };
      reader.readAsDataURL(file);
    } catch {
      toast.error("Signature upload failed");
      setSignUploading(false);
    }
  };

  // ── Validation per step ──

  const validateStep = (s: number): boolean => {
    if (s === 1) {
      if (!form.studioName.trim()) {
        toast.error("Studio name is required");
        return false;
      }
      if (!form.ownerName.trim()) {
        toast.error("Owner name is required");
        return false;
      }
    }
    if (s === 2) {
      if (!form.mobile.trim()) {
        toast.error("Mobile number is required");
        return false;
      }
      if (!/^[\d\s+\-().]{8,15}$/.test(form.mobile)) {
        toast.error("Please enter a valid mobile number");
        return false;
      }
    }
    return true;
  };

  const goNext = () => {
    if (!validateStep(step)) return;
    setStep((s) => Math.min(s + 1, 4));
  };

  const goBack = () => setStep((s) => Math.max(s - 1, 1));

  // ── Submit ──

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateStep(step)) return;
    setSaving(true);
    try {
      updateStudioProfile({
        name: form.studioName.trim(),
        ownerName: form.ownerName.trim(),
        phone: form.mobile.trim(),
        email: form.email.trim(),
        address: form.address.trim(),
        city: form.city.trim(),
        upiId: form.upiId.trim(),
        gstNumber: form.gstNumber.trim(),
        gstEnabled: !!form.gstNumber.trim(),
        gstPercent: Number(form.gstPercentage),
        logo: form.logoUrl,
        signature: form.signatureUrl,
      });
      toast.success(isUpdating ? "Studio updated!" : "Studio setup complete!");
      navigate({ to: "/dashboard" });
    } catch {
      toast.error("Setup failed. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      id="setup-page"
      className="min-h-screen flex flex-col"
      style={{ background: "#FFFFFF" }}
    >
      {/* ── Top header ── */}
      <header
        className="flex items-center gap-3 px-6 py-4 border-b"
        style={{ borderColor: "#f3f4f6" }}
      >
        <div
          className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: "#DC2626" }}
        >
          <Camera className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p
            className="font-display font-bold text-sm truncate"
            style={{ color: "#111827" }}
          >
            {isUpdating ? "Update Your Studio" : "Studio Setup"}
          </p>
          <p className="text-xs" style={{ color: "#6b7280" }}>
            Step {step} of 4
          </p>
        </div>
        {/* Step progress bar */}
        <div className="hidden sm:flex items-center gap-1">
          {STEPS.map((s) => (
            <div key={s.id} className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => step > s.id && setStep(s.id)}
                className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-smooth"
                style={{
                  background: step >= s.id ? "#DC2626" : "#f3f4f6",
                  color: step >= s.id ? "white" : "#9ca3af",
                  cursor: step > s.id ? "pointer" : "default",
                }}
                data-ocid={`setup.step_${s.id}.tab`}
              >
                {step > s.id ? <CheckCircle className="w-3.5 h-3.5" /> : s.id}
              </button>
              {s.id < 4 && (
                <div
                  className="w-6 h-0.5 rounded"
                  style={{ background: step > s.id ? "#DC2626" : "#e5e7eb" }}
                />
              )}
            </div>
          ))}
        </div>
      </header>

      {/* ── Main content ── */}
      <div className="flex-1 flex items-start justify-center p-4 md:p-8">
        <div className="w-full max-w-xl">
          {/* Step label */}
          <div className="mb-6">
            {(() => {
              const current = STEPS.find((s) => s.id === step)!;
              const Icon = current.icon;
              return (
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: "#fef2f2" }}
                  >
                    <Icon className="w-5 h-5" style={{ color: "#DC2626" }} />
                  </div>
                  <div>
                    <h2
                      className="font-display font-bold text-lg"
                      style={{ color: "#111827" }}
                    >
                      {step === 1 && "Studio Information"}
                      {step === 2 && "Contact Details"}
                      {step === 3 && "Financial Settings"}
                      {step === 4 && "Branding"}
                    </h2>
                    <p className="text-sm" style={{ color: "#6b7280" }}>
                      {step === 1 &&
                        "Basic details about your photography studio"}
                      {step === 2 && "How clients can reach you"}
                      {step === 3 && "Payment and billing configuration"}
                      {step === 4 &&
                        "Upload your logo and signature for invoices"}
                    </p>
                  </div>
                </div>
              );
            })()}
          </div>

          <form onSubmit={handleSubmit}>
            <div
              className="rounded-2xl p-6 space-y-5"
              style={{
                background: "#FFFFFF",
                border: "1px solid #e5e7eb",
                boxShadow: "0 4px 16px rgba(0,0,0,0.06)",
              }}
            >
              {/* ── STEP 1: Studio Info ── */}
              {step === 1 && (
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="studioName">
                      Studio Name <span style={{ color: "#DC2626" }}>*</span>
                    </Label>
                    <Input
                      id="studioName"
                      placeholder="Aura Photography Studio"
                      value={form.studioName}
                      onChange={(e) => setField("studioName", e.target.value)}
                      required
                      data-ocid="setup.studio_name.input"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="ownerName">
                      Owner Name <span style={{ color: "#DC2626" }}>*</span>
                    </Label>
                    <Input
                      id="ownerName"
                      placeholder="Sarah Johnson"
                      value={form.ownerName}
                      onChange={(e) => setField("ownerName", e.target.value)}
                      required
                      data-ocid="setup.owner_name.input"
                    />
                  </div>
                </div>
              )}

              {/* ── STEP 2: Contact ── */}
              {step === 2 && (
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="mobile">
                      Mobile Number <span style={{ color: "#DC2626" }}>*</span>
                    </Label>
                    <Input
                      id="mobile"
                      placeholder="+91 98765 43210"
                      value={form.mobile}
                      onChange={(e) => setField("mobile", e.target.value)}
                      required
                      data-ocid="setup.mobile.input"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="studio@example.com"
                      value={form.email}
                      onChange={(e) => setField("email", e.target.value)}
                      data-ocid="setup.email.input"
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="city">
                        <MapPin
                          className="inline w-3.5 h-3.5 mr-1"
                          style={{ color: "#DC2626" }}
                        />
                        City
                      </Label>
                      <Input
                        id="city"
                        placeholder="Mumbai"
                        value={form.city}
                        onChange={(e) => setField("city", e.target.value)}
                        data-ocid="setup.city.input"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="address">Studio Address</Label>
                    <Textarea
                      id="address"
                      placeholder="123 Studio Lane, Mumbai, Maharashtra 400001"
                      value={form.address}
                      onChange={(e) => setField("address", e.target.value)}
                      rows={3}
                      data-ocid="setup.address.input"
                    />
                  </div>
                </div>
              )}

              {/* ── STEP 3: Financial ── */}
              {step === 3 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="upiId">UPI ID</Label>
                      <Input
                        id="upiId"
                        placeholder="studio@upi"
                        value={form.upiId}
                        onChange={(e) => setField("upiId", e.target.value)}
                        data-ocid="setup.upi_id.input"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="gstNumber">GST Number</Label>
                      <Input
                        id="gstNumber"
                        placeholder="22AAAAA0000A1Z5"
                        value={form.gstNumber}
                        onChange={(e) => setField("gstNumber", e.target.value)}
                        data-ocid="setup.gst_number.input"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="gstPercentage">GST %</Label>
                      <Input
                        id="gstPercentage"
                        type="number"
                        min={0}
                        max={28}
                        placeholder="18"
                        value={form.gstPercentage}
                        onChange={(e) =>
                          setField("gstPercentage", Number(e.target.value))
                        }
                        data-ocid="setup.gst_percentage.input"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="invoicePrefix">Invoice Prefix</Label>
                      <Input
                        id="invoicePrefix"
                        placeholder="INV"
                        value={form.invoicePrefix}
                        onChange={(e) =>
                          setField("invoicePrefix", e.target.value)
                        }
                        data-ocid="setup.invoice_prefix.input"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="invoiceStartNumber">
                        Invoice Start No.
                      </Label>
                      <Input
                        id="invoiceStartNumber"
                        type="number"
                        placeholder="1001"
                        value={form.invoiceStartNumber}
                        onChange={(e) =>
                          setField("invoiceStartNumber", Number(e.target.value))
                        }
                        data-ocid="setup.invoice_start_number.input"
                      />
                    </div>
                  </div>

                  {/* Preview badge */}
                  <div
                    className="flex items-center gap-2 p-3 rounded-xl"
                    style={{
                      background: "#fef2f2",
                      border: "1px solid #fecaca",
                    }}
                  >
                    <CreditCard
                      className="w-4 h-4 flex-shrink-0"
                      style={{ color: "#DC2626" }}
                    />
                    <p className="text-xs" style={{ color: "#374151" }}>
                      First invoice will be:{" "}
                      <strong>
                        {form.invoicePrefix}-
                        {String(form.invoiceStartNumber).padStart(4, "0")}
                      </strong>
                    </p>
                  </div>
                </div>
              )}

              {/* ── STEP 4: Branding ── */}
              {step === 4 && (
                <div className="space-y-6">
                  {/* Logo upload */}
                  <div className="space-y-3">
                    <Label>Studio Logo</Label>
                    <div className="flex items-center gap-4">
                      <div
                        className="w-20 h-20 rounded-2xl flex items-center justify-center flex-shrink-0 overflow-hidden"
                        style={{
                          background:
                            logoPreview || form.logoUrl
                              ? "transparent"
                              : "#fef2f2",
                          border: "2px dashed #fecaca",
                        }}
                      >
                        {logoPreview || form.logoUrl ? (
                          <img
                            src={logoPreview || form.logoUrl}
                            alt="Studio logo"
                            className="w-full h-full object-cover rounded-2xl"
                          />
                        ) : (
                          <Camera
                            className="w-8 h-8"
                            style={{ color: "#fca5a5" }}
                          />
                        )}
                      </div>
                      <div className="flex-1">
                        <input
                          ref={logoInputRef}
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleLogoUpload}
                          data-ocid="setup.logo.upload_button"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          className="w-full gap-2"
                          onClick={() => logoInputRef.current?.click()}
                          disabled={logoUploading}
                          data-ocid="setup.logo_upload.button"
                        >
                          {logoUploading ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Upload className="w-4 h-4" />
                          )}
                          {logoUploading ? "Uploading..." : "Upload Logo"}
                        </Button>
                        <p
                          className="text-xs mt-1.5"
                          style={{ color: "#9ca3af" }}
                        >
                          PNG, JPG, SVG — recommended 200×200px
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Signature upload */}
                  <div className="space-y-3">
                    <Label>Signature</Label>
                    <div
                      className="w-full h-24 rounded-xl flex items-center justify-center overflow-hidden"
                      style={{
                        background:
                          signPreview || form.signatureUrl
                            ? "transparent"
                            : "#f9fafb",
                        border: "2px dashed #e5e7eb",
                      }}
                    >
                      {signPreview || form.signatureUrl ? (
                        <img
                          src={signPreview || form.signatureUrl}
                          alt="Signature"
                          className="h-full object-contain"
                        />
                      ) : (
                        <div className="flex flex-col items-center gap-1">
                          <PenLine
                            className="w-6 h-6"
                            style={{ color: "#d1d5db" }}
                          />
                          <p className="text-xs" style={{ color: "#9ca3af" }}>
                            No signature uploaded
                          </p>
                        </div>
                      )}
                    </div>
                    <input
                      ref={signInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleSignatureUpload}
                      data-ocid="setup.signature.upload_button"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full gap-2"
                      onClick={() => signInputRef.current?.click()}
                      disabled={signUploading}
                      data-ocid="setup.signature_upload.button"
                    >
                      {signUploading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <PenLine className="w-4 h-4" />
                      )}
                      {signUploading ? "Uploading..." : "Upload Signature"}
                    </Button>
                    <p className="text-xs" style={{ color: "#9ca3af" }}>
                      PNG with transparent background recommended
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* ── Navigation buttons ── */}
            <div className="flex gap-3 mt-6">
              {step > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1 h-11"
                  onClick={goBack}
                  disabled={saving}
                  data-ocid="setup.back_button"
                >
                  Back
                </Button>
              )}
              {step < 4 ? (
                <Button
                  type="button"
                  className="flex-1 h-11 font-semibold"
                  style={{ background: "#DC2626", color: "white" }}
                  onClick={goNext}
                  data-ocid="setup.next_button"
                >
                  Next: {STEPS[step].label}
                </Button>
              ) : (
                <Button
                  type="submit"
                  className="flex-1 h-11 font-semibold gap-2"
                  style={{ background: "#DC2626", color: "white" }}
                  disabled={saving}
                  data-ocid="setup.submit_button"
                >
                  {saving ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Saving...
                    </>
                  ) : isUpdating ? (
                    "Update Studio"
                  ) : (
                    "Complete Setup"
                  )}
                </Button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
