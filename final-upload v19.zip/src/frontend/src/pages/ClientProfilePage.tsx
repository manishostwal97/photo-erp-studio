import AddPaymentDialog from "@/components/client/AddPaymentDialog";
import AddRentalDialog from "@/components/client/AddRentalDialog";
import ClientPaymentTab from "@/components/client/ClientPaymentTab";
import ClientProgramsTab from "@/components/client/ClientProgramsTab";
import ClientRentalsTab from "@/components/client/ClientRentalsTab";
import ClientTeamTab from "@/components/client/ClientTeamTab";
import AppLayout from "@/components/layout/AppLayout";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  computeInvoiceBalance,
  formatCurrency,
  formatDate,
  generateWhatsAppLink,
  getDeliveryStageLabel,
  getDeliveryStageProgress,
  getInitials,
  getPaymentStatus,
  getStatusColor,
} from "@/lib/utils";
import { cn } from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { PaymentLedgerEntry } from "@/types";
import type { Client, Expense, Invoice } from "@/types";
import { useNavigate, useParams } from "@tanstack/react-router";
import {
  AlertTriangle,
  ArrowLeft,
  Building2,
  Calendar,
  Camera,
  CheckCircle2,
  Clock,
  CreditCard,
  Edit2,
  ExternalLink,
  FileText,
  HardHat,
  Home,
  ListOrdered,
  Loader2,
  Mail,
  MapPin,
  MessageCircle,
  Package,
  Phone,
  Plus,
  StickyNote,
  Trash2,
  TrendingDown,
  Truck,
  User,
  Users,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

// ---------- Stat Card ----------

function StatCard({
  label,
  value,
  icon: Icon,
  highlight,
}: {
  label: string;
  value: string;
  icon: React.ElementType;
  highlight?: boolean;
}) {
  return (
    <Card
      className={`border ${highlight ? "border-primary/30 bg-primary/5" : "border-border"}`}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-muted-foreground font-medium">
            {label}
          </span>
          <Icon
            className={`w-4 h-4 ${highlight ? "text-primary" : "text-muted-foreground"}`}
          />
        </div>
        <p
          className={`font-display text-lg sm:text-xl font-bold whitespace-nowrap overflow-hidden text-ellipsis ${highlight ? "text-primary" : "text-foreground"}`}
        >
          {value}
        </p>
      </CardContent>
    </Card>
  );
}

// ---------- Invoice Row ----------

function InvoiceRow({ invoice, index }: { invoice: Invoice; index: number }) {
  const navigate = useNavigate();
  const balance = computeInvoiceBalance(invoice);
  const status = getPaymentStatus(invoice);

  return (
    <button
      type="button"
      className="w-full flex items-center gap-3 p-3 rounded-xl border border-border bg-card hover:border-primary/30 hover:shadow-sm transition-all text-left group"
      onClick={() => navigate({ to: `/invoices/${invoice.id}` })}
      data-ocid={`client.invoice.${index}`}
    >
      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
        <FileText className="w-4 h-4 text-primary" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-sm text-foreground">
            {invoice.invoiceNumber}
          </span>
          <span className="text-xs text-muted-foreground truncate">
            {invoice.eventType}
          </span>
        </div>
        <div className="text-xs text-muted-foreground mt-0.5">
          {formatDate(invoice.eventStartDate)}
        </div>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <div className="text-right hidden sm:block">
          <p className="text-sm font-semibold text-foreground">
            {formatCurrency(invoice.dealAmount)}
          </p>
          {balance > 0 && (
            <p className="text-xs text-destructive font-medium">
              {formatCurrency(balance)} due
            </p>
          )}
        </div>
        <Badge className={cn("text-xs border", getStatusColor(status))}>
          {status}
        </Badge>
        <ExternalLink className="w-3.5 h-3.5 text-muted-foreground group-hover:text-primary transition-colors" />
      </div>
    </button>
  );
}

// ---------- Payment Row ----------

interface PaymentRowData {
  id: string;
  date: string;
  amount: number;
  mode: string;
  invoiceNumber: string;
  notes?: string;
}

// ---------- Delivery Card ----------

function DeliveryCard({
  invoice,
  index,
  deliveryStage,
}: { invoice: Invoice; index: number; deliveryStage?: string }) {
  const stage = deliveryStage ?? "RAW_BACKUP";
  const progress = getDeliveryStageProgress(stage);
  const label = getDeliveryStageLabel(stage);

  return (
    <Card
      className="border border-border"
      data-ocid={`client.delivery.${index}`}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="font-semibold text-sm text-foreground">
              {invoice.invoiceNumber}
            </p>
            <p className="text-xs text-muted-foreground">{invoice.eventType}</p>
          </div>
          <Badge
            className={cn(
              "text-xs border",
              progress === 100
                ? "bg-green-100 text-green-700 border-green-200"
                : "bg-blue-100 text-blue-700 border-blue-200",
            )}
          >
            {label}
          </Badge>
        </div>
        <Progress value={progress} className="h-2" />
        <p className="text-xs text-muted-foreground mt-2">
          {progress}% complete
        </p>
      </CardContent>
    </Card>
  );
}

// ---------- Client Form Values ----------

interface ClientFormValues {
  name: string;
  phone: string;
  whatsapp: string;
  eventVenueName: string;
  eventVenueAddress: string;
  email: string;
  city: string;
  address: string;
  notes: string;
  photo: string;
}

const defaultClientForm: ClientFormValues = {
  name: "",
  phone: "",
  whatsapp: "",
  eventVenueName: "",
  eventVenueAddress: "",
  email: "",
  city: "",
  address: "",
  notes: "",
  photo: "",
};

// ---------- Edit Client Modal ----------

function EditClientModal({
  open,
  onClose,
  client,
}: {
  open: boolean;
  onClose: () => void;
  client: Client;
}) {
  const { updateClient } = useERPStore();
  const [form, setForm] = useState<ClientFormValues>(defaultClientForm);
  const [saving, setSaving] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setForm({
        name: client.name,
        phone: client.phone,
        whatsapp: client.whatsapp ?? "",
        eventVenueName: client.eventVenueName ?? "",
        eventVenueAddress: client.eventVenueAddress ?? "",
        email: client.email ?? "",
        city: client.city ?? "",
        address: client.address ?? "",
        notes: client.notes ?? "",
        photo: client.photo ?? "",
      });
    }
  }, [open, client]);

  const set = (field: keyof ClientFormValues, value: string) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  const handlePhotoFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => set("photo", (e.target?.result as string) ?? "");
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      toast.error("Name is required");
      return;
    }
    if (!form.phone.trim()) {
      toast.error("Phone is required");
      return;
    }
    setSaving(true);
    try {
      updateClient(client.id, {
        name: form.name,
        phone: form.phone,
        whatsapp: form.whatsapp || undefined,
        eventVenueName: form.eventVenueName || undefined,
        eventVenueAddress: form.eventVenueAddress || undefined,
        email: form.email || undefined,
        city: form.city || undefined,
        address: form.address || undefined,
        notes: form.notes || undefined,
        photo: form.photo || undefined,
      });
      toast.success("Client updated");
      onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) onClose();
      }}
    >
      <DialogContent
        className="w-[95vw] max-w-lg max-h-[85dvh] overflow-y-auto sm:w-full"
        data-ocid="client_profile.edit_dialog"
      >
        <DialogHeader>
          <DialogTitle className="font-display text-lg">
            Edit Client
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5 mt-2">
          {/* Photo */}
          <div className="flex flex-col items-center gap-3">
            <Avatar
              className="w-20 h-20 cursor-pointer ring-2 ring-border hover:ring-primary transition-all"
              onClick={() => photoInputRef.current?.click()}
            >
              <AvatarImage src={form.photo} />
              <AvatarFallback className="bg-primary/10 text-primary text-lg font-semibold">
                {getInitials(form.name) || <User className="w-8 h-8" />}
              </AvatarFallback>
            </Avatar>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => photoInputRef.current?.click()}
              data-ocid="client_profile.photo.upload_button"
            >
              Upload Photo
            </Button>
            <input
              ref={photoInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handlePhotoFile(f);
              }}
            />
          </div>
          {/* Name + Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="ep-name">
                Name <span className="text-primary">*</span>
              </Label>
              <Input
                id="ep-name"
                placeholder="Full name"
                value={form.name}
                onChange={(e) => set("name", e.target.value)}
                data-ocid="client_profile.name.input"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ep-phone">
                Phone <span className="text-primary">*</span>
              </Label>
              <Input
                id="ep-phone"
                placeholder="+91 9876543210"
                value={form.phone}
                onChange={(e) => set("phone", e.target.value)}
                data-ocid="client_profile.phone.input"
                required
              />
            </div>
          </div>
          {/* WhatsApp */}
          <div className="space-y-1.5">
            <Label htmlFor="ep-wa">WhatsApp</Label>
            <Input
              id="ep-wa"
              placeholder="WhatsApp number"
              value={form.whatsapp}
              onChange={(e) => set("whatsapp", e.target.value)}
              data-ocid="client_profile.whatsapp.input"
            />
          </div>
          {/* Email + City */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="ep-email">Email</Label>
              <Input
                id="ep-email"
                type="email"
                placeholder="email@example.com"
                value={form.email}
                onChange={(e) => set("email", e.target.value)}
                data-ocid="client_profile.email.input"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ep-city">City</Label>
              <Input
                id="ep-city"
                placeholder="City"
                value={form.city}
                onChange={(e) => set("city", e.target.value)}
                data-ocid="client_profile.city.input"
              />
            </div>
          </div>
          {/* Address */}
          <div className="space-y-1.5">
            <Label htmlFor="ep-address">Client Address</Label>
            <Textarea
              id="ep-address"
              placeholder="Full address"
              value={form.address}
              onChange={(e) => set("address", e.target.value)}
              rows={2}
              data-ocid="client_profile.address.textarea"
            />
          </div>
          {/* Venue Name + Venue Address */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="ep-venue">Event Venue Name</Label>
              <Input
                id="ep-venue"
                placeholder="Wedding hall / venue name"
                value={form.eventVenueName}
                onChange={(e) => set("eventVenueName", e.target.value)}
                data-ocid="client_profile.venue_name.input"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ep-venue-addr">Venue Address</Label>
              <Input
                id="ep-venue-addr"
                placeholder="Venue address"
                value={form.eventVenueAddress}
                onChange={(e) => set("eventVenueAddress", e.target.value)}
                data-ocid="client_profile.venue_address.input"
              />
            </div>
          </div>
          {/* Notes */}
          <div className="space-y-1.5">
            <Label htmlFor="ep-notes">Notes</Label>
            <Textarea
              id="ep-notes"
              placeholder="Internal notes"
              value={form.notes}
              onChange={(e) => set("notes", e.target.value)}
              rows={2}
              data-ocid="client_profile.notes.textarea"
            />
          </div>
          <div className="flex justify-end gap-3 pt-1">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              data-ocid="client_profile.edit.cancel_button"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              disabled={saving}
              data-ocid="client_profile.edit.submit_button"
            >
              {saving ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : null}
              Save Changes
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// MAIN PAGE
// ============================================================

export default function ClientProfilePage() {
  const { clientId } = useParams({ strict: false }) as { clientId: string };
  const navigate = useNavigate();
  const {
    clients,
    invoices,
    expenses,
    deliveryTrackers,
    teamMembers,
    deleteClient,
  } = useERPStore();

  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [rentalDialogOpen, setRentalDialogOpen] = useState(false);
  const [editingPayment, setEditingPayment] =
    useState<PaymentLedgerEntry | null>(null);

  const client = clients.find((c) => c.id === clientId) ?? null;

  // Filter invoices belonging to this client by id or name match
  const clientInvoices = useMemo(
    () =>
      invoices.filter((inv) => {
        if (!client) return false;
        if (inv.clientId === client.id) return true;
        const nameMatch =
          inv.clientName.trim().toLowerCase() ===
          client.name.trim().toLowerCase();
        if (!nameMatch) return false;
        if (client.phone) {
          const cleanInv = (
            inv.clientWhatsapp ??
            inv.clientPhone ??
            ""
          ).replace(/\D/g, "");
          const cleanClient = client.phone.replace(/\D/g, "");
          if (cleanInv && cleanClient && cleanInv !== cleanClient) return false;
        }
        return true;
      }),
    [invoices, client],
  );

  // Computed stats — all using computeInvoiceBalance as single source of truth
  const totalPaid = useMemo(
    () =>
      clientInvoices.reduce((sum, inv) => {
        return (
          sum +
          (inv.paymentHistory ?? []).reduce(
            (s, p) => s + (Number(p.amount) || 0),
            0,
          )
        );
      }, 0),
    [clientInvoices],
  );

  // totalBalance = sum of outstanding dues only (never negative)
  const totalBalance = useMemo(
    () =>
      clientInvoices.reduce(
        (sum, inv) => sum + Math.max(0, computeInvoiceBalance(inv)),
        0,
      ),
    [clientInvoices],
  );

  const totalDeal = useMemo(
    () =>
      clientInvoices.reduce(
        (sum, inv) => sum + (Number(inv.dealAmount) || 0),
        0,
      ),
    [clientInvoices],
  );

  // All expenses linked to this client — by clientId OR by an invoiceId that belongs to them
  const clientExpenses = useMemo<Expense[]>(() => {
    if (!client) return [];
    const invIds = new Set(clientInvoices.map((inv) => inv.id));
    return expenses.filter(
      (e) =>
        e.clientId === client.id || (e.invoiceId && invIds.has(e.invoiceId)),
    );
  }, [expenses, client, clientInvoices]);

  // Total expenses linked to this client
  const totalExpenses = useMemo(
    () => clientExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0),
    [clientExpenses],
  );

  // Total team payment = sum of effective rates across all assignments (half-day = 50%)
  const totalTeamPayment = useMemo(() => {
    return clientInvoices.reduce((sum, inv) => {
      return (
        sum +
        (inv.teamAssignments ?? []).reduce((s, a) => {
          const rate = Number(a.rateUsed) || 0;
          const multiplier = a.dayType === "half" ? 0.5 : 1;
          return s + rate * multiplier;
        }, 0)
      );
    }, 0);
  }, [clientInvoices]);

  // Flat payments list — sorted desc by date
  const _allPayments: PaymentRowData[] = useMemo(
    () =>
      clientInvoices
        .flatMap((inv) =>
          (inv.paymentHistory ?? []).map((p) => ({
            id: p.id,
            date: p.date,
            amount: p.amount,
            mode: p.mode,
            invoiceNumber: inv.invoiceNumber,
            notes: p.notes,
          })),
        )
        .sort(
          (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime(),
        ),
    [clientInvoices],
  );

  // Unique team members assigned across all client invoices
  const assignedTeamMemberIds = useMemo(() => {
    const ids = new Set<string>();
    for (const inv of clientInvoices) {
      for (const a of inv.teamAssignments ?? []) {
        if (a.teamMemberId) ids.add(a.teamMemberId);
      }
    }
    return ids;
  }, [clientInvoices]);

  const waLink = client
    ? generateWhatsAppLink(
        client.whatsapp || client.phone,
        `Hi ${client.name}, `,
      )
    : "#";

  const handleDelete = async () => {
    if (!client) return;
    setDeleting(true);
    try {
      deleteClient(client.id);
      toast.success("Client deleted");
      navigate({ to: "/clients" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed");
    } finally {
      setDeleting(false);
      setDeleteOpen(false);
    }
  };

  if (!clientId) {
    return (
      <AppLayout>
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <User className="w-16 h-16 text-muted-foreground" />
          <p className="text-lg font-semibold text-foreground">
            No client selected
          </p>
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate({ to: "/clients" })}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Clients
          </Button>
        </div>
      </AppLayout>
    );
  }

  if (!client) {
    return (
      <AppLayout>
        <div className="space-y-6" data-ocid="client_profile.loading_state">
          <div className="flex items-center gap-4">
            <Skeleton className="w-20 h-20 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-7 w-48" />
              <Skeleton className="h-4 w-32" />
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              // biome-ignore lint/suspicious/noArrayIndexKey: skeleton
              <Skeleton key={i} className="h-24" />
            ))}
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6 pb-20 lg:pb-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3 sm:gap-4 min-w-0">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => navigate({ to: "/clients" })}
              data-ocid="client_profile.back_button"
              aria-label="Back to clients"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <Avatar className="w-16 h-16 sm:w-20 sm:h-20 ring-2 ring-primary/20 flex-shrink-0">
              <AvatarImage src={client.photo} />
              <AvatarFallback className="bg-primary/10 text-primary text-2xl font-bold">
                {getInitials(client.name)}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <h2 className="font-display text-xl sm:text-2xl font-bold text-foreground truncate">
                {client.name}
              </h2>
              <div className="flex items-center gap-3 mt-1">
                {client.city && (
                  <span className="flex items-center gap-1 text-sm text-muted-foreground">
                    <MapPin className="w-3.5 h-3.5" />
                    {client.city}
                  </span>
                )}
                <span className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Phone className="w-3.5 h-3.5" />
                  {client.phone}
                </span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2 ml-auto sm:ml-0 flex-wrap">
            <Button
              type="button"
              size="sm"
              className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2"
              onClick={() =>
                navigate({
                  to: "/invoices/new",
                  search: { clientId: client.id } as Record<string, string>,
                })
              }
              data-ocid="client_profile.new_invoice_button"
            >
              <FileText className="w-4 h-4" />
              <span className="hidden sm:inline">New Invoice</span>
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-2"
              onClick={() => setEditOpen(true)}
              data-ocid="client_profile.edit_button"
            >
              <Edit2 className="w-4 h-4" />
              <span className="hidden sm:inline">Edit</span>
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-2 text-destructive hover:bg-destructive/10 hover:border-destructive"
              onClick={() => setDeleteOpen(true)}
              data-ocid="client_profile.delete_button"
            >
              <Trash2 className="w-4 h-4" />
              <span className="hidden sm:inline">Delete</span>
            </Button>
            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              data-ocid="client_profile.whatsapp_link"
            >
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                <span className="hidden sm:inline">WhatsApp</span>
              </Button>
            </a>
          </div>
        </div>

        {/* Edit Modal */}
        <EditClientModal
          open={editOpen}
          onClose={() => setEditOpen(false)}
          client={client}
        />

        {/* Delete Confirmation Dialog */}
        <Dialog
          open={deleteOpen}
          onOpenChange={(o) => !deleting && setDeleteOpen(o)}
        >
          <DialogContent
            className="w-[95vw] max-w-sm max-h-[85dvh] overflow-y-auto sm:w-full"
            data-ocid="client_profile.delete_dialog"
          >
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 font-display">
                <AlertTriangle className="w-5 h-5 text-destructive" />
                Delete Client
              </DialogTitle>
            </DialogHeader>
            <p className="text-sm text-muted-foreground">
              Are you sure you want to delete <strong>{client?.name}</strong>?
              This action cannot be undone. All client data will be permanently
              removed.
            </p>
            <div className="flex justify-end gap-3 mt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDeleteOpen(false)}
                disabled={deleting}
                data-ocid="client_profile.delete.cancel_button"
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleDelete}
                disabled={deleting}
                data-ocid="client_profile.delete.confirm_button"
              >
                {deleting ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : null}
                Delete Client
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Action Bar */}
        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            size="sm"
            className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2"
            onClick={() => {
              setEditingPayment(null);
              setPaymentDialogOpen(true);
            }}
            data-ocid="client_profile.add_payment_button"
          >
            <Plus className="w-4 h-4" />
            Add Payment
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="gap-2"
            onClick={() => setRentalDialogOpen(true)}
            data-ocid="client_profile.add_rental_button"
          >
            <Camera className="w-4 h-4" />
            Add Rental
          </Button>
        </div>

        {/* Dialogs */}
        <AddPaymentDialog
          open={paymentDialogOpen}
          onClose={() => {
            setPaymentDialogOpen(false);
            setEditingPayment(null);
          }}
          clientId={client.id}
          clientInvoices={clientInvoices.map((inv) => ({
            id: inv.id,
            invoiceNumber: inv.invoiceNumber,
          }))}
          editEntry={editingPayment}
        />
        <AddRentalDialog
          open={rentalDialogOpen}
          onClose={() => setRentalDialogOpen(false)}
          clientId={client.id}
        />

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
          <StatCard
            label="Total Invoices"
            value={String(clientInvoices.length)}
            icon={FileText}
          />
          <StatCard
            label="Total Revenue"
            value={formatCurrency(totalDeal)}
            icon={CreditCard}
          />
          <StatCard
            label="Total Paid"
            value={formatCurrency(totalPaid)}
            icon={CreditCard}
          />
          <StatCard
            label="Balance Due"
            value={formatCurrency(totalBalance)}
            icon={Truck}
            highlight={totalBalance > 0}
          />
          <StatCard
            label="Total Expenses"
            value={formatCurrency(totalExpenses)}
            icon={Building2}
          />
          <StatCard
            label="Team Payments"
            value={formatCurrency(totalTeamPayment)}
            icon={Users}
          />
        </div>

        {/* Tabs */}
        <Tabs defaultValue="overview">
          <TabsList className="flex flex-wrap h-auto gap-1 w-full overflow-x-auto">
            <TabsTrigger
              value="overview"
              data-ocid="client_profile.overview.tab"
            >
              Overview
            </TabsTrigger>
            <TabsTrigger
              value="invoices"
              data-ocid="client_profile.invoices.tab"
            >
              Invoices
            </TabsTrigger>
            <TabsTrigger
              value="payments"
              data-ocid="client_profile.payments.tab"
            >
              Payments
            </TabsTrigger>
            <TabsTrigger value="events" data-ocid="client_profile.events.tab">
              Events
            </TabsTrigger>
            <TabsTrigger
              value="expenses"
              data-ocid="client_profile.expenses.tab"
            >
              Expenses
            </TabsTrigger>
            <TabsTrigger
              value="delivery"
              data-ocid="client_profile.delivery.tab"
            >
              Delivery
            </TabsTrigger>
            <TabsTrigger value="team" data-ocid="client_profile.team.tab">
              Team
            </TabsTrigger>
            <TabsTrigger value="rentals" data-ocid="client_profile.rentals.tab">
              Rentals
            </TabsTrigger>
            <TabsTrigger
              value="programs"
              data-ocid="client_profile.programs.tab"
            >
              Programs
            </TabsTrigger>
          </TabsList>

          {/* Overview */}
          <TabsContent value="overview" className="mt-6 space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Contact info */}
              <Card className="border border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="font-display text-base">
                    Contact Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { icon: Phone, label: "Phone", value: client.phone },
                    {
                      icon: MessageCircle,
                      label: "WhatsApp",
                      value: client.whatsapp,
                    },
                    { icon: Mail, label: "Email", value: client.email },
                    { icon: MapPin, label: "City", value: client.city },
                    {
                      icon: Building2,
                      label: "Address",
                      value: client.address,
                    },
                    {
                      icon: Home,
                      label: "Venue Name",
                      value: client.eventVenueName,
                    },
                    {
                      icon: MapPin,
                      label: "Venue Address",
                      value: client.eventVenueAddress,
                    },
                  ]
                    .filter((item) => item.value)
                    .map(({ icon: Icon, label, value }) => (
                      <div key={label} className="flex items-start gap-3">
                        <Icon className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="text-xs text-muted-foreground">
                            {label}
                          </p>
                          <p className="text-sm text-foreground font-medium">
                            {value}
                          </p>
                        </div>
                      </div>
                    ))}
                  {!client.phone && !client.email && (
                    <p className="text-sm text-muted-foreground">
                      No contact info
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Notes */}
              <Card className="border border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="font-display text-base flex items-center gap-2">
                    <StickyNote className="w-4 h-4" />
                    Notes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {client.notes ? (
                    <p className="text-sm text-foreground whitespace-pre-wrap">
                      {client.notes}
                    </p>
                  ) : (
                    <p className="text-sm text-muted-foreground italic">
                      No notes added
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Recent events */}
            {clientInvoices.length > 0 && (
              <Card className="border border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="font-display text-base flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Recent Events
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {clientInvoices.slice(0, 3).map((inv, i) => (
                    <div key={inv.id}>
                      <div className="flex items-center justify-between py-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground">
                            {inv.eventType}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {formatDate(inv.eventStartDate)}
                            {inv.eventEndDate &&
                            inv.eventEndDate !== inv.eventStartDate
                              ? ` – ${formatDate(inv.eventEndDate)}`
                              : ""}
                          </p>
                          {(inv.programs ?? []).filter((p) => p.enabled)
                            .length > 0 && (
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {(inv.programs ?? [])
                                .filter((p) => p.enabled)
                                .map((p) => p.name)
                                .join(" · ")}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                          <Badge
                            className={cn(
                              "text-xs border",
                              getStatusColor(getPaymentStatus(inv)),
                            )}
                          >
                            {getPaymentStatus(inv)}
                          </Badge>
                        </div>
                      </div>
                      {i < clientInvoices.slice(0, 3).length - 1 && (
                        <Separator />
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Invoices */}
          <TabsContent value="invoices" className="mt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-foreground">
                {clientInvoices.length} Invoice
                {clientInvoices.length !== 1 ? "s" : ""}
              </h3>
              <Button
                type="button"
                size="sm"
                className="bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() =>
                  navigate({
                    to: "/invoices/new",
                    search: { clientId: client.id } as Record<string, string>,
                  })
                }
                data-ocid="client_profile.create_invoice_button"
              >
                Create Invoice for Client
              </Button>
            </div>
            {clientInvoices.length === 0 ? (
              <div
                className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3"
                data-ocid="client_profile.invoices.empty_state"
              >
                <FileText className="w-10 h-10 opacity-40" />
                <p className="font-medium">No invoices yet</p>
              </div>
            ) : (
              <div className="space-y-2">
                {clientInvoices.map((inv, i) => (
                  <InvoiceRow key={inv.id} invoice={inv} index={i + 1} />
                ))}
              </div>
            )}
          </TabsContent>

          {/* Payments */}
          <TabsContent value="payments" className="mt-6">
            <ClientPaymentTab
              clientId={client.id}
              onEdit={(entry) => {
                setEditingPayment(entry);
                setPaymentDialogOpen(true);
              }}
            />
          </TabsContent>

          {/* Events */}
          <TabsContent value="events" className="mt-6">
            <h3 className="font-display font-semibold text-foreground mb-4">
              Event History
            </h3>
            {clientInvoices.length === 0 ? (
              <div
                className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3"
                data-ocid="client_profile.events.empty_state"
              >
                <Calendar className="w-10 h-10 opacity-40" />
                <p className="font-medium">No events recorded</p>
              </div>
            ) : (
              <div className="space-y-3">
                {clientInvoices.map((inv, i) => {
                  const balance = computeInvoiceBalance(inv);
                  const status = getPaymentStatus(inv);
                  return (
                    <button
                      key={inv.id}
                      type="button"
                      className="w-full text-left border border-border rounded-xl p-4 bg-card hover:border-primary/30 transition-all"
                      onClick={() => navigate({ to: `/invoices/${inv.id}` })}
                      data-ocid={`client_profile.event.${i + 1}`}
                    >
                      <div className="flex items-start justify-between gap-3 flex-wrap">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold text-sm text-foreground">
                              {inv.eventType}
                            </span>
                            <Badge
                              className={cn(
                                "text-xs border",
                                getStatusColor(status),
                              )}
                            >
                              {status}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {formatDate(inv.eventStartDate)}
                            {inv.eventEndDate &&
                            inv.eventEndDate !== inv.eventStartDate
                              ? ` – ${formatDate(inv.eventEndDate)}`
                              : ""}
                          </p>
                          {inv.eventVenueName && (
                            <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              {inv.eventVenueName}
                            </p>
                          )}
                          {(inv.programs ?? []).filter((p) => p.enabled)
                            .length > 0 && (
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {(inv.programs ?? [])
                                .filter((p) => p.enabled)
                                .map((p) => p.name)
                                .join(" · ")}
                            </p>
                          )}
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-bold text-foreground">
                            {formatCurrency(inv.dealAmount)}
                          </p>
                          {balance > 0 && (
                            <p className="text-xs text-destructive font-medium">
                              {formatCurrency(balance)} due
                            </p>
                          )}
                          <p className="text-xs text-muted-foreground font-mono">
                            {inv.invoiceNumber}
                          </p>
                        </div>
                      </div>
                    </button>
                  );
                })}

                {/* Team assigned across events */}
                {assignedTeamMemberIds.size > 0 && (
                  <Card className="border border-border mt-4">
                    <CardHeader className="pb-3">
                      <CardTitle className="font-display text-base flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        Team Assigned
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {Array.from(assignedTeamMemberIds).map((tmId) => {
                          const tm = teamMembers.find((m) => m.id === tmId);
                          if (!tm) return null;
                          return (
                            <button
                              type="button"
                              key={tmId}
                              className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border bg-muted/30 hover:border-primary/30 transition-colors"
                              onClick={() => navigate({ to: `/team/${tmId}` })}
                              data-ocid={`client_profile.team_member.${tmId}`}
                            >
                              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary text-[10px] font-bold">
                                {getInitials(tm.name)}
                              </div>
                              <div className="text-left">
                                <p className="text-xs font-medium text-foreground">
                                  {tm.name}
                                </p>
                                <p className="text-[10px] text-muted-foreground">
                                  {tm.role}
                                </p>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </TabsContent>

          {/* Expenses */}
          <TabsContent value="expenses" className="mt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-foreground">
                {clientExpenses.length} Expense
                {clientExpenses.length !== 1 ? "s" : ""}
              </h3>
              <Badge className="bg-red-100 text-red-700 border-red-200 font-semibold">
                Total: {formatCurrency(totalExpenses)}
              </Badge>
            </div>
            {clientExpenses.length === 0 ? (
              <div
                className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3"
                data-ocid="client_profile.expenses.empty_state"
              >
                <TrendingDown className="w-10 h-10 opacity-40" />
                <p className="font-medium">
                  No expenses recorded for this client
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {clientExpenses
                  .slice()
                  .sort(
                    (a, b) =>
                      new Date(b.date).getTime() - new Date(a.date).getTime(),
                  )
                  .map((exp, i) => {
                    const linkedInv = clientInvoices.find(
                      (inv) => inv.id === exp.invoiceId,
                    );
                    return (
                      <div
                        key={exp.id}
                        className="flex items-center gap-3 p-3 rounded-xl border border-border bg-card"
                        data-ocid={`client_profile.expense.${i + 1}`}
                      >
                        <div className="w-8 h-8 rounded-lg bg-red-50 flex items-center justify-center flex-shrink-0">
                          <TrendingDown className="w-4 h-4 text-red-500" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-semibold text-sm text-foreground">
                              {formatCurrency(exp.amount)}
                            </span>
                            <Badge variant="secondary" className="text-xs">
                              {exp.category}
                            </Badge>
                            {exp.paymentMode && (
                              <Badge
                                variant="outline"
                                className="text-xs capitalize"
                              >
                                {exp.paymentMode.replace("_", " ")}
                              </Badge>
                            )}
                          </div>
                          <div className="text-xs text-muted-foreground mt-0.5">
                            {formatDate(exp.date)}
                            {exp.vendor ? ` · ${exp.vendor}` : ""}
                            {linkedInv ? ` · ${linkedInv.invoiceNumber}` : ""}
                          </div>
                          {exp.notes && (
                            <p className="text-xs text-muted-foreground mt-0.5 truncate">
                              {exp.notes}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </TabsContent>

          {/* Team */}
          <TabsContent value="team" className="mt-6">
            <h3 className="font-display font-semibold text-foreground mb-4">
              Assigned Team Members
            </h3>
            <ClientTeamTab
              clientInvoices={clientInvoices}
              teamMembers={teamMembers}
            />
          </TabsContent>

          {/* Rentals */}
          <TabsContent value="rentals" className="mt-6">
            <h3 className="font-display font-semibold text-foreground mb-4">
              Equipment Rentals
            </h3>
            <ClientRentalsTab clientId={client.id} />
          </TabsContent>

          {/* Programs */}
          <TabsContent value="programs" className="mt-6">
            <h3 className="font-display font-semibold text-foreground mb-4">
              All Programs
            </h3>
            <ClientProgramsTab clientInvoices={clientInvoices} />
          </TabsContent>

          {/* Delivery */}
          <TabsContent value="delivery" className="mt-6">
            <h3 className="font-display font-semibold text-foreground mb-4">
              Delivery Status
            </h3>
            {clientInvoices.length === 0 ? (
              <div
                className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-3"
                data-ocid="client_profile.delivery.empty_state"
              >
                <Truck className="w-10 h-10 opacity-40" />
                <p className="font-medium">No deliveries tracked</p>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 gap-4">
                {clientInvoices.map((inv, i) => {
                  const tracker = deliveryTrackers.find(
                    (t) => t.invoiceId === inv.id,
                  );
                  const stage = tracker?.currentStage ?? "RAW_BACKUP";
                  const isDelivered = stage === "DELIVERED";
                  return (
                    <div key={inv.id} className="relative">
                      <DeliveryCard
                        invoice={inv}
                        index={i + 1}
                        deliveryStage={stage}
                      />
                      {isDelivered && (
                        <div className="absolute top-2 right-2 flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4 text-green-600" />
                          <span className="text-xs text-green-600 font-semibold">
                            Delivered
                          </span>
                        </div>
                      )}
                      {!tracker && (
                        <div className="absolute top-2 right-2 flex items-center gap-1">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">
                            Not tracked
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
