import AppLayout from "@/components/layout/AppLayout";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { getInitials } from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { Client, Expense } from "@/types";
import type { Invoice, TeamAssignment } from "@/types";
import { useNavigate } from "@tanstack/react-router";
import {
  AlertCircle,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Clock,
  Eye,
  MapPin,
  Receipt,
  Users,
} from "lucide-react";
import { useCallback, useMemo, useRef, useState } from "react";
const sortByDateTime = (
  a: {
    date?: string;
    dateRangeStart?: string;
    startDate?: string;
    time?: string;
    startTime?: string;
  },
  b: {
    date?: string;
    dateRangeStart?: string;
    startDate?: string;
    time?: string;
    startTime?: string;
  },
) => {
  const dateA = new Date(
    a.date || a.dateRangeStart || a.startDate || "",
  ).getTime();
  const dateB = new Date(
    b.date || b.dateRangeStart || b.startDate || "",
  ).getTime();
  if (dateA !== dateB) return dateA - dateB;
  const timeA = (a.time || a.startTime || "").toString();
  const timeB = (b.time || b.startTime || "").toString();
  return timeA.localeCompare(timeB);
};

interface CalendarEvent {
  invoiceId: string;
  invoiceNumber: string;
  clientId?: string;
  clientName: string;
  eventType: string;
  programName?: string;
  time?: string;
  venueName?: string;
  venueAddress?: string;
  teamAssignments: TeamAssignment[];
  date: string;
  status: string;
}

const DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTH_NAMES = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

// ─── Expense helpers ─────────────────────────────────────────────────────────

interface CalendarExpense {
  id: string;
  vendor: string;
  category: string;
  amount: number;
  date: string;
}

function buildExpenseMap(expenses: Expense[]): Map<string, CalendarExpense[]> {
  const map = new Map<string, CalendarExpense[]>();
  for (const e of expenses) {
    if (!e.date) continue;
    const key = toDateKey(e.date);
    if (!key) continue;
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push({
      id: e.id,
      vendor: e.vendor,
      category: e.category,
      amount: e.amount,
      date: key,
    });
  }
  return map;
}

// ─── Payment reminder helpers ─────────────────────────────────────────────────

interface PaymentReminder {
  invoiceId: string;
  invoiceNumber: string;
  clientName: string;
  pendingAmount: number;
  date: string;
}

function buildPaymentReminderMap(
  invoices: Invoice[],
): Map<string, PaymentReminder[]> {
  const map = new Map<string, PaymentReminder[]>();
  for (const inv of invoices) {
    if (!inv.pendingAmount || inv.pendingAmount <= 0) continue;
    // Use eventStartDate as the reminder anchor
    const key = toDateKey(inv.eventStartDate);
    if (!key) continue;
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push({
      invoiceId: inv.id,
      invoiceNumber: inv.invoiceNumber,
      clientName: inv.clientName,
      pendingAmount: inv.pendingAmount,
      date: key,
    });
  }
  return map;
}

// ─── Date helpers ─────────────────────────────────────────────────────────────

function toDateKey(dateStr: string): string {
  if (!dateStr) return "";
  const d = new Date(dateStr);
  if (Number.isNaN(d.getTime())) return "";
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function addDays(dateKey: string, n: number): string {
  const d = new Date(dateKey);
  d.setDate(d.getDate() + n);
  return toDateKey(d.toISOString());
}

function buildEventMap(
  invoices: Invoice[],
  clients: Client[],
): Map<string, CalendarEvent[]> {
  const map = new Map<string, CalendarEvent[]>();

  function push(dateKey: string, evt: CalendarEvent) {
    if (!dateKey) return;
    if (!map.has(dateKey)) map.set(dateKey, []);
    map.get(dateKey)!.push(evt);
  }

  for (const inv of invoices) {
    if (!inv.eventStartDate && (!inv.programs || inv.programs.length === 0))
      continue;

    // Resolve venue from client profile if available
    const client = inv.clientId
      ? clients.find((c) => c.id === inv.clientId)
      : undefined;
    const venueName = inv.eventVenueName ?? client?.eventVenueName;
    const venueAddress = inv.eventVenueAddress ?? client?.eventVenueAddress;

    const base: Omit<CalendarEvent, "date" | "programName" | "time"> = {
      invoiceId: inv.id,
      invoiceNumber: inv.invoiceNumber,
      clientId: inv.clientId,
      clientName: inv.clientName,
      eventType: inv.eventType,
      venueName,
      venueAddress,
      teamAssignments: inv.teamAssignments ?? [],
      status: inv.status,
    };

    // Wedding programs
    if (inv.programs && inv.programs.length > 0) {
      let pushed = false;
      const sortedPrograms = [...inv.programs].sort(sortByDateTime);
      for (const prog of sortedPrograms) {
        if (!prog.enabled || !prog.date) continue;
        const key = toDateKey(prog.date);
        push(key, {
          ...base,
          date: key,
          programName: prog.name,
          time: prog.startTime
            ? prog.endTime
              ? `${prog.startTime} – ${prog.endTime}`
              : prog.startTime
            : undefined,
        });
        pushed = true;
      }
      // If no programs had dates, fall back to event start date
      if (!pushed) {
        const startKey = toDateKey(inv.eventStartDate);
        if (startKey) push(startKey, { ...base, date: startKey });
      }
    } else {
      const startKey = toDateKey(inv.eventStartDate);
      const endKey = inv.eventEndDate ? toDateKey(inv.eventEndDate) : "";
      if (startKey) {
        push(startKey, { ...base, date: startKey });
        if (endKey && endKey !== startKey) {
          let cur = addDays(startKey, 1);
          let i = 0;
          while (cur <= endKey && i < 30) {
            push(cur, { ...base, date: cur });
            cur = addDays(cur, 1);
            i++;
          }
        }
      }
    }
  }

  return map;
}

function CalendarEventChip({ event }: { event: CalendarEvent }) {
  return (
    <div className="text-[10px] leading-tight px-1.5 py-0.5 rounded bg-primary/10 text-primary truncate border border-primary/20 font-medium">
      {event.programName
        ? `${event.clientName} · ${event.programName}`
        : `${event.clientName} · ${event.eventType}`}
    </div>
  );
}

function DayDetailModal({
  dateKey,
  events,
  expenses,
  reminders,
  onClose,
}: {
  dateKey: string;
  events: CalendarEvent[];
  expenses: CalendarExpense[];
  reminders: PaymentReminder[];
  onClose: () => void;
}) {
  const navigate = useNavigate();
  const { teamMembers } = useERPStore();
  const d = new Date(dateKey);
  const title = d.toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent
        className="w-[95vw] max-w-lg max-h-[85dvh] overflow-y-auto p-4 sm:p-6 sm:w-full"
        data-ocid="calendar.day_modal"
      >
        <DialogHeader>
          <DialogTitle className="font-display text-base">{title}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 pr-1">
          {/* ── Booked events ──────────────────────────────────────────── */}
          {(() => {
            const groups = new Map<string, CalendarEvent[]>();
            for (const evt of events) {
              const key = evt.clientId || evt.clientName;
              if (!groups.has(key)) groups.set(key, []);
              groups.get(key)!.push(evt);
            }
            return Array.from(groups.entries()).map(([key, evts], gi) => {
              const clientName = evts[0].clientName;
              const invoiceId = evts[0].invoiceId;
              const allPrograms = evts
                .filter((e) => e.programName)
                .map((e) => `${e.programName}${e.time ? ` · ${e.time}` : ""}`);
              const allMembers = Array.from(
                new Set(
                  evts.flatMap((e) =>
                    e.teamAssignments.map((a) => {
                      const member = teamMembers.find(
                        (m) => m.id === a.teamMemberId,
                      );
                      return member?.name ?? a.teamMemberName;
                    }),
                  ),
                ),
              );
              const hasPending = reminders.some(
                (r) => r.invoiceId === invoiceId,
              );
              return (
                <div
                  key={`group-${key}`}
                  className="p-3 rounded-xl border border-border bg-card hover:border-primary/30 transition-colors"
                  data-ocid={`calendar.modal.event.${gi + 1}`}
                >
                  {/* Client header */}
                  <div className="flex items-center gap-2 mb-2">
                    <Avatar className="w-8 h-8 flex-shrink-0">
                      <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">
                        {getInitials(clientName)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-sm text-foreground truncate">
                        {clientName}
                      </h3>
                      {evts[0].venueName && (
                        <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                          <MapPin className="w-2.5 h-2.5" />
                          {evts[0].venueName}
                        </p>
                      )}
                    </div>
                    {hasPending && (
                      <Badge
                        variant="outline"
                        className="text-[10px] h-5 px-1.5 border-orange-300 text-orange-600 bg-orange-50"
                      >
                        Payment Due
                      </Badge>
                    )}
                  </div>

                  {/* Programs list */}
                  {allPrograms.length > 0 && (
                    <div className="space-y-1 mb-2">
                      {allPrograms.map((prog, _pi) => (
                        <div
                          key={`prog-${prog}`}
                          className="flex items-center gap-1.5 text-xs text-foreground"
                        >
                          <Clock className="w-3 h-3 text-primary flex-shrink-0" />
                          <span>{prog}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Team members */}
                  {allMembers.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-border">
                      <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide mb-1.5 flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        Assigned Team
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {allMembers.map((name, _mi) => (
                          <span
                            key={`member-${name}`}
                            className="inline-flex items-center gap-1 text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full"
                          >
                            <span className="w-3.5 h-3.5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                              <span className="text-[8px] font-bold text-primary">
                                {getInitials(name)}
                              </span>
                            </span>
                            {name}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Action buttons */}
                  <div className="flex gap-2 mt-3 pt-2.5 border-t border-border">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="flex-1 h-7 text-xs gap-1"
                      onClick={() => {
                        navigate({ to: `/invoices/${invoiceId}` });
                        onClose();
                      }}
                      data-ocid="calendar.view_invoice.button"
                    >
                      <Eye className="w-3 h-3" />
                      View
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      className="flex-1 h-7 text-xs gap-1 bg-primary text-primary-foreground hover:bg-primary/90"
                      onClick={() => {
                        navigate({ to: `/invoices/${invoiceId}/edit` });
                        onClose();
                      }}
                      data-ocid="calendar.edit_invoice.button"
                    >
                      Edit
                    </Button>
                  </div>
                </div>
              );
            });
          })()}

          {/* ── Payment reminders ──────────────────────────────────────── */}
          {reminders.length > 0 && (
            <div>
              <p className="text-[10px] font-semibold text-orange-500 uppercase tracking-wide mb-1.5 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                Payment Due
              </p>
              <div className="space-y-2">
                {reminders.map((r, i) => (
                  <div
                    key={`reminder-${r.invoiceId}-${i}`}
                    className="flex items-center justify-between p-2.5 rounded-lg border border-orange-200 bg-orange-50"
                    data-ocid={`calendar.modal.reminder.${i + 1}`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-6 h-6 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
                        <AlertCircle className="w-3 h-3 text-orange-500" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-foreground truncate">
                          {r.clientName}
                        </p>
                        <p className="text-[10px] text-muted-foreground">
                          #{r.invoiceNumber}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className="text-xs font-bold text-orange-600">
                        ₹{r.pendingAmount.toLocaleString("en-IN")}
                      </span>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2 text-[10px]"
                        onClick={() => {
                          navigate({ to: `/invoices/${r.invoiceId}` });
                          onClose();
                        }}
                        data-ocid={`calendar.modal.reminder.view.${i + 1}`}
                      >
                        <Eye className="w-2.5 h-2.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── Expenses ───────────────────────────────────────────────── */}
          {expenses.length > 0 && (
            <div>
              <p className="text-[10px] font-semibold text-amber-600 uppercase tracking-wide mb-1.5 flex items-center gap-1">
                <Receipt className="w-3 h-3" />
                Expenses
              </p>
              <div className="space-y-2">
                {expenses.map((exp, i) => (
                  <div
                    key={`exp-${exp.id}-${i}`}
                    className="flex items-center justify-between p-2.5 rounded-lg border border-amber-200 bg-amber-50"
                    data-ocid={`calendar.modal.expense.${i + 1}`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0">
                        <Receipt className="w-3 h-3 text-amber-600" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-foreground truncate">
                          {exp.vendor}
                        </p>
                        <p className="text-[10px] text-muted-foreground">
                          {exp.category}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-amber-700 flex-shrink-0">
                      ₹{exp.amount.toLocaleString("en-IN")}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function CalendarPage() {
  const { invoices, clients, expenses } = useERPStore();
  const today = new Date();
  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth());
  const [selectedDay, setSelectedDay] = useState<string | null>(null);

  const eventMap = useMemo(
    () => buildEventMap(invoices, clients),
    [invoices, clients],
  );

  const expenseMap = useMemo(() => buildExpenseMap(expenses), [expenses]);

  const reminderMap = useMemo(
    () => buildPaymentReminderMap(invoices),
    [invoices],
  );

  // ─── Swipe gesture detection ────────────────────────────────────────────
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
  }, []);

  const handleTouchEnd = useCallback(
    (e: React.TouchEvent) => {
      if (touchStartX.current === null || touchStartY.current === null) return;
      const dx = e.changedTouches[0].clientX - touchStartX.current;
      const dy = e.changedTouches[0].clientY - touchStartY.current;
      // Only trigger if horizontal swipe dominates and is >= 50px
      if (Math.abs(dx) >= 50 && Math.abs(dx) > Math.abs(dy)) {
        if (dx < 0) {
          // swipe left → next month
          if (viewMonth === 11) {
            setViewMonth(0);
            setViewYear((y) => y + 1);
          } else setViewMonth((m) => m + 1);
        } else {
          // swipe right → prev month
          if (viewMonth === 0) {
            setViewMonth(11);
            setViewYear((y) => y - 1);
          } else setViewMonth((m) => m - 1);
        }
      }
      touchStartX.current = null;
      touchStartY.current = null;
    },
    [viewMonth],
  );

  const firstDay = new Date(viewYear, viewMonth, 1);
  const lastDay = new Date(viewYear, viewMonth + 1, 0);
  const startDow = firstDay.getDay();
  const daysInMonth = lastDay.getDate();
  const todayKey = toDateKey(today.toISOString());

  function prevMonth() {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear((y) => y - 1);
    } else setViewMonth((m) => m - 1);
  }
  function nextMonth() {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear((y) => y + 1);
    } else setViewMonth((m) => m + 1);
  }
  function goToday() {
    setViewYear(today.getFullYear());
    setViewMonth(today.getMonth());
  }

  type CalendarCell =
    | { dateKey: string; day: number }
    | { dateKey: string; day: null };
  const cells: CalendarCell[] = [];
  for (let i = 0; i < startDow; i++)
    cells.push({ dateKey: `blank-${i}`, day: null });
  for (let d = 1; d <= daysInMonth; d++) {
    const dateKey = `${viewYear}-${String(viewMonth + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    cells.push({ dateKey, day: d });
  }
  while (cells.length % 7 !== 0)
    cells.push({ dateKey: `blank-tail-${cells.length}`, day: null });

  // biome-ignore lint/correctness/useExhaustiveDependencies: today is stable across renders
  const upcomingEvents = useMemo(() => {
    const result: CalendarEvent[] = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(today);
      d.setDate(d.getDate() + i);
      const key = toDateKey(d.toISOString());
      const evts = eventMap.get(key) ?? [];
      result.push(...evts);
    }
    return result.sort((a, b) => a.date.localeCompare(b.date));
  }, [eventMap]);

  const selectedEvents = selectedDay ? (eventMap.get(selectedDay) ?? []) : [];
  const selectedExpenses = selectedDay
    ? (expenseMap.get(selectedDay) ?? [])
    : [];
  const selectedReminders = selectedDay
    ? (reminderMap.get(selectedDay) ?? [])
    : [];

  return (
    <AppLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-bold text-foreground">
              Calendar
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              View all booked events and programs
            </p>
          </div>
          <div className="flex items-center gap-3 text-sm flex-wrap">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-primary inline-block" />
              <span className="text-muted-foreground">Booked</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-amber-500 inline-block" />
              <span className="text-muted-foreground">Expense</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-orange-500 inline-block" />
              <span className="text-muted-foreground">Payment due</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-green-500 inline-block" />
              <span className="text-muted-foreground">Free</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          {/* Calendar */}
          <div className="xl:col-span-3">
            <div className="bg-card border border-border rounded-2xl shadow-card overflow-hidden">
              {/* Month nav */}
              <div className="flex items-center justify-between px-5 py-4 border-b border-border">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={prevMonth}
                  data-ocid="calendar.prev_month.button"
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                <div className="flex items-center gap-3">
                  <span className="font-display font-semibold text-lg text-foreground">
                    {MONTH_NAMES[viewMonth]} {viewYear}
                  </span>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={goToday}
                    className="text-xs h-7 px-2.5"
                    data-ocid="calendar.today.button"
                  >
                    Today
                  </Button>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={nextMonth}
                  data-ocid="calendar.next_month.button"
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </div>

              {/* Day headers */}
              <div className="grid grid-cols-7 border-b border-border">
                {DAY_NAMES.map((d) => (
                  <div
                    key={d}
                    className="py-2.5 text-center text-xs font-semibold text-muted-foreground tracking-wide"
                  >
                    {d}
                  </div>
                ))}
              </div>

              {/* Day cells */}
              <div
                className="grid grid-cols-7 scroll-smooth"
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
              >
                {cells.map((cell) => {
                  if (cell.day === null) {
                    return (
                      <div
                        key={cell.dateKey}
                        className="h-24 border-b border-r border-border last:border-r-0 bg-muted/20"
                      />
                    );
                  }
                  const { dateKey, day } = cell;
                  const evts = eventMap.get(dateKey) ?? [];
                  const dayExpenses = expenseMap.get(dateKey) ?? [];
                  const dayReminders = reminderMap.get(dateKey) ?? [];
                  const hasEvents = evts.length > 0;
                  const hasExpenses = dayExpenses.length > 0;
                  const hasReminders = dayReminders.length > 0;
                  const hasAny = hasEvents || hasExpenses || hasReminders;
                  const isToday = dateKey === todayKey;
                  const visible = evts.slice(0, 2);
                  const extra = evts.length - visible.length;

                  return (
                    <button
                      key={dateKey}
                      type="button"
                      onClick={() => hasAny && setSelectedDay(dateKey)}
                      className={`min-h-[44px] sm:h-24 border-b border-r border-border last:border-r-0 p-1 sm:p-1.5 text-left transition-colors flex flex-col gap-0.5 ${
                        hasAny
                          ? "cursor-pointer hover:bg-primary/5"
                          : "cursor-default"
                      } ${isToday ? "ring-1 ring-inset ring-primary/40" : ""}`}
                      data-ocid={`calendar.day.${day}`}
                    >
                      <div className="flex items-center justify-start gap-0.5">
                        <span
                          className={`text-xs font-semibold w-6 h-6 flex items-center justify-center rounded-full leading-none flex-shrink-0 ${
                            hasEvents
                              ? "bg-primary text-primary-foreground"
                              : isToday
                                ? "bg-muted text-foreground"
                                : "text-muted-foreground"
                          }`}
                        >
                          {day}
                        </span>
                        {/* Indicator dots row */}
                        <span className="flex items-center gap-0.5 flex-wrap">
                          {!hasEvents && !hasExpenses && !hasReminders && (
                            <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
                          )}
                          {hasExpenses && (
                            <span
                              className="w-1.5 h-1.5 rounded-full bg-amber-500"
                              title="Expense"
                            />
                          )}
                          {hasReminders && (
                            <span
                              className="w-1.5 h-1.5 rounded-full bg-orange-500"
                              title="Payment due"
                            />
                          )}
                        </span>
                      </div>
                      {/* Event chips — hidden on very small screens to keep cells clean */}
                      <div className="hidden sm:flex flex-col gap-0.5 overflow-hidden">
                        {visible.map((evt, i) => (
                          <CalendarEventChip
                            key={`${evt.invoiceId}-chip${i}`}
                            event={evt}
                          />
                        ))}
                        {extra > 0 && (
                          <span className="text-[10px] text-primary font-medium px-1">
                            +{extra} more
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Upcoming sidebar */}
          <div className="xl:col-span-1">
            <div className="bg-card border border-border rounded-2xl shadow-card overflow-hidden">
              <div className="flex items-center gap-2 px-4 py-3.5 border-b border-border">
                <Calendar className="w-4 h-4 text-primary" />
                <span className="font-display font-semibold text-sm text-foreground">
                  Next 7 Days
                </span>
              </div>
              {upcomingEvents.length === 0 ? (
                <div
                  className="py-10 text-center"
                  data-ocid="calendar.upcoming.empty_state"
                >
                  <Calendar className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">
                    No upcoming events
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {upcomingEvents.map((evt, i) => (
                    <div
                      key={`${evt.invoiceId}-up${i}`}
                      className="px-4 py-3"
                      data-ocid={`calendar.upcoming.item.${i + 1}`}
                    >
                      <div className="flex items-start gap-2">
                        <div className="flex-shrink-0 w-10 text-center">
                          <div className="text-xs font-bold text-primary">
                            {new Date(evt.date).toLocaleDateString("en-IN", {
                              day: "numeric",
                            })}
                          </div>
                          <div className="text-[10px] text-muted-foreground">
                            {new Date(evt.date).toLocaleDateString("en-IN", {
                              month: "short",
                            })}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-foreground truncate">
                            {evt.clientName}
                          </p>
                          <p className="text-[10px] text-muted-foreground truncate">
                            {evt.programName ?? evt.eventType}
                          </p>
                          {evt.time && (
                            <p className="text-[10px] text-muted-foreground flex items-center gap-1 mt-0.5">
                              <Clock className="w-2.5 h-2.5" />
                              {evt.time}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Day detail modal */}
      {selectedDay &&
        (selectedEvents.length > 0 ||
          selectedExpenses.length > 0 ||
          selectedReminders.length > 0) && (
          <DayDetailModal
            dateKey={selectedDay}
            events={selectedEvents}
            expenses={selectedExpenses}
            reminders={selectedReminders}
            onClose={() => setSelectedDay(null)}
          />
        )}
    </AppLayout>
  );
}
