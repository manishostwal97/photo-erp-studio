import { useRouterState } from "@tanstack/react-router";
import { FileText, GraduationCap, Star } from "lucide-react";
import { useEffect, useState } from "react";
import { PillTabs } from "../components/shared/PillTabs";
import ProgressReports from "./ProgressReports";
import ReportCards from "./ReportCards";
import StandardsReport from "./StandardsReport";

type ReportTab = "progress" | "cards" | "standards";

function getTabFromSearch(search: string): ReportTab {
  const params = new URLSearchParams(search);
  const t = params.get("tab");
  if (t === "cards") return "cards";
  if (t === "standards") return "standards";
  return "progress";
}

export default function Reports() {
  const routerState = useRouterState();
  const [activeTab, setActiveTab] = useState<ReportTab>(() =>
    getTabFromSearch(String(routerState.location.search ?? "")),
  );

  // Sync tab when navigating with ?tab= param
  useEffect(() => {
    setActiveTab(getTabFromSearch(String(routerState.location.search ?? "")));
  }, [routerState.location.search]);

  return (
    <div className="space-y-5">
      {/* Pill tab navigation — inline at top of content area, not in header */}
      <PillTabs
        tabs={[
          {
            value: "progress" as const,
            label: "Progress Reports",
            icon: <FileText size={14} />,
          },
          {
            value: "cards" as const,
            label: "Report Cards",
            icon: <GraduationCap size={14} />,
          },
          {
            value: "standards" as const,
            label: "Standards Report",
            icon: <Star size={14} />,
          },
        ]}
        activeTab={activeTab}
        onChange={setActiveTab}
      />

      {/* Tab description */}
      <p className="text-xs text-muted-foreground -mt-1">
        {activeTab === "progress" &&
          "Teacher-written narrative summaries shared with parents"}
        {activeTab === "cards" && "Official grades and marks for the term"}
        {activeTab === "standards" &&
          "Standards-based mastery across curriculum areas"}
      </p>

      {/* Tab panels */}
      <div role="tabpanel">
        {activeTab === "progress" ? (
          <ProgressReports />
        ) : activeTab === "cards" ? (
          <ReportCards />
        ) : (
          <StandardsReport />
        )}
      </div>
    </div>
  );
}
