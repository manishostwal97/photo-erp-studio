import AppLayout from "@/components/layout/AppLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { RentalEntry } from "@/types";
import {
  Camera,
  ChevronDown,
  ChevronUp,
  Clock,
  DollarSign,
  Package,
  PlusCircle,
  Store,
  Trash2,
  User,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

// ─── Constants ──────────────────────────────────────────────────────────────

const EQUIPMENT_TYPES: {
  value: RentalEntry["equipmentType"];
  label: string;
}[] = [
  { value: "camera", label: "Camera" },
  { value: "lens", label: "Lens" },
  { value: "drone", label: "Drone" },
  { value: "light", label: "Light" },
  { value: "other", label: "Other" },
];

const STATUS_OPTIONS: { value: RentalEntry["status"]; label: string }[] = [
  { value: "active", label: "Active" },
  { value: "returned", label: "Returned" },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getEquipmentLabel(type: RentalEntry["equipmentType"]) {
  return EQUIPMENT_TYPES.find((t) => t.value === type)?.label ?? type;
}

function getStatusBadge(status: RentalEntry["status"]) {
  if (status === "active") {
    return (
      <Badge className="bg-primary/10 text-primary border-primary/20">
        Active
      </Badge>
    );
  }
  return (
    <Badge className="bg-success-subtle text-success border-success/20">
      Returned
    </Badge>
  );
}

// ─── Page Component ───────────────────────────────────────────────────────────

export default function EquipmentRentalPage() {
  const { getAllRentals, addEquipmentRental, clients, invoices } =
    useERPStore();
  const rentals = getAllRentals();

  const [tab, setTab] = useState<"all" | "active" | "returned" | "byClient">(
    "all",
  );
  const [showAdd, setShowAdd] = useState(false);
  const [expandedClients, setExpandedClients] = useState<Set<string>>(
    new Set(),
  );

  const [form, setForm] = useState({
    clientId: "",
    invoiceId: "",
    equipmentType: "camera" as RentalEntry["equipmentType"],
    vendor: "",
    rentAmount: "",
    paidAmount: "",
    startDate: "",
    endDate: "",
    status: "active" as RentalEntry["status"],
    notes: "",
  });

  const filteredRentals = useMemo(() => {
    if (tab === "active") return rentals.filter((r) => r.status === "active");
    if (tab === "returned")
      return rentals.filter((r) => r.status === "returned");
    return rentals;
  }, [rentals, tab]);

  const stats = useMemo(() => {
    const totalActive = rentals.filter((r) => r.status === "active").length;
    const totalDue = rentals.reduce((sum, r) => sum + (r.dueAmount || 0), 0);
    const now = new Date();
    const thisMonthCount = rentals.filter((r) => {
      const d = new Date(r.createdAt);
      return (
        d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()
      );
    }).length;
    return { totalActive, totalDue, thisMonthCount };
  }, [rentals]);

  const byClient = useMemo(() => {
    const map = new Map<string, RentalEntry[]>();
    for (const r of rentals) {
      const list = map.get(r.clientId) ?? [];
      list.push(r);
      map.set(r.clientId, list);
    }
    return map;
  }, [rentals]);

  const handleAdd = () => {
    if (!form.clientId || !form.vendor || !form.rentAmount || !form.startDate) {
      toast.error("Please fill all required fields");
      return;
    }
    const rentAmount = Number.parseFloat(form.rentAmount);
    const paidAmount = Number.parseFloat(form.paidAmount || "0");
    if (Number.isNaN(rentAmount) || rentAmount <= 0) {
      toast.error("Invalid rent amount");
      return;
    }

    const rental: RentalEntry = {
      id: crypto.randomUUID(),
      clientId: form.clientId,
      invoiceId: form.invoiceId || undefined,
      equipmentType: form.equipmentType,
      vendor: form.vendor.trim(),
      rentAmount,
      paidAmount,
      dueAmount: rentAmount - paidAmount,
      startDate: form.startDate,
      endDate: form.endDate || undefined,
      status: form.status,
      notes: form.notes.trim() || undefined,
      createdAt: new Date().toISOString(),
    };

    addEquipmentRental(rental);
    toast.success("Equipment rental added");
    setShowAdd(false);
    setForm({
      clientId: "",
      invoiceId: "",
      equipmentType: "camera",
      vendor: "",
      rentAmount: "",
      paidAmount: "",
      startDate: "",
      endDate: "",
      status: "active",
      notes: "",
    });
  };

  const toggleClient = (clientId: string) => {
    setExpandedClients((prev) => {
      const next = new Set(prev);
      if (next.has(clientId)) next.delete(clientId);
      else next.add(clientId);
      return next;
    });
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="page-title">Equipment Rental</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Manage all camera, lens, drone and light rentals
            </p>
          </div>
          <Button
            type="button"
            onClick={() => setShowAdd(true)}
            data-ocid="rental.add_button"
            className="bg-primary text-primary-foreground hover:bg-primary-hover shadow-sm"
          >
            <PlusCircle className="w-4 h-4 mr-2" />
            Add Rental
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card className="stat-card-accent card-hover border-border">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Active Rentals
                  </p>
                  <p className="stat-number mt-1">{stats.totalActive}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Package className="w-5 h-5 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="stat-card-accent card-hover border-border">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Due</p>
                  <p className="stat-number mt-1">
                    {formatCurrency(stats.totalDue)}
                  </p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-destructive" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="stat-card-accent card-hover border-border">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">This Month</p>
                  <p className="stat-number mt-1">{stats.thisMonthCount}</p>
                </div>
                <div className="w-10 h-10 rounded-lg bg-info/10 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-info" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2">
          {(
            [
              { key: "all", label: "All Rentals" },
              { key: "active", label: "Active" },
              { key: "returned", label: "Returned" },
              { key: "byClient", label: "By Client" },
            ] as const
          ).map((t) => (
            <Button
              key={t.key}
              type="button"
              variant={tab === t.key ? "default" : "outline"}
              size="sm"
              onClick={() => setTab(t.key)}
              data-ocid={`rental.tab.${t.key}`}
              className={
                tab === t.key
                  ? "bg-primary text-primary-foreground"
                  : "border-border text-foreground hover:bg-muted"
              }
            >
              {t.label}
            </Button>
          ))}
        </div>

        {/* List / By Client */}
        {tab === "byClient" ? (
          <div className="space-y-3 overflow-x-auto">
            {byClient.size === 0 && (
              <div className="text-center py-12 bg-card rounded-xl border border-border">
                <Camera className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">No rentals yet</p>
              </div>
            )}
            {Array.from(byClient.entries()).map(([clientId, list]) => {
              const client = clients.find((c) => c.id === clientId);
              const expanded = expandedClients.has(clientId);
              const clientDue = list.reduce((s, r) => s + r.dueAmount, 0);
              return (
                <div
                  key={clientId}
                  className="bg-card rounded-xl border border-border overflow-hidden"
                >
                  <button
                    type="button"
                    onClick={() => toggleClient(clientId)}
                    className="w-full flex items-center justify-between px-4 py-3 hover:bg-muted/40 transition-colors"
                    data-ocid={`rental.client.${clientId}.toggle`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <User className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      <span className="font-medium text-sm truncate">
                        {client?.name ?? "Unknown Client"}
                      </span>
                      <Badge
                        variant="secondary"
                        className="text-xs flex-shrink-0"
                      >
                        {list.length}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 flex-shrink-0">
                      <span className="text-sm font-semibold text-destructive">
                        Due {formatCurrency(clientDue)}
                      </span>
                      {expanded ? (
                        <ChevronUp className="w-4 h-4 text-muted-foreground" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-muted-foreground" />
                      )}
                    </div>
                  </button>
                  {expanded && (
                    <div className="px-4 pb-4 space-y-3">
                      {list.map((r) => (
                        <RentalCard
                          key={r.id}
                          rental={r}
                          client={client}
                          linkedInvoiceNumber={
                            r.invoiceId
                              ? invoices.find((i) => i.id === r.invoiceId)
                                  ?.invoiceNumber
                              : undefined
                          }
                        />
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="space-y-3 overflow-x-auto">
            {filteredRentals.length === 0 ? (
              <div className="text-center py-12 bg-card rounded-xl border border-border">
                <Camera className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">
                  {tab === "active"
                    ? "No active rentals"
                    : tab === "returned"
                      ? "No returned rentals"
                      : "No rentals yet"}
                </p>
              </div>
            ) : (
              filteredRentals.map((r) => (
                <RentalCard
                  key={r.id}
                  rental={r}
                  client={clients.find((c) => c.id === r.clientId)}
                  linkedInvoiceNumber={
                    r.invoiceId
                      ? invoices.find((i) => i.id === r.invoiceId)
                          ?.invoiceNumber
                      : undefined
                  }
                />
              ))
            )}
          </div>
        )}
      </div>

      {/* Add Rental Dialog */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="w-[95vw] sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display">
              Add Equipment Rental
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>
                  Client <span className="text-destructive">*</span>
                </Label>
                <Select
                  value={form.clientId}
                  onValueChange={(v) => setForm((f) => ({ ...f, clientId: v }))}
                >
                  <SelectTrigger data-ocid="rental.form.client.select">
                    <SelectValue placeholder="Select client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Linked Invoice (optional)</Label>
                <Select
                  value={form.invoiceId}
                  onValueChange={(v) => {
                    const inv = invoices.find((i) => i.id === v);
                    setForm((f) => ({
                      ...f,
                      invoiceId: v,
                      clientId: inv?.clientId ? inv.clientId : f.clientId,
                    }));
                  }}
                >
                  <SelectTrigger data-ocid="rental.form.invoice.select">
                    <SelectValue placeholder="Select linked invoice..." />
                  </SelectTrigger>
                  <SelectContent>
                    {invoices.map((inv) => (
                      <SelectItem key={inv.id} value={inv.id}>
                        #{inv.invoiceNumber} – {inv.clientName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Equipment Type</Label>
                <Select
                  value={form.equipmentType}
                  onValueChange={(v) =>
                    setForm((f) => ({
                      ...f,
                      equipmentType: v as RentalEntry["equipmentType"],
                    }))
                  }
                >
                  <SelectTrigger data-ocid="rental.form.type.select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {EQUIPMENT_TYPES.map((t) => (
                      <SelectItem key={t.value} value={t.value}>
                        {t.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>
                  Vendor <span className="text-destructive">*</span>
                </Label>
                <Input
                  placeholder="Vendor / Source"
                  value={form.vendor}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, vendor: e.target.value }))
                  }
                  data-ocid="rental.form.vendor.input"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <Label>
                  Rent Amount <span className="text-destructive">*</span>
                </Label>
                <Input
                  type="number"
                  placeholder="0"
                  value={form.rentAmount}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, rentAmount: e.target.value }))
                  }
                  data-ocid="rental.form.rent.input"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Paid Amount</Label>
                <Input
                  type="number"
                  placeholder="0"
                  value={form.paidAmount}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, paidAmount: e.target.value }))
                  }
                  data-ocid="rental.form.paid.input"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Status</Label>
                <Select
                  value={form.status}
                  onValueChange={(v) =>
                    setForm((f) => ({
                      ...f,
                      status: v as RentalEntry["status"],
                    }))
                  }
                >
                  <SelectTrigger data-ocid="rental.form.status.select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUS_OPTIONS.map((s) => (
                      <SelectItem key={s.value} value={s.value}>
                        {s.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>
                  Start Date <span className="text-destructive">*</span>
                </Label>
                <Input
                  type="date"
                  value={form.startDate}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, startDate: e.target.value }))
                  }
                  data-ocid="rental.form.start_date.input"
                />
              </div>
              <div className="space-y-1.5">
                <Label>End Date</Label>
                <Input
                  type="date"
                  value={form.endDate}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, endDate: e.target.value }))
                  }
                  data-ocid="rental.form.end_date.input"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Textarea
                placeholder="Any additional details..."
                value={form.notes}
                onChange={(e) =>
                  setForm((f) => ({ ...f, notes: e.target.value }))
                }
                data-ocid="rental.form.notes.textarea"
              />
            </div>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowAdd(false)}
              data-ocid="rental.form.cancel_button"
              className="w-full sm:w-auto"
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={handleAdd}
              data-ocid="rental.form.submit_button"
              className="w-full sm:w-auto bg-primary text-primary-foreground hover:bg-primary-hover"
            >
              Save Rental
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}

// ─── Rental Card ──────────────────────────────────────────────────────────────

function RentalCard({
  rental,
  client,
  linkedInvoiceNumber,
}: {
  rental: RentalEntry;
  client?: { name: string; phone?: string };
  linkedInvoiceNumber?: string;
}) {
  return (
    <div className="bg-card rounded-xl border border-border p-4 sm:p-5 card-hover">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
        <div className="flex items-start gap-3 min-w-0">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
            <Camera className="w-5 h-5 text-primary" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-semibold text-sm text-foreground">
                {getEquipmentLabel(rental.equipmentType)}
              </h3>
              {getStatusBadge(rental.status)}
            </div>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Store className="w-3 h-3" />
                {rental.vendor}
              </span>
              {client && (
                <span className="flex items-center gap-1">
                  <User className="w-3 h-3" />
                  {client.name}
                </span>
              )}
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {formatDate(rental.startDate)}
                {rental.endDate ? ` – ${formatDate(rental.endDate)}` : ""}
              </span>
            </div>
            {linkedInvoiceNumber && (
              <p className="text-xs text-primary font-medium mt-1">
                Linked Invoice: #{linkedInvoiceNumber}
              </p>
            )}
            {rental.notes && (
              <p className="text-xs text-muted-foreground mt-1.5 line-clamp-2">
                {rental.notes}
              </p>
            )}
          </div>
        </div>

        <div className="flex flex-row sm:flex-col items-center sm:items-end gap-2 sm:gap-1 flex-shrink-0">
          <span className="text-sm font-semibold text-foreground">
            {formatCurrency(rental.rentAmount)}
          </span>
          {rental.dueAmount > 0 && (
            <span className="text-xs text-destructive font-medium">
              Due {formatCurrency(rental.dueAmount)}
            </span>
          )}
          {rental.dueAmount <= 0 && (
            <span className="text-xs text-success font-medium">Paid</span>
          )}
        </div>
      </div>
    </div>
  );
}
