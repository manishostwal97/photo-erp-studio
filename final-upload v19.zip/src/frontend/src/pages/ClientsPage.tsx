import AppLayout from "@/components/layout/AppLayout";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  computeInvoiceBalance,
  formatCurrency,
  generateWhatsAppLink,
  getInitials,
} from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { Client, Invoice } from "@/types";
import { useNavigate } from "@tanstack/react-router";
import {
  Edit2,
  Grid3X3,
  List,
  Loader2,
  MapPin,
  MessageCircle,
  Phone,
  Plus,
  Search,
  Trash2,
  User,
  Users,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

// ---------- Form values ----------

interface ClientFormValues {
  name: string;
  phone: string;
  whatsapp: string;
  eventVenueName: string;
  eventVenueAddress: string;
  email: string;
  city: string;
  address: string;
  notes: string;
  photo: string;
}

const defaultForm: ClientFormValues = {
  name: "",
  phone: "",
  whatsapp: "",
  eventVenueName: "",
  eventVenueAddress: "",
  email: "",
  city: "",
  address: "",
  notes: "",
  photo: "",
};

// ---------- Helpers ----------

function getClientInvoices(client: Client, invoices: Invoice[]): Invoice[] {
  return invoices.filter((inv) => {
    if (inv.clientId === client.id) return true;
    const nameMatch =
      inv.clientName.trim().toLowerCase() === client.name.trim().toLowerCase();
    if (!nameMatch) return false;
    if (client.phone) {
      const cleanInv = (inv.clientWhatsapp ?? inv.clientPhone ?? "").replace(
        /\D/g,
        "",
      );
      const cleanClient = client.phone.replace(/\D/g, "");
      if (cleanInv && cleanClient && cleanInv !== cleanClient) return false;
    }
    return true;
  });
}

// ---------- Photo Upload ----------

function PhotoUpload({
  value,
  onChange,
  name,
}: { value: string; onChange: (url: string) => void; name: string }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const handleFile = (file: File) => {
    setUploading(true);
    const reader = new FileReader();
    reader.onload = (e) => {
      onChange((e.target?.result as string) ?? "");
      setUploading(false);
    };
    reader.onerror = () => {
      toast.error("Failed to read image");
      setUploading(false);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="flex flex-col items-center gap-3">
      <Avatar className="w-20 h-20 cursor-pointer ring-2 ring-border hover:ring-primary transition-all">
        <AvatarImage src={value} />
        <AvatarFallback className="bg-primary/10 text-primary text-lg font-semibold">
          {getInitials(name) || <User className="w-8 h-8" />}
        </AvatarFallback>
      </Avatar>
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => inputRef.current?.click()}
        disabled={uploading}
        data-ocid="client.photo.upload_button"
      >
        {uploading ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
        {uploading ? "Uploading..." : "Upload Photo"}
      </Button>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
        }}
      />
    </div>
  );
}

// ---------- Add/Edit Modal ----------

interface ClientModalProps {
  open: boolean;
  onClose: () => void;
  client?: Client | null;
}

function ClientModal({ open, onClose, client }: ClientModalProps) {
  const { addClient, updateClient } = useERPStore();
  const [form, setForm] = useState<ClientFormValues>(defaultForm);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setForm(
        client
          ? {
              name: client.name,
              phone: client.phone,
              whatsapp: client.whatsapp ?? "",
              eventVenueName: client.eventVenueName ?? "",
              eventVenueAddress: client.eventVenueAddress ?? "",
              email: client.email ?? "",
              city: client.city ?? "",
              address: client.address ?? "",
              notes: client.notes ?? "",
              photo: client.photo ?? "",
            }
          : defaultForm,
      );
    }
  }, [open, client]);

  const set = (field: keyof ClientFormValues, value: string) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      toast.error("Name is required");
      return;
    }
    if (!form.phone.trim()) {
      toast.error("Mobile is required");
      return;
    }
    setSaving(true);
    try {
      if (client) {
        updateClient(client.id, { ...form });
        toast.success("Client updated");
      } else {
        addClient({
          id: `client-${Date.now()}`,
          ...form,
          createdAt: new Date().toISOString(),
        });
        toast.success("Client added");
      }
      onClose();
    } catch {
      toast.error("Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) onClose();
      }}
    >
      <DialogContent
        className="w-[95vw] max-w-lg max-h-[90vh] overflow-y-auto"
        data-ocid="client.dialog"
      >
        <DialogHeader>
          <DialogTitle className="font-display text-lg">
            {client ? "Edit Client" : "Add New Client"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5 mt-2">
          <PhotoUpload
            value={form.photo}
            onChange={(url) => set("photo", url)}
            name={form.name}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="c-name">
                Name <span className="text-primary">*</span>
              </Label>
              <Input
                id="c-name"
                placeholder="Full name"
                value={form.name}
                onChange={(e) => set("name", e.target.value)}
                data-ocid="client.name.input"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="c-mobile">
                Mobile <span className="text-primary">*</span>
              </Label>
              <Input
                id="c-mobile"
                placeholder="+91 9876543210"
                value={form.phone}
                onChange={(e) => set("phone", e.target.value)}
                data-ocid="client.mobile.input"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="c-wa">WhatsApp</Label>
              <Input
                id="c-wa"
                placeholder="WhatsApp number"
                value={form.whatsapp}
                onChange={(e) => set("whatsapp", e.target.value)}
                data-ocid="client.whatsapp.input"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="c-venue">Event Venue Name</Label>
              <Input
                id="c-venue"
                placeholder="Event venue name"
                value={form.eventVenueName}
                onChange={(e) => set("eventVenueName", e.target.value)}
                data-ocid="client.venue_name.input"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="c-venue-addr">Event Venue Address</Label>
            <Input
              id="c-venue-addr"
              placeholder="Venue full address"
              value={form.eventVenueAddress}
              onChange={(e) => set("eventVenueAddress", e.target.value)}
              data-ocid="client.venue_address.input"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="c-email">Email</Label>
              <Input
                id="c-email"
                type="email"
                placeholder="email@example.com"
                value={form.email}
                onChange={(e) => set("email", e.target.value)}
                data-ocid="client.email.input"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="c-city">City</Label>
              <Input
                id="c-city"
                placeholder="City"
                value={form.city}
                onChange={(e) => set("city", e.target.value)}
                data-ocid="client.city.input"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="c-address">Address</Label>
            <Textarea
              id="c-address"
              placeholder="Full address"
              value={form.address}
              onChange={(e) => set("address", e.target.value)}
              rows={2}
              data-ocid="client.address.textarea"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="c-notes">Notes</Label>
            <Textarea
              id="c-notes"
              placeholder="Internal notes about this client"
              value={form.notes}
              onChange={(e) => set("notes", e.target.value)}
              rows={2}
              data-ocid="client.notes.textarea"
            />
          </div>

          <div className="flex justify-end gap-3 pt-1">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              data-ocid="client.cancel_button"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              disabled={saving}
              data-ocid="client.submit_button"
            >
              {saving ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : null}
              {client ? "Save Changes" : "Add Client"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ---------- Delete Confirm ----------

function DeleteClientDialog({
  client,
  onClose,
  onConfirm,
  loading,
}: {
  client: Client | null;
  onClose: () => void;
  onConfirm: () => void;
  loading: boolean;
}) {
  return (
    <AlertDialog
      open={!!client}
      onOpenChange={(o) => {
        if (!o) onClose();
      }}
    >
      <AlertDialogContent data-ocid="client.delete.dialog">
        <AlertDialogHeader>
          <AlertDialogTitle>Delete {client?.name}?</AlertDialogTitle>
          <AlertDialogDescription>
            This will permanently remove <strong>{client?.name}</strong> and all
            associated data.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel
            onClick={onClose}
            data-ocid="client.delete.cancel_button"
          >
            Cancel
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            disabled={loading}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            data-ocid="client.delete.confirm_button"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
            Delete Client
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

interface ClientCardProps {
  client: Client;
  invoices: Invoice[];
  onEdit: (c: Client) => void;
  onDelete: (c: Client) => void;
  onView: (c: Client) => void;
  index: number;
}

function ClientCard({
  client,
  invoices,
  onEdit,
  onDelete,
  onView,
  index,
}: ClientCardProps) {
  const clientInvoices = getClientInvoices(client, invoices);
  const totalBalance = clientInvoices.reduce(
    (sum, inv) => sum + computeInvoiceBalance(inv),
    0,
  );
  const waLink = generateWhatsAppLink(
    client.whatsapp || client.phone,
    `Hi ${client.name}, `,
  );

  return (
    <Card
      className="border border-border shadow-sm hover:shadow-md hover:border-primary/30 transition-all duration-200 group"
      data-ocid={`client.card.${index}`}
    >
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <Avatar className="w-14 h-14 ring-2 ring-border group-hover:ring-primary/30 transition-all">
              <AvatarImage src={client.photo} />
              <AvatarFallback className="bg-primary/10 text-primary font-semibold text-lg">
                {getInitials(client.name)}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <p className="font-semibold text-foreground truncate max-w-[100px] sm:max-w-[140px]">
                {client.name}
              </p>
              {client.city && (
                <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3 h-3 flex-shrink-0" />
                  {client.city}
                </p>
              )}
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            {totalBalance > 0 && (
              <Badge className="bg-destructive/10 text-destructive border-destructive/20 text-xs">
                {formatCurrency(totalBalance)}
              </Badge>
            )}
            <Badge variant="secondary" className="text-xs">
              {clientInvoices.length} inv
            </Badge>
          </div>
        </div>

        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
          <Phone className="w-3.5 h-3.5 flex-shrink-0" />
          <span className="truncate">{client.phone}</span>
        </div>

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="default"
            size="sm"
            className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 text-xs"
            onClick={() => onView(client)}
            data-ocid={`client.view_button.${index}`}
          >
            View Profile
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="w-8 h-8 hover:bg-primary/10 hover:text-primary"
            asChild
          >
            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              data-ocid={`client.whatsapp_button.${index}`}
              aria-label={`WhatsApp ${client.name}`}
            >
              <MessageCircle className="w-4 h-4" />
            </a>
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="w-8 h-8 hover:bg-primary/10 hover:text-primary"
            onClick={() => onEdit(client)}
            data-ocid={`client.edit_button.${index}`}
            aria-label={`Edit ${client.name}`}
          >
            <Edit2 className="w-4 h-4" />
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="w-8 h-8 hover:bg-destructive/10 hover:text-destructive"
            onClick={() => onDelete(client)}
            data-ocid={`client.delete_button.${index}`}
            aria-label={`Delete ${client.name}`}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function ClientRow({
  client,
  invoices,
  onEdit,
  onDelete,
  onView,
  index,
}: ClientCardProps) {
  const clientInvoices = getClientInvoices(client, invoices);
  const totalBalance = clientInvoices.reduce(
    (sum, inv) => sum + computeInvoiceBalance(inv),
    0,
  );
  const waLink = generateWhatsAppLink(
    client.whatsapp || client.phone,
    `Hi ${client.name}, `,
  );

  return (
    <div
      className="flex items-center gap-3 p-3 rounded-xl border border-border bg-card hover:border-primary/30 hover:shadow-sm transition-all"
      data-ocid={`client.row.${index}`}
    >
      <Avatar className="w-10 h-10 flex-shrink-0">
        <AvatarImage src={client.photo} />
        <AvatarFallback className="bg-primary/10 text-primary font-semibold text-sm">
          {getInitials(client.name)}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-sm text-foreground truncate">
          {client.name}
        </p>
        <p className="text-xs text-muted-foreground truncate">{client.city}</p>
      </div>
      <div className="hidden sm:flex items-center gap-1 text-xs text-muted-foreground min-w-[100px]">
        <Phone className="w-3 h-3" />
        <span className="truncate">{client.phone}</span>
      </div>
      <div className="hidden md:block min-w-[90px] text-right">
        {totalBalance > 0 ? (
          <span className="text-xs font-semibold text-destructive">
            {formatCurrency(totalBalance)}
          </span>
        ) : (
          <span className="text-xs text-green-600 font-medium">Settled</span>
        )}
      </div>
      <Badge variant="secondary" className="text-xs hidden sm:inline-flex">
        {clientInvoices.length} inv
      </Badge>
      <div className="flex items-center gap-1">
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="w-8 h-8 hover:bg-primary/10 hover:text-primary"
          onClick={() => onView(client)}
          data-ocid={`client.list_view_button.${index}`}
          aria-label={`View ${client.name}`}
        >
          <User className="w-4 h-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="w-8 h-8 hover:bg-primary/10 hover:text-primary"
          asChild
        >
          <a
            href={waLink}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`WhatsApp ${client.name}`}
          >
            <MessageCircle className="w-4 h-4" />
          </a>
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="w-8 h-8 hover:bg-primary/10 hover:text-primary"
          onClick={() => onEdit(client)}
          data-ocid={`client.list_edit_button.${index}`}
          aria-label={`Edit ${client.name}`}
        >
          <Edit2 className="w-4 h-4" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="w-8 h-8 hover:bg-destructive/10 hover:text-destructive"
          onClick={() => onDelete(client)}
          data-ocid={`client.list_delete_button.${index}`}
          aria-label={`Delete ${client.name}`}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}

function EmptyClients({ onAdd }: { onAdd: () => void }) {
  return (
    <div
      className="flex flex-col items-center justify-center py-20 gap-6"
      data-ocid="clients.empty_state"
    >
      <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
        <Users className="w-12 h-12 text-primary" />
      </div>
      <div className="text-center">
        <h3 className="font-display text-xl font-semibold text-foreground mb-2">
          No clients yet
        </h3>
        <p className="text-muted-foreground text-sm max-w-xs">
          Start building your client base. Add your first client to get started.
        </p>
      </div>
      <Button
        type="button"
        className="bg-primary text-primary-foreground hover:bg-primary/90"
        onClick={onAdd}
        data-ocid="clients.empty_add_button"
      >
        <Plus className="w-4 h-4 mr-2" />
        Add Your First Client
      </Button>
    </div>
  );
}

// ============================================================
// MAIN PAGE
// ============================================================

export default function ClientsPage() {
  const navigate = useNavigate();
  const { clients, invoices, deleteClient } = useERPStore();

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [modalOpen, setModalOpen] = useState(false);
  const [editClient, setEditClient] = useState<Client | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Client | null>(null);
  const [deleting, setDeleting] = useState(false);

  const filteredClients = clients.filter((c) => {
    const q = search.toLowerCase();
    const matchSearch =
      !q ||
      c.name.toLowerCase().includes(q) ||
      c.phone.toLowerCase().includes(q) ||
      (c.city ?? "").toLowerCase().includes(q);
    if (!matchSearch) return false;
    if (filter === "pending") {
      const balance = getClientInvoices(c, invoices).reduce(
        (sum, inv) => sum + computeInvoiceBalance(inv),
        0,
      );
      return balance > 0;
    }
    if (filter === "upcoming") {
      const now = new Date();
      return getClientInvoices(c, invoices).some(
        (inv) => inv.eventStartDate && new Date(inv.eventStartDate) > now,
      );
    }
    return true;
  });

  const handleDelete = () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      deleteClient(deleteTarget.id);
      toast.success("Client deleted");
      setDeleteTarget(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed");
    } finally {
      setDeleting(false);
    }
  };

  const openAdd = () => {
    setEditClient(null);
    setModalOpen(true);
  };
  const openEdit = (c: Client) => {
    setEditClient(c);
    setModalOpen(true);
  };
  const closeModal = () => {
    setModalOpen(false);
    setEditClient(null);
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <h2 className="font-display text-2xl font-bold text-foreground">
              Clients
            </h2>
            <Badge className="bg-primary/10 text-primary border-primary/20 font-semibold">
              {clients.length}
            </Badge>
          </div>
          <Button
            type="button"
            className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm"
            onClick={openAdd}
            data-ocid="clients.add_button"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Client
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1 min-w-0">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, phone or city…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 w-full"
              data-ocid="clients.search_input"
            />
          </div>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger
              className="w-full sm:w-48 flex-shrink-0"
              data-ocid="clients.filter.select"
            >
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Clients</SelectItem>
              <SelectItem value="pending">Has Pending Balance</SelectItem>
              <SelectItem value="upcoming">Has Upcoming Event</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex items-center border border-border rounded-lg overflow-hidden">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className={`rounded-none h-9 w-9 ${view === "grid" ? "bg-primary/10 text-primary" : "text-muted-foreground"}`}
              onClick={() => setView("grid")}
              data-ocid="clients.view_grid.toggle"
              aria-label="Grid view"
            >
              <Grid3X3 className="w-4 h-4" />
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className={`rounded-none h-9 w-9 ${view === "list" ? "bg-primary/10 text-primary" : "text-muted-foreground"}`}
              onClick={() => setView("list")}
              data-ocid="clients.view_list.toggle"
              aria-label="List view"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {filteredClients.length === 0 && clients.length === 0 ? (
          <EmptyClients onAdd={openAdd} />
        ) : filteredClients.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-16 text-muted-foreground"
            data-ocid="clients.no_results"
          >
            <Search className="w-10 h-10 mb-3 opacity-40" />
            <p className="font-medium">No clients match your search</p>
            <p className="text-sm mt-1">Try adjusting your filters</p>
          </div>
        ) : view === "grid" ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            {filteredClients.map((c, i) => (
              <ClientCard
                key={c.id}
                client={c}
                invoices={invoices}
                onEdit={openEdit}
                onDelete={setDeleteTarget}
                onView={(cl) => navigate({ to: `/clients/${cl.id}` })}
                index={i + 1}
              />
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {filteredClients.map((c, i) => (
              <ClientRow
                key={c.id}
                client={c}
                invoices={invoices}
                onEdit={openEdit}
                onDelete={setDeleteTarget}
                onView={(cl) => navigate({ to: `/clients/${cl.id}` })}
                index={i + 1}
              />
            ))}
          </div>
        )}
      </div>

      <ClientModal open={modalOpen} onClose={closeModal} client={editClient} />
      <DeleteClientDialog
        client={deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
      />
    </AppLayout>
  );
}
