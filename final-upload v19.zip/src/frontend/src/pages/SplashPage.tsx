import { useAuthStore } from "@/stores/authStore";
import { useStudioStore } from "@/stores/useStudioStore";
import { useNavigate } from "@tanstack/react-router";
import { useEffect, useRef } from "react";

export default function SplashPage() {
  const navigate = useNavigate();
  const { isAuthenticated, initialized } = useAuthStore();
  const isSetupComplete = useStudioStore((s) => s.isSetupComplete);
  // isHydrated is set to true by Zustand's onRehydrateStorage callback once
  // the persisted studio profile has been loaded from localStorage.
  const isHydrated = useStudioStore((s) => s.isHydrated);
  const progressRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      // Wait for BOTH auth initialization AND store rehydration before navigating.
      // Without this check the splash could navigate before persisted state
      // (isSetupComplete, studioProfile) is restored, sending logged-in users
      // to /setup even though they've already completed setup.
      if (!initialized || !isHydrated) return;
      if (!isAuthenticated) {
        navigate({ to: "/login" });
      } else if (!isSetupComplete) {
        navigate({ to: "/setup" });
      } else {
        navigate({ to: "/dashboard" });
      }
    }, 3000);
    return () => clearTimeout(timer);
  }, [isAuthenticated, isSetupComplete, initialized, isHydrated, navigate]);

  return (
    <div
      id="splash-page"
      className="min-h-screen bg-white flex flex-col items-center justify-center relative overflow-hidden"
      style={{ background: "#FFFFFF" }}
    >
      {/* Subtle radial gradient accent */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 50%, rgba(220,38,38,0.06) 0%, transparent 70%)",
        }}
      />

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center gap-8">
        {/* Camera SVG with zoom-in animation */}
        <div className="splash-camera" aria-hidden="true">
          <svg
            width="96"
            height="80"
            viewBox="0 0 96 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
          >
            {/* Camera body */}
            <rect x="4" y="18" width="88" height="56" rx="12" fill="#DC2626" />
            {/* Viewfinder bump */}
            <rect x="34" y="6" width="28" height="16" rx="6" fill="#DC2626" />
            {/* Lens outer ring */}
            <circle cx="48" cy="46" r="22" fill="#b91c1c" />
            {/* Lens inner glass */}
            <circle
              cx="48"
              cy="46"
              r="16"
              fill="white"
              fillOpacity="0.15"
              stroke="white"
              strokeWidth="2.5"
            />
            {/* Lens reflection */}
            <circle cx="48" cy="46" r="8" fill="white" fillOpacity="0.2" />
            <circle cx="42" cy="40" r="3" fill="white" fillOpacity="0.4" />
            {/* Flash dot */}
            <circle cx="76" cy="28" r="5" fill="white" fillOpacity="0.8" />
            {/* Shutter button */}
            <circle cx="76" cy="28" r="3" fill="white" />
          </svg>
        </div>

        {/* App name with fade-in delay */}
        <div className="splash-text text-center flex flex-col items-center gap-1">
          <h1
            className="font-display font-bold tracking-widest uppercase"
            style={{
              color: "#DC2626",
              fontSize: "clamp(1.25rem, 4vw, 1.875rem)",
            }}
          >
            PHOTOGRAPHY INVOICE STUDIO
          </h1>
          <p className="text-sm tracking-wide" style={{ color: "#6b7280" }}>
            Professional Studio Management
          </p>
        </div>

        {/* Dots indicator */}
        <div className="flex gap-2" aria-label="Loading">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="splash-dot w-2 h-2 rounded-full"
              style={{
                background: "#DC2626",
                animationDelay: `${i * 0.2}s`,
              }}
            />
          ))}
        </div>
      </div>

      {/* Loading bar at bottom */}
      <div
        className="absolute bottom-0 left-0 right-0 h-1"
        style={{ background: "rgba(220,38,38,0.08)" }}
        aria-hidden="true"
      >
        <div
          ref={progressRef}
          className="splash-progress h-full"
          style={{ background: "#DC2626" }}
        />
      </div>

      <style>{`
        @keyframes splashZoomIn {
          from { opacity: 0; transform: scale(0.3); }
          to   { opacity: 1; transform: scale(1); }
        }
        @keyframes splashFadeIn {
          from { opacity: 0; transform: translateY(12px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes splashDot {
          0%, 80%, 100% { opacity: 0.3; transform: scale(0.8); }
          40%            { opacity: 1;   transform: scale(1.2); }
        }
        @keyframes splashProgress {
          from { width: 0%; }
          to   { width: 100%; }
        }
        .splash-camera {
          animation: splashZoomIn 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) both;
          filter: drop-shadow(0 8px 24px rgba(220,38,38,0.25));
        }
        .splash-text {
          animation: splashFadeIn 0.6s ease-out 0.7s both;
        }
        .splash-dot {
          animation: splashDot 1.2s ease-in-out infinite;
        }
        .splash-progress {
          animation: splashProgress 2.5s ease-in-out forwards;
        }
        @media (prefers-reduced-motion: reduce) {
          .splash-camera, .splash-text, .splash-dot, .splash-progress {
            animation: none;
            opacity: 1;
            width: 100%;
          }
        }
      `}</style>
    </div>
  );
}
