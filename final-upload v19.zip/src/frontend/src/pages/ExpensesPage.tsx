import AppLayout from "@/components/layout/AppLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { Expense, PaymentMode } from "@/types";
import {
  AlertTriangle,
  Download,
  Edit2,
  PlusCircle,
  Receipt,
  Trash2,
  TrendingDown,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { toast } from "sonner";

// ─── Constants ──────────────────────────────────────────────────────────────

const EXPENSE_CATEGORIES = [
  { value: "petrol", label: "Petrol", color: "#f97316" },
  { value: "food", label: "Food", color: "#22c55e" },
  { value: "hotel", label: "Hotel", color: "#3b82f6" },
  { value: "equipment", label: "Equipment", color: "#f59e0b" },
  { value: "travel", label: "Travel", color: "#06b6d4" },
  { value: "labor", label: "Labor", color: "#8b5cf6" },
  { value: "printing", label: "Printing", color: "#ec4899" },
  { value: "editing", label: "Editing", color: "#14b8a6" },
  { value: "salary", label: "Salary", color: "#a855f7" },
  { value: "rent", label: "Rent", color: "#0ea5e9" },
  { value: "misc", label: "Misc", color: "#94a3b8" },
] as const;

type CategoryValue = (typeof EXPENSE_CATEGORIES)[number]["value"];

const CATEGORY_BADGE: Record<CategoryValue, string> = {
  petrol: "bg-orange-100 text-orange-700 border-orange-200",
  food: "bg-green-100 text-green-700 border-green-200",
  hotel: "bg-blue-100 text-blue-700 border-blue-200",
  equipment: "bg-yellow-100 text-yellow-700 border-yellow-200",
  travel: "bg-cyan-100 text-cyan-700 border-cyan-200",
  labor: "bg-purple-100 text-purple-700 border-purple-200",
  printing: "bg-pink-100 text-pink-700 border-pink-200",
  editing: "bg-teal-100 text-teal-700 border-teal-200",
  salary: "bg-violet-100 text-violet-700 border-violet-200",
  rent: "bg-sky-100 text-sky-700 border-sky-200",
  misc: "bg-muted text-muted-foreground border-border",
};

function getCategoryColor(cat: string): string {
  return EXPENSE_CATEGORIES.find((c) => c.value === cat)?.color ?? "#94a3b8";
}

function getCategoryLabel(cat: string): string {
  return EXPENSE_CATEGORIES.find((c) => c.value === cat)?.label ?? cat;
}

const PAYMENT_MODES: { value: PaymentMode; label: string }[] = [
  { value: "cash", label: "Cash" },
  { value: "upi", label: "UPI" },
  { value: "bank_transfer", label: "Bank Transfer" },
  { value: "cheque", label: "Cheque" },
  { value: "card", label: "Card" },
  { value: "other", label: "Other" },
];

const MONTHS = [
  { value: 0, label: "January" },
  { value: 1, label: "February" },
  { value: 2, label: "March" },
  { value: 3, label: "April" },
  { value: 4, label: "May" },
  { value: 5, label: "June" },
  { value: 6, label: "July" },
  { value: 7, label: "August" },
  { value: 8, label: "September" },
  { value: 9, label: "October" },
  { value: 10, label: "November" },
  { value: 11, label: "December" },
];

const CURRENT_YEAR = new Date().getFullYear();
const YEAR_OPTIONS = Array.from({ length: 5 }, (_, i) => CURRENT_YEAR - i);

function todayISO(): string {
  return new Date().toISOString().split("T")[0];
}

// ─── Expense Form ─────────────────────────────────────────────────────────────

interface ExpenseFormValues {
  vendor: string;
  amount: number;
  date: string;
  category: string;
  customCategory: string;
  paymentMode: PaymentMode;
  clientId: string;
  invoiceId: string;
  teamMemberId: string;
  notes: string;
}

function defaultExpenseForm(): ExpenseFormValues {
  return {
    vendor: "",
    amount: 0,
    date: todayISO(),
    category: "misc",
    customCategory: "",
    paymentMode: "cash",
    clientId: "none",
    invoiceId: "none",
    teamMemberId: "none",
    notes: "",
  };
}

interface ExpenseModalProps {
  open: boolean;
  onClose: () => void;
  editing?: Expense;
}

function ExpenseModal({ open, onClose, editing }: ExpenseModalProps) {
  const { clients, invoices, teamMembers, addExpense, updateExpense } =
    useERPStore();
  const [form, setForm] = useState<ExpenseFormValues>(() =>
    editing
      ? {
          vendor: editing.vendor,
          amount: editing.amount,
          date: editing.date,
          category: editing.category,
          customCategory: "",
          paymentMode: editing.paymentMode,
          clientId: editing.clientId ?? "none",
          invoiceId: editing.invoiceId ?? "none",
          teamMemberId: editing.teamMemberId ?? "none",
          notes: editing.notes ?? "",
        }
      : defaultExpenseForm(),
  );
  const [submitting, setSubmitting] = useState(false);

  // Reset form when editing changes
  // biome-ignore lint/correctness/useExhaustiveDependencies: reset on editing/open change
  useEffect(() => {
    setForm(
      editing
        ? {
            vendor: editing.vendor,
            amount: editing.amount,
            date: editing.date,
            category: editing.category,
            customCategory: "",
            paymentMode: editing.paymentMode,
            clientId: editing.clientId ?? "none",
            invoiceId: editing.invoiceId ?? "none",
            teamMemberId: editing.teamMemberId ?? "none",
            notes: editing.notes ?? "",
          }
        : defaultExpenseForm(),
    );
  }, [editing?.id, open]);

  // Derived: is the category a custom (non-preset) value?
  const isCustomCategory =
    !EXPENSE_CATEGORIES.some((c) => c.value === form.category) &&
    form.category !== "misc";

  const set = <K extends keyof ExpenseFormValues>(
    field: K,
    value: ExpenseFormValues[K],
  ) => setForm((prev) => ({ ...prev, [field]: value }));

  const filteredInvoices = useMemo(
    () =>
      form.clientId && form.clientId !== "none"
        ? (invoices ?? []).filter((inv) => inv.clientId === form.clientId)
        : (invoices ?? []),
    [invoices, form.clientId],
  );

  // When invoice is selected, auto-populate clientId and eventName
  function handleInvoiceSelect(invId: string) {
    set("invoiceId", invId);
    if (invId && invId !== "none") {
      const inv = (invoices ?? []).find((i) => i.id === invId);
      if (inv) {
        set("clientId", inv.clientId ?? "none");
      }
    }
  }

  // Resolve effective category value: custom text or preset key
  function getEffectiveCategory(): string {
    if (form.category === "__custom__") {
      return form.customCategory.trim() || "misc";
    }
    return form.category;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.vendor.trim()) {
      toast.error("Vendor / description is required");
      return;
    }
    if (!form.amount || form.amount <= 0) {
      toast.error("Amount must be greater than 0");
      return;
    }
    setSubmitting(true);
    try {
      const effectiveCategory = getEffectiveCategory();
      const resolvedClientId =
        form.clientId && form.clientId !== "none" ? form.clientId : undefined;
      const resolvedInvoiceId =
        form.invoiceId && form.invoiceId !== "none"
          ? form.invoiceId
          : undefined;
      const resolvedTeamMemberId =
        form.teamMemberId && form.teamMemberId !== "none"
          ? form.teamMemberId
          : undefined;
      // Pull event name from linked invoice
      const linkedInvoice = resolvedInvoiceId
        ? (invoices ?? []).find((i) => i.id === resolvedInvoiceId)
        : undefined;
      const resolvedEventName =
        linkedInvoice?.customEventName || linkedInvoice?.eventType || undefined;

      const expenseData = {
        vendor: form.vendor,
        amount: form.amount,
        date: form.date,
        category: effectiveCategory,
        paymentMode: form.paymentMode,
        clientId: resolvedClientId,
        invoiceId: resolvedInvoiceId,
        teamMemberId: resolvedTeamMemberId,
        eventName: resolvedEventName,
        notes: form.notes || undefined,
      };

      if (editing) {
        updateExpense(editing.id, expenseData);
        toast.success("Expense updated");
      } else {
        addExpense({
          id: `exp-${Date.now()}`,
          ...expenseData,
          createdAt: new Date().toISOString(),
        });
        toast.success("Expense added");
      }
      onClose();
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : "Failed to save expense",
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) onClose();
      }}
    >
      <DialogContent
        className="w-[95vw] max-w-lg max-h-[90vh] p-0 flex flex-col"
        data-ocid="expenses.dialog"
      >
        <DialogHeader className="px-6 pt-6 pb-2 shrink-0">
          <DialogTitle className="font-display">
            {editing ? "Edit Expense" : "Add Expense"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0">
          <div className="flex-1 overflow-y-auto px-6 space-y-4">
            {/* Vendor + Amount */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5 col-span-2 sm:col-span-1">
                <Label htmlFor="exp-vendor">Vendor / Description *</Label>
                <Input
                  id="exp-vendor"
                  placeholder="e.g. Petrol for wedding"
                  value={form.vendor}
                  onChange={(e) => set("vendor", e.target.value)}
                  data-ocid="expenses.vendor.input"
                  required
                />
              </div>
              <div className="space-y-1.5 col-span-2 sm:col-span-1">
                <Label htmlFor="exp-amount">Amount (₹) *</Label>
                <Input
                  id="exp-amount"
                  type="number"
                  min={0}
                  step={1}
                  placeholder="0"
                  value={form.amount || ""}
                  onChange={(e) => set("amount", Number(e.target.value))}
                  data-ocid="expenses.amount.input"
                  required
                />
              </div>
            </div>

            {/* Date + Category */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="exp-date">Date *</Label>
                <Input
                  id="exp-date"
                  type="date"
                  value={form.date}
                  onChange={(e) => set("date", e.target.value)}
                  data-ocid="expenses.date.input"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label>Category *</Label>
                <Select
                  value={isCustomCategory ? "__custom__" : form.category}
                  onValueChange={(v) => {
                    if (v === "__custom__") {
                      set("category", "__custom__");
                    } else {
                      set("category", v);
                      set("customCategory", "");
                    }
                  }}
                >
                  <SelectTrigger data-ocid="expenses.category.select">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    {EXPENSE_CATEGORIES.map((c) => (
                      <SelectItem key={c.value} value={c.value}>
                        {c.label}
                      </SelectItem>
                    ))}
                    <SelectItem value="__custom__">Custom…</SelectItem>
                  </SelectContent>
                </Select>
                {(form.category === "__custom__" || isCustomCategory) && (
                  <Input
                    className="mt-1.5"
                    placeholder="Enter custom category name"
                    value={form.customCategory}
                    onChange={(e) => set("customCategory", e.target.value)}
                    data-ocid="expenses.custom_category.input"
                  />
                )}
              </div>
            </div>

            {/* Payment Mode */}
            <div className="space-y-1.5">
              <Label>Payment Mode</Label>
              <Select
                value={form.paymentMode}
                onValueChange={(v) => set("paymentMode", v as PaymentMode)}
              >
                <SelectTrigger data-ocid="expenses.payment_mode.select">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  {PAYMENT_MODES.map((m) => (
                    <SelectItem key={m.value} value={m.value}>
                      {m.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Client */}
            <div className="space-y-1.5">
              <Label>Client (optional)</Label>
              <Select
                value={form.clientId || "none"}
                onValueChange={(v) => set("clientId", v)}
              >
                <SelectTrigger data-ocid="expenses.client.select">
                  <SelectValue placeholder="Select client…" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— None —</SelectItem>
                  {(clients ?? []).map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Invoice */}
            <div className="space-y-1.5">
              <Label>Invoice (optional)</Label>
              <Select
                value={form.invoiceId || "none"}
                onValueChange={handleInvoiceSelect}
              >
                <SelectTrigger data-ocid="expenses.invoice.select">
                  <SelectValue placeholder="Select invoice…" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— None —</SelectItem>
                  {(filteredInvoices ?? []).map((inv) => (
                    <SelectItem key={inv.id} value={inv.id}>
                      {inv.invoiceNumber} — {inv.clientName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Team Member */}
            <div className="space-y-1.5">
              <Label>Team Member (optional)</Label>
              <Select
                value={form.teamMemberId || "none"}
                onValueChange={(v) => set("teamMemberId", v)}
              >
                <SelectTrigger data-ocid="expenses.team_member.select">
                  <SelectValue placeholder="Select team member…" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— None —</SelectItem>
                  {(teamMembers ?? []).map((m) => (
                    <SelectItem key={m.id} value={m.id}>
                      {m.name}
                      {m.role ? ` — ${m.role}` : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Notes */}
            <div className="space-y-1.5">
              <Label htmlFor="exp-notes">Notes</Label>
              <Textarea
                id="exp-notes"
                placeholder="Additional notes…"
                rows={2}
                value={form.notes}
                onChange={(e) => set("notes", e.target.value)}
                data-ocid="expenses.notes.textarea"
              />
            </div>
          </div>
          <DialogFooter className="gap-2 px-6 py-4 border-t shrink-0">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              data-ocid="expenses.cancel_button"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={submitting}
              className="bg-primary text-primary-foreground"
              data-ocid="expenses.submit_button"
            >
              {submitting ? "Saving…" : editing ? "Update" : "Add Expense"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Delete Confirm ───────────────────────────────────────────────────────────

function DeleteConfirm({
  open,
  vendorName,
  onConfirm,
  onCancel,
  isDeleting,
}: {
  open: boolean;
  vendorName: string;
  onConfirm: () => void;
  onCancel: () => void;
  isDeleting: boolean;
}) {
  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) onCancel();
      }}
    >
      <DialogContent
        className="w-[95vw] max-w-sm"
        data-ocid="expenses.delete.dialog"
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display">
            <AlertTriangle className="w-5 h-5 text-destructive" />
            Delete Expense
          </DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">
          Delete{" "}
          <span className="font-semibold text-foreground">{vendorName}</span>?{" "}
          This cannot be undone.
        </p>
        <DialogFooter className="gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            data-ocid="expenses.delete.cancel_button"
          >
            Cancel
          </Button>
          <Button
            type="button"
            variant="destructive"
            disabled={isDeleting}
            onClick={onConfirm}
            data-ocid="expenses.delete.confirm_button"
          >
            {isDeleting ? "Deleting…" : "Delete"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── CSV Export ───────────────────────────────────────────────────────────────

function exportCSV(
  expenses: Expense[],
  clientMap: Map<string, string>,
  invoiceMap: Map<string, string>,
) {
  const header = [
    "Date",
    "Vendor",
    "Category",
    "Amount",
    "Payment Mode",
    "Client",
    "Invoice",
    "Notes",
  ];
  const rows = expenses.map((e) => [
    e.date,
    e.vendor,
    getCategoryLabel(e.category),
    e.amount.toString(),
    e.paymentMode,
    e.clientId ? (clientMap.get(e.clientId) ?? "") : "",
    e.invoiceId ? (invoiceMap.get(e.invoiceId) ?? "") : "",
    e.notes ?? "",
  ]);

  const csv = [header, ...rows]
    .map((row) =>
      row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","),
    )
    .join("\n");

  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `expenses-${new Date().toISOString().split("T")[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function ExpensesPage() {
  const { expenses, clients, invoices, deleteExpense } = useERPStore();

  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState(now.getMonth());
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());
  const [filterCategory, setFilterCategory] = useState("all");

  const [addOpen, setAddOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | undefined>();
  const [deleteTarget, setDeleteTarget] = useState<Expense | undefined>();
  const [isDeleting, setIsDeleting] = useState(false);

  const clientMap = useMemo(
    () => new Map(clients.map((c) => [c.id, c.name])),
    [clients],
  );
  const invoiceMap = useMemo(
    () => new Map(invoices.map((inv) => [inv.id, inv.invoiceNumber])),
    [invoices],
  );
  const clientObjMap = useMemo(
    () => new Map(clients.map((c) => [c.id, c])),
    [clients],
  );
  const invoiceObjMap = useMemo(
    () => new Map(invoices.map((inv) => [inv.id, inv])),
    [invoices],
  );

  // Filter expenses by month/year + category
  const filteredExpenses = useMemo(() => {
    return expenses.filter((e) => {
      const d = new Date(e.date);
      const monthMatch =
        d.getFullYear() === selectedYear && d.getMonth() === selectedMonth;
      const catMatch =
        filterCategory && filterCategory !== "all"
          ? e.category === filterCategory
          : true;
      return monthMatch && catMatch;
    });
  }, [expenses, selectedMonth, selectedYear, filterCategory]);

  // Total for selected month
  const monthTotal = useMemo(() => {
    return expenses
      .filter((e) => {
        const d = new Date(e.date);
        return (
          d.getFullYear() === selectedYear && d.getMonth() === selectedMonth
        );
      })
      .reduce((s, e) => s + (Number(e.amount) || 0), 0);
  }, [expenses, selectedMonth, selectedYear]);

  const filteredTotal = useMemo(
    () => filteredExpenses.reduce((s, e) => s + (Number(e.amount) || 0), 0),
    [filteredExpenses],
  );

  // Category breakdown for chart (month only)
  const categoryBreakdown = useMemo(() => {
    const monthExpenses = expenses.filter((e) => {
      const d = new Date(e.date);
      return d.getFullYear() === selectedYear && d.getMonth() === selectedMonth;
    });
    const map: Record<string, number> = {};
    for (const e of monthExpenses) {
      map[e.category] = (map[e.category] ?? 0) + (Number(e.amount) || 0);
    }
    return Object.entries(map)
      .map(([cat, total]) => ({
        name: getCategoryLabel(cat),
        value: total,
        color: getCategoryColor(cat),
        cat,
      }))
      .sort((a, b) => b.value - a.value);
  }, [expenses, selectedMonth, selectedYear]);

  function handleDelete() {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      deleteExpense(deleteTarget.id);
      toast.success("Expense deleted");
      setDeleteTarget(undefined);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to delete");
    } finally {
      setIsDeleting(false);
    }
  }

  return (
    <AppLayout>
      <div className="space-y-6 pb-20 lg:pb-6" data-ocid="expenses.page">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-display font-bold text-foreground">
              Expenses
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              Track and manage studio expenses
            </p>
          </div>
          <Button
            type="button"
            className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90 self-start sm:self-auto"
            onClick={() => setAddOpen(true)}
            data-ocid="expenses.add_button"
          >
            <PlusCircle className="w-4 h-4" />
            Add Expense
          </Button>
        </div>

        {/* Filters row */}
        <div
          className="flex flex-wrap items-center gap-2 sm:gap-3"
          data-ocid="expenses.filters.section"
        >
          <div className="flex items-center gap-2">
            <Select
              value={selectedMonth.toString()}
              onValueChange={(v) => setSelectedMonth(Number(v))}
            >
              <SelectTrigger className="w-36" data-ocid="expenses.month.select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {MONTHS.map((m) => (
                  <SelectItem key={m.value} value={m.value.toString()}>
                    {m.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={selectedYear.toString()}
              onValueChange={(v) => setSelectedYear(Number(v))}
            >
              <SelectTrigger className="w-24" data-ocid="expenses.year.select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {YEAR_OPTIONS.map((y) => (
                  <SelectItem key={y} value={y.toString()}>
                    {y}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger
              className="w-40"
              data-ocid="expenses.category_filter.select"
            >
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {EXPENSE_CATEGORIES.map((c) => (
                <SelectItem key={c.value} value={c.value}>
                  {c.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Summary cards + chart */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {/* Total card */}
          <Card className="border border-border shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-muted-foreground">
                  Total This Month
                </span>
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <TrendingDown className="w-4 h-4 text-primary" />
                </div>
              </div>
              <p className="text-2xl font-display font-bold text-primary">
                {formatCurrency(monthTotal)}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                {MONTHS[selectedMonth]?.label} {selectedYear}
              </p>
              <div className="flex flex-wrap gap-1.5 mt-3">
                {categoryBreakdown.slice(0, 3).map((cat) => (
                  <span
                    key={cat.cat}
                    className="text-xs px-2 py-0.5 rounded-full font-medium"
                    style={{ background: `${cat.color}20`, color: cat.color }}
                  >
                    {cat.name}: {formatCurrency(cat.value)}
                  </span>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Donut chart */}
          <Card className="border border-border shadow-sm sm:col-span-1 md:col-span-2">
            <CardContent className="p-5">
              <p className="text-sm font-medium text-muted-foreground mb-3">
                Category Breakdown — {MONTHS[selectedMonth]?.label}{" "}
                {selectedYear}
              </p>
              {categoryBreakdown.length === 0 ? (
                <div className="h-32 flex items-center justify-center text-muted-foreground text-sm">
                  No expenses this month
                </div>
              ) : (
                <div className="flex items-center gap-4">
                  <div className="w-32 h-32 flex-shrink-0">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={categoryBreakdown}
                          cx="50%"
                          cy="50%"
                          innerRadius={30}
                          outerRadius={55}
                          paddingAngle={2}
                          dataKey="value"
                        >
                          {categoryBreakdown.map((entry) => (
                            <Cell key={entry.cat} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(val: number) => formatCurrency(val)}
                          contentStyle={{
                            fontSize: 12,
                            borderRadius: 8,
                            border: "1px solid var(--border)",
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex-1 grid grid-cols-2 gap-x-4 gap-y-1.5">
                    {categoryBreakdown.map((cat) => (
                      <div
                        key={cat.cat}
                        className="flex items-center gap-1.5 min-w-0"
                      >
                        <span
                          className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                          style={{ background: cat.color }}
                        />
                        <span className="text-xs text-muted-foreground truncate">
                          {cat.name}
                        </span>
                        <span className="text-xs font-semibold text-foreground ml-auto">
                          {formatCurrency(cat.value)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Monthly totals grouped list */}
        {filteredExpenses.length > 0 &&
          (() => {
            // Group by month within the selected year (all months in filtered view)
            const byMonth: Record<string, Expense[]> = {};
            for (const exp of [...filteredExpenses].sort((a, b) =>
              b.date.localeCompare(a.date),
            )) {
              const d = new Date(exp.date);
              const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
              if (!byMonth[key]) byMonth[key] = [];
              byMonth[key].push(exp);
            }
            const monthKeys = Object.keys(byMonth).sort((a, b) =>
              b.localeCompare(a),
            );
            // Only show monthly subtotals section when showing multi-month data (no month filter active, or all)
            const multiMonth = monthKeys.length > 1;
            if (!multiMonth) return null;
            return (
              <div
                className="rounded-xl border border-border bg-card shadow-sm overflow-hidden"
                data-ocid="expenses.monthly_totals.section"
              >
                <div className="px-5 py-3 border-b border-border bg-muted/40">
                  <p className="text-sm font-semibold text-foreground">
                    Monthly Totals — {selectedYear}
                  </p>
                </div>
                <div className="divide-y divide-border">
                  {monthKeys.map((mk) => {
                    const label = new Date(`${mk}-01`).toLocaleString(
                      "default",
                      { month: "long", year: "numeric" },
                    );
                    const subtotal = byMonth[mk].reduce(
                      (s, e) => s + (Number(e.amount) || 0),
                      0,
                    );
                    return (
                      <div
                        key={mk}
                        className="flex items-center justify-between px-5 py-2.5"
                      >
                        <span className="text-sm text-foreground font-medium">
                          {label}
                        </span>
                        <div className="flex items-center gap-3">
                          <span className="text-xs text-muted-foreground">
                            {byMonth[mk].length} expense
                            {byMonth[mk].length !== 1 ? "s" : ""}
                          </span>
                          <span className="text-sm font-bold text-primary">
                            {formatCurrency(subtotal)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}

        {/* Expense table */}
        {filteredExpenses.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center py-20 text-center rounded-2xl border-2 border-dashed border-border bg-muted/30"
            data-ocid="expenses.empty_state"
          >
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <Receipt className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-lg font-display font-semibold text-foreground mb-2">
              No expenses found
            </h3>
            <p className="text-sm text-muted-foreground max-w-xs mb-6">
              No expenses match the selected filters. Try a different month or
              category.
            </p>
            <Button
              type="button"
              className="bg-primary text-primary-foreground"
              onClick={() => setAddOpen(true)}
              data-ocid="expenses.empty.add_button"
            >
              <PlusCircle className="w-4 h-4 mr-2" />
              Add First Expense
            </Button>
          </div>
        ) : (
          <div className="rounded-2xl border border-border bg-card overflow-hidden shadow-sm">
            {/* Desktop table */}
            <div className="hidden sm:block overflow-x-auto">
              <table className="w-full text-sm min-w-[600px]">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    <th className="text-left font-semibold text-muted-foreground px-5 py-3">
                      Date
                    </th>
                    <th className="text-left font-semibold text-muted-foreground px-4 py-3">
                      Vendor / Description
                    </th>
                    <th className="text-left font-semibold text-muted-foreground px-4 py-3">
                      Category
                    </th>
                    <th className="text-right font-semibold text-muted-foreground px-4 py-3">
                      Amount
                    </th>
                    <th className="text-left font-semibold text-muted-foreground px-4 py-3">
                      Mode
                    </th>
                    <th className="text-left font-semibold text-muted-foreground px-4 py-3">
                      Client
                    </th>
                    <th className="text-left font-semibold text-muted-foreground px-4 py-3">
                      Invoice
                    </th>
                    <th className="text-right font-semibold text-muted-foreground px-5 py-3">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredExpenses.map((exp, idx) => {
                    const client = exp.clientId
                      ? clientObjMap.get(exp.clientId)
                      : undefined;
                    const invoice = exp.invoiceId
                      ? invoiceObjMap.get(exp.invoiceId)
                      : undefined;
                    return (
                      <tr
                        key={exp.id}
                        className="border-b border-border last:border-0 hover:bg-muted/20 transition-colors"
                        data-ocid={`expenses.item.${idx + 1}`}
                      >
                        <td className="px-5 py-3.5 text-muted-foreground whitespace-nowrap">
                          {formatDate(exp.date)}
                        </td>
                        <td className="px-4 py-3.5">
                          <p className="font-semibold text-foreground">
                            {exp.vendor}
                          </p>
                          {exp.notes && (
                            <p className="text-xs text-muted-foreground line-clamp-1">
                              {exp.notes}
                            </p>
                          )}
                        </td>
                        <td className="px-4 py-3.5">
                          <Badge
                            variant="outline"
                            className={`text-xs font-medium ${
                              CATEGORY_BADGE[exp.category as CategoryValue] ??
                              CATEGORY_BADGE.misc
                            }`}
                          >
                            {getCategoryLabel(exp.category)}
                          </Badge>
                        </td>
                        <td className="px-4 py-3.5 text-right font-bold text-primary whitespace-nowrap">
                          {formatCurrency(exp.amount)}
                        </td>
                        <td className="px-4 py-3.5 text-xs text-muted-foreground capitalize">
                          {exp.paymentMode?.replace("_", " ") ?? "—"}
                        </td>
                        <td className="px-4 py-3.5 text-sm">
                          {client ? (
                            <span className="text-foreground font-medium">
                              {client.name}
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="px-4 py-3.5 text-sm">
                          {invoice ? (
                            <span className="text-foreground font-medium">
                              {invoice.invoiceNumber}
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="px-5 py-3.5">
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground hover:text-primary"
                              onClick={() => setEditingExpense(exp)}
                              data-ocid={`expenses.edit_button.${idx + 1}`}
                            >
                              <Edit2 className="w-4 h-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground hover:text-destructive"
                              onClick={() => setDeleteTarget(exp)}
                              data-ocid={`expenses.delete_button.${idx + 1}`}
                            >
                              <Trash2 className="w-4 h-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile cards */}
            <div className="sm:hidden divide-y divide-border">
              {filteredExpenses.map((exp, idx) => {
                const client = exp.clientId
                  ? clientObjMap.get(exp.clientId)
                  : undefined;
                const invoice = exp.invoiceId
                  ? invoiceObjMap.get(exp.invoiceId)
                  : undefined;
                return (
                  <div
                    key={exp.id}
                    className="p-4"
                    data-ocid={`expenses.item.${idx + 1}`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-foreground truncate">
                          {exp.vendor}
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {formatDate(exp.date)}
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="font-bold text-primary text-sm whitespace-nowrap">
                          {formatCurrency(exp.amount)}
                        </span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-muted-foreground hover:text-primary"
                          onClick={() => setEditingExpense(exp)}
                          data-ocid={`expenses.mobile.edit_button.${idx + 1}`}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-muted-foreground hover:text-destructive"
                          onClick={() => setDeleteTarget(exp)}
                          data-ocid={`expenses.mobile.delete_button.${idx + 1}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <Badge
                        variant="outline"
                        className={`text-xs ${
                          CATEGORY_BADGE[exp.category as CategoryValue] ??
                          CATEGORY_BADGE.misc
                        }`}
                      >
                        {getCategoryLabel(exp.category)}
                      </Badge>
                      <span className="text-xs text-muted-foreground capitalize">
                        {exp.paymentMode?.replace("_", " ")}
                      </span>
                      {client && (
                        <span className="text-xs text-muted-foreground">
                          {client.name}
                        </span>
                      )}
                      {invoice && (
                        <span className="text-xs text-muted-foreground">
                          {invoice.invoiceNumber}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom summary bar */}
            <div className="border-t border-border px-3 sm:px-5 py-3 bg-muted/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <p className="text-sm font-medium text-foreground">
                Showing {filteredExpenses.length} expense
                {filteredExpenses.length !== 1 ? "s" : ""} —{" "}
                <span className="text-primary font-bold">
                  {formatCurrency(filteredTotal)}
                </span>
              </p>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="gap-2"
                onClick={() =>
                  exportCSV(filteredExpenses, clientMap, invoiceMap)
                }
                data-ocid="expenses.export_csv_button"
              >
                <Download className="w-4 h-4" />
                Export CSV
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      <ExpenseModal open={addOpen} onClose={() => setAddOpen(false)} />
      {editingExpense && (
        <ExpenseModal
          open={!!editingExpense}
          onClose={() => setEditingExpense(undefined)}
          editing={editingExpense}
        />
      )}
      <DeleteConfirm
        open={!!deleteTarget}
        vendorName={deleteTarget?.vendor ?? ""}
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(undefined)}
        isDeleting={isDeleting}
      />
    </AppLayout>
  );
}
