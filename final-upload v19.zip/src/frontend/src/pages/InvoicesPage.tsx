import AppLayout from "@/components/layout/AppLayout";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  computeInvoiceBalance,
  formatCurrency,
  formatDate,
  getInitials,
  getPaymentStatus,
  getStatusColor,
} from "@/lib/utils";
import { getDeliveryStageLabel } from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { Invoice } from "@/types";
import { EventType } from "@/types";
import { useNavigate } from "@tanstack/react-router";
import {
  CalendarDays,
  Eye,
  FileText,
  LayoutGrid,
  List,
  Pencil,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const EVENT_TYPE_OPTIONS = Object.values(EventType);

const PAYMENT_STATUS_OPTIONS = [
  { value: "all", label: "All Statuses" },
  { value: "paid", label: "Paid" },
  { value: "partial", label: "Partial" },
  { value: "pending", label: "Pending" },
  { value: "overdue", label: "Overdue" },
];

const INVOICE_STATUS_OPTIONS = [
  { value: "all", label: "All" },
  { value: "active", label: "Active" },
  { value: "cancelled", label: "Cancelled" },
];

export default function InvoicesPage() {
  const navigate = useNavigate();
  const { invoices, deleteInvoice } = useERPStore();

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [paymentFilter, setPaymentFilter] = useState("all");
  const [eventTypeFilter, setEventTypeFilter] = useState("all");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const filtered = invoices.filter((inv) => {
    const q = search.toLowerCase();
    const matchSearch =
      !q ||
      inv.clientName.toLowerCase().includes(q) ||
      inv.invoiceNumber.toLowerCase().includes(q);
    const matchStatus = statusFilter === "all" || inv.status === statusFilter;
    const matchPayment =
      paymentFilter === "all" || getPaymentStatus(inv) === paymentFilter;
    const matchEvent =
      eventTypeFilter === "all" || inv.eventType === eventTypeFilter;
    return matchSearch && matchStatus && matchPayment && matchEvent;
  });

  function handleDelete(id: string) {
    try {
      deleteInvoice(id);
      toast.success("Invoice deleted");
      setDeleteId(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed");
    }
  }

  return (
    <AppLayout>
      <div data-ocid="invoices.page" className="space-y-6 pb-20 lg:pb-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-display font-bold text-foreground">
              Invoices
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              {invoices.length} total invoice{invoices.length !== 1 ? "s" : ""}
            </p>
          </div>
          <Button
            data-ocid="invoices.create_button"
            className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2 shrink-0"
            onClick={() => navigate({ to: "/invoices/new" })}
          >
            <Plus className="w-4 h-4" />
            Create Invoice
          </Button>
        </div>

        {/* Filters */}
        <div className="bg-card border border-border rounded-xl p-3 sm:p-4 space-y-3">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1 min-w-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                data-ocid="invoices.search_input"
                placeholder="Search by client or invoice…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 w-full"
              />
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <Button
                type="button"
                variant={viewMode === "grid" ? "secondary" : "ghost"}
                size="icon"
                data-ocid="invoices.grid_toggle"
                onClick={() => setViewMode("grid")}
              >
                <LayoutGrid className="w-4 h-4" />
              </Button>
              <Button
                type="button"
                variant={viewMode === "list" ? "secondary" : "ghost"}
                size="icon"
                data-ocid="invoices.list_toggle"
                onClick={() => setViewMode("list")}
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger
                data-ocid="invoices.status_filter"
                className="w-32 sm:w-36"
              >
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                {INVOICE_STATUS_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={paymentFilter} onValueChange={setPaymentFilter}>
              <SelectTrigger
                data-ocid="invoices.payment_filter"
                className="w-32 sm:w-40"
              >
                <SelectValue placeholder="Payment" />
              </SelectTrigger>
              <SelectContent>
                {PAYMENT_STATUS_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={eventTypeFilter} onValueChange={setEventTypeFilter}>
              <SelectTrigger
                data-ocid="invoices.event_filter"
                className="w-36 sm:w-44"
              >
                <SelectValue placeholder="Event Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Event Types</SelectItem>
                {EVENT_TYPE_OPTIONS.map((e) => (
                  <SelectItem key={e} value={e}>
                    {e}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* List */}
        {filtered.length === 0 ? (
          <div
            data-ocid="invoices.empty_state"
            className="bg-card rounded-xl border border-border p-16 text-center"
          >
            <FileText className="w-14 h-14 text-muted-foreground/40 mx-auto mb-4" />
            <h3 className="font-display font-semibold text-lg text-foreground">
              No invoices found
            </h3>
            <p className="text-sm text-muted-foreground mt-1 mb-6">
              {search ||
              statusFilter !== "all" ||
              paymentFilter !== "all" ||
              eventTypeFilter !== "all"
                ? "Try adjusting your filters"
                : "Create your first invoice to get started"}
            </p>
            {!search &&
              statusFilter === "all" &&
              paymentFilter === "all" &&
              eventTypeFilter === "all" && (
                <Button
                  data-ocid="invoices.empty_create_button"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2"
                  onClick={() => navigate({ to: "/invoices/new" })}
                >
                  <Plus className="w-4 h-4" />
                  Create Invoice
                </Button>
              )}
          </div>
        ) : viewMode === "grid" ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {filtered.map((inv, idx) => (
              <InvoiceCard
                key={inv.id}
                invoice={inv}
                index={idx + 1}
                onView={() => navigate({ to: `/invoices/${inv.id}` })}
                onEdit={() => navigate({ to: `/invoices/${inv.id}/edit` })}
                onDelete={() => setDeleteId(inv.id)}
              />
            ))}
          </div>
        ) : (
          <div className="bg-card rounded-xl border border-border overflow-hidden">
            <div className="overflow-x-auto -mx-0">
              <table className="w-full text-sm" style={{ minWidth: "600px" }}>
                <thead className="bg-muted/40">
                  <tr>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground">
                      Invoice #
                    </th>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground">
                      Client
                    </th>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground hidden md:table-cell">
                      Event
                    </th>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground hidden lg:table-cell">
                      Dates
                    </th>
                    <th className="text-right px-4 py-3 font-semibold text-muted-foreground">
                      Amount
                    </th>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground hidden md:table-cell">
                      Status
                    </th>
                    <th className="text-left px-4 py-3 font-semibold text-muted-foreground hidden lg:table-cell">
                      Delivery
                    </th>
                    <th className="px-4 py-3" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filtered.map((inv, idx) => (
                    <InvoiceRow
                      key={inv.id}
                      invoice={inv}
                      index={idx + 1}
                      onView={() => navigate({ to: `/invoices/${inv.id}` })}
                      onEdit={() =>
                        navigate({ to: `/invoices/${inv.id}/edit` })
                      }
                      onDelete={() => setDeleteId(inv.id)}
                    />
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Delete confirmation */}
        <AlertDialog
          open={!!deleteId}
          onOpenChange={(o) => !o && setDeleteId(null)}
        >
          <AlertDialogContent
            className="max-w-[95vw] sm:max-w-lg max-h-[90vh] overflow-y-auto"
            data-ocid="invoices.delete_dialog"
          >
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Invoice?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. The invoice and all its payment
                history will be permanently deleted.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel data-ocid="invoices.delete_cancel_button">
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction
                data-ocid="invoices.delete_confirm_button"
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={() => deleteId && handleDelete(deleteId)}
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AppLayout>
  );
}

interface InvoiceCardProps {
  invoice: Invoice;
  index: number;
  onView: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

function InvoiceCard({
  invoice,
  index,
  onView,
  onEdit,
  onDelete,
}: InvoiceCardProps) {
  const balance = computeInvoiceBalance(invoice);
  const payStatus = getPaymentStatus(invoice);

  return (
    <div
      data-ocid={`invoices.item.${index}`}
      className="bg-card border border-border rounded-xl p-4 hover:shadow-md transition-shadow duration-200 space-y-3 cursor-pointer"
      onClick={onView}
      onKeyDown={(e) => e.key === "Enter" && onView()}
    >
      <div className="flex items-start justify-between gap-2">
        <span className="font-mono font-bold text-sm text-primary">
          {invoice.invoiceNumber}
        </span>
        <div className="flex items-center gap-1.5">
          {(invoice.status as string) === "cancelled" && (
            <Badge
              variant="outline"
              className="text-[10px] px-1.5 h-5 bg-muted text-muted-foreground"
            >
              Cancelled
            </Badge>
          )}
          <Badge
            variant="outline"
            className={`text-[10px] px-1.5 h-5 capitalize border ${getStatusColor(payStatus)}`}
          >
            {payStatus}
          </Badge>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Avatar className="w-10 h-10 shrink-0">
          <AvatarFallback className="bg-primary/10 text-primary text-sm font-semibold">
            {getInitials(invoice.clientName)}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0">
          <p className="font-semibold text-foreground truncate">
            {invoice.clientName}
          </p>
          {invoice.eventStartDate && (
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
              <CalendarDays className="w-3 h-3" />
              {formatDate(invoice.eventStartDate)}
              {invoice.eventEndDate &&
                invoice.eventEndDate !== invoice.eventStartDate &&
                ` — ${formatDate(invoice.eventEndDate)}`}
            </p>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5">
        {invoice.eventType && (
          <Badge variant="secondary" className="text-[10px] px-2 h-5">
            {invoice.eventType}
          </Badge>
        )}
      </div>

      <div className="pt-2 border-t border-border flex items-center justify-between">
        <div>
          <p className="text-xs text-muted-foreground">Deal Amount</p>
          <p className="font-bold text-foreground whitespace-nowrap">
            {formatCurrency(invoice.dealAmount)}
          </p>
        </div>
        <div className="text-right">
          <p className="text-xs text-muted-foreground">Balance Due</p>
          <p
            className={`font-bold whitespace-nowrap ${balance > 0 ? "text-destructive" : "text-green-600"}`}
          >
            {formatCurrency(balance)}
          </p>
        </div>
      </div>

      <div
        className="flex gap-2"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => e.stopPropagation()}
      >
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="flex-1 gap-1 text-xs h-8"
          data-ocid={`invoices.view_button.${index}`}
          onClick={onView}
        >
          <Eye className="w-3.5 h-3.5" /> View
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="flex-1 gap-1 text-xs h-8"
          data-ocid={`invoices.edit_button.${index}`}
          onClick={onEdit}
        >
          <Pencil className="w-3.5 h-3.5" /> Edit
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="h-8 w-8 p-0 text-destructive hover:text-destructive"
          data-ocid={`invoices.delete_button.${index}`}
          onClick={onDelete}
        >
          <Trash2 className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
}

function InvoiceRow({
  invoice,
  index,
  onView,
  onEdit,
  onDelete,
}: InvoiceCardProps) {
  const balance = computeInvoiceBalance(invoice);
  const payStatus = getPaymentStatus(invoice);

  return (
    <tr
      data-ocid={`invoices.row.${index}`}
      className="hover:bg-muted/30 transition-colors cursor-pointer"
      onClick={onView}
      onKeyDown={(e) => e.key === "Enter" && onView()}
    >
      <td className="px-4 py-3">
        <span className="font-mono font-bold text-sm text-primary">
          {invoice.invoiceNumber}
        </span>
      </td>
      <td className="px-4 py-3">
        <div className="flex items-center gap-2">
          <Avatar className="w-7 h-7 shrink-0">
            <AvatarFallback className="bg-primary/10 text-primary text-xs">
              {getInitials(invoice.clientName)}
            </AvatarFallback>
          </Avatar>
          <span className="font-medium truncate max-w-[140px]">
            {invoice.clientName}
          </span>
        </div>
      </td>
      <td className="px-4 py-3 hidden md:table-cell">
        <Badge variant="secondary" className="text-[10px] px-2 h-5">
          {invoice.eventType}
        </Badge>
      </td>
      <td className="px-4 py-3 hidden lg:table-cell text-muted-foreground text-xs">
        {invoice.eventStartDate ? formatDate(invoice.eventStartDate) : "—"}
      </td>
      <td className="px-4 py-3 text-right">
        <div>
          <p className="font-semibold text-foreground whitespace-nowrap">
            {formatCurrency(invoice.dealAmount)}
          </p>
          {balance > 0 && (
            <p className="text-xs text-destructive">
              Due: {formatCurrency(balance)}
            </p>
          )}
        </div>
      </td>
      <td className="px-4 py-3 hidden md:table-cell">
        <Badge
          variant="outline"
          className={`text-[10px] px-2 h-5 capitalize border ${getStatusColor(payStatus)}`}
        >
          {payStatus}
        </Badge>
      </td>
      <td className="px-4 py-3 hidden lg:table-cell">
        <span className="text-xs text-muted-foreground">—</span>
      </td>
      <td
        className="px-4 py-3"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-1 justify-end">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            data-ocid={`invoices.row_edit.${index}`}
            onClick={onEdit}
          >
            <Pencil className="w-3.5 h-3.5" />
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-destructive"
            data-ocid={`invoices.row_delete.${index}`}
            onClick={onDelete}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      </td>
    </tr>
  );
}
