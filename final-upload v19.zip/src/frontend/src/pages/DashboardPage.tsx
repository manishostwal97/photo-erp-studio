import AppLayout from "@/components/layout/AppLayout";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useDashboardStats } from "@/hooks/useQueries";
import {
  computeInvoiceBalance,
  formatCurrency,
  formatDateShort,
  getDeliveryStageLabel,
  getDeliveryStageProgress,
  getInitials,
  getPaymentStatus,
  getStatusColor,
} from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type { Invoice, TeamMember } from "@/types";
import { useNavigate } from "@tanstack/react-router";
import {
  ArrowUpRight,
  BarChart3,
  Calendar,
  Camera,
  ChevronRight,
  CircleDollarSign,
  Clock,
  CreditCard,
  Eye,
  LayoutGrid,
  List,
  Table2,
  TrendingUp,
  Truck,
  Users,
} from "lucide-react";
import { useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

// ─── View Mode ────────────────────────────────────────────────────────────────
type ViewMode = "cards" | "list" | "table";

function getStoredViewMode(): ViewMode {
  try {
    const v = localStorage.getItem("dashboard_view_mode");
    if (v === "cards" || v === "list" || v === "table") return v;
  } catch {
    /* ignore */
  }
  return "cards";
}

function setStoredViewMode(mode: ViewMode) {
  try {
    localStorage.setItem("dashboard_view_mode", mode);
  } catch {
    /* ignore */
  }
}

// ─── Stat Card ────────────────────────────────────────────────────────────────
interface StatCardProps {
  label: string;
  value: string;
  icon: React.ReactNode;
  iconBg: string;
  sub?: string;
  loading?: boolean;
  ocid: string;
}

function StatCard({
  label,
  value,
  icon,
  iconBg,
  sub,
  loading,
  ocid,
}: StatCardProps) {
  if (loading) {
    return (
      <Card className="rounded-xl shadow-sm border border-border">
        <CardContent className="p-5">
          <div className="flex items-start justify-between">
            <div className="space-y-2 flex-1">
              <Skeleton className="h-4 w-28" />
              <Skeleton className="h-8 w-36" />
              <Skeleton className="h-3 w-20" />
            </div>
            <Skeleton className="w-11 h-11 rounded-full" />
          </div>
        </CardContent>
      </Card>
    );
  }
  return (
    <Card
      className="rounded-xl shadow-sm border border-border"
      data-ocid={ocid}
    >
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="min-w-0 flex-1">
            <p className="text-sm text-muted-foreground font-medium">{label}</p>
            <p className="text-xl sm:text-2xl font-display font-bold text-foreground mt-1 tracking-tight truncate">
              {value}
            </p>
            {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
          </div>
          <div
            className={`w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0 ml-3 ${iconBg}`}
          >
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Payment Status Badge ──────────────────────────────────────────────────────
function PaymentBadge({ invoice }: { invoice: Invoice }) {
  const status = getPaymentStatus(invoice);
  const labels: Record<string, string> = {
    paid: "Paid",
    partial: "Partial",
    pending: "Pending",
    overdue: "Overdue",
  };
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold border ${getStatusColor(status)}`}
    >
      {labels[status]}
    </span>
  );
}

// ─── Event Type Badge ──────────────────────────────────────────────────────────
const EVENT_COLORS: Record<string, string> = {
  Wedding: "bg-pink-100 text-pink-700 border-pink-200",
  "Maternity Shoot": "bg-purple-100 text-purple-700 border-purple-200",
  "Birthday Party": "bg-orange-100 text-orange-700 border-orange-200",
  "Corporate Event": "bg-blue-100 text-blue-700 border-blue-200",
  "Fashion Shoot": "bg-violet-100 text-violet-700 border-violet-200",
  "Pre Wedding": "bg-rose-100 text-rose-700 border-rose-200",
};

function EventBadge({ type }: { type: string }) {
  const cls =
    EVENT_COLORS[type] ??
    "bg-secondary text-secondary-foreground border-border";
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium border ${cls}`}
    >
      {type}
    </span>
  );
}

// ─── Delivery Progress ────────────────────────────────────────────────────────
function DeliveryProgress({ stage }: { stage: string }) {
  const pct = getDeliveryStageProgress(stage);
  const label = getDeliveryStageLabel(stage);
  const color =
    pct === 100
      ? "bg-green-500"
      : pct >= 60
        ? "bg-blue-500"
        : pct >= 30
          ? "bg-yellow-500"
          : "bg-red-400";
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="text-xs font-semibold text-foreground">{pct}%</span>
      </div>
      <div className="h-1.5 rounded-full bg-muted overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${color}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

// ─── Invoice Card (Large Card View) ───────────────────────────────────────────
function InvoiceCard({
  invoice,
  index,
  onView,
  onAddPayment,
}: {
  invoice: Invoice;
  index: number;
  onView: () => void;
  onAddPayment: () => void;
}) {
  const balance = computeInvoiceBalance(invoice);
  return (
    <Card
      className="rounded-xl border border-border shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden"
      data-ocid={`invoice.card.${index}`}
    >
      <CardContent className="p-0">
        <div className="p-4 pb-3">
          <div className="flex items-start gap-3">
            <Avatar className="w-10 h-10 ring-2 ring-primary/10">
              <AvatarImage alt={invoice.clientName} />
              <AvatarFallback className="bg-primary/10 text-primary font-bold text-sm">
                {getInitials(invoice.clientName)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="font-display font-semibold text-foreground truncate">
                {invoice.clientName}
              </p>
              <p className="text-xs text-muted-foreground">
                {invoice.invoiceNumber}
              </p>
            </div>
            <PaymentBadge invoice={invoice} />
          </div>
        </div>

        <div className="px-4 pb-3 flex flex-wrap gap-1.5">
          <EventBadge type={invoice.eventType} />
          {invoice.eventStartDate && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-muted text-muted-foreground border border-border">
              <Calendar className="w-3 h-3" />
              {formatDateShort(invoice.eventStartDate)}
              {invoice.eventEndDate &&
              invoice.eventEndDate !== invoice.eventStartDate
                ? ` – ${formatDateShort(invoice.eventEndDate)}`
                : ""}
            </span>
          )}
        </div>

        <div className="px-4 pb-3">
          <p
            className="text-xl font-display font-bold tracking-tight"
            style={{
              color:
                balance > 0 ? "oklch(var(--primary))" : "oklch(0.55 0.15 145)",
            }}
          >
            {formatCurrency(balance > 0 ? balance : 0)}
          </p>
          <p className="text-xs text-muted-foreground">
            {balance > 0 ? "Balance due" : "Fully paid"}
          </p>
        </div>

        <div className="px-4 pb-3">
          <DeliveryProgress stage={"RAW_BACKUP"} />
        </div>

        <div className="px-4 pb-4 flex gap-2">
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="flex-1 h-8 text-xs"
            onClick={onView}
            data-ocid={`invoice.view_button.${index}`}
          >
            <Eye className="w-3.5 h-3.5 mr-1" />
            View Invoice
          </Button>
          <Button
            type="button"
            size="sm"
            className="flex-1 h-8 text-xs bg-primary hover:bg-primary/90 text-primary-foreground"
            onClick={onAddPayment}
            data-ocid={`invoice.add_payment_button.${index}`}
          >
            <CreditCard className="w-3.5 h-3.5 mr-1" />
            Add Payment
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function InvoiceCardSkeleton() {
  return (
    <Card className="rounded-xl border border-border shadow-sm overflow-hidden">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center gap-3">
          <Skeleton className="w-10 h-10 rounded-full" />
          <div className="flex-1 space-y-1.5">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-3 w-20" />
          </div>
        </div>
        <Skeleton className="h-3 w-24" />
        <Skeleton className="h-6 w-28" />
        <Skeleton className="h-2 w-full rounded-full" />
        <div className="flex gap-2">
          <Skeleton className="h-8 flex-1 rounded-md" />
          <Skeleton className="h-8 flex-1 rounded-md" />
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Chart Helpers ────────────────────────────────────────────────────────────────
function buildMonthlyChartData(invoices: Invoice[]) {
  const now = new Date();
  const months: { name: string; revenue: number; idx: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({
      name: d.toLocaleDateString("en-IN", { month: "short" }),
      revenue: 0,
      idx: i,
    });
  }
  for (const inv of invoices) {
    if (!inv.eventStartDate) continue;
    const d = new Date(inv.eventStartDate);
    if (Number.isNaN(d.getTime())) continue;
    const mIdx = months.findIndex((m) => {
      const ref = new Date(now.getFullYear(), now.getMonth() - m.idx, 1);
      return (
        d.getMonth() === ref.getMonth() && d.getFullYear() === ref.getFullYear()
      );
    });
    if (mIdx >= 0) {
      const paid = inv.paymentHistory.reduce((s, p) => s + p.amount, 0);
      months[mIdx].revenue += paid;
    }
  }
  return months.map(({ name, revenue }) => ({ name, revenue }));
}

function buildEventTypeData(invoices: Invoice[]) {
  const counts: Record<string, number> = {};
  for (const inv of invoices) {
    counts[inv.eventType] = (counts[inv.eventType] ?? 0) + 1;
  }
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([name, value]) => ({ name, value }));
}

const PIE_COLORS = [
  "#DC2626",
  "#2563EB",
  "#D97706",
  "#16A34A",
  "#7C3AED",
  "#DB2777",
];

function RevenueTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ value: number }>;
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg shadow-md px-3 py-2">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-sm font-bold text-foreground">
        {formatCurrency(payload[0].value)}
      </p>
    </div>
  );
}

function EmptyState({ onCreateInvoice }: { onCreateInvoice: () => void }) {
  return (
    <div
      className="col-span-full flex flex-col items-center justify-center py-16 text-center"
      data-ocid="dashboard.empty_state"
    >
      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
        <Camera className="w-8 h-8 text-primary" />
      </div>
      <h3 className="font-display font-semibold text-foreground text-lg mb-2">
        No invoices yet
      </h3>
      <p className="text-muted-foreground text-sm mb-6 max-w-xs">
        Start by creating your first invoice to manage shoots, payments, and
        deliveries.
      </p>
      <Button
        type="button"
        className="bg-primary hover:bg-primary/90 text-primary-foreground"
        onClick={onCreateInvoice}
        data-ocid="dashboard.create_invoice_button"
      >
        Create First Invoice
      </Button>
    </div>
  );
}

// ─── Main Component ────────────────────────────────────────────────────────────
export default function DashboardPage() {
  const [viewMode, setViewMode] = useState<ViewMode>(getStoredViewMode);
  const { invoices, teamMembers: team } = useERPStore();

  // All stats computed from live store — single source of truth
  const { totalRevenue, pendingPayments, monthlyProfit, upcomingShoots } =
    useDashboardStats();

  const statsLoading = false;
  const invoicesLoading = false;
  const teamLoading = false;

  const handleViewMode = (mode: ViewMode) => {
    setViewMode(mode);
    setStoredViewMode(mode);
  };

  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate({ to: path });
  };

  const monthlyData = buildMonthlyChartData(invoices);
  const eventTypeData = buildEventTypeData(invoices);

  const pendingDeliveries = invoices.filter((inv) => inv.status !== "paid");

  const recentInvoices = [...invoices]
    .sort((a, b) => Number(b.createdAt) - Number(a.createdAt))
    .slice(0, 5);

  const availableTeam = team;
  const busyTeam: typeof team = [];

  return (
    <AppLayout>
      <div className="space-y-6 pb-20 lg:pb-6">
        {/* ── Stat Cards ── */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            label="Total Revenue"
            value={formatCurrency(totalRevenue)}
            icon={<CircleDollarSign className="w-5 h-5 text-primary" />}
            iconBg="bg-primary/10"
            sub="All time receipts"
            loading={statsLoading}
            ocid="dashboard.total_revenue.card"
          />
          <StatCard
            label="Pending Payments"
            value={formatCurrency(pendingPayments)}
            icon={<Clock className="w-5 h-5 text-orange-500" />}
            iconBg="bg-orange-50"
            sub="Balances due"
            loading={statsLoading}
            ocid="dashboard.pending_payments.card"
          />
          <StatCard
            label="Upcoming Shoots"
            value={String(upcomingShoots)}
            icon={<Camera className="w-5 h-5 text-blue-500" />}
            iconBg="bg-blue-50"
            sub="Next 7 days"
            loading={statsLoading}
            ocid="dashboard.upcoming_shoots.card"
          />
          <StatCard
            label="Monthly Profit"
            value={formatCurrency(monthlyProfit)}
            icon={<TrendingUp className="w-5 h-5 text-green-500" />}
            iconBg="bg-green-50"
            sub="This month"
            loading={statsLoading}
            ocid="dashboard.monthly_profit.card"
          />
        </div>

        {/* ── View Mode + Invoices ── */}
        <Card className="rounded-xl border border-border shadow-sm">
          <CardHeader className="pb-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <CardTitle className="font-display text-base font-semibold">
                Invoices
              </CardTitle>
              <div className="flex items-center gap-2">
                <div
                  className="flex rounded-lg border border-border overflow-hidden bg-muted p-0.5 gap-0.5"
                  data-ocid="dashboard.view_mode.toggle"
                >
                  {(
                    [
                      {
                        id: "cards" as const,
                        icon: <LayoutGrid className="w-3.5 h-3.5" />,
                        label: "Cards",
                      },
                      {
                        id: "list" as const,
                        icon: <List className="w-3.5 h-3.5" />,
                        label: "List",
                      },
                      {
                        id: "table" as const,
                        icon: <Table2 className="w-3.5 h-3.5" />,
                        label: "Table",
                      },
                    ] as const
                  ).map(({ id, icon, label }) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => handleViewMode(id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                        viewMode === id
                          ? "bg-card text-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                      data-ocid={`dashboard.view_mode.${id}_tab`}
                    >
                      {icon}
                      <span className="hidden sm:inline">{label}</span>
                    </button>
                  ))}
                </div>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  className="h-8 text-xs"
                  onClick={() => handleNavigate("/invoices/new")}
                  data-ocid="dashboard.new_invoice_button"
                >
                  + New Invoice
                </Button>
              </div>
            </div>
          </CardHeader>

          <CardContent className="pt-0">
            {/* Large Card View */}
            {viewMode === "cards" && (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                {invoicesLoading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    // biome-ignore lint/suspicious/noArrayIndexKey: skeleton
                    <InvoiceCardSkeleton key={i} />
                  ))
                ) : invoices.length === 0 ? (
                  <EmptyState
                    onCreateInvoice={() => handleNavigate("/invoices/new")}
                  />
                ) : (
                  invoices
                    .slice(0, 12)
                    .map((inv, i) => (
                      <InvoiceCard
                        key={inv.id}
                        invoice={inv}
                        index={i + 1}
                        onView={() => handleNavigate(`/invoices/${inv.id}`)}
                        onAddPayment={() =>
                          handleNavigate(`/invoices/${inv.id}`)
                        }
                      />
                    ))
                )}
              </div>
            )}

            {/* Compact List View */}
            {viewMode === "list" && (
              <div className="divide-y divide-border">
                {invoicesLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    // biome-ignore lint/suspicious/noArrayIndexKey: skeleton
                    <div key={i} className="py-3 flex items-center gap-3">
                      <Skeleton className="w-8 h-8 rounded-full" />
                      <div className="flex-1 space-y-1">
                        <Skeleton className="h-3 w-32" />
                        <Skeleton className="h-3 w-20" />
                      </div>
                      <Skeleton className="h-6 w-16 rounded-full" />
                      <Skeleton className="h-8 w-8 rounded-md" />
                    </div>
                  ))
                ) : invoices.length === 0 ? (
                  <EmptyState
                    onCreateInvoice={() => handleNavigate("/invoices/new")}
                  />
                ) : (
                  invoices.map((inv, i) => {
                    const balance = computeInvoiceBalance(inv);
                    return (
                      <div
                        key={inv.id}
                        className="py-3 flex items-center gap-3 hover:bg-muted/40 rounded-lg px-2 -mx-2 transition-colors"
                        data-ocid={`invoice.list.item.${i + 1}`}
                      >
                        <Avatar className="w-8 h-8 flex-shrink-0">
                          <AvatarImage />
                          <AvatarFallback className="bg-primary/10 text-primary text-xs font-bold">
                            {getInitials(inv.clientName)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm text-foreground truncate">
                            {inv.clientName}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {inv.invoiceNumber} · {inv.eventType}
                          </p>
                        </div>
                        <div className="hidden sm:block text-xs text-muted-foreground flex-shrink-0">
                          {inv.eventStartDate
                            ? formatDateShort(inv.eventStartDate)
                            : "—"}
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p
                            className={`text-sm font-bold whitespace-nowrap ${
                              balance > 0 ? "text-primary" : "text-green-600"
                            }`}
                          >
                            {formatCurrency(balance > 0 ? balance : 0)}
                          </p>
                          <PaymentBadge invoice={inv} />
                        </div>
                        <Button
                          type="button"
                          size="icon"
                          variant="ghost"
                          className="w-8 h-8 flex-shrink-0"
                          onClick={() => handleNavigate(`/invoices/${inv.id}`)}
                          data-ocid={`invoice.list.view_button.${i + 1}`}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                    );
                  })
                )}
              </div>
            )}

            {/* Table View */}
            {viewMode === "table" && (
              <div className="overflow-x-auto">
                <table className="w-full text-sm min-w-[600px]">
                  <thead>
                    <tr className="border-b border-border">
                      {[
                        "Client",
                        "Invoice #",
                        "Event Type",
                        "Event Dates",
                        "Balance",
                        "Status",
                        "Team",
                        "Delivery",
                        "Actions",
                      ].map((h) => (
                        <th
                          key={h}
                          className="text-left py-3 px-2 text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap"
                        >
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {invoicesLoading ? (
                      Array.from({ length: 5 }).map((_, i) => (
                        // biome-ignore lint/suspicious/noArrayIndexKey: skeleton
                        <tr key={i} className="border-b border-border">
                          {Array.from({ length: 9 }).map((__, j) => (
                            // biome-ignore lint/suspicious/noArrayIndexKey: skeleton
                            <td key={j} className="py-3 px-2">
                              <Skeleton className="h-4 w-full" />
                            </td>
                          ))}
                        </tr>
                      ))
                    ) : invoices.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="py-12 text-center">
                          <EmptyState
                            onCreateInvoice={() =>
                              handleNavigate("/invoices/new")
                            }
                          />
                        </td>
                      </tr>
                    ) : (
                      invoices.map((inv, i) => {
                        const balance = computeInvoiceBalance(inv);
                        return (
                          <tr
                            key={inv.id}
                            className="border-b border-border hover:bg-muted/40 transition-colors"
                            data-ocid={`invoice.table.row.${i + 1}`}
                          >
                            <td className="py-3 px-2">
                              <div className="flex items-center gap-2">
                                <Avatar className="w-7 h-7">
                                  <AvatarImage />
                                  <AvatarFallback className="bg-primary/10 text-primary text-[10px] font-bold">
                                    {getInitials(inv.clientName)}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="font-medium text-foreground whitespace-nowrap">
                                  {inv.clientName}
                                </span>
                              </div>
                            </td>
                            <td className="py-3 px-2 text-muted-foreground font-mono text-xs whitespace-nowrap">
                              {inv.invoiceNumber}
                            </td>
                            <td className="py-3 px-2">
                              <EventBadge type={inv.eventType} />
                            </td>
                            <td className="py-3 px-2 text-muted-foreground text-xs whitespace-nowrap">
                              {inv.eventStartDate
                                ? formatDateShort(inv.eventStartDate)
                                : "—"}
                              {inv.eventEndDate &&
                              inv.eventEndDate !== inv.eventStartDate
                                ? ` – ${formatDateShort(inv.eventEndDate)}`
                                : ""}
                            </td>
                            <td className="py-3 px-2 text-right">
                              <span
                                className={`font-bold whitespace-nowrap ${
                                  balance > 0
                                    ? "text-primary"
                                    : "text-green-600"
                                }`}
                              >
                                {formatCurrency(balance > 0 ? balance : 0)}
                              </span>
                            </td>
                            <td className="py-3 px-2">
                              <PaymentBadge invoice={inv} />
                            </td>
                            <td className="py-3 px-2">
                              <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                                <Users className="w-3.5 h-3.5" />
                                {inv.teamAssignments?.length ?? 0}
                              </span>
                            </td>
                            <td className="py-3 px-2 min-w-[120px]">
                              <DeliveryProgress stage={"RAW_BACKUP"} />
                            </td>
                            <td className="py-3 px-2">
                              <Button
                                type="button"
                                size="sm"
                                variant="ghost"
                                className="h-7 px-2 text-xs"
                                onClick={() =>
                                  handleNavigate(`/invoices/${inv.id}`)
                                }
                                data-ocid={`invoice.table.view_button.${i + 1}`}
                              >
                                <Eye className="w-3.5 h-3.5 mr-1" />
                                View
                              </Button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* ── Charts Row ── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Monthly Revenue Bar Chart */}
          <Card
            className="rounded-xl border border-border shadow-sm lg:col-span-2"
            data-ocid="dashboard.revenue_chart.card"
          >
            <CardHeader className="pb-2">
              <CardTitle className="font-display text-base font-semibold flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-primary" />
                Monthly Revenue
              </CardTitle>
            </CardHeader>
            <CardContent>
              {invoicesLoading ? (
                <Skeleton className="h-48 w-full rounded-lg" />
              ) : (
                <div className="overflow-x-auto w-full">
                  <ResponsiveContainer width="100%" height={200} minWidth={320}>
                    <BarChart
                      data={monthlyData}
                      margin={{ top: 4, right: 4, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="oklch(0.9 0.01 0)"
                        vertical={false}
                      />
                      <XAxis
                        dataKey="name"
                        tick={{ fontSize: 11, fill: "oklch(0.5 0 0)" }}
                        axisLine={false}
                        tickLine={false}
                      />
                      <YAxis
                        tick={{ fontSize: 10, fill: "oklch(0.5 0 0)" }}
                        axisLine={false}
                        tickLine={false}
                        tickFormatter={(v: number) =>
                          `₹${(v / 1000).toFixed(0)}k`
                        }
                      />
                      <Tooltip content={<RevenueTooltip />} />
                      <Bar
                        dataKey="revenue"
                        fill="#DC2626"
                        radius={[4, 4, 0, 0]}
                        maxBarSize={40}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Event Type Distribution */}
          <Card
            className="rounded-xl border border-border shadow-sm"
            data-ocid="dashboard.event_distribution.card"
          >
            <CardHeader className="pb-2">
              <CardTitle className="font-display text-base font-semibold flex items-center gap-2">
                <Camera className="w-4 h-4 text-primary" />
                Event Types
              </CardTitle>
            </CardHeader>
            <CardContent>
              {invoicesLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    // biome-ignore lint/suspicious/noArrayIndexKey: skeleton
                    <Skeleton key={i} className="h-6 w-full" />
                  ))}
                </div>
              ) : eventTypeData.length === 0 ? (
                <div className="flex items-center justify-center h-40 text-muted-foreground text-sm">
                  No events yet
                </div>
              ) : (
                <div className="space-y-2">
                  {eventTypeData.map((item, i) => {
                    const total = eventTypeData.reduce(
                      (s, x) => s + x.value,
                      0,
                    );
                    const pct =
                      total > 0 ? Math.round((item.value / total) * 100) : 0;
                    return (
                      <div key={item.name} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-foreground font-medium truncate max-w-[130px]">
                            {item.name}
                          </span>
                          <span className="text-muted-foreground">
                            {item.value} ({pct}%)
                          </span>
                        </div>
                        <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{
                              width: `${pct}%`,
                              backgroundColor:
                                PIE_COLORS[i % PIE_COLORS.length],
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ── Bottom Row ── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Recent Activity */}
          <Card
            className="rounded-xl border border-border shadow-sm"
            data-ocid="dashboard.recent_activity.card"
          >
            <CardHeader className="pb-2">
              <CardTitle className="font-display text-base font-semibold flex items-center gap-2">
                <ArrowUpRight className="w-4 h-4 text-primary" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {invoicesLoading ? (
                <div className="space-y-3">
                  {Array.from({ length: 4 }).map((_, i) => (
                    // biome-ignore lint/suspicious/noArrayIndexKey: skeleton
                    <div key={i} className="flex gap-2">
                      <Skeleton className="w-7 h-7 rounded-full flex-shrink-0" />
                      <div className="flex-1 space-y-1">
                        <Skeleton className="h-3 w-full" />
                        <Skeleton className="h-3 w-16" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : recentInvoices.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6">
                  No recent activity
                </p>
              ) : (
                <div className="space-y-1">
                  {recentInvoices.map((inv, i) => {
                    const balance = computeInvoiceBalance(inv);
                    return (
                      <button
                        key={inv.id}
                        type="button"
                        className="w-full flex items-center gap-3 py-2.5 px-2 rounded-lg hover:bg-muted/50 transition-colors text-left"
                        onClick={() => handleNavigate(`/invoices/${inv.id}`)}
                        data-ocid={`dashboard.recent.item.${i + 1}`}
                      >
                        <Avatar className="w-7 h-7 flex-shrink-0">
                          <AvatarImage />
                          <AvatarFallback className="bg-primary/10 text-primary text-[10px] font-bold">
                            {getInitials(inv.clientName)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">
                            {inv.clientName}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {inv.invoiceNumber}
                          </p>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p
                            className={`text-xs font-bold whitespace-nowrap ${
                              balance > 0 ? "text-primary" : "text-green-600"
                            }`}
                          >
                            {formatCurrency(balance > 0 ? balance : 0)}
                          </p>
                          <PaymentBadge invoice={inv} />
                        </div>
                      </button>
                    );
                  })}
                  <Button
                    type="button"
                    variant="ghost"
                    className="w-full h-8 text-xs text-primary hover:text-primary mt-1"
                    onClick={() => handleNavigate("/invoices")}
                    data-ocid="dashboard.view_all_invoices_button"
                  >
                    View all invoices{" "}
                    <ChevronRight className="w-3.5 h-3.5 ml-1" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Pending Deliveries */}
          <Card
            className="rounded-xl border border-border shadow-sm"
            data-ocid="dashboard.pending_deliveries.card"
          >
            <CardHeader className="pb-2">
              <CardTitle className="font-display text-base font-semibold flex items-center gap-2">
                <Truck className="w-4 h-4 text-primary" />
                Pending Deliveries
                {!invoicesLoading && pendingDeliveries.length > 0 && (
                  <Badge variant="secondary" className="ml-auto text-xs">
                    {pendingDeliveries.length}
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {invoicesLoading ? (
                <div className="space-y-3">
                  {Array.from({ length: 4 }).map((_, i) => (
                    // biome-ignore lint/suspicious/noArrayIndexKey: skeleton
                    <div key={i} className="space-y-1.5">
                      <Skeleton className="h-3 w-32" />
                      <Skeleton className="h-2 w-full rounded-full" />
                    </div>
                  ))}
                </div>
              ) : pendingDeliveries.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center mb-2">
                    <Truck className="w-5 h-5 text-green-500" />
                  </div>
                  <p className="text-sm font-medium text-foreground">
                    All caught up!
                  </p>
                  <p className="text-xs text-muted-foreground">
                    No pending deliveries
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {pendingDeliveries.slice(0, 6).map((inv, i) => (
                    <button
                      key={inv.id}
                      type="button"
                      className="w-full text-left hover:bg-muted/50 rounded-lg px-2 py-2 transition-colors"
                      onClick={() => handleNavigate(`/invoices/${inv.id}`)}
                      data-ocid={`dashboard.delivery.item.${i + 1}`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <p className="text-sm font-medium text-foreground truncate max-w-[160px]">
                          {inv.clientName}
                        </p>
                        <span className="text-xs text-muted-foreground flex-shrink-0 ml-2">
                          {getDeliveryStageLabel("RAW_BACKUP")}
                        </span>
                      </div>
                      <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all"
                          style={{
                            width: `${getDeliveryStageProgress("RAW_BACKUP")}%`,
                            backgroundColor:
                              getDeliveryStageProgress("RAW_BACKUP") >= 60
                                ? "#2563EB"
                                : "#DC2626",
                          }}
                        />
                      </div>
                    </button>
                  ))}
                  {pendingDeliveries.length > 6 && (
                    <Button
                      type="button"
                      variant="ghost"
                      className="w-full h-8 text-xs text-primary hover:text-primary"
                      onClick={() => handleNavigate("/delivery")}
                      data-ocid="dashboard.view_all_deliveries_button"
                    >
                      +{pendingDeliveries.length - 6} more{" "}
                      <ChevronRight className="w-3.5 h-3.5 ml-1" />
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Team Availability */}
          <Card
            className="rounded-xl border border-border shadow-sm"
            data-ocid="dashboard.team_availability.card"
          >
            <CardHeader className="pb-2">
              <CardTitle className="font-display text-base font-semibold flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" />
                Team Availability
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {teamLoading ? (
                <div className="space-y-3">
                  {Array.from({ length: 4 }).map((_, i) => (
                    // biome-ignore lint/suspicious/noArrayIndexKey: skeleton
                    <div key={i} className="flex items-center gap-2">
                      <Skeleton className="w-8 h-8 rounded-full" />
                      <div className="flex-1 space-y-1">
                        <Skeleton className="h-3 w-24" />
                        <Skeleton className="h-3 w-14" />
                      </div>
                      <Skeleton className="h-5 w-14 rounded-full" />
                    </div>
                  ))}
                </div>
              ) : team.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                    <Users className="w-5 h-5 text-primary" />
                  </div>
                  <p className="text-sm font-medium text-foreground">
                    No team members
                  </p>
                  <Button
                    type="button"
                    variant="link"
                    className="text-xs text-primary p-0 h-auto mt-1"
                    onClick={() => handleNavigate("/team")}
                    data-ocid="dashboard.add_team_member_link"
                  >
                    Add team members
                  </Button>
                </div>
              ) : (
                <div className="space-y-1">
                  <div className="flex gap-2 mb-3">
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-50 border border-green-200">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                      <span className="text-xs font-medium text-green-700">
                        {availableTeam.length} Available
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-orange-50 border border-orange-200">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />
                      <span className="text-xs font-medium text-orange-700">
                        {busyTeam.length} Busy
                      </span>
                    </div>
                  </div>
                  {team.slice(0, 6).map((member, i) => {
                    const isAvailable = true;
                    return (
                      <div
                        key={member.id}
                        className="flex items-center gap-2.5 py-2"
                        data-ocid={`dashboard.team.item.${i + 1}`}
                      >
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={member.photo} />
                          <AvatarFallback className="bg-secondary text-secondary-foreground text-xs font-semibold">
                            {getInitials(member.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">
                            {member.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {member.role}
                          </p>
                        </div>
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
                            isAvailable
                              ? "bg-green-50 text-green-700 border-green-200"
                              : "bg-orange-50 text-orange-700 border-orange-200"
                          }`}
                        >
                          {isAvailable ? "Available" : "Busy"}
                        </span>
                      </div>
                    );
                  })}
                  {team.length > 6 && (
                    <Button
                      type="button"
                      variant="ghost"
                      className="w-full h-8 text-xs text-primary hover:text-primary mt-1"
                      onClick={() => handleNavigate("/team")}
                      data-ocid="dashboard.view_all_team_button"
                    >
                      View all team{" "}
                      <ChevronRight className="w-3.5 h-3.5 ml-1" />
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
