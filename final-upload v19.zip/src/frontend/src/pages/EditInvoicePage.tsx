import AppLayout from "@/components/layout/AppLayout";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { formatCurrency, getMinimumAdvance, safeNumber } from "@/lib/utils";
import { useERPStore } from "@/stores/useAppStore";
import type {
  Client,
  Invoice,
  InvoiceService,
  Package,
  PackageExtraCharge,
  Service,
  TeamMember,
  WeddingProgram,
} from "@/types";
import { EventType } from "@/types";
import { useNavigate, useParams } from "@tanstack/react-router";
import { ChevronLeft, Package2, Plus, Trash2, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
const EVENT_TYPES = Object.values(EventType);

const WEDDING_PROGRAMS = [
  "Mata Ji Pujan",
  "Ganesh Pujan / Chak",
  "Haldi",
  "Mehendi",
  "Sangeet / DJ Night",
  "Wedding / Fere",
  "Reception",
  "Gangoj",
  "Mamera",
  "Bindoli / Procession",
  "Barat",
];

type WeddingProgramState = WeddingProgram;

function initWeddingPrograms(
  existing: WeddingProgram[],
): WeddingProgramState[] {
  // Start with the existing array in its original order (preserves custom programs too)
  const result: WeddingProgramState[] = existing.map((p) => ({
    ...p,
    enabled: true,
  }));
  // Append any WEDDING_PROGRAMS presets not already present
  for (const name of WEDDING_PROGRAMS) {
    if (!result.some((p) => p.name === name)) {
      result.push({
        id: name,
        name,
        enabled: false,
        date: "",
        startTime: "",
        endTime: "",
        location: "",
        notes: "",
      });
    }
  }
  return result;
}

interface ServiceRow {
  serviceId: string;
  name: string;
  category: string;
  unitPrice: number;
  quantity: number;
  total: number;
  notes: string;
  enabled: boolean;
}

function buildServiceRow(s: Service, existing?: InvoiceService): ServiceRow {
  if (existing) {
    return {
      serviceId: s.id,
      name: s.name,
      category: s.category,
      unitPrice: existing.unitPrice,
      quantity: existing.quantity,
      total: existing.total,
      notes: existing.notes ?? "",
      enabled: true,
    };
  }
  return {
    serviceId: s.id,
    name: s.name,
    category: s.category,
    unitPrice: s.price,
    quantity: 1,
    total: s.price,
    notes: "",
    enabled: false,
  };
}

export default function EditInvoicePage() {
  const { invoiceId } = useParams({ strict: false }) as { invoiceId: string };
  const navigate = useNavigate();
  const {
    invoices,
    clients,
    services: allServicesRaw,
    packages,
    teamMembers,
    updateInvoice,
  } = useERPStore();

  const invoice = invoices.find((i) => i.id === invoiceId) ?? null;
  const allServices = allServicesRaw;
  const loadingInvoice = false;

  // Form state
  const [clientSearch, setClientSearch] = useState("");
  const [selectedClientId, setSelectedClientId] = useState("");
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [clientWhatsapp, setClientWhatsapp] = useState("");
  const [eventStartDate, setEventStartDate] = useState("");
  const [eventEndDate, setEventEndDate] = useState("");
  const [city, setCity] = useState("");
  const [address, setAddress] = useState("");
  const [venueName, setVenueName] = useState("");
  const [venueAddress, setVenueAddress] = useState("");
  const [eventType, setEventType] = useState("");
  const [weddingPrograms, setWeddingPrograms] = useState<WeddingProgramState[]>(
    () => initWeddingPrograms([]),
  );
  const [customPrograms, setCustomPrograms] = useState<
    Array<{
      name: string;
      date: string;
      time: string;
      notes: string;
      _k: number;
    }>
  >([]);
  const [serviceRows, setServiceRows] = useState<ServiceRow[]>([]);
  const [customServices, setCustomServices] = useState<
    Array<InvoiceService & { _k: number }>
  >([]);
  const [dealAmount, setDealAmount] = useState(0);
  const [discount, setDiscount] = useState(0);
  const [advancePaid, setAdvancePaid] = useState(0);
  const [paymentNotes, setPaymentNotes] = useState("");
  const [terms, setTerms] = useState("");
  const [initialized, setInitialized] = useState(false);

  const [selectedPackageId, setSelectedPackageId] = useState("");
  const [packageExtraCharges, setPackageExtraCharges] = useState<
    PackageExtraCharge[]
  >([]);
  const [gstEnabled, setGstEnabled] = useState(false);
  const [installments, setInstallments] = useState<
    Array<{ label: string; date: string; amount: number; isPaid: boolean }>
  >([]);

  const gstPct = 18;
  const [selectedTeam, setSelectedTeam] = useState<string[]>([]);

  // Pre-fill form when invoice loads
  useEffect(() => {
    if (invoice && !initialized) {
      setSelectedClientId(invoice.clientId ?? "");
      setClientName(invoice.clientName);
      setClientPhone(invoice.clientPhone ?? "");
      setClientWhatsapp(invoice.clientWhatsapp ?? "");
      setEventStartDate(invoice.eventStartDate);
      setEventEndDate(invoice.eventEndDate ?? "");
      setCity(invoice.clientCity ?? "");
      setAddress(invoice.clientAddress ?? "");
      setVenueName(invoice.eventVenueName ?? "");
      setVenueAddress(invoice.eventVenueAddress ?? "");
      setEventType(invoice.eventType);
      setWeddingPrograms(initWeddingPrograms(invoice.programs ?? []));
      setCustomPrograms([]);
      setDealAmount(invoice.dealAmount);
      setDiscount(invoice.discount ?? 0);
      setAdvancePaid(invoice.advancePaid);
      setPaymentNotes(invoice.notes ?? "");
      setTerms(invoice.termsAndConditions ?? "");
      setSelectedTeam(
        (invoice.teamAssignments ?? []).map((a) => a.teamMemberId),
      );
      setSelectedPackageId(invoice.packageId ?? "");
      setGstEnabled(invoice.gstEnabled ?? false);
      setPackageExtraCharges(invoice.packageExtraCharges ?? []);

      // Merge catalog services with existing invoice services
      const invoiceSvcMap = new Map<string, InvoiceService>();
      for (const svc of invoice.services) {
        if (svc.serviceId) invoiceSvcMap.set(svc.serviceId, svc);
      }
      const rows = allServices.map((s) =>
        buildServiceRow(s, invoiceSvcMap.get(s.id)),
      );

      // Custom services (no serviceId)
      const customSvcs = invoice.services
        .filter((s) => !s.serviceId)
        .map((s, i) => ({ ...s, _k: i }));
      setServiceRows(rows);
      setCustomServices(customSvcs);
      setInitialized(true);
    }
  }, [invoice, allServices, initialized]);

  function handlePackageSelect(pkgId: string) {
    const realId = pkgId === "no-package" ? "" : pkgId;
    setSelectedPackageId(realId);
    setPackageExtraCharges([]);
    if (!realId) return;
    const pkg = packages.find((p) => p.id === realId);
    if (pkg && pkg.basePrice > 0) setDealAmount(pkg.basePrice);
  }

  function handleClientSelect(id: string) {
    setSelectedClientId(id);
    const client = clients.find((c) => c.id === id);
    if (client) {
      setClientName(client.name);
      setClientPhone(client.phone);
      setClientWhatsapp(client.whatsapp ?? "");
      setCity(client.city ?? "");
      setAddress(client.address ?? "");
      setVenueName(client.eventVenueName ?? "");
      setVenueAddress(client.eventVenueAddress ?? "");
    }
  }

  const enabledServices: InvoiceService[] = useMemo(() => {
    const fromCatalog = serviceRows
      .filter((r) => r.enabled)
      .map(
        (r): InvoiceService => ({
          serviceId: r.serviceId,
          name: r.name,
          category: r.category,
          unitPrice: r.unitPrice,
          quantity: r.quantity,
          total: r.quantity * r.unitPrice,
          notes: r.notes,
        }),
      );
    return [...fromCatalog, ...customServices];
  }, [serviceRows, customServices]);

  const extraChargesTotal = packageExtraCharges.reduce(
    (s, c) => s + safeNumber(c.extraTotal),
    0,
  );
  const servicesTotal = enabledServices.reduce(
    (s, r) => s + safeNumber(r.total),
    0,
  );
  const subtotal =
    safeNumber(dealAmount) -
    safeNumber(discount) +
    safeNumber(extraChargesTotal);
  const gstAmount = gstEnabled ? subtotal * (safeNumber(gstPct) / 100) : 0;
  const grandTotal = safeNumber(subtotal) + safeNumber(gstAmount);
  const balance = safeNumber(grandTotal) - safeNumber(advancePaid);
  const minAdvance = getMinimumAdvance(grandTotal);

  useEffect(() => {
    if (dealAmount > 0 && eventStartDate) {
      const adv = Math.max(grandTotal * 0.5, 20000);
      const remaining = grandTotal - adv;
      const half = Math.ceil(remaining / 2);
      const startMs = new Date(eventStartDate).getTime();
      const endD = eventEndDate
        ? new Date(eventEndDate)
        : new Date(eventStartDate);
      const midMs = Math.round((startMs + endD.getTime()) / 2);
      const secondDue = new Date(midMs > startMs ? midMs : startMs)
        .toISOString()
        .split("T")[0];
      const thirdDate = new Date(endD);
      thirdDate.setMonth(thirdDate.getMonth() + 1);
      setInstallments([
        {
          label: "Advance (1st)",
          date: new Date().toISOString().split("T")[0],
          amount: adv,
          isPaid: advancePaid >= adv,
        },
        {
          label: "2nd Installment",
          date: secondDue,
          amount: half,
          isPaid: false,
        },
        {
          label: "3rd Installment (Final)",
          date: thirdDate.toISOString().split("T")[0],
          amount: remaining - half,
          isPaid: false,
        },
      ]);
    } else {
      setInstallments([]);
    }
  }, [grandTotal, advancePaid, eventStartDate, eventEndDate, dealAmount]);

  function updateWeddingProgram(
    index: number,
    field: keyof WeddingProgram,
    value: string | boolean,
  ) {
    setWeddingPrograms((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  }

  function addCustomProgram() {
    setCustomPrograms((prev) => [
      ...prev,
      { name: "", date: "", time: "", notes: "", _k: ++editKeyRef.current },
    ]);
  }
  function updateCustomProgram(
    i: number,
    field: "name" | "date" | "time" | "notes",
    value: string,
  ) {
    setCustomPrograms((prev) => {
      const u = [...prev];
      u[i] = { ...u[i], [field]: value };
      return u;
    });
  }
  function removeCustomProgram(i: number) {
    setCustomPrograms((prev) => prev.filter((_, idx) => idx !== i));
  }

  function updateServiceRow(
    i: number,
    field: keyof ServiceRow,
    value: number | string | boolean,
  ) {
    setServiceRows((prev) => {
      const u = [...prev];
      const row = { ...u[i], [field]: value };
      row.total = row.quantity * row.unitPrice;
      u[i] = row;
      return u;
    });
  }

  function addCustomService() {
    setCustomServices((prev) => [
      ...prev,
      {
        name: "",
        category: "",
        unitPrice: 0,
        quantity: 1,
        total: 0,
        notes: "",
        _k: ++editKeyRef.current,
      },
    ]);
  }
  function updateCustomService(
    i: number,
    field: keyof InvoiceService,
    value: number | string,
  ) {
    setCustomServices((prev) => {
      const u = [...prev];
      const row = { ...u[i], [field]: value };
      row.total = Number(row.quantity) * Number(row.unitPrice);
      u[i] = row;
      return u;
    });
  }
  function removeCustomService(i: number) {
    setCustomServices((prev) => prev.filter((_, idx) => idx !== i));
  }

  function toggleTeam(id: string) {
    setSelectedTeam((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  }

  const [isSaving, setIsSaving] = useState(false);

  function handleSubmit() {
    if (!invoice) return;
    if (!clientName.trim()) {
      toast.error("Client name is required");
      return;
    }
    if (!eventType) {
      toast.error("Event type is required");
      return;
    }
    if (grandTotal < 0 || !Number.isFinite(grandTotal)) {
      toast.error(
        "Grand total cannot be negative or invalid. Check deal amount and discount.",
      );
      return;
    }
    for (const inst of installments) {
      if (!Number.isFinite(inst.amount) || inst.amount < 0) {
        toast.error(
          "One or more installment amounts are invalid. Check payment schedule.",
        );
        return;
      }
    }

    setIsSaving(true);
    try {
      const now = new Date().toISOString();
      const teamAssignments = selectedTeam.map((id) => {
        const m = teamMembers.find((t) => t.id === id);
        return {
          teamMemberId: id,
          teamMemberName: m?.name ?? id,
        };
      });
      updateInvoice(invoice.id, {
        clientId: selectedClientId || invoice.clientId,
        clientName: clientName.trim(),
        clientPhone,
        clientWhatsapp,
        clientCity: city,
        clientAddress: address,
        eventVenueName: venueName,
        eventVenueAddress: venueAddress,
        eventType,
        eventStartDate,
        eventEndDate,
        programs:
          eventType === EventType.WEDDING
            ? weddingPrograms.filter((p) => p.enabled)
            : [],
        services: enabledServices,
        teamAssignments,
        dealAmount,
        discount,
        subtotal,
        gstEnabled,
        gstPercent: gstEnabled ? gstPct : 0,
        gstAmount: gstEnabled ? gstAmount : 0,
        totalAmount: grandTotal,
        advancePaid,
        pendingAmount: balance,
        packageId: selectedPackageId || undefined,
        packageName: packages.find((p) => p.id === selectedPackageId)?.name,
        packageExtraCharges,
        notes: paymentNotes,
        termsAndConditions: terms,
        updatedAt: now,
      });
      toast.success("Invoice updated!");
      navigate({ to: `/invoices/${invoice.id}` });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to update");
    } finally {
      setIsSaving(false);
    }
  }

  const editKeyRef = useRef(0);

  const filteredClients = clients.filter((c) =>
    c.name.toLowerCase().includes(clientSearch.toLowerCase()),
  );

  if (loadingInvoice || (invoice && !initialized)) {
    return (
      <AppLayout>
        <div className="max-w-4xl mx-auto space-y-4">
          <Skeleton className="h-10 w-48" />
          {Array.from({ length: 4 }).map((_, i) => (
            // biome-ignore lint/suspicious/noArrayIndexKey: skeletons
            <Skeleton key={i} className="h-40 w-full rounded-xl" />
          ))}
        </div>
      </AppLayout>
    );
  }

  if (!invoice) {
    return (
      <AppLayout>
        <div className="max-w-4xl mx-auto text-center py-20">
          <h3 className="font-display font-bold text-xl text-foreground">
            Invoice not found
          </h3>
          <Button
            className="mt-4"
            onClick={() => navigate({ to: "/invoices" })}
          >
            Back to Invoices
          </Button>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div
        data-ocid="edit_invoice.page"
        className="max-w-4xl mx-auto space-y-6 pb-12"
      >
        <div className="flex items-center gap-3">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="gap-1"
            data-ocid="edit_invoice.back_button"
            onClick={() => navigate({ to: `/invoices/${invoiceId}` })}
          >
            <ChevronLeft className="w-4 h-4" /> Back
          </Button>
          <div>
            <h2 className="text-2xl font-display font-bold text-foreground">
              Edit Invoice
            </h2>
            <p className="text-sm text-muted-foreground">
              {invoice.invoiceNumber}
            </p>
          </div>
        </div>

        {/* SECTION 1: Client Info */}
        <FormSection title="Client Information" number={1}>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>Search & Replace Client (optional)</Label>
              <div className="relative">
                <Input
                  data-ocid="edit_invoice.client_search_input"
                  placeholder="Search clients…"
                  value={clientSearch}
                  onChange={(e) => setClientSearch(e.target.value)}
                />
              </div>
              {clientSearch && filteredClients.length > 0 && (
                <div className="border border-border rounded-lg bg-card shadow-lg max-h-48 overflow-y-auto">
                  {filteredClients.map((c) => (
                    <button
                      type="button"
                      key={c.id}
                      className="w-full text-left px-4 py-2.5 hover:bg-muted/50 flex items-center gap-3 transition-colors"
                      onClick={() => {
                        handleClientSelect(c.id);
                        setClientSearch("");
                      }}
                    >
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold">
                        {c.name.slice(0, 1).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{c.name}</p>
                        <p className="text-xs text-muted-foreground">
                          <p className="text-xs text-muted-foreground">
                            {c.phone}
                          </p>
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Client Name *</Label>
                <Input
                  data-ocid="edit_invoice.client_name_input"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Phone Number</Label>
                <Input
                  data-ocid="edit_invoice.phone_input"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label>WhatsApp Number</Label>
                <Input
                  data-ocid="edit_invoice.whatsapp_input"
                  value={clientWhatsapp}
                  onChange={(e) => setClientWhatsapp(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Event Start Date</Label>
                <Input
                  type="date"
                  data-ocid="edit_invoice.start_date_input"
                  value={eventStartDate}
                  onChange={(e) => setEventStartDate(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Event End Date</Label>
                <Input
                  type="date"
                  data-ocid="edit_invoice.end_date_input"
                  value={eventEndDate}
                  onChange={(e) => setEventEndDate(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label>City</Label>
                <Input
                  data-ocid="edit_invoice.city_input"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Full Address</Label>
              <Textarea
                data-ocid="edit_invoice.address_input"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                rows={2}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Event Venue Name</Label>
                <Input
                  data-ocid="edit_invoice.venue_name_input"
                  placeholder="Wedding hall / venue name"
                  value={venueName}
                  onChange={(e) => setVenueName(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Venue Address</Label>
                <Input
                  data-ocid="edit_invoice.venue_address_input"
                  placeholder="Venue address"
                  value={venueAddress}
                  onChange={(e) => setVenueAddress(e.target.value)}
                />
              </div>
            </div>
          </div>
        </FormSection>

        {/* SECTION 2: Package */}
        <FormSection title="Package" number={2}>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Select Package (optional)</Label>
              <Select
                value={selectedPackageId}
                onValueChange={handlePackageSelect}
              >
                <SelectTrigger data-ocid="edit_invoice.package_select">
                  <SelectValue placeholder="No package" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="no-package">
                    No package — custom pricing
                  </SelectItem>
                  {packages.map((pkg) => (
                    <SelectItem key={pkg.id} value={pkg.id}>
                      {pkg.name} — {formatCurrency(pkg.basePrice)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {selectedPackageId &&
              packages.find((p) => p.id === selectedPackageId) && (
                <div className="bg-primary/5 border border-primary/20 rounded-lg p-3 flex items-center gap-3">
                  <Package2 className="w-4 h-4 text-primary shrink-0" />
                  <span className="flex-1 text-sm font-medium">
                    {packages.find((p) => p.id === selectedPackageId)?.name}
                  </span>
                  <button
                    type="button"
                    onClick={() => handlePackageSelect("no-package")}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            {packageExtraCharges.length > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 space-y-1">
                <p className="text-xs font-semibold text-amber-700 uppercase">
                  Extra Charges
                </p>
                {packageExtraCharges.map((c, i) => (
                  // biome-ignore lint/suspicious/noArrayIndexKey: order-stable
                  <div key={i} className="flex justify-between text-sm">
                    <span>
                      {(
                        c as {
                          ruleName?: string;
                          serviceName?: string;
                          actualQuantity: number;
                        }
                      ).ruleName ??
                        (
                          c as {
                            ruleName?: string;
                            serviceName?: string;
                            actualQuantity: number;
                          }
                        ).serviceName}
                      : {Number(c.actualQuantity)} used
                    </span>
                    <span className="font-semibold text-amber-700">
                      +{formatCurrency(Number(c.extraTotal))}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </FormSection>

        {/* SECTION 3: Event Type */}
        <FormSection title="Event Type" number={3}>
          <div className="space-y-1.5">
            <Label>Event Type *</Label>
            <Select value={eventType} onValueChange={setEventType}>
              <SelectTrigger data-ocid="edit_invoice.event_type_select">
                <SelectValue placeholder="Select event type…" />
              </SelectTrigger>
              <SelectContent>
                {EVENT_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </FormSection>

        {/* SECTION 4: Wedding Programs */}
        {eventType === EventType.WEDDING && (
          <FormSection title="Wedding Programs" number={4}>
            <div className="space-y-2">
              {weddingPrograms.map((prog, i) => (
                <div
                  key={prog.id}
                  className={`border rounded-lg bg-background overflow-hidden transition-colors ${
                    prog.enabled ? "border-primary/30" : "border-border"
                  }`}
                >
                  <label className="flex items-center gap-3 px-4 py-3 cursor-pointer">
                    <input
                      type="checkbox"
                      className="w-4 h-4 accent-primary rounded"
                      checked={prog.enabled}
                      onChange={(e) =>
                        updateWeddingProgram(i, "enabled", e.target.checked)
                      }
                    />
                    <span className="font-medium text-sm flex-1">
                      {prog.name}
                    </span>
                    {prog.enabled && prog.date && (
                      <Badge variant="secondary" className="text-[10px] h-5">
                        {prog.date}
                      </Badge>
                    )}
                  </label>
                  {prog.enabled && (
                    <div className="px-4 pb-4 grid grid-cols-1 sm:grid-cols-2 gap-3 border-t border-border pt-3">
                      <div className="space-y-1.5">
                        <Label>Date</Label>
                        <Input
                          type="date"
                          value={prog.date ?? ""}
                          onChange={(e) =>
                            updateWeddingProgram(i, "date", e.target.value)
                          }
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label>Start Time</Label>
                        <Input
                          type="time"
                          value={prog.startTime ?? ""}
                          onChange={(e) =>
                            updateWeddingProgram(i, "startTime", e.target.value)
                          }
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label>End Time</Label>
                        <Input
                          type="time"
                          value={prog.endTime ?? ""}
                          onChange={(e) =>
                            updateWeddingProgram(i, "endTime", e.target.value)
                          }
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label>Location</Label>
                        <Input
                          value={prog.location ?? ""}
                          onChange={(e) =>
                            updateWeddingProgram(i, "location", e.target.value)
                          }
                        />
                      </div>
                      <div className="sm:col-span-2 space-y-1.5">
                        <Label>Notes</Label>
                        <Textarea
                          value={prog.notes ?? ""}
                          onChange={(e) =>
                            updateWeddingProgram(i, "notes", e.target.value)
                          }
                          rows={2}
                        />
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </FormSection>
        )}

        {/* SECTION 5: Custom Programs */}
        <FormSection
          title="Custom Programs"
          number={eventType === EventType.WEDDING ? 9 : 8}
        >
          <div className="space-y-3">
            {customPrograms.map((prog, i) => (
              <div
                key={prog._k}
                className="border border-border rounded-lg p-4 space-y-3 bg-background"
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium text-sm">Program {i + 1}</span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-destructive"
                    onClick={() => removeCustomProgram(i)}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Program Name</Label>
                    <Input
                      value={prog.name}
                      onChange={(e) =>
                        updateCustomProgram(i, "name", e.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Date</Label>
                    <Input
                      type="date"
                      value={prog.date}
                      onChange={(e) =>
                        updateCustomProgram(i, "date", e.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Time</Label>
                    <Input
                      type="time"
                      value={prog.time}
                      onChange={(e) =>
                        updateCustomProgram(i, "time", e.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Notes</Label>
                    <Input
                      value={prog.notes}
                      onChange={(e) =>
                        updateCustomProgram(i, "notes", e.target.value)
                      }
                    />
                  </div>
                </div>
              </div>
            ))}
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="gap-2"
              data-ocid="edit_invoice.add_program_button"
              onClick={addCustomProgram}
            >
              <Plus className="w-4 h-4" /> Add Program
            </Button>
          </div>
        </FormSection>

        {/* SECTION 6: Services */}
        <FormSection
          title="Services"
          number={eventType === EventType.WEDDING ? 5 : 4}
        >
          <div className="space-y-3">
            {serviceRows.map((row, i) => (
              <div
                key={row.serviceId}
                className={`border rounded-lg p-4 transition-colors ${row.enabled ? "border-primary/30 bg-primary/5" : "border-border bg-background"}`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <Switch
                      checked={row.enabled}
                      onCheckedChange={(v) => updateServiceRow(i, "enabled", v)}
                    />
                    <div>
                      <p className="font-medium text-sm">{row.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">
                        {row.category}
                      </p>
                    </div>
                  </div>
                  {row.enabled && (
                    <span className="font-bold text-primary">
                      {formatCurrency(row.total)}
                    </span>
                  )}
                </div>
                {row.enabled && (
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <Label className="text-xs">Qty</Label>
                      <Input
                        type="number"
                        min="1"
                        value={row.quantity}
                        onChange={(e) =>
                          updateServiceRow(
                            i,
                            "quantity",
                            Number(e.target.value),
                          )
                        }
                        className="h-8 text-sm"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Unit Price (₹)</Label>
                      <Input
                        type="number"
                        min="0"
                        value={row.unitPrice}
                        onChange={(e) =>
                          updateServiceRow(
                            i,
                            "unitPrice",
                            Number(e.target.value),
                          )
                        }
                        className="h-8 text-sm"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Total</Label>
                      <Input
                        value={formatCurrency(row.total)}
                        readOnly
                        className="h-8 text-sm bg-muted"
                      />
                    </div>
                  </div>
                )}
              </div>
            ))}
            {customServices.map((svc, i) => (
              <div
                key={(svc as InvoiceService & { _k: number })._k}
                className="border border-dashed border-border rounded-lg p-4 space-y-3 bg-background"
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-muted-foreground">
                    Custom Service
                  </span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-destructive"
                    onClick={() => removeCustomService(i)}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="sm:col-span-2 space-y-1">
                    <Label className="text-xs">Service Name</Label>
                    <Input
                      value={svc.name}
                      onChange={(e) =>
                        updateCustomService(i, "name", e.target.value)
                      }
                      className="h-8 text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Qty</Label>
                    <Input
                      type="number"
                      min="1"
                      value={svc.quantity}
                      onChange={(e) =>
                        updateCustomService(
                          i,
                          "quantity",
                          Number(e.target.value),
                        )
                      }
                      className="h-8 text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Unit Price (₹)</Label>
                    <Input
                      type="number"
                      min="0"
                      value={svc.unitPrice}
                      onChange={(e) =>
                        updateCustomService(
                          i,
                          "unitPrice",
                          Number(e.target.value),
                        )
                      }
                      className="h-8 text-sm"
                    />
                  </div>
                </div>
              </div>
            ))}
            <div className="flex items-center justify-between pt-2 border-t border-border">
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="gap-2"
                data-ocid="edit_invoice.add_custom_service_button"
                onClick={addCustomService}
              >
                <Plus className="w-4 h-4" /> Add Custom Service
              </Button>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Services Total</p>
                <p className="font-bold text-foreground">
                  {formatCurrency(servicesTotal)}
                </p>
              </div>
            </div>
          </div>
        </FormSection>

        {/* SECTION 7: Team */}
        <FormSection
          title="Team Assignment"
          number={eventType === EventType.WEDDING ? 6 : 5}
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {teamMembers.map((member) => (
              <label
                key={member.id}
                className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                  selectedTeam.includes(member.id)
                    ? "border-primary/40 bg-primary/5"
                    : "border-border bg-background hover:bg-muted/30"
                }`}
              >
                <input
                  type="checkbox"
                  checked={selectedTeam.includes(member.id)}
                  onChange={() => toggleTeam(member.id)}
                  className="accent-primary"
                />
                <div className="min-w-0">
                  <p className="font-medium text-sm truncate">{member.name}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-xs text-muted-foreground">
                      {member.role}
                    </span>
                    <Badge
                      variant="outline"
                      className="text-[10px] h-4 px-1.5 border-green-300 text-green-600"
                    >
                      Available
                    </Badge>
                  </div>
                </div>
              </label>
            ))}
          </div>
        </FormSection>

        {/* SECTION 8: Payment */}
        <FormSection
          title="Payment Summary"
          number={eventType === EventType.WEDDING ? 8 : 7}
        >
          <div className="space-y-4">
            {gstPct > 0 && (
              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <div>
                  <p className="font-medium text-sm">Apply GST ({gstPct}%)</p>
                  <p className="text-xs text-muted-foreground">
                    Toggle GST on this invoice
                  </p>
                </div>
                <Switch
                  checked={gstEnabled}
                  onCheckedChange={setGstEnabled}
                  data-ocid="edit_invoice.gst_toggle"
                />
              </div>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Total Deal Amount (₹) *</Label>
                <Input
                  type="number"
                  min="0"
                  data-ocid="edit_invoice.deal_amount_input"
                  value={dealAmount || ""}
                  onChange={(e) => setDealAmount(safeNumber(e.target.value))}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Discount (₹)</Label>
                <Input
                  type="number"
                  min="0"
                  data-ocid="edit_invoice.discount_input"
                  value={discount || ""}
                  onChange={(e) => setDiscount(safeNumber(e.target.value))}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Advance Received (₹)</Label>
                <Input
                  type="number"
                  min="0"
                  data-ocid="edit_invoice.advance_input"
                  value={advancePaid || ""}
                  onChange={(e) => setAdvancePaid(safeNumber(e.target.value))}
                />
                {grandTotal > 0 && (
                  <p className="text-xs text-amber-600">
                    Min. advance: <strong>{formatCurrency(minAdvance)}</strong>
                  </p>
                )}
              </div>
              <div className="space-y-1.5">
                <Label>Payment Notes</Label>
                <Input
                  data-ocid="edit_invoice.payment_notes_input"
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                />
              </div>
            </div>
            <div className="bg-muted/40 rounded-lg p-4 space-y-2">
              <SummaryRow
                label="Deal Amount"
                value={formatCurrency(dealAmount)}
              />
              {discount > 0 && (
                <SummaryRow
                  label="Discount"
                  value={`-${formatCurrency(discount)}`}
                  className="text-green-600"
                />
              )}
              {extraChargesTotal > 0 && (
                <SummaryRow
                  label="Package Extra Charges"
                  value={`+${formatCurrency(extraChargesTotal)}`}
                  className="text-amber-600"
                />
              )}
              <SummaryRow label="Subtotal" value={formatCurrency(subtotal)} />
              {gstEnabled && gstPct > 0 && (
                <SummaryRow
                  label={`GST (${gstPct}%)`}
                  value={formatCurrency(gstAmount)}
                />
              )}
              <div className="border-t border-border pt-2">
                <SummaryRow
                  label="Grand Total"
                  value={formatCurrency(grandTotal)}
                  className="font-bold text-foreground text-base"
                />
              </div>
              <SummaryRow
                label="Advance Paid"
                value={formatCurrency(advancePaid)}
                className="text-green-600"
              />
              <SummaryRow
                label="Balance Due"
                value={formatCurrency(balance)}
                className={
                  balance > 0
                    ? "font-bold text-destructive text-base"
                    : "font-bold text-green-600 text-base"
                }
              />
            </div>
            {installments.length > 0 && (
              <div className="border border-border rounded-lg overflow-hidden">
                <div className="bg-muted/40 px-4 py-2 border-b border-border">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Payment Schedule
                  </p>
                </div>
                <div className="divide-y divide-border">
                  {installments.map((inst, i) => (
                    <div
                      key={`${inst.date}-${i}`}
                      className="flex items-center justify-between px-4 py-3"
                      data-ocid={`edit_invoice.installment.${i + 1}`}
                    >
                      <div>
                        <p className="font-medium text-sm">{inst.label}</p>
                        <p className="text-xs text-muted-foreground">
                          Due: {inst.date}
                        </p>
                      </div>
                      <div className="text-right flex items-center gap-2">
                        <span className="font-bold text-foreground">
                          {formatCurrency(inst.amount)}
                        </span>
                        {inst.isPaid ? (
                          <Badge
                            variant="outline"
                            className="text-[10px] border-green-300 text-green-600"
                          >
                            Paid
                          </Badge>
                        ) : (
                          <Badge
                            variant="outline"
                            className="text-[10px] border-yellow-300 text-yellow-600"
                          >
                            Pending
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </FormSection>

        {/* SECTION 9: Terms */}
        <FormSection
          title="Terms & Conditions"
          number={eventType === EventType.WEDDING ? 9 : 8}
        >
          <div className="space-y-1.5">
            <Label>Terms & Conditions</Label>
            <Textarea
              data-ocid="edit_invoice.terms_textarea"
              value={terms}
              onChange={(e) => setTerms(e.target.value)}
              rows={6}
            />
          </div>
        </FormSection>

        <Button
          type="button"
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-12 text-base font-semibold"
          data-ocid="edit_invoice.submit_button"
          disabled={isSaving}
          onClick={handleSubmit}
        >
          {isSaving ? "Updating…" : "Update Invoice"}
        </Button>
      </div>
    </AppLayout>
  );
}

function FormSection({
  title,
  number,
  children,
}: { title: string; number: number; children: React.ReactNode }) {
  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="bg-muted/30 border-b border-border px-5 py-3 flex items-center gap-3">
        <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center shrink-0">
          {number}
        </div>
        <h3 className="font-display font-semibold text-foreground">{title}</h3>
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

function SummaryRow({
  label,
  value,
  className = "",
}: { label: string; value: string; className?: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className={className || "text-foreground"}>{value}</span>
    </div>
  );
}
