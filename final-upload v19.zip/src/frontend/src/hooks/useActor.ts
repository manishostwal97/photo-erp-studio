import { ExternalBlob } from "@caffeineai/object-storage";
import { useMemo } from "react";
import { createActor } from "../backend";
import { useInternetIdentity } from "./useInternetIdentity";

const CANISTER_ID = (import.meta.env.CANISTER_ID_BACKEND as string) ?? "";

export function useActor() {
  const { identity } = useInternetIdentity();

  const actor = useMemo(() => {
    if (!identity || !CANISTER_ID) return null;
    return createActor(
      CANISTER_ID,
      async (file: ExternalBlob) => {
        return file.getBytes();
      },
      async (bytes: Uint8Array) => {
        return ExternalBlob.fromBytes(bytes as Uint8Array<ArrayBuffer>);
      },
      {
        agentOptions: { identity },
      },
    );
  }, [identity]);

  return { actor, isFetching: false };
}
