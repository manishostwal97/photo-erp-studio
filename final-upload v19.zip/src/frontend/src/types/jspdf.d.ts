declare module "jspdf" {
  export class jsPDF {
    constructor(
      orientation?: string,
      unit?: string,
      format?: string | number[],
      compress?: boolean,
    );
    setFontSize(size: number): this;
    setFont(fontName: string, fontStyle?: string): this;
    setTextColor(r: number, g?: number, b?: number): this;
    setFillColor(r: number, g?: number, b?: number): this;
    text(
      text: string | string[],
      x: number,
      y: number,
      options?: { align?: string; maxWidth?: number },
    ): this;
    line(x1: number, y1: number, x2: number, y2: number): this;
    rect(x: number, y: number, w: number, h: number, style?: string): this;
    roundedRect(
      x: number,
      y: number,
      w: number,
      h: number,
      rx: number,
      ry: number,
      style?: string,
    ): this;
    addPage(): this;
    save(filename: string): void;
    output(type: "blob"): Blob;
    output(type: string): string | ArrayBuffer;
    internal: {
      pageSize: {
        width: number;
        height: number;
        getWidth(): number;
        getHeight(): number;
      };
    };
    getTextWidth(text: string): number;
    addImage(
      imageData: string,
      format: string,
      x: number,
      y: number,
      width: number,
      height: number,
    ): this;
    setDrawColor(r: number, g?: number, b?: number): this;
    setLineWidth(width: number): void;
    splitTextToSize(text: string, maxWidth: number): string[];
    getNumberOfPages(): number;
    setPage(page: number): this;
  }
  export default jsPDF;
}
