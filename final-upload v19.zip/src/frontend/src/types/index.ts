// Self-contained types — no @/backend dependency

// ─── Enums ───────────────────────────────────────────────────────────────────

export enum DeliveryStage {
  RAW_BACKUP = "RAW_BACKUP",
  SELECTION_PENDING = "SELECTION_PENDING",
  EDITING = "EDITING",
  ALBUM_DESIGNING = "ALBUM_DESIGNING",
  PRINTING = "PRINTING",
  READY = "READY",
  DELIVERED = "DELIVERED",
}

export enum EventType {
  WEDDING = "Wedding",
  MUNDAN_CEREMONY = "Mundan Ceremony",
  MATERNITY_SHOOT = "Maternity Shoot",
  NEWBORN_SHOOT = "Newborn Shoot",
  MODEL_PORTFOLIO = "Model Portfolio",
  PERSONAL_BRANDING = "Personal Branding",
  BIRTHDAY_PARTY = "Birthday Party",
  ANNIVERSARY = "Anniversary",
  BABY_SHOWER = "Baby Shower",
  HOUSEWARMING = "Housewarming",
  CORPORATE_EVENT = "Corporate Event",
  PRODUCT_LAUNCH = "Product Launch",
  AWARD_CEREMONY = "Award Ceremony",
  OFFICE_EVENT = "Office Event",
  FOOD_SHOOT = "Food Shoot",
  ECOMMERCE_SHOOT = "Ecommerce Shoot",
  REAL_ESTATE_SHOOT = "Real Estate Shoot",
  FASHION_SHOOT = "Fashion Shoot",
  CONCERT = "Concert",
  SPORTS_EVENT = "Sports Event",
  PET_PHOTOGRAPHY = "Pet Photography",
  ART_WORKSHOP = "Art Workshop",
  TRAVEL_PROJECT = "Travel Project",
  CUSTOM_EVENT = "Custom Event",
}

export type AppRole = "admin" | "editor" | "staff";
export type PaymentStatus = "paid" | "partial" | "pending" | "overdue";
export type ServiceCategory =
  | "Cinematic"
  | "Traditional"
  | "Drone"
  | "Album"
  | "Editing"
  | "Custom";
export type PaymentMode =
  | "cash"
  | "upi"
  | "bank_transfer"
  | "cheque"
  | "card"
  | "other";

// ─── Core Entities ────────────────────────────────────────────────────────────

export interface Client {
  id: string;
  name: string;
  phone: string;
  whatsapp?: string;
  email?: string;
  address?: string;
  city?: string;
  eventVenueName?: string;
  eventVenueAddress?: string;
  notes?: string;
  photo?: string;
  createdAt: string;
}

export interface Service {
  id: string;
  name: string;
  category: ServiceCategory;
  price: number;
  description?: string;
  isCustom?: boolean;
}

export interface PackageExtraChargeRule {
  serviceId?: string;
  serviceName: string;
  includedLimit: number;
  unit: string;
  extraChargePerUnit: number;
}

export interface PackageIncludedLimit {
  albumSheets?: number;
  videoHours?: number;
  eventDays?: number;
  [key: string]: number | undefined;
}

export interface Package {
  id: string;
  name: string;
  basePrice: number;
  totalDays?: number;
  services: Service[];
  includedLimits?: PackageIncludedLimit;
  extraChargeRules?: PackageExtraChargeRule[];
  isActive: boolean;
  createdAt?: string;
}

export interface PaymentHistoryEntry {
  id: string;
  amount: number;
  date: string;
  mode: PaymentMode;
  notes?: string;
  createdAt: string;
  editHistory?: Array<{ amount: number; date: string; editedAt: string }>;
}

export interface TeamAssignment {
  /** Unique assignment ID — generated on create */
  id?: string;
  teamMemberId: string;
  teamMemberName: string;
  role?: string;
  program?: string;
  /** Single date (ISO) — used when dateRangeStart is absent */
  date?: string;
  /** Multi-day range start (ISO) */
  dateRangeStart?: string;
  /** Multi-day range end (ISO) */
  dateRangeEnd?: string;
  startTime?: string;
  endTime?: string;
  location?: string;
  notes?: string;
  /** Linked invoice ID */
  invoiceId?: string;
  clientName?: string;
  /** 'full' = full day, 'half' = half day (50% rate) */
  dayType?: "full" | "half";
  /** Calculated rate for this assignment (with/without camera × day type) */
  rateUsed?: number;
  /** Amount paid to team member for this assignment */
  paymentReceived?: number;
  /** Pending = rateUsed - paymentReceived */
  paymentPending?: number;
  /**
   * Multi-date entries — each item is one work day with its own program and dayType.
   * When present, these override single `date` / `dateRangeStart` / `dateRangeEnd`.
   */
  dateEntries?: AssignmentDateEntry[];
  createdAt?: number;
  updatedAt?: number;
}

export interface AssignmentDateEntry {
  /** ISO date string, e.g. '2024-04-18' */
  date: string;
  /** e.g. 'Haldi', 'Wedding', 'Reception' */
  program: string;
  /** full = full day, half = half day (50% rate) */
  dayType: "full" | "half";
  startTime?: string;
  endTime?: string;
  location?: string;
  source?: "invoice" | "custom";
  withCamera?: boolean;
  isFullDay?: boolean;
}

export interface WorkHistoryEntry {
  invoiceId: string;
  clientName: string;
  eventName: string;
  program?: string;
  date?: string;
  startTime?: string;
  endTime?: string;
  location?: string;
  role?: string;
  dayType?: "full" | "half";
  withCamera?: boolean;
  rateUsed?: number;
  paymentReceived?: number;
  paymentPending?: number;
  recordedAt: string;
  /** Links this history entry to the TeamAssignment that created it */
  assignmentId?: string;
}

export interface InvoiceService {
  serviceId?: string;
  name: string;
  category?: string;
  quantity: number;
  unitPrice: number;
  total: number;
  notes?: string;
}

export interface PackageExtraCharge {
  ruleName: string;
  actualQuantity: number;
  includedQuantity: number;
  extraQuantity: number;
  extraChargePerUnit: number;
  extraTotal: number;
}

export interface PaymentSchedule {
  invoiceId: string;
  advance: number;
  advanceDue: string;
  secondInstallment: number;
  secondDue: string;
  thirdInstallment: number;
  thirdDue: string;
}

export interface WeddingProgram {
  id: string;
  name: string;
  enabled: boolean;
  date?: string;
  startTime?: string;
  endTime?: string;
  location?: string;
  notes?: string;
  teamAssignments?: TeamAssignment[];
}

export interface Invoice {
  id: string;
  /** YYMMXX format, e.g. 260501 */
  invoiceNumber: string;
  clientId?: string;
  clientName: string;
  clientPhone: string;
  clientWhatsapp?: string;
  clientEmail?: string;
  clientAddress?: string;
  clientCity?: string;
  eventVenueName?: string;
  eventVenueAddress?: string;
  eventType: string;
  customEventName?: string;
  eventStartDate: string;
  eventEndDate?: string;
  programs?: WeddingProgram[];
  services: InvoiceService[];
  packageId?: string;
  packageName?: string;
  packageBasePrice?: number;
  packageExtraCharges?: PackageExtraCharge[];
  /** Deal/base amount before extras */
  dealAmount: number;
  subtotal: number;
  gstEnabled?: boolean;
  gstPercent?: number;
  gstAmount?: number;
  discount?: number;
  totalAmount: number;
  advancePaid: number;
  pendingAmount: number;
  status: PaymentStatus;
  paymentHistory: PaymentHistoryEntry[];
  paymentSchedule?: PaymentSchedule;
  teamAssignments?: TeamAssignment[];
  notes?: string;
  termsAndConditions?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  phone: string;
  email?: string;
  perDayRateWithCamera: number;
  perDayRateWithoutCamera: number;
  cameraName?: string;
  equipmentDetails?: string;
  skills?: string[];
  notes?: string;
  photo?: string;
  joinedAt: string;
  assignments?: TeamAssignment[];
  workHistory?: WorkHistoryEntry[];
}

export interface Expense {
  id: string;
  date: string;
  vendor: string;
  category: string;
  amount: number;
  paymentMode: PaymentMode;
  notes?: string;
  clientId?: string;
  invoiceId?: string;
  /** Linked team member ID */
  teamMemberId?: string;
  /** Event name pulled from linked invoice */
  eventName?: string;
  createdAt: string;
}

export interface DeliveryStageEntry {
  stage: DeliveryStage | string;
  timestamp: string;
  notes?: string;
  updatedBy?: string;
}

export interface DeliveryTracker {
  id: string;
  invoiceId: string;
  clientName: string;
  eventName: string;
  currentStage: DeliveryStage | string;
  stageHistory: DeliveryStageEntry[];
  assignedEditor?: string;
  dueDate?: string;
  createdAt: string;
}

export interface StudioProfile {
  name: string;
  ownerName: string;
  phone: string;
  email?: string;
  gstNumber?: string;
  gstEnabled: boolean;
  gstPercent?: number;
  upiId?: string;
  address?: string;
  city?: string;
  logo?: string;
  signature?: string;
  whatsappTemplates: WhatsAppTemplates;
}

export interface WhatsAppTemplates {
  eventReminder?: string;
  advanceReminder?: string;
  balanceReminder?: string;
  paymentReceived?: string;
  deliveryReady?: string;
  finalThankYou?: string;
  teamReminder?: string;
}

export interface CustomProgramTemplate {
  id: string;
  name: string;
  isDefault?: boolean;
}

export interface CustomEventTemplate {
  id: string;
  name: string;
  fields?: Record<string, unknown>;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  createdAt: string;
  invoiceId?: string;
  clientId?: string;
}

export interface AppUser {
  email: string;
  role: AppRole;
  name?: string;
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

export interface DashboardStats {
  totalRevenue: number;
  pendingPayments: number;
  monthlyProfit: number;
  upcomingEvents: number;
  totalClients: number;
  activeInvoices: number;
}

// ─── Payment Ledger ───────────────────────────────────────────────────────────

export interface PaymentLedgerEntry {
  id: string;
  date: string;
  amount: number;
  mode: PaymentMode;
  note?: string;
  linkedInvoiceId?: string;
  linkedClientId: string;
  balanceAfterPayment: number;
  createdAt: string;
}

export interface ClientPaymentLedger {
  clientId: string;
  totalPaid: number;
  totalDue: number;
  runningBalance: number;
  entries: PaymentLedgerEntry[];
}

// ─── Equipment Rental ─────────────────────────────────────────────────────────

export interface RentalEntry {
  id: string;
  clientId: string;
  invoiceId?: string;
  equipmentType: "camera" | "lens" | "drone" | "light" | "other";
  vendor: string;
  rentAmount: number;
  paidAmount: number;
  dueAmount: number;
  startDate: string;
  endDate?: string;
  status: "active" | "returned";
  notes?: string;
  createdAt: string;
}
