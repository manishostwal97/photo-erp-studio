/**
 * PDF Export Utility
 * Dynamically loads html2canvas + jsPDF from CDN and exports
 * a given DOM element to a downloadable PDF file.
 *
 * Falls back to window.print() if CDN libraries fail to load.
 */

declare global {
  interface Window {
    html2canvas?: (
      element: HTMLElement,
      options?: Record<string, unknown>,
    ) => Promise<HTMLCanvasElement>;
    jspdf?: {
      jsPDF: new (
        orientation: string,
        unit: string,
        format: string | number[],
      ) => JsPDFInstance;
    };
  }
}

interface JsPDFInstance {
  addImage(
    data: string,
    format: string,
    x: number,
    y: number,
    width: number,
    height: number,
  ): void;
  addPage(): void;
  save(filename: string): void;
  internal: {
    pageSize: { getWidth(): number; getHeight(): number };
  };
}

function loadScript(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) {
      resolve();
      return;
    }
    const script = document.createElement("script");
    script.src = src;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`Failed to load ${src}`));
    document.head.appendChild(script);
  });
}

async function ensureLibraries(): Promise<void> {
  await Promise.all([
    loadScript(
      "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js",
    ),
    loadScript(
      "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js",
    ),
  ]);
}

export interface PdfExportOptions {
  /** Filename without extension */
  filename: string;
  /** A4 orientation: 'portrait' | 'landscape'. Defaults to 'portrait'. */
  orientation?: "portrait" | "landscape";
  /** Scale factor for html2canvas. Defaults to 2. */
  scale?: number;
}

/**
 * Export a DOM element to a PDF file.
 */
export async function exportElementToPdf(
  element: HTMLElement,
  options: PdfExportOptions,
): Promise<void> {
  const { filename, orientation = "portrait", scale = 2 } = options;

  try {
    await ensureLibraries();

    if (!window.html2canvas || !window.jspdf) {
      throw new Error("Libraries not available");
    }

    const canvas = await window.html2canvas(element, {
      scale,
      useCORS: true,
      logging: false,
      backgroundColor: "#ffffff",
    });

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF(orientation, "mm", "a4");

    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    if (imgHeight <= pageHeight) {
      pdf.addImage(
        canvas.toDataURL("image/jpeg", 0.95),
        "JPEG",
        0,
        0,
        imgWidth,
        imgHeight,
      );
    } else {
      // Multi-page: slice canvas into page-height chunks
      const pagesCount = Math.ceil(imgHeight / pageHeight);
      const pixelsPerPage = Math.floor(canvas.height / pagesCount);

      for (let i = 0; i < pagesCount; i++) {
        if (i > 0) pdf.addPage();
        const sourceY = i * pixelsPerPage;
        const sliceH = Math.min(pixelsPerPage, canvas.height - sourceY);
        const sliceCanvas = document.createElement("canvas");
        sliceCanvas.width = canvas.width;
        sliceCanvas.height = sliceH;
        const ctx = sliceCanvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(
            canvas,
            0,
            sourceY,
            canvas.width,
            sliceH,
            0,
            0,
            canvas.width,
            sliceH,
          );
        }
        const sliceImgH = (sliceH / canvas.height) * imgHeight;
        pdf.addImage(
          sliceCanvas.toDataURL("image/jpeg", 0.95),
          "JPEG",
          0,
          0,
          pageWidth,
          sliceImgH,
        );
      }
    }

    pdf.save(`${filename}.pdf`);
  } catch (_err) {
    window.print();
  }
}

/**
 * Export multiple DOM elements as separate pages in one PDF.
 */
export async function exportElementsToPdf(
  elements: HTMLElement[],
  options: PdfExportOptions,
): Promise<void> {
  if (elements.length === 0) return;
  if (elements.length === 1) return exportElementToPdf(elements[0], options);

  const { filename, orientation = "portrait", scale = 2 } = options;

  try {
    await ensureLibraries();

    if (!window.html2canvas || !window.jspdf) {
      throw new Error("Libraries not available");
    }

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF(orientation, "mm", "a4");
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();

    for (let i = 0; i < elements.length; i++) {
      if (i > 0) pdf.addPage();
      const canvas = await window.html2canvas(elements[i], {
        scale,
        useCORS: true,
        logging: false,
        backgroundColor: "#ffffff",
      });
      const imgWidth = pageWidth;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      if (imgHeight <= pageHeight) {
        pdf.addImage(
          canvas.toDataURL("image/jpeg", 0.95),
          "JPEG",
          0,
          0,
          imgWidth,
          imgHeight,
        );
      } else {
        const pagesCount = Math.ceil(imgHeight / pageHeight);
        const pixelsPerPage = Math.floor(canvas.height / pagesCount);
        for (let p = 0; p < pagesCount; p++) {
          if (p > 0) pdf.addPage();
          const sourceY = p * pixelsPerPage;
          const sliceH = Math.min(pixelsPerPage, canvas.height - sourceY);
          const sliceCanvas = document.createElement("canvas");
          sliceCanvas.width = canvas.width;
          sliceCanvas.height = sliceH;
          const ctx = sliceCanvas.getContext("2d");
          if (ctx) {
            ctx.drawImage(
              canvas,
              0,
              sourceY,
              canvas.width,
              sliceH,
              0,
              0,
              canvas.width,
              sliceH,
            );
          }
          const sliceImgH = (sliceH / canvas.height) * imgHeight;
          pdf.addImage(
            sliceCanvas.toDataURL("image/jpeg", 0.95),
            "JPEG",
            0,
            0,
            pageWidth,
            sliceImgH,
          );
        }
      }
    }

    pdf.save(`${filename}.pdf`);
  } catch (_err) {
    window.print();
  }
}
